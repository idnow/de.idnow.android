package de.idnow.sdk.Activities.callbacks;

public interface StartCallback {
    void onSuccess();
}
