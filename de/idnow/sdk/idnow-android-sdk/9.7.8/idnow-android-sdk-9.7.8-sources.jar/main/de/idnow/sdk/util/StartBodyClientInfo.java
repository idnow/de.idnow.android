package de.idnow.sdk.util;

public class StartBodyClientInfo {

    @Override
    public String toString() {
        return "StartBodyClientInfo{" +
                "language='" + language + '\'' +
                ", locale='" + locale + '\'' +
                ", screenWidth='" + screenWidth + '\'' +
                ", screenHeight='" + screenHeight + '\'' +
                ", clientVersion='" + clientVersion + '\'' +
                ", frontCameraWidth='" + frontCameraWidth + '\'' +
                ", frontCameraHeight='" + frontCameraHeight + '\'' +
                ", backCameraWidth='" + backCameraWidth + '\'' +
                ", backCameraHeight='" + backCameraHeight + '\'' +
                ", flashLight=" + flashLight +
                ", connectionType='" + connectionType + '\'' +
                ", osVersion='" + osVersion + '\'' +
                ", deviceInfo='" + deviceInfo + '\'' +
                '}';
    }

    String language;
    String locale;
    String screenWidth;
    String screenHeight;
    String clientVersion;
    String frontCameraWidth;
    String frontCameraHeight;
    String backCameraWidth;
    String backCameraHeight;
    boolean flashLight;
    String connectionType;
    String osVersion;

    public StartBodyClientInfo(String language, String locale, String screenWidth, String screenHeight,
                               String clientVersion, String frontCameraWidth, String frontCameraHeight,
                               String backCameraWidth, String backCameraHeight, boolean flashLight, String connectionType, String osVersion, String deviceInfo) {
        this.language = language;
        this.locale = locale;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.clientVersion = clientVersion;
        this.frontCameraWidth = frontCameraWidth;
        this.frontCameraHeight = frontCameraHeight;
        this.backCameraWidth = backCameraWidth;
        this.backCameraHeight = backCameraHeight;
        this.flashLight = flashLight;
        this.connectionType = connectionType;
        this.osVersion = osVersion;
        this.deviceInfo = deviceInfo;
    }

    String deviceInfo;

}
