package de.idnow.sdk.models;



/**
 * @author Mathias Grasy
 * @date 16.10.2014
 * @brief (short description)
 */


public class Models_eSignature
{
	boolean allowupload;
	public boolean handwritten;

	public Models_eSignature( boolean handwritten, boolean allowupload )
	{
		this.handwritten = handwritten;
		this.allowupload = allowupload;
	}

	public boolean isHandwritten()
	{
		return handwritten;
	}

	public void setHandwritten( boolean handwritten )
	{
		this.handwritten = handwritten;
	}

	public boolean isAllowupload()
	{
		return allowupload;
	}

	public void setAllowupload( boolean allowupload )
	{
		this.allowupload = allowupload;
	}
}
