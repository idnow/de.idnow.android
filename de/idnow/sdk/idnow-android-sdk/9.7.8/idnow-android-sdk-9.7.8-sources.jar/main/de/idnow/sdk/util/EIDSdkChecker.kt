package de.idnow.sdk.util

/**
 * Simple helper class to determine if eID SDK is present
 */
object EIDSdkChecker {

    val isEidSdkAvailable: Boolean by lazy {
        try {
            Class.forName("de.idnow.android.eid.eIDSdk")
            true
        } catch (e: ClassNotFoundException) {
            false
        } catch (e: NoClassDefFoundError) {
            false
        } catch (e: LinkageError) {
            false
        }
    }
}