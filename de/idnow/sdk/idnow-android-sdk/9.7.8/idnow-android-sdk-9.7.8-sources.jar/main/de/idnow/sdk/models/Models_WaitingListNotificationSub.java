package de.idnow.sdk.models;

public class Models_WaitingListNotificationSub
{

	String type;
	String appName;
	String subscriptionToken;

	public Models_WaitingListNotificationSub(String type, String appName, String subscriptionToken)
	{
		this.type = type;
		this.appName = appName;
		this.subscriptionToken = subscriptionToken;
	}

	public String getType() {
		return type;
	}

	public String getAppName() {
		return appName;
	}

	public String getSubscriptionToken() {
		return subscriptionToken;
	}
}
