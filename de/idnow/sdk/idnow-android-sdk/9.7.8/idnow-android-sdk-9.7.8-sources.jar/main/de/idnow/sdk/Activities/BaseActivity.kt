package de.idnow.sdk.Activities

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.R
import de.idnow.sdk.util.IDnowErrorCode
import de.idnow.sdk.util.Util_Log
import de.idnow.sdk.util.permissionsManager.AppPermissionsManager
import de.idnow.sdk.util.ui.ViewHelper

abstract class BaseActivity : AppCompatActivity() {
    private val appPermissionsManager: AppPermissionsManager
            by lazy { AppPermissionsManager(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(this.javaClass.simpleName, "onCreate:")
        if (IDnowSDK.getTransactionToken().isEmpty()) {
            val errorIntent = Intent()

            errorIntent.putExtra(IDnowSDK.RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorMissingTransactionToken)
            errorIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, "Transaction token wasn't supplied.")

            setResult(IDnowSDK.RESULT_CODE_FAILED, errorIntent)
            finish()
            return
        }
        appPermissionsManager.init()
        enableEdgeToEdge()
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        findViewById<View>(R.id.main)?.let(ViewHelper::applySafePadding)
            ?: Util_Log.e(
                "IDNOW_${this@BaseActivity::class.simpleName}",
                "Main layout not found"
            )
    }

    override fun onResume() {
        Log.i(this.javaClass.simpleName, "onResume:  ")
        if (IDnowSDK.getTransactionToken().isEmpty()) {
            finish()
        } else {
            super.onResume()
            appPermissionsManager.onResume()
        }
    }

    fun runWithPermissions(onPermissionsGrantedCallback: () -> Unit) =
        appPermissionsManager.request(onPermissionsGrantedCallback)

    fun checkPermissionsGranted(): Boolean =
        appPermissionsManager.checkPermissionsGranted()

    internal fun isDarkUiMode(): Boolean {
        val nightModeFlags = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return nightModeFlags == Configuration.UI_MODE_NIGHT_YES
    }
}