package de.idnow.sdk.models;

public class Model_VideoIdentPlus  {

    boolean idImage;
    boolean segmentationAndClassification;
    boolean documentChecking;
    boolean selfieImage;
    boolean reuseImages;


    public Model_VideoIdentPlus(boolean idImage, boolean segmentationAndClassification, boolean documentChecking, boolean selfieImage, boolean reuseImages) {
        this.idImage = idImage;
        this.segmentationAndClassification = segmentationAndClassification;
        this.documentChecking = documentChecking;
        this.selfieImage = selfieImage;
        this.reuseImages = reuseImages;
    }

    public boolean isIdImage() {
        return idImage;
    }

    public void setIdImage(boolean idImage) {
        this.idImage = idImage;
    }

    public boolean isSegmentationAndClassification() {
        return segmentationAndClassification;
    }

    public void setSegmentationAndClassification(boolean segmentationAndClassification) {
        this.segmentationAndClassification = segmentationAndClassification;
    }

    public boolean isDocumentChecking() {
        return documentChecking;
    }

    public void setDocumentChecking(boolean documentChecking) {
        this.documentChecking = documentChecking;
    }

    public boolean isSelfieImage() {
        return selfieImage;
    }

    public void setSelfieImage(boolean selfieImage) {
        this.selfieImage = selfieImage;
    }


    public boolean isReuseImages() {
        return reuseImages;
    }

    public void setReuseImages(boolean reuseImages) {
        this.reuseImages = reuseImages;
    }
}
