package de.idnow.sdk.models;



/**
 * 
 * @date 10.10.2014
 * @author Mathias Grasy
 * @version 1.0
 * @brief is send to the server, when the user wants confirmation token to be send again to his mobile phone
 */


public class Models_MobileNumber
{

	String	mobile;

	public Models_MobileNumber( String mobile )
	{
		this.mobile = mobile;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile()
	{
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile( String mobile )
	{
		this.mobile = mobile;
	}

}
