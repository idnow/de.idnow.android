package de.idnow.sdk;

import android.annotation.SuppressLint;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.EditText;

import de.idnow.sdk.Activities.BaseActivity;
import de.idnow.sdk.util.Util_Util;

/**
 * @author Mathias Grasy
 * @version 1.0
 */
@SuppressLint("Registered")
public class BaseActivities_BaseFragmentActivity extends BaseActivity
{

	public void setupUI( View view)
	{
		// Set up touch listener for non-text box views to hide keyboard.
		if ( !( view instanceof EditText ) )
		{
			view.setOnTouchListener( new OnTouchListener()
			{
				@Override
				public boolean onTouch( View v, MotionEvent event )
				{
					Util_Util.hideSoftKeyboard( BaseActivities_BaseFragmentActivity.this );

					if ( event.getAction() == MotionEvent.ACTION_UP )
					{
						v.performClick();

						return true;
					}
					else
					{
						// RelativeLayout.LayoutParams params = new LayoutParams( LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT );
						// params.addRule( RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE );
						// bottomLayout.setLayoutParams( params ); // causes layout update
						return false;
					}
				}

			} );
		}

		// If a layout container, iterate over children and seed recursion.
		if ( view instanceof ViewGroup )
		{

			for ( int i = 0; i < ( ( ViewGroup ) view ).getChildCount(); i++ )
			{
				View innerView = ( ( ViewGroup ) view ).getChildAt( i );
				setupUI( innerView);
			}
		}
	}

}
