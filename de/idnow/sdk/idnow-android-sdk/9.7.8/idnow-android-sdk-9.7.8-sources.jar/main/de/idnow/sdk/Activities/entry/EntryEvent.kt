package de.idnow.sdk.Activities.entry

import android.content.Intent
import android.os.Bundle
import de.idnow.sdk.models.Model_CustomLogData
import de.idnow.sdk.models.Models_MobileStoreLinks

sealed interface EntryEvent {
    data object CheckForRuntimePermissions : EntryEvent
    data class ShowNoConnectionDialog(
        val dismissScreen: Boolean
    ) : EntryEvent

    data object ShowCameraAvailableDialog : EntryEvent
    data object ShowNfcDialog : EntryEvent
    data class ShowWalletAccountExpiredDialog(
        val onContinue: () -> Unit
    ) : EntryEvent

    data object InitializeEidSdk : EntryEvent

    data class ShowRESTCallErrorDialog(
        val responseCode: Int,
        val retryAllowed: Boolean,
        val onConfirmAction: () -> Unit,
        val result: String,
        val finishActivityAfterDialog: Boolean,
        val activeVideoCall: Boolean,
        val resultError: String
    ) : EntryEvent

    data class ShowLinkAutoIdent(
        val mobileStoreLinks: Models_MobileStoreLinks,
        val message: String
    ) : EntryEvent

    data class ShowOfficeHoursUnsupportedProductDialog(
        val message: String
    ) : EntryEvent

    data class ShowMessageOKCancelDialog(
        val message: String,
        val onConfirm: () -> Unit
    ) : EntryEvent

    data class ShowEIDDialog(
        val message: String
    ) : EntryEvent

    data class ShowDocumentNotUploadedDialog(
        val message: String
    ) : EntryEvent

    data class NavigateToActivity(
        val classz: Class<*>,
        val extras: Bundle? = null,
        val requestResult: Boolean = false,
        val disableTransitions: Boolean = false
    ) : EntryEvent

    data class NavigateBack(
        val intent: Intent,
        val resultCode: Int
    ) : EntryEvent

    data object ShowCancelVerificationIdentificationDialog : EntryEvent

    data class InitCustomLog(
        val data: Model_CustomLogData
    ) : EntryEvent
}