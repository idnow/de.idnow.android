package de.idnow.sdk.Activities;

import static de.idnow.sdk.util.IDnowExternalLog.logExternally;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager.LayoutParams;
import android.webkit.WebView;
import android.widget.ProgressBar;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.network.IDNowWebViewClient;
import de.idnow.sdk.util.LogEventTypeEnum;
import de.idnow.sdk.util.Util_Log;

public class Activities_LegalNoticesActivity extends BaseActivity {
	private final String LOGTAG = "IDNOW_Activities_LegalNoticesActivity";

	private AsyncTask<Void, Void, String> mLicenseLoader;

	private WebView     mWebView;
	private ProgressBar mIndeterminateProgress;

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );

		setTheme(androidx.appcompat.R.style.Theme_AppCompat_Light_NoActionBar);

		if ( IDnowSDK.preventScreenshot )
		{
			// secures against manual screenshots and automatic screenshots
			getWindow().setFlags( LayoutParams.FLAG_SECURE, LayoutParams.FLAG_SECURE );
		}


		setContentView( R.layout.activity_legal_notices );

		mIndeterminateProgress = findViewById( R.id.licensesFragmentIndeterminateProgress );
		mWebView = findViewById( R.id.licensesFragmentWebView );
		mWebView.getSettings().setAllowUniversalAccessFromFileURLs(false);
		mWebView.setWebViewClient(new IDNowWebViewClient());

		loadLicenses();
	}

	@Override
	public void onDestroy()
	{
		super.onDestroy();
		if ( mLicenseLoader != null )
		{
			mLicenseLoader.cancel( true );
		}
	}

	private void loadLicenses()
	{
		final Context context = this;
		// Load asynchronously in case of a very large file.
		mLicenseLoader = new AsyncTask<Void, Void, String>()
		{


			@Override
			protected String doInBackground( Void... params )
			{
				AssetManager am = context.getAssets();
				InputStream rawResource = null;
				try {
					rawResource = am.open("open_source_licenses.html");
				} catch (IOException e) {
					Util_Log.e(LOGTAG, "Load license asset failed", e);
				}

				if (rawResource != null){
					BufferedReader bufferedReader = new BufferedReader( new InputStreamReader( rawResource ) );

					String line;
					StringBuilder sb = new StringBuilder();

					try
					{
						while ( ( line = bufferedReader.readLine() ) != null )
						{
							sb.append( line );
							sb.append( "\n" );
						}
						bufferedReader.close();
					}
					catch ( IOException e )
					{
						logExternally(context, "Error in Loading Licences : " + e.getMessage(), LogEventTypeEnum.ERROR.get());
						Util_Log.e(LOGTAG, "Error loading licences", e);
					}

					return sb.toString();
				} else {
					return "";
				}

			}

			@Override
			protected void onPostExecute( String licensesBody )
			{
				super.onPostExecute( licensesBody );
				if ( isCancelled() )
				{
					return;
				}

				mIndeterminateProgress.setVisibility( View.INVISIBLE );
				mWebView.setVisibility( View.VISIBLE );
				mWebView.loadDataWithBaseURL( null, licensesBody, "text/html", "utf-8", null );
				mLicenseLoader = null;
			}

		}.execute();
	}

	@Override
	public void onBackPressed()
	{
		setResult( IDnowSDK.RESULT_CODE_INTERNAL );
		finish();
	}
}
