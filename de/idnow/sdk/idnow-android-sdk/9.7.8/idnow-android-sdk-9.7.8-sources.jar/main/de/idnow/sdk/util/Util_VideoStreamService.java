package de.idnow.sdk.util;

import de.idnow.sdk.Activities.Activities_BeforeStartingActivity;
import de.idnow.sdk.Activities.Activities_DeviceSupportActivity;
import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_CallQualityCheck;
import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_LIVESWITCH;
import de.idnow.sdk.Activities.Activities_VideoOverviewCheckActivity;

/**
 * Created by Mathias Grasy on 28.10.2015.
 */
public class Util_VideoStreamService
{
	/**
	 * returns either the tokbox containing liveStream class or the one with the liveswitch implementation
	 */
	public static Class<?> getClassForVideoLiveStreaming()
	{
		return Activities_VideoLiveStreamActivity_LIVESWITCH.class;
	}

	public static Class<?> getClassForCallQualityCheck()
	{
		return Activities_VideoLiveStreamActivity_CallQualityCheck.class;
	}

	public static Class<?> getClassForOverviewCheck()
	{
		return Activities_VideoOverviewCheckActivity.class;
	}

	public static Class<?> getClassForBeforeStartingActivity()
	{
		return Activities_BeforeStartingActivity.class;
	}

	public static Class<?> getClassDeviceSupportActivity()
	{
	   return Activities_DeviceSupportActivity .class;
	}

}
