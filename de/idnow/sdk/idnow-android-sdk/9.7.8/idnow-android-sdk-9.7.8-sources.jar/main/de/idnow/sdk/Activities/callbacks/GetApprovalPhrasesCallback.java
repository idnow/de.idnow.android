package de.idnow.sdk.Activities.callbacks;

import android.text.SpannableString;
import android.text.style.ClickableSpan;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface GetApprovalPhrasesCallback {
    void onAddEntry(SpannableString entry);
    void onUpdateEntries();
    void onNewEntries();
    ClickableSpan onClickLink(String link);

    void implementView();
    void dataToPDF(okhttp3.ResponseBody response) throws FileNotFoundException, IOException;

}
