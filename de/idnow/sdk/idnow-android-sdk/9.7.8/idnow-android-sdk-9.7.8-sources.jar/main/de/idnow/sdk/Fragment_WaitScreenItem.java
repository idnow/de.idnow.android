package de.idnow.sdk;

import android.animation.Animator;
import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_Super;
import de.idnow.sdk.util.Enum_WaitScreens;
import de.idnow.sdk.util.PausableCountDownTimer;

public class Fragment_WaitScreenItem extends Fragment implements PausableCountDownTimer.ITimerStatus {

    private static final String WAITING_SCREEN_PAGE_NO_EXTRA = "WAITING_SCREEN_PAGE_NO_EXTRA";

    private Context context;

    private Enum_WaitScreens currentPage;
    private int currentPageNumber;

    private IWaitScreenCallback callback;

    private LottieAnimationView waitLottieAnimation;
    private ProgressBar waitProgressBar;
    private TextView title;
    private TextView description;

    private View rootView;
    private boolean isPlaying = false;
    private int seekPosition = 0;

    private PausableCountDownTimer progressBarTimer;

    public static Fragment_WaitScreenItem newInstance(int position) {
        Fragment_WaitScreenItem fragment = new Fragment_WaitScreenItem();

        Bundle args = new Bundle();
        args.putInt(WAITING_SCREEN_PAGE_NO_EXTRA, position);

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
        if (context instanceof Activities_VideoLiveStreamActivity_Super) {
            callback = (IWaitScreenCallback) context;
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getExtras();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.view_wait_screen_fragment, container, false);

        initializeViews();
        setupItems();

        return rootView;
    }

    @Override
    public void onTimerFinished() {
        callback.onAnimationCompleted(currentPageNumber);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (progressBarTimer != null) {
            progressBarTimer.resume();
        }
        if (isPlaying) {
           // waitVideoAnimation.seekTo(seekPosition);
           // waitVideoAnimation.start();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (progressBarTimer != null) {
            progressBarTimer.pause();
        }
        if (isPlaying) {

           // seekPosition = waitVideoAnimation.getCurrentPosition();
          //  waitVideoAnimation.pause();


        }
    }

    private void getExtras() {
        if (getArguments() != null) {
            currentPageNumber = getArguments().getInt("WAITING_SCREEN_PAGE_NO_EXTRA");
            currentPage = Enum_WaitScreens.values()[currentPageNumber];
        }
    }

    private void initializeViews() {
        if (rootView != null) {
            description = rootView.findViewById(R.id.wait_fragment_description);
            waitLottieAnimation = rootView.findViewById(R.id.wait_fragment_animation);
            waitProgressBar = rootView.findViewById(R.id.wait_progress_bar);


        }
    }

    private void setupItems() {
        setupDescription();
        setupProgressBar();
        setupLottieAnimation();
    }

    public void setupLottieAnimation() {
        String path = currentPage.getVideoPath(context);
        if (path == null) {
            waitLottieAnimation.setVisibility(View.GONE);
            waitProgressBar.setVisibility(View.VISIBLE);

            progressBarTimer = new PausableCountDownTimer(this);
            progressBarTimer.startTimer(Config.WAITING_SCREEN_FIRST_PAGE_SPINNER_DURATION_IN_MS);
            return;
        }
        waitLottieAnimation.setAnimation(path);
    }

    private void setupDescription() {
        String text = currentPage.getDescription(context);
        text = text == null ? "" : text;
        description.setText(text);
    }

    private void setupProgressBar() {
        Drawable progressBarDrawable = waitProgressBar.getIndeterminateDrawable().mutate();
        progressBarDrawable.setColorFilter(
                context.getResources().getColor(R.color.wait_screen_progressbar_tint_color),
                PorterDuff.Mode.SRC_IN);
        waitProgressBar.setIndeterminateDrawable(progressBarDrawable);
}

   public void playAnimation() {
        isPlaying = true;
        if (waitLottieAnimation.getVisibility() == View.VISIBLE) {
            waitLottieAnimation.playAnimation();
            waitLottieAnimation.addAnimatorListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animation) {

                }

                @Override
                public void onAnimationEnd(Animator animation) {
                    if (callback != null) {
                        isPlaying = false;
                        callback.onAnimationCompleted(currentPageNumber);
                    }
                }

                @Override
                public void onAnimationCancel(Animator animation) {

                }

                @Override
                public void onAnimationRepeat(Animator animation) {

                }
            });
        }
    }

    public void stopAnimation() {
        if (waitLottieAnimation.getVisibility() == View.VISIBLE) {
            waitLottieAnimation.pauseAnimation();
        }
    }
}
