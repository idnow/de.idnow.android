package de.idnow.sdk.models;

/**
 * @author Mathias Grasy
 * @version 1.0
 * @date 10.10.2014
 * @brief is received from the server (/api/v1/{transactionToken} call). list-attribute of OfficeHours object
 */

public class Models_OfficeHour
{

	String hours;
	String days;

	public Models_OfficeHour()
	{

	}

	public Models_OfficeHour( String hours, String days )
	{
		this.days = days;
		this.hours = hours;
	}

	/**
	 * @return the hours
	 */
	public String getHours()
	{
		return hours;
	}

	/**
	 * @param hours the hours to set
	 */
	public void setHours( String hours )
	{
		this.hours = hours;
	}

	/**
	 * @return the days
	 */
	public String getDays()
	{
		return days;
	}

	/**
	 * @param days the days to set
	 */
	public void setDays( String days )
	{
		this.days = days;
	}

}
