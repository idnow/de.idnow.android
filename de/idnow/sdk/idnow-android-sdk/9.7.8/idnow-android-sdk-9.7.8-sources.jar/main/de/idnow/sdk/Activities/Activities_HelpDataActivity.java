package de.idnow.sdk.Activities;

import android.os.Bundle;
import android.view.WindowManager.LayoutParams;
import android.widget.TextView;

import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.util.Util_Strings;

import static de.idnow.sdk.util.Util_Strings.KEY_VIDEOIDENT_HELPDATA_TEXT;
import static de.idnow.sdk.util.Util_Strings.LOCAL_VIDEOIDENT_HELPDATA_TEXT;

/**
 * @author Mathias Grasy
 * @version 1.0
 * @brief activity that displays a help text and gets called by the OverviewCheckActivity
 */
public class Activities_HelpDataActivity extends BaseActivity
{

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );

		setTheme(androidx.appcompat.R.style.Theme_AppCompat_Light_NoActionBar);

		if ( IDnowSDK.preventScreenshot )
		{
			// secures against manual screenshots and automatic screenshots
			getWindow().setFlags( LayoutParams.FLAG_SECURE, LayoutParams.FLAG_SECURE );
		}


		setContentView( R.layout.activity_help_data );

		TextView textView = findViewById(R.id.id_data_text);
		textView.setText(Util_Strings.getStringWithDefault(this, KEY_VIDEOIDENT_HELPDATA_TEXT, LOCAL_VIDEOIDENT_HELPDATA_TEXT));


	}
}
