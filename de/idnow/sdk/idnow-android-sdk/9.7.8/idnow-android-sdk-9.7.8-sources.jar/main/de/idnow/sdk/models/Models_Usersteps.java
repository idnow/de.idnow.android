package de.idnow.sdk.models;


/**
 * Created by Mathias Grasy on 04.02.2016.
 */
public class Models_Usersteps
{

	Models_Signature signature;

	public Models_Usersteps( Models_Signature signature )
	{
		this.signature = signature;
	}

	public Models_Signature getSignature()
	{
		return signature;
	}

	public void setSignature( Models_Signature signature )
	{
		this.signature = signature;
	}
}
