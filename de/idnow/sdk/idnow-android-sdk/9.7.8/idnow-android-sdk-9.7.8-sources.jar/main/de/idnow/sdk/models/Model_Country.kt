package de.idnow.sdk.models

internal data class Model_Country(
    val name: String = "",
    val dial_code: String = "",
    val code: String = ""
)

internal data class Model_Countries(
    val countries: List<Model_Country> = emptyList()
)
