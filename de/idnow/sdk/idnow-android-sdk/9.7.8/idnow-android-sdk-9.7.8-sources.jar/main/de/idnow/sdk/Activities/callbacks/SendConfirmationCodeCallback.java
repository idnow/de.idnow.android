package de.idnow.sdk.Activities.callbacks;

import de.idnow.sdk.network.RetrofitError;

public interface SendConfirmationCodeCallback {
    void init();
    void onSuccess();
    void onFailure(RetrofitError error, String result, String errorCause, int statusCode);
}
