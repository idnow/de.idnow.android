package de.idnow.sdk.util.helper

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalLensFacing
import androidx.camera.lifecycle.ProcessCameraProvider
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.util.Util_Log
import de.idnow.sdk.util.camera.CameraType

internal object CameraHelper {
    private const val LOGTAG = "IDNOW_CameraHelper"

    @SuppressLint("RestrictedApi")
    @OptIn(ExperimentalLensFacing::class)
    fun hasCamera(type: CameraType): Boolean {
        return try {
            val context = IDnowSDK.getInstance().appContext
            val lensFacingRequired =
                if (type == CameraType.FRONT) {
                    listOf(CameraSelector.LENS_FACING_FRONT, CameraSelector.LENS_FACING_EXTERNAL)
                } else {
                    listOf(CameraSelector.LENS_FACING_BACK)
                }

            ProcessCameraProvider.Companion.getInstance(context).get()
                .availableCameraInfos
                .any { it.lensFacing in lensFacingRequired && it.cameraIdentifier != null }
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Check camera availability failed", e)
            false
        }
    }

    fun hasTorch(): Boolean {
        return try {
            val context = IDnowSDK.getInstance().appContext
            ProcessCameraProvider.Companion.getInstance(context).get()
                .availableCameraInfos
                .any { it.hasFlashUnit() }
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Check torch availability failed", e)
            false
        }
    }

    fun checkResolutionSupport(requiredResolution: Long): Boolean {
        return checkResolutionSupport(CameraType.FRONT, requiredResolution) &&
                checkResolutionSupport(CameraType.BACK, requiredResolution)
    }

    @SuppressLint("RestrictedApi")
    @OptIn(ExperimentalLensFacing::class)
    fun checkResolutionSupport(
        type: CameraType,
        requiredResolution: Long
    ): Boolean {
        try {
            val context = IDnowSDK.getInstance().appContext
            val cameraProvider = ProcessCameraProvider.getInstance(context).get()
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val lensFacingRequired =
                if (type == CameraType.FRONT) {
                    listOf(CameraSelector.LENS_FACING_FRONT, CameraSelector.LENS_FACING_EXTERNAL)
                } else {
                    listOf(CameraSelector.LENS_FACING_BACK)
                }
            val cameraIds = cameraProvider.availableCameraInfos
                .filter { it.lensFacing in lensFacingRequired && it.cameraIdentifier != null }
                .let { cameras ->
                    cameras.firstOrNull { it.lensFacing == lensFacingRequired.first() }
                        ?: cameras.firstOrNull()
                }?.cameraIdentifier
                ?.cameraIds
                ?: run {
                    Util_Log.w(
                        LOGTAG,
                        "Check resolution support failed. ${type.name} camera not found"
                    )
                    return false
                }

            cameraIds.forEach {
                val cameraSpecs = cameraManager.getCameraCharacteristics(it)
                val sensorArraySize = cameraSpecs
                    .get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
                    ?: return false

                if (requiredResolution <= (sensorArraySize.width() * sensorArraySize.height())) {
                    return true
                }
            }
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Check resolution support failed", e)
        }

        return false
    }
}