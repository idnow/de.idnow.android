package de.idnow.sdk.util;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import androidx.annotation.Nullable;

import de.idnow.sdk.R;

/**
 * @author Mathias Grasy
 * @date 05.11.2014
 * @brief collection of static strings for the photo ident. this class static hashmaps have to be created and it's not possible to use the strings.xml
 * in this case.
 */
@SuppressWarnings("WeakerAccess")
public
class Util_PhotoStrings
{

	public static final String SIGNATURE = "signature";

	public static String getDriverslicense( Context context )
	{
		return context.getResources().getString( R.string.photo_ident_driving_license );
	}

	public static String getIdcard( Context context )
	{
		return context.getResources().getString( R.string.photo_ident_ic_card );
	}

	public static String getPassport( Context context )
	{
		return context.getResources().getString( R.string.photo_ident_passport );
	}

	public static String getResidencepermit( Context context )
	{
		return context.getResources().getString( R.string.photo_ident_residence_permit );
	}

	// server strings
	public static final String SERVER_STRING_IDCARD            = "IDCARD";
	public static final String SERVER_STRING_PASSPORT          = "PASSPORT";
	public static final String SERVER_STRING_RESISTENCE_PERMIT = "RESIDENCE_PERMIT";
	public static final String SERVER_STRING_DRIVERS_LICENSE   = "DRIVERS_LICENSE";

	public static final String SERVER_STRING_IDFRONTSIDE = "IDFRONTSIDE";
	public static final String SERVER_STRING_IDBACKSIDE  = "IDBACKSIDE";
	public static final String SERVER_STRING_SELFIE  = "FACE";

	public static final String SERVER_STRING_IDHOLOGRAMS = "IDHOLOGRAMS";

	public static final String SERVER_STRING_FACE = "FACESCREENSHOT";

	public static final String SERVER_STRING_DRIVERSFRONTSIDE = "DRIVERSFRONTSIDE";
	public static final String SERVER_STRING_DRIVERSBACKSIDE  = "DRIVERSBACKSIDE";
	public static final String SERVER_STRING_DRIVERSHOLOGRAMS = "DRIVERSHOLOGRAMS";

	// TODO
	public static final String SERVER_STRING_HOLOGRAMS_VIDEO = "IDHOLOGRAMSVIDEO";

	// shared prefs
	public static final String SHARED_PREFS_NAME           = "de.idnow";
	public static final String SHARED_PREFS_KEY            = "hashmap";
	public static final String SHARED_PREFS_KEY_DATA       = "photodata";
	public static final String SHARED_PREFS_FILENAMES_DATA = "hashmap_image_filenames";


}
