package de.idnow.sdk.Activities.callbacks;

import de.idnow.sdk.network.RetrofitError;

public interface SendIdentToPhoneCallback {
    void onFailure(String result, String errorCause, RetrofitError error);
    void onSuccess();
    void onReceiveByEmail(boolean receiveByEmail);

}
