package de.idnow.sdk.Liveswitch;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Rect;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.MeteringRectangle;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;

import de.idnow.sdk.Config;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.camera.CameraType;
import fm.liveswitch.AudioConfig;
import fm.liveswitch.AudioEncoder;
import fm.liveswitch.AudioFormat;
import fm.liveswitch.AudioSink;
import fm.liveswitch.AudioSource;
import fm.liveswitch.LayoutScale;
import fm.liveswitch.MediaSourceState;
import fm.liveswitch.NullAudioSink;
import fm.liveswitch.NullVideoSink;
import fm.liveswitch.SourceInput;
import fm.liveswitch.VideoConfig;
import fm.liveswitch.VideoEncoder;
import fm.liveswitch.VideoFormat;
import fm.liveswitch.VideoPipe;
import fm.liveswitch.VideoSink;
import fm.liveswitch.VideoSource;
import fm.liveswitch.ViewSink;
import fm.liveswitch.android.AudioRecordSource;
import fm.liveswitch.android.Camera2Source;
import fm.liveswitch.android.Camera2SourceListener;
import fm.liveswitch.android.CameraPreview;
import fm.liveswitch.vp9.Encoder;

public class LocalMedia extends fm.liveswitch.RtcLocalMedia<View> {

    private final String LOGTAG = "IDNOW_LocalMedia";

    protected Context context;
    private final CameraPreview cameraPreview;
    private CameraType activeCameraType = CameraType.FRONT;
    private CameraCaptureSession cameraSession;
    private CaptureRequest.Builder camerCaptureRequestBuilder;
    private final VideoConfig videoConfig;
    private final boolean enableSoftwareH264;

    @SuppressLint("ClickableViewAccessibility")
    public LocalMedia(Context context, boolean enableSoftwareH264, boolean disableAudio, boolean disableVideo, AecContext aecContext) {
        super(disableAudio, disableVideo, aecContext);
        this.enableSoftwareH264 = enableSoftwareH264;
        this.context = context;
        cameraPreview = new CameraPreview(context, LayoutScale.Cover);
        cameraPreview.getView().setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                requestCameraFocus((int) event.getX(), (int) event.getY());
            }
            return true;
        });
        int width = Config.VIDEO_CONFIG_WIDTH;
        int frameRate = Config.VIDEO_CONFIG_FRAME_RATE;
        int height = Config.VIDEO_CONFIG_HEIGHT;
        if (width == 0 && height == 0 && frameRate == 0) {
            videoConfig = new VideoConfig(640, 480, 15);
        } else {
            videoConfig = new VideoConfig(width, height, frameRate);
        }

        super.initialize();
    }

    public void openCamera(CameraType type) {
        if (activeCameraType != type) {
            Camera2Source videoSource = (Camera2Source) getVideoSource();
            if (videoSource != null) {
                changeVideoSourceInput(type == CameraType.BACK ? videoSource.getBackInput() : videoSource.getFrontInput());
                activeCameraType = type;
            }
        }
    }

    public void requestCameraFocusCenter() {
        int centerX = cameraPreview.getView().getWidth() / 2;
        int centerY = cameraPreview.getView().getHeight() / 2;
        requestCameraFocus(centerX, centerY);
    }

    /**
     * x and y represent the coordinates based on the camera preview view
     */
    private void requestCameraFocus(int x, int y) {
        if (isVideoSourceClosed()) {
            Util_Log.w(LOGTAG, "Camera focus won't be requested. Reason: video source is closed");
            return;
        }
        try {
            Camera2Source source = (Camera2Source) getVideoSource();
            CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            CameraCharacteristics cameraSpecs = manager.getCameraCharacteristics(source.getCameraId());

            Rect sensorArraySize = cameraSpecs.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            if (sensorArraySize == null)
                throw new NullPointerException("Sensor array size is null");
            int translatedX = (x / cameraPreview.getView().getWidth()) * sensorArraySize.width();
            int translatedY = (y / cameraPreview.getView().getHeight()) * sensorArraySize.height();

            MeteringRectangle focusArea = new MeteringRectangle(
                    translatedX,
                    translatedY,
                    cameraPreview.getView().getWidth() / 10,
                    cameraPreview.getView().getHeight() / 10,
                    MeteringRectangle.METERING_WEIGHT_MAX - 1
            );

            camerCaptureRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_AUTO);
            camerCaptureRequestBuilder.set(CaptureRequest.CONTROL_AF_REGIONS, new MeteringRectangle[]{focusArea});
            camerCaptureRequestBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START);

            cameraSession.capture(camerCaptureRequestBuilder.build(), new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(@NonNull CameraCaptureSession session,
                                               @NonNull CaptureRequest request,
                                               @NonNull TotalCaptureResult result) {
                    camerCaptureRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
                    camerCaptureRequestBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE);
                    try {
                        cameraSession.setRepeatingRequest(camerCaptureRequestBuilder.build(), null, null);
                    } catch (CameraAccessException e) {
                        Util_Log.e(LOGTAG, "Reactivate CONTROL_AF_MODE_CONTINUOUS_VIDEO failed", e);
                    }
                }
            }, null);
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Request camera focus failed. x = " + x + " - y = " + y, e);
        }
    }

    @Override
    protected ViewSink<View> createViewSink() {
        return null;
    }

    @Override
    protected VideoSource createVideoSource() {
        Camera2Source source = new Camera2Source(cameraPreview, videoConfig);
        Camera2SourceListener listener = new Camera2SourceListener() {
            @Override
            public void onCameraCaptureSession(CameraCaptureSession cameraCaptureSession) {
                cameraSession = cameraCaptureSession;
            }

            @Override
            public void onCameraRequestBuilder(CaptureRequest.Builder builder) {
                camerCaptureRequestBuilder = builder;
            }
        };
        source.setListener(listener);
        return source;
    }

    public void setCameraTorchEnabled(boolean enabled) {
        if (isVideoSourceClosed()) {
            Util_Log.w(LOGTAG, "Camera torch won't be set to " + enabled + ". Reason: video source is closed");
            return;
        }
        try {
            int flagValue = enabled ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF;
            camerCaptureRequestBuilder.set(CaptureRequest.FLASH_MODE, flagValue);
            cameraSession.setRepeatingRequest(camerCaptureRequestBuilder.build(), null, null);
        } catch (CameraAccessException | NullPointerException | IllegalStateException e) {
            Util_Log.e(LOGTAG, "Set torch to " + enabled + " failed", e);
        }
    }

    private boolean isVideoSourceClosed() {
        VideoSource videoSource = getVideoSource();
        return videoSource == null ||
                ((Camera2Source) getVideoSource()).getCamera() == null ||
                videoSource.getState().getAssignedValue() >= MediaSourceState.Stopping.getAssignedValue() ||
                cameraSession == null ||
                camerCaptureRequestBuilder == null;
    }

    public View getView() {
        return cameraPreview.getView();
    }

    @Override
    protected AudioSink createAudioRecorder(AudioFormat audioFormat) {
        return new NullAudioSink();
    }

    @Override
    protected VideoSink createVideoRecorder(VideoFormat videoFormat) {
        return new NullVideoSink();
    }

    @Override
    protected VideoPipe createImageConverter(VideoFormat videoFormat) {
        return new fm.liveswitch.yuv.ImageConverter(videoFormat);
    }

    @Override
    protected AudioSource createAudioSource(AudioConfig audioConfig) {
        return new AudioRecordSource(context, audioConfig);
    }

    @Override
    protected AudioEncoder createOpusEncoder(AudioConfig audioConfig) {
        return new fm.liveswitch.opus.Encoder(audioConfig);
    }

    @Override
    protected VideoEncoder createH264Encoder() {
        if (enableSoftwareH264) {
            return new fm.liveswitch.openh264.Encoder();
        } else {
            return null;
        }
    }

    @Override
    protected VideoEncoder createVp8Encoder() {
        return new fm.liveswitch.vp8.Encoder();
    }

    @Override
    protected VideoEncoder createVp9Encoder() {
        return new Encoder();
    }

    public void addStateLogging() {
        this.addOnVideoStarted(() -> {
            logState();
            Util_Log.i(LOGTAG, "addOnVideoStarted");
        });

        this.addOnAudioStarted(() -> {
            logState();
            Util_Log.i(LOGTAG, "addOnAudioStarted");
        });

        this.getAudioTrack().addOnStarted(() -> {
            logState();
            Util_Log.i(LOGTAG, "local audio track started");
        });
        this.getAudioTrack().addOnStopped(() -> {
            logState();
            Util_Log.i(LOGTAG, "local audio track stopped");
        });
        this.getVideoTrack().addOnStarted(() -> {
            logState();
            Util_Log.i(LOGTAG, "local video track started");
        });
        this.getVideoTrack().addOnStopped(() -> {
            logState();
            Util_Log.i(LOGTAG, "local video track stopped");
        });

        this.getVideoTrack().getSourceInputs().then(sourceInputs -> {
            for (SourceInput sourceInput : sourceInputs) {
                Util_Log.d(LOGTAG, "sourceInputs: " + sourceInput.toJson());
            }
        });
    }

    private void logState() {
        Util_Log.i(LOGTAG, "local media state: " + this.getState().name());
    }
}