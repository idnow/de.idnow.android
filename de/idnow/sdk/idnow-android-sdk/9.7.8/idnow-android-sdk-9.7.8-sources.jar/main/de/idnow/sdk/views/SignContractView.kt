package de.idnow.sdk.views

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.RelativeLayout
import de.idnow.sdk.databinding.ViewSignContractBinding
import de.idnow.sdk.util.Util_UtilUI

class SignContractView @JvmOverloads constructor(
    context: Context,
    attributeSet: AttributeSet? = null,
    defStyle: Int = 0
) : RelativeLayout(context, attributeSet, defStyle) {

    private var binding: ViewSignContractBinding
    var drawingViewPlaceholder: LinearLayout


    init {
        binding = ViewSignContractBinding.inflate(LayoutInflater.from(context), this, true)
        drawingViewPlaceholder = binding.drawingViewPlaceholder

        Util_UtilUI.setESignatureTextColorSelector(binding.textViewResign)
    }

    fun setTextViewResignOnClickListener(listener: OnClickListener) {
        binding.textViewResign.setOnClickListener(listener)
        binding.textViewResign.isPressed = false
    }




}