package de.idnow.sdk.models;


import com.google.gson.annotations.SerializedName;

/**
 * @author Mathias Grasy
 * @version 1.0
 * @date 20.04.2016
 * @brief received from the server with the getCustomer call
 */


public class Models_URL_Settings
{
	@SerializedName("android.successURL")
	String sucessUrl;

	@SerializedName("android.failureURL")
	String failureUrl;

	public Models_URL_Settings( String sucessUrl, String failureUrl )
	{
		this.sucessUrl = sucessUrl;
		this.failureUrl = failureUrl;
	}

	public String getFailureUrl()
	{
		return failureUrl;
	}

	public void setFailureUrl( String failureUrl )
	{
		this.failureUrl = failureUrl;
	}

	public String getSucessUrl()
	{
		return sucessUrl;
	}

	public void setSucessUrl( String sucessUrl )
	{
		this.sucessUrl = sucessUrl;
	}
}
