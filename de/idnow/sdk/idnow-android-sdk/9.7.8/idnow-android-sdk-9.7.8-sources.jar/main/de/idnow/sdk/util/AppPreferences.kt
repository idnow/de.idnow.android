package de.idnow.sdk.util

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import de.idnow.sdk.util.permissionsManager.PermissionStatus

internal class AppPreferences(
    private val context: Context
) {
    private object Constants {
        const val SHARED_PREFS_NAME: String = "de.idnow"
        const val PERMISSION_STATUS_KEY: String = "de.idnow.prefs.permissions_status.key"
    }

    fun setPermissionStatus(status: PermissionStatus) {
        getSharedPrefs().edit(commit = true) {
            putString(Constants.PERMISSION_STATUS_KEY, status.name)
        }
    }

    fun getPermissionStatus(): PermissionStatus {
        return getSharedPrefs().getString(Constants.PERMISSION_STATUS_KEY, null)
            ?.let { PermissionStatus.valueOf(it) } ?: PermissionStatus.UNKNOWN
    }

    private fun getSharedPrefs(): SharedPreferences =
        context.getSharedPreferences(Constants.SHARED_PREFS_NAME, Context.MODE_PRIVATE)
}