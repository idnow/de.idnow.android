package de.idnow.sdk.models;

/**
 * Created by lars.mehrtens on 03.10.17.
 */

public class Models_eSignRefused {
}
