package de.idnow.sdk.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.animation.Animation;
import android.widget.LinearLayout;

import de.idnow.sdk.R;

/**
 * Created by lars.mehrtens on 21.02.17.
 */

public class AnimationAverseLinearLayout extends LinearLayout {

    private boolean mIsAnimationAverse = true;

    public AnimationAverseLinearLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        setOrientation(VERTICAL);
//        setGravity(Gravity.CENTER);
//        setWeightSum(1.0f);

        LayoutInflater.from(context).inflate(R.layout.view_animation_averse_linear_layout, this, true);
    }

    public void setAnimationAverse(boolean isAnimationAverse) {
        if (isAnimationAverse) {
            clearAnimation();
        }
        mIsAnimationAverse = isAnimationAverse;
    }

    @Override
    public void startAnimation(Animation animation) {
        if (!mIsAnimationAverse) {
            super.startAnimation(animation);
        }
    }
}
