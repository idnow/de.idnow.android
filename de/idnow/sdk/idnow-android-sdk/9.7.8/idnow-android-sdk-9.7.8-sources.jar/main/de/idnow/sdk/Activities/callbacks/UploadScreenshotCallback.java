package de.idnow.sdk.Activities.callbacks;

public interface UploadScreenshotCallback {
    void onResult();
}
