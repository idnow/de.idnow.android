package de.idnow.sdk.models;



/**
 * @author Mathias Grasy
 * @version 1.0
 * @date 10.10.2014
 * @brief is send in the start call, including information about the device
 */


public class Models_NewMirrorConference
{
	Models_ClientInfo clientInfo;

	public Models_NewMirrorConference(Models_ClientInfo clientInfo)
	{
		this.clientInfo = clientInfo;
	}
}
