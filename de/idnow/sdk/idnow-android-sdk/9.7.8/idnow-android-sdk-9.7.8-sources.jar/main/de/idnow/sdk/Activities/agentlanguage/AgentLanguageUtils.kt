package de.idnow.sdk.Activities.agentlanguage

import android.content.Context
import de.idnow.sdk.R
import de.idnow.sdk.util.Util_Strings
import java.util.Locale

class AgentLanguageUtils {

    companion object {

        fun getDisplayLanguage(context: Context, code: String): String {
            val displayLanguage = Util_Strings.getStringWithDefault(
                context,
                "js.languages.${code.toUpperCase()}",
                R.string.blank
            )

            if (displayLanguage.isEmpty()) {
                return Locale(code).displayName
            }

            return displayLanguage
        }

    }
}