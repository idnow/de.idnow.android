package de.idnow.sdk.util;


import androidx.annotation.NonNull;

import java.util.HashSet;

import de.idnow.sdk.IDnowSDK;

public class Util_IdentSessionAssistant {

    private static Util_IdentSessionAssistant assistant;
    private final HashSet<IDnowSDK.SessionType> activeSessions;

    private Util_IdentSessionAssistant(){

        activeSessions = new HashSet<>();
    }

    public synchronized static Util_IdentSessionAssistant getInstance(){
        if(assistant == null){
            assistant = new Util_IdentSessionAssistant();
        }
        return assistant;
    }

    public synchronized boolean isSessionActive(@NonNull IDnowSDK.SessionType sessionType){
        return activeSessions.contains(sessionType);
    }

    public synchronized void indicateSessionStarted(@NonNull IDnowSDK.SessionType sessionType){
        activeSessions.add(sessionType);
    }

    public synchronized void indicateSessionStopped(@NonNull IDnowSDK.SessionType sessionType){
        activeSessions.remove(sessionType);
    }


}
