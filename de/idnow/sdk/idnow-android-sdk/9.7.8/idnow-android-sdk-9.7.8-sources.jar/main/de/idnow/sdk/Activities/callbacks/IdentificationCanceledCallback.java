package de.idnow.sdk.Activities.callbacks;

public interface IdentificationCanceledCallback {
    void onFailure();
    void onSuccess();
}
