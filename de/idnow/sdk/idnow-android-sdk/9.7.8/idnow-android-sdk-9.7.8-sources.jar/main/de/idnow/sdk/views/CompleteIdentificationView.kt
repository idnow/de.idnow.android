package de.idnow.sdk.views

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import de.idnow.sdk.databinding.ViewCompleteIdentificationBinding
import de.idnow.sdk.util.Util_Strings
import de.idnow.sdk.util.ui.ViewHelper

class CompleteIdentificationView @JvmOverloads constructor(
    context: Context,
    attributeSet: AttributeSet? = null,
    defStyle: Int = 0
) : LinearLayout(context, attributeSet, defStyle) {

    init {
        val binding = ViewCompleteIdentificationBinding.inflate(LayoutInflater.from(context), this, true)
        ViewHelper.applySafeBotPadding(binding.main)
        binding.completeViText.text = Util_Strings.getStringWithDefault(
            context,
            Util_Strings.KEY_VIDEO_IDENT_PLUS_IDENT_BEING_COMPELTED,
            Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_IDENT_BEING_COMPELTED
        )
        binding.completeViDesc.text = Util_Strings.getStringWithDefault(
            context,
            Util_Strings.KEY_VIDEO_IDENT_PLUS_IDENT_BEING_WAIT,
            Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_IDENT_BEING_WAIT
        )
    }
}