package de.idnow.sdk.models;



/**
 * @date 16.10.2014
 * @author Mathias Grasy
 * @brief (short description)
 * 
 */


public class Models_Documenttype
{
	String[]					images;
	Models_AllowedDocuments[]	alloweddocuments;

	/**
	 * @param images
	 * @param alloweddocuments
	 */
	public Models_Documenttype( String[] images, Models_AllowedDocuments[] alloweddocuments )
	{
		super();
		this.images = images;
		this.alloweddocuments = alloweddocuments;
	}

	/**
	 * @return the images
	 */
	public String[] getImages()
	{
		return images;
	}

	/**
	 * @param images the images to set
	 */
	public void setImages( String[] images )
	{
		this.images = images;
	}

	/**
	 * @return the alloweddocuments
	 */
	public Models_AllowedDocuments[] getAlloweddocuments()
	{
		return alloweddocuments;
	}

	/**
	 * @param alloweddocuments the alloweddocuments to set
	 */
	public void setAlloweddocuments( Models_AllowedDocuments[] alloweddocuments )
	{
		this.alloweddocuments = alloweddocuments;
	}

}
