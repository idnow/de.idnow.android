package de.idnow.sdk.Liveswitch;

import fm.liveswitch.AecPipe;
import fm.liveswitch.AudioConfig;
import fm.liveswitch.AudioSink;
import fm.liveswitch.android.AudioRecordSource;
import fm.liveswitch.android.AudioTrackSink;
import fm.liveswitch.audioprocessing.AecProcessor;

public class AecContext extends fm.liveswitch.AecContext {
    @Override
    protected AecPipe createProcessor() {
        AudioConfig config = new AudioConfig(16000, 1);

        int tailLength = AudioTrackSink.getBufferDelay(config) + AudioRecordSource.getBufferDelay(config);
        return new AecProcessor(config, tailLength);
    }

    @Override
    protected AudioSink createOutputMixerSink(AudioConfig audioConfig) {
        return new AudioTrackSink(audioConfig);
    }
}
