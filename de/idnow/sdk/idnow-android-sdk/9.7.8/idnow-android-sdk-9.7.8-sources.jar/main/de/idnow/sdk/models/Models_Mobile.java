package de.idnow.sdk.models;

import com.google.gson.annotations.SerializedName;

public class Models_Mobile {

    @SerializedName("checkBoxInstructionsScreen")
    public Boolean checkBoxInstructionsScreen;

    @SerializedName("enableDarkModeAndroid")
    public Boolean enableDarkModeAndroid;

    public Boolean isCheckBoxInstructionsScreen() {
        return checkBoxInstructionsScreen;
    }

    public void setCheckBoxInstructionsScreen(Boolean checkBoxInstructionsScreen) {
        this.checkBoxInstructionsScreen = checkBoxInstructionsScreen;
    }

    public Models_Mobile(Boolean checkBoxInstructionsScreen, Boolean enableDarkModeAndroid) {
        this.checkBoxInstructionsScreen = checkBoxInstructionsScreen;
        this.enableDarkModeAndroid = enableDarkModeAndroid;
    }

    public Boolean getEnableDarkModeAndroid() {
        return enableDarkModeAndroid;
    }

    public void setEnableDarkModeAndroid(Boolean enableDarkModeAndroid) {
        this.enableDarkModeAndroid = enableDarkModeAndroid;
    }
}
