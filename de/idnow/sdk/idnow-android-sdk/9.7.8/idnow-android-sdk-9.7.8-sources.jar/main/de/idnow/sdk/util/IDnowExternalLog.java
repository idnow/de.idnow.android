package de.idnow.sdk.util;

import android.content.Context;
import android.content.Intent;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

//TODO this needs to be deleted as it is not used anymore
public class IDnowExternalLog {

    private static final String ACTION_LOG_EVENT = "action_log_event";
    private static final String EXTRA_LOG_MESSAGE_KEY = "extra_log_message_key";
    private static final String EXTRA_EVENT_TYPE_KEY = "extra_event_type_key";
    private static final String EXTRA_DATA_KEY = "extra_data_key";

    public static void logExternally(Context context, String message, String eventType) {
        Intent intent = new Intent(ACTION_LOG_EVENT);
        intent.putExtra(EXTRA_LOG_MESSAGE_KEY, message);
        intent.putExtra(EXTRA_EVENT_TYPE_KEY, eventType);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    public static void logExternally(Context context, String message, String extraData, String eventType) {
        Intent intent = new Intent(ACTION_LOG_EVENT);
        intent.putExtra(EXTRA_LOG_MESSAGE_KEY, message);
        intent.putExtra(EXTRA_DATA_KEY, extraData);
        intent.putExtra(EXTRA_EVENT_TYPE_KEY, eventType);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }
}
