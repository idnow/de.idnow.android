package de.idnow.sdk.util;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import java.util.Collections;
import java.util.List;

import de.idnow.sdk.models.Models_CallError;
import de.idnow.sdk.models.Models_RESTError;
import de.idnow.sdk.network.RetrofitError;

/**
 * @author Mathias Grasy
 * @version 1.0
 */
public class Util_UtilRetrofit {
    private static final String LOGTAG = "IDNOW_Util_UtilRetrofit";

    public static String printRetrofitError(RetrofitError error) {
        if (error != null && error.getBody() != null)
            return error.getBody().getMessage();

        return "";
    }

    public static String getErrorIdRetrofit(String result) {
        List<Models_RESTError> errors = extractErrorList(result);
        return errors.isEmpty() ? "" : String.valueOf(errors.get(0).getId());
    }

    public static String getErrorCauseRetrofit(String result) {
        List<Models_RESTError> errors = extractErrorList(result);
        return errors.isEmpty() ? "" : errors.get(0).getCause();
    }

    public static String getErrorTypeRetrofit(String result) {
        List<Models_RESTError> errors = extractErrorList(result);
        return errors.isEmpty() ? "" : errors.get(0).getErrorType();
    }

    private static List<Models_RESTError> extractErrorList(String jsonCallError) {
        try {
            Models_CallError errorObj = new Gson().fromJson(jsonCallError, Models_CallError.class);
            if (errorObj != null && errorObj.getErrors() != null)
                return errorObj.getErrors();
        } catch (JsonSyntaxException e) {
            Util_Log.e(LOGTAG, "Extract error list failed", e);
        }

        return Collections.emptyList();
    }
}