package de.idnow.sdk.views

import android.content.Context
import android.util.AttributeSet
import androidx.viewpager.widget.ViewPager



class CircleIndicator : BaseCircleIndicator {
    private var mViewpager: ViewPager? = null

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    fun setViewPager(viewPager: ViewPager?) {
        mViewpager = viewPager
        if (mViewpager != null && mViewpager?.adapter != null) {
            mLastPosition = -1
            createIndicators()
            mViewpager?.removeOnPageChangeListener(mInternalPageChangeListener)
            mViewpager?.addOnPageChangeListener(mInternalPageChangeListener)
            mInternalPageChangeListener.onPageSelected(mViewpager?.currentItem ?: 0)
        }
    }

    private fun createIndicators() {
        val adapter = mViewpager?.adapter
        val count: Int
        count = adapter?.count ?: 0
        createIndicators(count, mViewpager?.currentItem ?: 0)
    }

    private val mInternalPageChangeListener: ViewPager.OnPageChangeListener =
        object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int, positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(position: Int) {
                if (mViewpager?.adapter == null || (mViewpager?.adapter?.count ?: 0) <= 0
                ) {
                    return
                }
                animatePageSelected(position)
            }

            override fun onPageScrollStateChanged(state: Int) {}
        }

    @Deprecated("User ViewPager addOnPageChangeListener")
    fun setOnPageChangeListener(
        onPageChangeListener: ViewPager.OnPageChangeListener?
    ) {
        if (mViewpager == null) {
            throw NullPointerException("can not find Viewpager , setViewPager first")
        }
        if(onPageChangeListener != null) {
            mViewpager?.removeOnPageChangeListener(onPageChangeListener)
            mViewpager?.addOnPageChangeListener(onPageChangeListener)
        }
    }
}

