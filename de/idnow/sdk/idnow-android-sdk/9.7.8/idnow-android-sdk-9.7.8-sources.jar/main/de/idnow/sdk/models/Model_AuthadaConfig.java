package de.idnow.sdk.models;

public class Model_AuthadaConfig {

    public String stagingUrl;
    public String productionUrl;

    public Model_AuthadaConfig(String stagingUrl, String productionUrl) {
        this.stagingUrl = stagingUrl;
        this.productionUrl = productionUrl;
    }

    public String getStagingUrl() {
        return stagingUrl;
    }

    public void setStagingUrl(String stagingUrl) {
        this.stagingUrl = stagingUrl;
    }

    public String getProductionUrl() {
        return productionUrl;
    }

    public void setProductionUrl(String productionUrl) {
        this.productionUrl = productionUrl;
    }
}
