package de.idnow.sdk.network;

import java.util.Map;

import de.idnow.sdk.models.Model_AgentFeedback;
import de.idnow.sdk.models.Model_Classification;
import de.idnow.sdk.models.Model_InstantSignStart;
import de.idnow.sdk.models.Models_ApprovalPhrase;
import de.idnow.sdk.models.Models_CallQualityTest;
import de.idnow.sdk.models.Models_ConfirmationToken;
import de.idnow.sdk.models.Models_Consent;
import de.idnow.sdk.models.Models_Customer;
import de.idnow.sdk.models.Models_DocumentInfo;
import de.idnow.sdk.models.Models_Email;
import de.idnow.sdk.models.Models_EmptyJson;
import de.idnow.sdk.models.Models_Enrollment;
import de.idnow.sdk.models.Models_MobileNumber;
import de.idnow.sdk.models.Models_NewMirrorConference;
import de.idnow.sdk.models.Models_OfficeHours;
import de.idnow.sdk.models.Models_PDFDocument;
import de.idnow.sdk.models.Models_RegistrationeSign;
import de.idnow.sdk.models.Models_SdpOffer;
import de.idnow.sdk.models.Models_StartObject;
import de.idnow.sdk.models.Models_StartObjectResult;
import de.idnow.sdk.models.Models_TextMessage;
import de.idnow.sdk.models.Models_WaitingListNotificationSub;
import de.idnow.sdk.models.Models_authenticationPossible;
import de.idnow.sdk.models.Models_eSignRefused;
import fm.liveswitch.Candidate;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * @author Mathias Grasy
 * @version 1.0
 * @brief overview of the available REST calls
 */
public interface Network_RESTCalls {
	@GET("/api/v1/{transactionToken}")
	Call<Models_OfficeHours> getCompanyShortname(@Path("transactionToken") String companyShort);

	@GET("/assets/messages.json")
	Call<Map<String, String>> getMessagesJSON(@Query("shortName") String companyShort);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/start")
	Call<Models_StartObjectResult> start(@Body Models_StartObject startObject, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);
	@POST("/api/v1/{companyShort}/trustedOriginalData/{transactionToken}/start")
	Call<Model_InstantSignStart> startInstanteSign(@Body Models_StartObject startObject, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);


	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/prepareSigningSession")
	Call<Models_EmptyJson> prepareSigningSession(@Body Models_EmptyJson models_emptyJson, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken, @Header("Identification-Signature")String header);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/sendConfirmationToken")
	Call<Object> sendConfirmationToken(@Body Models_ConfirmationToken confirmationToken, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/resendConfirmationToken")
	Call<Object> requestConfirmationToken(@Body Models_MobileNumber mobile, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/resendConfirmationTokenViaEmail")
	Call<Object> requestConfirmationTokenByEmail(@Body Models_Email email, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/requestVideoChat")
	Call<Models_EmptyJson> requestVideoChat(@Body Models_EmptyJson emptyJson, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/setupComplete")
	Call<Models_EmptyJson> setupComplete(@Body Models_EmptyJson emptyJson, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/appEnteredBackground")
	Call<Models_EmptyJson> appEnteredBackground(@Body Models_EmptyJson emptyJson, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/appEnteredForeground")
	Call<Models_EmptyJson> appEnteredForeground(@Body Models_EmptyJson emptyJson, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	@GET("/api/v1/{companyShort}/identifications/{transactionToken}")
	Call<Models_Customer> getCustomer(@Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	@GET("/api/v1/{companyShort}/identifications/{transactionToken}/classification")
	Call<Object> getClassification(@Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/uploadDocumentInfo")
	Call<Object> uploadDocumentInfo(@Body Models_DocumentInfo models_documentInfo, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/uploadImage/{type}")
	Call<Model_Classification> uploadImage(@Body RequestBody screenshot, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort, @Path("type") String type);

	@Headers({"Content-Type: application/octet-stream"})
	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/uploadScreenshot/{type}")
	Call<Object> uploadScreenshot(@Body RequestBody screenshot, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort, @Path("type") String type);

	// encoding: "vp8" or "h264"
	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/uploadVideo/{encoding}")
	Call<Object> uploadVideo(@Body RequestBody video, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort, @Path("encoding") String encoding);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/canceled")
	Call<Object> identificationCanceled(@Body Models_EmptyJson emptyJson, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/canceled")
	Call<Object> identificationCanceled(@Body String reason, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/failed")
	Call<Object> identificationFailed(@Body Models_EmptyJson emptyJson, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	@POST("/api/v1/conferences/{sessionId}/USER/{agentToken}/sendSdpOffer")
	Call<Models_SdpOffer> sendSdpOffer(@Body Models_SdpOffer sdpOffer, @Path("sessionId") String sessionId, @Path("agentToken") String agentToken);

	@POST("/api/v1/conferences/{conferenceID}/{peerType}/{peerID}/sendCandidate")
	Call<String> sendCandidate(@Body Candidate candidate, @Path("conferenceID") String conferenceID, @Path("peerType") String peerType, @Path("peerID") String peerID);

	//	@POST("/api/v1/startMirrorConference")
	@POST("/api/v1/{companyToken}/identifications/{transactionToken}/startCallQualityTest")
	Call<Models_CallQualityTest> startCallQualityTest(@Body Models_NewMirrorConference mirrorConference, @Path("companyToken") String companyToken, @Path("transactionToken") String transactionToken);

	@POST("/api/v1/{companyToken}/identifications/{transactionToken}/stopCallQualityTest")
	Call<Boolean> stopCallQualityTest(@Body Models_NewMirrorConference mirrorConference, @Path("companyToken") String shortname, @Path("transactionToken") String token);

	// ==========================
	// Waiting list notifications
	// ==========================
	@POST("/api/v1/{shortname}/identifications/{token}/notificationSubscription")
	Call<Models_WaitingListNotificationSub> sendNotificationSubscription(@Body Models_WaitingListNotificationSub subscription, @Path("shortname") String sessionId, @Path("token") String token);

	@POST("/api/v1/{shortname}/identifications/{token}/waitingListEnrollment")
	Call<Models_Enrollment> sendWaitingListEnrollment(@Body Models_Enrollment enrollment, @Path("shortname") String sessionId, @Path("token") String token);

	// ==========
	// E-SIGNING
	// ==========

	@GET("/api/v1/{companyShort}/identifications/{transactionToken}/approvalPhrases")
	Call<Models_ApprovalPhrase[]> getApprovalPhrases(@Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);


	@GET("/api/v1/{companyShort}/identifications/{transactionToken}/tspDocument")
	Call<okhttp3.ResponseBody> getTSPDocuments(@Header("Identification-Signature") String IdentificationSignature, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/signingRefuse")
	Call<Object> refuseSigning(@Body Models_eSignRefused refusal, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/sMobileNumber")
	Call<Object> updateConfirmMobileNumber(@Body Models_MobileNumber number, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/updateMobileNumber")
	Call<Models_MobileNumber> updateMobileNumber(@Body Models_MobileNumber number, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

	@GET("/api/v1/{companyShort}/identifications/{transactionToken}/signingDone")
	Call<Object> signingDone(@Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

	// Live version:
	@GET("/api/v1/{companyShort}/identifications/{transactionToken}/documents")
	Call<Models_PDFDocument[]> getDocuments(@Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

	// =============
	// TEXT CHAT
	// =============
	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/chat/agent/sendMsg")
	Call<Object> sendMessage(@Body Models_TextMessage message, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	// =============
	// WALLET
	// =============

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/createAccount")
	Call<Models_RegistrationeSign> createAccount(@Body Models_RegistrationeSign models_registrationeSign, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

	@GET("/api/v1/{companyShort}/identifications/{transactionToken}/authenticationPossible")
	Call<Models_authenticationPossible> authenticationPossible(@Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);


	// =============
	// AGENT FEEDBACK
	// =============

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/agentFeedback")
	Call<Void> agentFeedback(@Body Model_AgentFeedback model_agentFeedback, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

	@POST("/api/v1/{companyShort}/identifications/{transactionToken}/consent")
	Call<Void> sendUserConsent(@Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort, @Body Models_Consent modelsConsent, @Header("Identification-Signature") String header);
}
