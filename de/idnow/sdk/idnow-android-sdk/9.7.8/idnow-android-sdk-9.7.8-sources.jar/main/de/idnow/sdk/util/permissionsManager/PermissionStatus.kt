package de.idnow.sdk.util.permissionsManager

internal enum class PermissionStatus {
    UNKNOWN,//TODO IS THIS NEEDED?
    GRANTED,
    DENIED_CAN_ASK_AGAIN,
    DENIED_PERMANENTLY
}