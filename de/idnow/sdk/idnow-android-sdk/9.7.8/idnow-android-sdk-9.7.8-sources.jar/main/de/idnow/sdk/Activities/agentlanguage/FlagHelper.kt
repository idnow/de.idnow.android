package de.idnow.sdk.Activities.agentlanguage

import java.util.*

class FlagHelper {

    companion object {
        fun getFlagCode(language: String = Locale.getDefault().language): String {
            return if (language == "en") {
                "gb"
            } else language
        }
    }
}