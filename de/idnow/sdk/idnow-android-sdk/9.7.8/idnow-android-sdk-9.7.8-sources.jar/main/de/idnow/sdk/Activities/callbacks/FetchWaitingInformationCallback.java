package de.idnow.sdk.Activities.callbacks;

import de.idnow.sdk.models.Models_Customer;

public interface FetchWaitingInformationCallback {
    void updateInfo(Models_Customer info);
    void onSuccess(Models_Customer result);
}
