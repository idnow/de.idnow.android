package de.idnow.sdk.Activities;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.Arrays;
import java.util.List;

import de.idnow.sdk.Adapters.CustomLinearLayoutManager;
import de.idnow.sdk.Adapters.IDnowListDocumentAdapter;
import de.idnow.sdk.Config;
import de.idnow.sdk.R;
import de.idnow.sdk.util.Util_PhotoDataHolder;

public class Fragment_IDDocument_list extends Fragment implements View.OnClickListener, IDnowListDocumentAdapter.DocumentItemClickListener {

    public RecyclerView list_document_type;
    private IDnowListDocumentAdapter listDocumentAdapter;

    public Context context;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        View view =  inflater.inflate(R.layout.fragement_view_iddocuments_list, container, false);

        context = getContext();

            list_document_type = view.findViewById(R.id.list_document_type);

            list_document_type.setLayoutManager(new CustomLinearLayoutManager(context, LinearLayoutManager.VERTICAL,false));

        List<String> exampleList = null;

        DividerItemDecoration verticalDecoration = new DividerItemDecoration(list_document_type.getContext(),DividerItemDecoration.VERTICAL);

        Drawable verticalDivider = ContextCompat.getDrawable(context, R.drawable.vertical_divider);
        verticalDecoration.setDrawable(verticalDivider);

        list_document_type.addItemDecoration(verticalDecoration);


        try {

            Config.VIDEO_IDENT_PLUS_COUNTRY = Util_PhotoDataHolder.getSelectedCountry( context ) ;

            exampleList = Util_PhotoDataHolder.getDocumentListToCountryname( context ).get(Util_PhotoDataHolder.getSelectedCountry( context ) );


        }catch (Exception e){
            exampleList  = Arrays.asList("Identity Card", "Passport", "Residence Permit");

        }



        listDocumentAdapter = new IDnowListDocumentAdapter(context, exampleList);

        listDocumentAdapter.setDocumentItemClickListener(this);


        list_document_type.setAdapter(listDocumentAdapter);


        return view;
    }

    public static Fragment_IDDocument_list newInstance() {
        return new Fragment_IDDocument_list();
    }


    @Override
    public void onClick(View v) {

    }

    @Override
    public void onDocumentItemClick(int position) {

    }

//    public void showIntroFragment(Fragment fragment) {
//
//        if (fragment instanceof Fragment_IDDocument_list){
//            Fragment_IDDocument_list.showMe(this);
//        }
//    }
//
//    public void hideIntroFragment(Fragment fragment) {
//
//        if (fragment instanceof Fragment_IDDocument_list){
//            Fragment_IDDocument_list.hideMe(this);
//        }
//    }


//    public static void showMe(Activities_TakePhotoActivity activity) {
//        IDnowFragmentManager.showFragment(activity, Fragment_IDDocument_list.class);
//    }
//
//    public static void hideMe(Activities_TakePhotoActivity activity) {
//        IDnowFragmentManager.hideFragment(activity, Fragment_IDDocument_list.class);
//    }

    public static void showMe(Activities_VideoLiveStreamActivity_Super activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_IDDocument_list.class);
    }

    public static void hideMe(Activities_VideoLiveStreamActivity_Super activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_IDDocument_list.class);
    }


}
