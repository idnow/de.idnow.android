package de.idnow.sdk.messages

import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.util.RemoteAnimationsCollection
import de.idnow.sdk.util.Util_Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val LOGTAG = "IDNOW_LottieAnimationsProvider"

internal object AnimationsCollectionProvider : BaseProvider() {
    private val coroutineDispatcher = Dispatchers.IO

    suspend fun fetch(onDone: (RemoteAnimationsCollection) -> Unit) =
        withContext(coroutineDispatcher) {
            try {
                val response = provideRestApiService().getLottieAnimations(
                    companyShort = IDnowSDK.getCompanyId()
                )
                if (response.isSuccessful) {
                    val collection = response.body()
                        ?: throw Exception("Response body was null, but it shouldn't have been")
                    onDone(collection)
                }
            } catch (e: Exception) {
                Util_Log.e(LOGTAG, "Error fetching animations", e)
            }
        }
}