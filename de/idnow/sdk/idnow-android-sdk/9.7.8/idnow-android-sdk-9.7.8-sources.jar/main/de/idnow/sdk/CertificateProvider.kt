package de.idnow.sdk

/**
 * @brief classes that implement this interface are used to provide custom mTLS certificates
 * used by network connections.
 *
 * In order to use custom certificates please subclass CertificateProvider and add
 * an instance of your new class to the IDnowSDK:
 *
 * IDnowSDK.setCertificateProvider( >>YOUR_SUBCLASS<< )
 */
abstract class CertificateProvider {
    companion object {
        const val DEFAULT_FEATURE_CERTIFICATE = true
        const val DEFAULT_FEATURE_FINGERPRINT = true
        const val DEFAULT_FEATURE_SERVER_CERT = true
    }

    /**
     * subclasses need to implement this function in a way that it returns a DER encoded byte stream
     * representing the private key.
     *
     * openssl command to convert from PEM to DER: openssl rsa -outform der -in yourkey.pem -out yourkey.der
     *
     * @return DER encoded private key
     */
    open fun providePrivateKeyBytestream(): ByteArray? {
        if (featureCertificate())
            throw RuntimeException("Needs to be implemented in a subclass")

        return null
    }

    /**
     * subclasses need to implement this function in a way that it returns a DER encoded byte stream
     * representing the x509/ASN.1 certificate.
     *
     * openssl command to convert form PEM to DER: openssl x509 -outform der -in yourcertificate.pem -out yourcertificate.der
     *
     * @return DER encoded x509/ASN.1 certificate
     */
    open fun provideCertificateBytestream(): ByteArray? {
        if (featureCertificate())
            throw RuntimeException("Needs to be implemented in a subclass")

        return null
    }

    /**
     * subclasses need to implement this function in a way that it returns the raw bytes containing the SHA256 fingerprint
     * of the used server certificates
     *
     * @return raw bytes of the SHA256 fingerprint of server certificates
     */
    open fun provideServerFingerPrintByteStreams(): Array<ByteArray>? {
        if (featureFingerPrint())
            throw RuntimeException("Needs to be implemented in a subclass")

        return null
    }

    /**
     * subclasses need to implement this function in a way that it returns a DER encoded byte stream
     * representing the x509/ASN.1 certificate.
     *
     * openssl command to convert form PEM to DER: openssl x509 -outform der -in yourcertificate.pem -out yourcertificate.der
     *
     * @return DER encoded x509/ASN.1 server certificates
     */
    open fun provideServerCertificateBytestreams(): Array<ByteArray>? {
        if (featureServerCert())
            throw RuntimeException("Needs to be implemented in a subclass")

        return null
    }

    /**
     * these bool flags configure which features the underlying connection uses
     * Override these in case you only need one of the features.
     */
    open fun featureCertificate(): Boolean =
        DEFAULT_FEATURE_CERTIFICATE

    open fun featureFingerPrint(): Boolean =
        DEFAULT_FEATURE_FINGERPRINT

    open fun featureServerCert(): Boolean =
        DEFAULT_FEATURE_SERVER_CERT
}