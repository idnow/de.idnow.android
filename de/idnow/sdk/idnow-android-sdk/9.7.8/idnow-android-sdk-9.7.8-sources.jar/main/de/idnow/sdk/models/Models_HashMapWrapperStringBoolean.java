/**
 * @date 24.10.2014
 * @author Mathias Grasy
 * @brief (short description)
 * 
 * description long
 */

package de.idnow.sdk.models;

import java.util.Map;



/**
 * @date 24.10.2014
 * @author Mathias Grasy
 * @brief (short description)
 * 
 */


public class Models_HashMapWrapperStringBoolean
{

	private Map<String, Boolean>	map;

	/**
	 * @param map
	 */
	public Models_HashMapWrapperStringBoolean( Map<String, Boolean> map )
	{
		super();
		this.map = map;
	}

	/**
	 * @return the map
	 */
	public Map<String, Boolean> getMap()
	{
		return map;
	}

	/**
	 * @param map the map to set
	 */
	public void setMap( Map<String, Boolean> map )
	{
		this.map = map;
	}

}
