package de.idnow.sdk.models;



/**
 * 
 * @date 10.10.2014
 * @author Mathias Grasy
 * @version 1.0
 */


public class Models_SdpOffer
{

	public Models_SdpOffer(String sdpMessage, Boolean isOffer, String tieBreaker)
	{
		this.sdpMessage = sdpMessage;
		this.isOffer = isOffer;
		this.tieBreaker = tieBreaker;
	}

	String	sdpMessage;

	Boolean	isOffer;

	String	tieBreaker;

	/**
	 * @return the sdpMessage
	 */
	public String getSdpMessage()
	{
		return sdpMessage;
	}

	/**
	 * @param sdpMessage the sdpMessage to set
	 */
	public void setSdpMessage( String sdpMessage )
	{
		this.sdpMessage = sdpMessage;
	}

	/**
	 * @return the tieBreaker
	 */
	public String getTieBreaker()
	{
		return tieBreaker;
	}

	/**
	 * @param tieBreaker the tieBreaker to set
	 */
	public void setTieBreaker( String tieBreaker )
	{
		this.tieBreaker = tieBreaker;
	}

	/**
	 * @return the isOffer
	 */
	public Boolean getIsOffer()
	{
		return isOffer;
	}

	/**
	 * @param isOffer the isOffer to set
	 */
	public void setIsOffer( Boolean isOffer )
	{
		this.isOffer = isOffer;
	}

}
