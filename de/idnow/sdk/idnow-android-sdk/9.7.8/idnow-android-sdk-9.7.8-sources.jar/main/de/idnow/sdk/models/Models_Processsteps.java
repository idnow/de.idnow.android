package de.idnow.sdk.models;


/**
 * @author Mathias Grasy
 * @date 16.10.2014
 * @brief (short description)
 */

public class Models_Processsteps
{
	Models_Documenttype iddocument;
	Models_Documenttype facecheck;
	Models_Documenttype driverslicense;

	Models_eSignature esigning;

	/**
	 * @param esigning
	 * @param facecheck
	 * @param driverslicense
	 * @param iddocument
	 */
	public Models_Processsteps( Models_eSignature esigning, Models_Documenttype facecheck, Models_Documenttype driverslicense, Models_Documenttype iddocument )
	{
		this.esigning = esigning;
		this.facecheck = facecheck;
		this.driverslicense = driverslicense;
		this.iddocument = iddocument;
	}

	public Models_eSignature getEsigning()
	{
		return esigning;
	}

	public void setEsigning( Models_eSignature esigning )
	{
		this.esigning = esigning;
	}

	/**
	 * @return the iddocument
	 */
	public Models_Documenttype getIddocument()
	{
		return iddocument;
	}

	/**
	 * @param iddocument the iddocument to set
	 */
	public void setIddocument( Models_Documenttype iddocument )
	{
		this.iddocument = iddocument;
	}

	/**
	 * @return the facecheck
	 */
	public Models_Documenttype getFacecheck()
	{
		return facecheck;
	}

	/**
	 * @param facecheck the facecheck to set
	 */
	public void setFacecheck( Models_Documenttype facecheck )
	{
		this.facecheck = facecheck;
	}

	/**
	 * @return the driverslicense
	 */
	public Models_Documenttype getDriverslicense()
	{
		return driverslicense;
	}

	/**
	 * @param driverslicense the driverslicense to set
	 */
	public void setDriverslicense( Models_Documenttype driverslicense )
	{
		this.driverslicense = driverslicense;
	}

}
