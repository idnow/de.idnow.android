package de.idnow.sdk;

import android.content.Intent;

public interface IDnowResultCallback {
    void onResult(int resultCode, Intent data);
}
