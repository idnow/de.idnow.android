package de.idnow.sdk.models;


import java.util.Date;

import de.idnow.sdk.util.Util_Util;

/**
 * Created by Mathias Grasy on 23.09.2016.
 */

public class Models_ChatMessage
{
	String text;
	String date;
	String originator;
	String name;

	public Models_ChatMessage( String text, String date, String originator )
	{
		this.text = text;
		this.date = date;
		this.originator = originator;
	}

	public Models_ChatMessage( String text, Date date, String originator, String name )
	{
		this.text = text;
		this.date = Util_Util.convertDateToFormattedDateString( date, Util_Util.SIMPLE_DATE_FORMAT );
		this.originator = originator;
		this.name = name;
	}

	public String getName()
	{
		return name;
	}

	public String getText()
	{
		return text;
	}

	public void setText( String text )
	{
		this.text = text;
	}

	public String getDate()
	{
		return date;
	}

	public void setDate( String date )
	{
		this.date = date;
	}

	public String getOriginator()
	{
		return originator;
	}

	public void setOriginator( String originator )
	{
		this.originator = originator;
	}
}
