package de.idnow.sdk.util;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;

import de.idnow.sdk.network.IDNowWebViewClient;

import androidx.annotation.Nullable;
import okhttp3.OkHttpClient;

/**
 * Created by Mathias Grasy on 05.08.2015.
 */
public class Util_Custom_WebViewClient extends IDNowWebViewClient
{

	private final Context context;
	private final String LOGTAG = "IDNOW_Util_Custom_WebViewClient";
	private final String WEBVIEW_SHALL_OPEN_EXTRERNALLY = "openExternally";

	public Util_Custom_WebViewClient(Context context)
	{
		this.context = context;
	}

	@Override
	public boolean shouldOverrideUrlLoading( WebView view, String url )
	{
		if (url != null) {
			Uri targetUrl = Uri.parse(url);
			if (targetUrl.getQueryParameter(WEBVIEW_SHALL_OPEN_EXTRERNALLY) != null) {
				return handleLoadingInBrowser(view, url);
			}
		}

		return handleNormalLoading(view, url);
		/* just for testing
		// show the contract
		if ( url.equals( "https://www.google.de/webhp?output=search&tbm=isch&tbo=u" ) )
		{
			( ( Activities_VideoLiveStreamActivity ) context ).showContract();
		}
		// decline the contract
		else if ( url.equals( "https://www.google.de/webhp?output=search" ) )
		{
			( ( Activities_VideoLiveStreamActivity ) context ).declineContract();
		}
		else
		{ */
	}

	protected boolean handleNormalLoading(WebView view, String url) {
		Util_Log.d(LOGTAG, "WebView wants to open: " + url);
		view.loadUrl(url);
		return false;
	}

	protected boolean handleLoadingInBrowser(WebView view, String url) {
		Util_Log.d(LOGTAG, "WebView wants to open in a new window: " + url);
		view.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
		return true;
	}

	@Override
	public void onPageStarted( WebView view, String url, Bitmap favicon )
	{
		super.onPageStarted( view, url, favicon );
	}
}

