package de.idnow.sdk.models;


/**
 * @author Mathias Grasy
 * @version 1.0
 * @brief is received from the server (/api/v1/{transactionToken} call) as attribute of the OfficeHours object
 */

public class Models_Company
{

	String name;

	public Models_Company( String name )
	{
		this.name = name;
	}

	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName( String name )
	{
		this.name = name;
	}
}
