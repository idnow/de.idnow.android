package de.idnow.sdk.models;

import java.util.List;
import java.util.Map;



/**
 * @date 06.11.2014
 * @author Mathias Grasy
 * @brief this class is used to store the photoDataHolder settings into the shared preferences.
 * 
 */


public class Models_PhotoDataHolderData
{
	private Map<String, List<String>>	documentListToCountryname;
	private Map<String, List<String>>	documentImageTypesToDocument;

	private List<String>				countryList;
	private List<String>				countryISOCodeList;

	private String						selectedCountry			= "";
	private String						selectedDocument		= "";

	private String						selectedDocumentImageType	= "";

	private Map<String, Boolean>		imageDocumentTakenHashMap;
	private Map<String, String>			imageFilenameToImageDocumentHashMap;

	/**
	 * @param documentListToCountryname
	 * @param countryList
	 * @param countryISOCodeList
	 * @param selectedCountry
	 * @param selectedDocument
	 * @param imageDocumentTakenHashMap
	 * @param imageFilenameToImageDocumentHashMap
	 */
	public Models_PhotoDataHolderData( Map<String, List<String>> documentListToCountryname,Map<String, List<String>> documentImageTypesToDocument,
			List<String> countryList, List<String> countryISOCodeList,  String selectedCountry,
			String selectedDocument, Map<String, Boolean> imageDocumentTakenHashMap,
			Map<String, String> imageFilenameToImageDocumentHashMap, String selectedDocumentImageType )
	{
		super();
		this.documentListToCountryname = documentListToCountryname;
		this.documentImageTypesToDocument = documentImageTypesToDocument;
		this.countryList = countryList;
		this.countryISOCodeList = countryISOCodeList;
		this.selectedCountry = selectedCountry;
		this.selectedDocument = selectedDocument;
		this.imageDocumentTakenHashMap = imageDocumentTakenHashMap;
		this.imageFilenameToImageDocumentHashMap = imageFilenameToImageDocumentHashMap;
		this.selectedDocumentImageType = selectedDocumentImageType;
	}

	/**
	 * @return the documentListToCountryname
	 */
	public Map<String, List<String>> getDocumentListToCountryname()
	{
		return documentListToCountryname;
	}

	/**
	 * @param documentListToCountryname the documentListToCountryname to set
	 */
	public void setDocumentListToCountryname( Map<String, List<String>> documentListToCountryname )
	{
		this.documentListToCountryname = documentListToCountryname;
	}

	/**
	 * @return the countryList
	 */
	public List<String> getCountryList()
	{
		return countryList;
	}

	/**
	 * @param countryList the countryList to set
	 */
	public void setCountryList( List<String> countryList )
	{
		this.countryList = countryList;
	}

	/**
	 * @return the countryISOCodeList
	 */
	public List<String> getCountryISOCodeList()
	{
		return countryISOCodeList;
	}

	/**
	 * @param countryISOCodeList the countryISOCodeList to set
	 */
	public void setCountryISOCodeList( List<String> countryISOCodeList )
	{
		this.countryISOCodeList = countryISOCodeList;
	}


	/**
	 * @return the selectedCountry
	 */
	public String getSelectedCountry()
	{
		return selectedCountry;
	}

	/**
	 * @param selectedCountry the selectedCountry to set
	 */
	public void setSelectedCountry( String selectedCountry )
	{
		this.selectedCountry = selectedCountry;
	}

	/**
	 * @return the selectedDocument
	 */
	public String getSelectedDocument()
	{
		return selectedDocument;
	}

	/**
	 * @param selectedDocument the selectedDocument to set
	 */
	public void setSelectedDocument( String selectedDocument )
	{
		this.selectedDocument = selectedDocument;
	}

	/**
	 * @return the imageDocumentTakenHashMap
	 */
	public Map<String, Boolean> getImageDocumentTakenHashMap()
	{
		return imageDocumentTakenHashMap;
	}

	/**
	 * @param imageDocumentTakenHashMap the imageDocumentTakenHashMap to set
	 */
	public void setImageDocumentTakenHashMap( Map<String, Boolean> imageDocumentTakenHashMap )
	{
		this.imageDocumentTakenHashMap = imageDocumentTakenHashMap;
	}

	/**
	 * @return the imageFilenameToImageDocumentHashMap
	 */
	public Map<String, String> getImageFilenameToImageDocumentHashMap()
	{
		return imageFilenameToImageDocumentHashMap;
	}

	/**
	 * @param imageFilenameToImageDocumentHashMap the imageFilenameToImageDocumentHashMap to set
	 */
	public void setImageFilenameToImageDocumentHashMap( Map<String, String> imageFilenameToImageDocumentHashMap )
	{
		this.imageFilenameToImageDocumentHashMap = imageFilenameToImageDocumentHashMap;
	}

	public Map<String, List<String>> getDocumentImageTypesToDocument() {
		return documentImageTypesToDocument;
	}

	public void setDocumentImageTypesToDocument(Map<String, List<String>> documentImageTypesToDocument) {
		this.documentImageTypesToDocument = documentImageTypesToDocument;
	}


	public String getSelectedDocumentImageType() {
		return selectedDocumentImageType;
	}

	public void setSelectedDocumentImageType(String selectedDocumentImageType) {
		this.selectedDocumentImageType = selectedDocumentImageType;
	}


}
