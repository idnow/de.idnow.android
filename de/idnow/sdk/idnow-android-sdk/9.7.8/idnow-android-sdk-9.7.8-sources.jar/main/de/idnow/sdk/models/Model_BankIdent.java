package de.idnow.sdk.models;

public class Model_BankIdent {
    private boolean enabled;

    public Model_BankIdent() {
    }

    public Model_BankIdent(Boolean enabled) {
        this.enabled = enabled;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }
}
