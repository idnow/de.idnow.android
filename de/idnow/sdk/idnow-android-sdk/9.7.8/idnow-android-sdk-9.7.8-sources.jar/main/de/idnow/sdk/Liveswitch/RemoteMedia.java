package de.idnow.sdk.Liveswitch;

import android.content.Context;
import android.widget.FrameLayout;

import de.idnow.sdk.util.Util_Log;
import fm.liveswitch.AecContext;
import fm.liveswitch.AudioConfig;
import fm.liveswitch.AudioDecoder;
import fm.liveswitch.AudioFormat;
import fm.liveswitch.AudioSink;
import fm.liveswitch.IAction0;
import fm.liveswitch.IAction1;
import fm.liveswitch.LayoutScale;
import fm.liveswitch.NullAudioSink;
import fm.liveswitch.NullVideoSink;
import fm.liveswitch.SourceInput;
import fm.liveswitch.VideoDecoder;
import fm.liveswitch.VideoFormat;
import fm.liveswitch.VideoFrame;
import fm.liveswitch.VideoPipe;
import fm.liveswitch.VideoSink;
import fm.liveswitch.ViewSink;
import fm.liveswitch.android.OpenGLSink;

public class RemoteMedia extends fm.liveswitch.RtcRemoteMedia<FrameLayout> {

    private final String LOGTAG = "IDNOW_RemoteMedia";

    private final boolean enableSoftwareH264;
    private final Context context;

    public RemoteMedia(final Context context, boolean enableSoftwareH264, boolean disableAudio, boolean disableVideo, AecContext aecContext) {
        super(disableAudio, disableVideo, aecContext);
        this.context = context;
        this.enableSoftwareH264 = enableSoftwareH264;

        super.initialize();

//        addStateLogging();
    }

    @Override
    protected ViewSink<FrameLayout> createViewSink()
    {
        OpenGLSink openGLSink = new OpenGLSink(context, LayoutScale.Cover);
        return openGLSink;
    }

    @Override
    protected AudioSink createAudioRecorder(AudioFormat audioFormat) {
        return new NullAudioSink();
    }

    @Override
    protected VideoSink createVideoRecorder(VideoFormat videoFormat) {
        return new NullVideoSink();
    }

    @Override
    protected VideoPipe createImageConverter(VideoFormat videoFormat) {
        return new fm.liveswitch.yuv.ImageConverter(videoFormat);
    }

    @Override
    protected AudioDecoder createOpusDecoder(AudioConfig audioConfig) {
        return new fm.liveswitch.opus.Decoder(audioConfig);
    }

    @Override
    protected AudioSink createAudioSink(AudioConfig audioConfig) {
        return new fm.liveswitch.android.AudioTrackSink(audioConfig);
    }

    @Override
    protected VideoDecoder createH264Decoder() {
        if (enableSoftwareH264) {
            return new fm.liveswitch.openh264.Decoder();
        } else {
            return null;
        }
    }

    @Override
    protected VideoDecoder createVp8Decoder() {
        return new fm.liveswitch.vp8.Decoder();
    }

    @Override
    protected VideoDecoder createVp9Decoder() {
        return new fm.liveswitch.vp9.Decoder();
    }

    public void addStateLogging() {
        this.getAudioTrack().addOnStarted(new IAction0() {
            @Override
            public void invoke() {
                Util_Log.i(LOGTAG, "remote audio track started");
            }
        });
        this.getAudioTrack().addOnStopped(new IAction0() {
            @Override
            public void invoke() {
                Util_Log.i(LOGTAG, "remote audio track stopped");
            }
        });
        this.getVideoTrack().addOnStarted(new IAction0() {
            @Override
            public void invoke() {
                Util_Log.i(LOGTAG, "remote video track started");
            }
        });
        this.getVideoTrack().addOnStopped(new IAction0() {
            @Override
            public void invoke() {
                Util_Log.i(LOGTAG, "remote video track stopped");
            }
        });

        this.addOnActiveAudioSinkChange(new IAction1<AudioSink>() {
            @Override
            public void invoke(AudioSink audioSink) {
                Util_Log.d(LOGTAG, "Sink changed: " + audioSink.toString());
            }
        });

        this.getVideoTrack().getSourceInputs().then(new IAction1<SourceInput[]>() {
            @Override
            public void invoke(SourceInput[] sourceInputs) {
                for (SourceInput sourceInput : sourceInputs) {
                    Util_Log.d(LOGTAG, "sourceInputs: " + sourceInput.toJson());
                }
            }
        });

        this.getVideoTrack().getInput().addOnProcessFrame(new IAction1<VideoFrame>() {
            @Override
            public void invoke(VideoFrame videoFrame) {
                if (videoFrame.getRtpSequenceNumber() % 100 == 0)
                    Util_Log.i(LOGTAG, "getVideoTrack().getInput().addOnProcessFrame === " + videoFrame.getRtpSequenceNumber());
            }
        });

        this.getVideoTrack().getActiveSink().getInput().addOnRaiseFrame(new IAction1<VideoFrame>() {
            @Override
            public void invoke(VideoFrame videoFrame) {
                if (videoFrame.getRtpSequenceNumber() % 100 == 0)
                    Util_Log.i(LOGTAG, "getVideoTrack().getActiveSink().getInput().addOnRaiseFrame === " + videoFrame.getRtpSequenceNumber());
            }
        });

        addOnVideoDestroyed(new IAction0() {
            @Override
            public void invoke() {
                Util_Log.i(LOGTAG, "addOnVideoDestroyed !!!");
            }
        });
    }
}
