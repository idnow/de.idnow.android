package de.idnow.sdk.util;

import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;

import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.ViewPager;

import de.idnow.sdk.Adapters.Adapter_WaitScreenViewPager;
import de.idnow.sdk.Config;
import de.idnow.sdk.Fragment_WaitScreenItem;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.views.CircleIndicator;

public class UI_WaitScreen {

    private final FragmentActivity activity;
    private ViewGroup parentView;

    private View rootView;
    private View poweredByView;

    private ViewPagerCustomDuration waitScreenViewPager;
    private CircleIndicator pageIndicator;
    private Fragment_WaitScreenItem currentAdapterPageScreen;

    public UI_WaitScreen(FragmentActivity activity) {
        this.activity = activity;
    }

    public void inflateView(ViewGroup parent) {
        this.parentView = parent;

        getViewToInflate();
        parentView.addView(rootView);

        initializeViews(rootView);
        setupAdapter();
        disablePagerInteraction();
    }

    public void removeView() {
        if (currentAdapterPageScreen != null) {
            currentAdapterPageScreen.stopAnimation();
        }

        parentView.removeView(rootView);
        parentView.removeView(poweredByView);
    }

    private View getViewToInflate() {
        rootView = activity.getLayoutInflater().inflate(R.layout.view_wait_screen, null);

        rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (IDnowSDK.getShowPoweredBy()) {
                    preparePoweredByLayout();
                }

                rootView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });

        return rootView;
    }

    private void preparePoweredByLayout() {
        poweredByView = activity.getLayoutInflater().inflate(R.layout.powered_by_layout, null);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.BOTTOM;
        params.bottomMargin = waitScreenViewPager.getHeight() + pageIndicator.getHeight();

        poweredByView.setLayoutParams(params);

        parentView.addView(poweredByView);
    }

    private void initializeViews(View rootView) {
        if (rootView != null) {
            waitScreenViewPager = rootView.findViewById(R.id.waiting_screen_view_pager);
            pageIndicator = rootView.findViewById(R.id.waiting_screen_pager_indicator);
        }
    }

    private void setupAdapter() {
        final Adapter_WaitScreenViewPager viewPagerAdapter =
                new Adapter_WaitScreenViewPager(activity.getSupportFragmentManager());
        waitScreenViewPager.setScrollDuration(Config.WAITING_SCREEN_PAGE_TRANSITION_DURATION_IN_MS);
        waitScreenViewPager.setAdapter(viewPagerAdapter);
        waitScreenViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                currentAdapterPageScreen = ((Fragment_WaitScreenItem)
                        viewPagerAdapter.instantiateItem(waitScreenViewPager, position));

                currentAdapterPageScreen.playAnimation();
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        pageIndicator.setViewPager(waitScreenViewPager);
    }

    private void disablePagerInteraction() {
        waitScreenViewPager.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });
    }

    public void displayNextPage(int nextPageNumber) {

        Handler handler = new Handler();
        handler.post(new Runnable()
        {
            @Override
            public void run()
            {
                waitScreenViewPager.setCurrentItem(nextPageNumber == Enum_WaitScreens.values().length ? 0 : nextPageNumber, true);
            }
        });

    }
}
