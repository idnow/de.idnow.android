package de.idnow.sdk.util

import android.content.Context
import android.util.TypedValue
import androidx.annotation.DimenRes

internal class ResourceHelper(
    private val context: Context
) {
    fun getFloatDimen(@DimenRes id: Int): Float {
        val outValue = TypedValue()
        context.resources.getValue(id, outValue, true)
        return outValue.float
    }
}