package de.idnow.sdk.network.connectivityService.models

import android.net.Network

internal data class ConnectivityState(
    val hasInternetAccess: Boolean = false,
    val networks: Set<Network> = emptySet(),
    val mainNetworkType: NetworkType = NetworkType.Unknown,
) {
    fun isOnline(): Boolean {
        return networks.isNotEmpty() && hasInternetAccess
    }
}
