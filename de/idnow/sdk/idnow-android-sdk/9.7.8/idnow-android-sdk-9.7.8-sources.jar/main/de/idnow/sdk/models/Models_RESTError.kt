package de.idnow.sdk.models;


/**
 * @author Mathias Grasy
 * @version 1.0
 * @date 10.10.2014
 * @brief received from the server, when an error appeared. contains the cause of the error and a message.
 */


data class Models_RESTError(
    val id: Int = -1,
    val cause: String = "",
    val errorType: String = "",
    val key: String = "",
    val message: String = ""
)
