package de.idnow.sdk.models;

public class Models_WaitingList
{
	Models_WaitingListNotification android;
	Models_WaitingListNotification ios;
	int waitingListTimeOut;
	int waitingQueueTreshold;
	int waitingQueueForcedTreshold;

	public Models_WaitingList(int waitingQueueTreshold, Models_WaitingListNotification android, int waitingListTimeOut, Models_WaitingListNotification ios )
	{
		super();
		this.waitingQueueTreshold = waitingQueueTreshold;
		this.android = android;
		this.waitingListTimeOut = waitingListTimeOut;
		this.ios = ios;
	}

	public Models_WaitingListNotification getAndroid() {
		return android;
	}

	public void setAndroid(Models_WaitingListNotification android) {
		this.android = android;
	}

	public Models_WaitingListNotification getIos() {
		return ios;
	}

	public void setIos(Models_WaitingListNotification ios) {
		this.ios = ios;
	}

	public int getWaitingListTimeOut() {
		return waitingListTimeOut;
	}

	public void setWaitingListTimeOut(int waitingListTimeOut) {
		this.waitingListTimeOut = waitingListTimeOut;
	}

	public int getWaitingQueueTreshold() {
		return waitingQueueTreshold;
	}

	public void setWaitingQueueTreshold(int waitingQueueThresold) {
		this.waitingQueueTreshold = waitingQueueTreshold;
	}


	public int getWaitingQueueForcedTreshold(){ return waitingQueueForcedTreshold; }


	public void setWaitingQueueForcedTreshold(int waitingQueueForcedTreshold) {
		this.waitingQueueForcedTreshold = waitingQueueForcedTreshold;
	}




}
