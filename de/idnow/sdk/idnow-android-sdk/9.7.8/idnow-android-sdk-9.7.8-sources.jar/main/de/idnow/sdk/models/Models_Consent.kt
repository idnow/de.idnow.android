package de.idnow.sdk.models

data class Models_Consent(val consentValue: Boolean)