package de.idnow.sdk.models;


import com.google.gson.annotations.SerializedName;

/**
 * @author Mathias Grasy
 * @version 1.0
 * @date 10.10.2014
 */


public class Models_StartObjectResult
{
	public String         token;
	public String         mobile;
	public String         email;
	public String         status;
	public int			  remainingInternalTokenRetries;
	public Models_Request request;
	public Models_Data data;

	@SerializedName("enableOTP")
	public Models_EnableOTP enableOTP;

	@SerializedName("enableOTPForWallet")
	public Models_OTPForWallet enableOTPForWallet;

	public Models_StartObjectResult( String token, String status, String email, String mobile, int remainingInternalTokenRetries, Models_Request request, Models_Data data )
	{
		this.token = token;
		this.data = data;
		this.status = status;
		this.email = email;
		this.remainingInternalTokenRetries = remainingInternalTokenRetries;
		this.mobile = mobile;
		this.request = request;
	}

	public Models_StartObjectResult(String token, String mobile, String email, String status, int remainingInternalTokenRetries, Models_Request request, Models_Data data, Models_EnableOTP enableOTP) {
		this.token = token;
		this.mobile = mobile;
		this.email = email;
		this.status = status;
		this.remainingInternalTokenRetries = remainingInternalTokenRetries;
		this.request = request;
		this.data = data;
		this.enableOTP = enableOTP;
	}

	public Models_StartObjectResult(String token, String mobile, String email, String status, int remainingInternalTokenRetries, Models_Request request, Models_Data data, Models_EnableOTP enableOTP, Models_OTPForWallet enableOTPForWallet) {
		this.token = token;
		this.mobile = mobile;
		this.email = email;
		this.status = status;
		this.remainingInternalTokenRetries = remainingInternalTokenRetries;
		this.request = request;
		this.data = data;
		this.enableOTP = enableOTP;
		this.enableOTPForWallet = enableOTPForWallet;
	}

	public Models_OTPForWallet getEnableOTPForWallet() {
		return enableOTPForWallet;
	}

	public void setEnableOTPForWallet(Models_OTPForWallet enableOTPForWallet) {
		this.enableOTPForWallet = enableOTPForWallet;
	}

	public void setTransactionToken(String token )
	{
		this.token = token;
	}

	public int getRemainingInternalTokenRetries() {
		return remainingInternalTokenRetries;
	}

	public void setRemainingInternalTokenRetries(int remainingInternalTokenRetries) {
		this.remainingInternalTokenRetries = remainingInternalTokenRetries;
	}

	public Models_Request getRequest() {
		return request;
	}

	public void setRequest(Models_Request request) {
		this.request = request;
	}

	public Models_EnableOTP getEnableOTP() {
		return enableOTP;
	}

	public void setEnableOTP(Models_EnableOTP enableOTP) {
		this.enableOTP = enableOTP;
	}

	@Override
	public String toString() {
		return "Models_StartObjectResult{" +
				"token='" + token + '\'' +
				", mobile='" + mobile + '\'' +
				", email='" + email + '\'' +
				", status='" + status + '\'' +
				", remainingInternalTokenRetries=" + remainingInternalTokenRetries +
				", request=" + request +
				", data=" + data +
				", enableOTP=" + enableOTP +
				'}';
	}
}
