package de.idnow.sdk.models;

import java.util.Collections;
import java.util.List;

/**
 * @author Mathias Grasy
 * @version 1.0
 * @date 10.10.2014
 * @brief is received from the server (/api/v1/{transactionToken} call)
 */

public class Models_OfficeHours {
    List<Models_OfficeHour> officeHours;
    boolean officeOpen;

    // bank info
    String shortname;
    String shortcode;
    String name;

    String highCallVolumeMessage;

    boolean waitingListNotified;

    // waiting queue
    int estimatedWaitingTime;
    int numberOfWaitingChatRequests;

    List<String> availableLanguages;

    Models_Settings settings;

    Models_Company company;

    public Models_OfficeHours() {
    }

    public Models_OfficeHours(String shortname, String shortcode, String name, Models_Company company, List<Models_OfficeHour> officeHours,
                              boolean officeOpen, Models_Settings settings) {
        this.officeHours = officeHours;
        this.officeOpen = officeOpen;
        this.shortcode = shortcode;
        this.shortname = shortname;
        this.company = company;
        this.settings = settings;
    }

    /**
     * this message is shown, when no agent takes the call after a specified period of time. this message can be set by the server.
     *
     * @return
     */
    public String getHighCallVolumeMessage() {
        return highCallVolumeMessage;
    }

    /**
     * @return the settings
     */
    public Models_Settings getSettings() {
        return settings;
    }

    /**
     * @param settings the settings to set
     */
    public void setSettings(Models_Settings settings) {
        this.settings = settings;
    }

    /**
     * @return the shortname
     */
    public String getShortname() {
        return shortname;
    }

    /**
     * @param shortname the shortname to set
     */
    public void setShortname(String shortname) {
        this.shortname = shortname;
    }

    /**
     * @return the shortcode
     */
    public String getShortcode() {
        return shortcode;
    }

    /**
     * @param shortcode the shortcode to set
     */
    public void setShortcode(String shortcode) {
        this.shortcode = shortcode;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the company
     */
    public Models_Company getCompany() {
        return company;
    }

    /**
     * @param company the company to set
     */
    public void setCompany(Models_Company company) {
        this.company = company;
    }

    /**
     * @return the officeOpen
     */
    public boolean isOfficeOpen() {
        return officeOpen;
    }

    /**
     * @param officeOpen the officeOpen to set
     */
    public void setOfficeOpen(boolean officeOpen) {
        this.officeOpen = officeOpen;
    }

    /**
     * @return the officeHours
     */
    public List<Models_OfficeHour> getOfficeHours() {
        return officeHours;
    }

    /**
     * @param officeHours the officeHours to set
     */
    public void setOfficeHours(List<Models_OfficeHour> officeHours) {
        this.officeHours = officeHours;
    }

    public int getEstimatedWaitingTime() {
        return estimatedWaitingTime < 0 ? 0 : estimatedWaitingTime;
    }

    public int getNumberOfWaitingChatRequests() {
        return numberOfWaitingChatRequests < 0 ? 0 : numberOfWaitingChatRequests;
    }

    public boolean isWaitingListNotified() {
        return waitingListNotified;
    }

    public List<String> getAvailableLanguages() {
        if (availableLanguages == null) {
            return Collections.emptyList();
        }
        return availableLanguages;
    }

    public void setAvailableLanguages(List<String> availableLanguages) {
        this.availableLanguages = availableLanguages;
    }
}
