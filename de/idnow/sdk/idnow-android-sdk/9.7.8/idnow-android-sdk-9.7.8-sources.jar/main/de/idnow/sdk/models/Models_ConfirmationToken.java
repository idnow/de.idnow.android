package de.idnow.sdk.models;



/**
 * @author Mathias Grasy
 * @version 1.0
 * @brief is send to the server during the identification process
 */


public class Models_ConfirmationToken
{
	String	confirmationToken;

	public Models_ConfirmationToken( String token )
	{
		this.confirmationToken = token;
	}

	public void setToken( String token )
	{
		this.confirmationToken = token;
	}

	public String getToken()
	{
		return confirmationToken;
	}
}
