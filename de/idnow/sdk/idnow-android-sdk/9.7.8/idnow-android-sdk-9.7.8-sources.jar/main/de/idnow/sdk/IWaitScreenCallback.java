package de.idnow.sdk;

import de.idnow.sdk.util.UI_SMSWaitScreen;

public interface IWaitScreenCallback {

    void onAnimationCompleted(int currentPage);

    void onSMSFlowCompleted();

    void onUpdateMobilePhoneNumber(CharSequence phoneNo, UI_SMSWaitScreen ui_smsWaitScreen);
}
