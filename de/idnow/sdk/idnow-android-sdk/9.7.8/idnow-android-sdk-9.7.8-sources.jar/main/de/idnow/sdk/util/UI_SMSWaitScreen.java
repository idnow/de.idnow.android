package de.idnow.sdk.util;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.media.MediaPlayer;
import android.net.Uri;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.style.UnderlineSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import com.airbnb.lottie.LottieAnimationView;

import androidx.fragment.app.FragmentActivity;

import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_Super;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.IWaitScreenCallback;
import de.idnow.sdk.R;

import static de.idnow.sdk.util.Util_CustomLogData.EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_CROSS_BTN;

public class UI_SMSWaitScreen {

    private final FragmentActivity activity;
    private IWaitScreenCallback callback;

    private ViewGroup parent;
    private View rootView;
    private View poweredByView;

    private LottieAnimationView busyVideoAnimation;
    private TextView smsTitle;
    private TextView busyTitle;
    private TextView description;
    private EditText mobileNumberEditText;
    private Button notifyBtn;
    private Button waitBtn;
    private ClickableTextView waitClickableText;

    public UI_SMSWaitScreen(FragmentActivity activity) {
        this.activity = activity;
        if (activity instanceof Activities_VideoLiveStreamActivity_Super) {
            callback = (IWaitScreenCallback) activity;
        }
    }

    public void inflateView(ViewGroup parent) {
        this.parent = parent;

        View viewToInflate = getViewToInflate();
        parent.addView(viewToInflate, viewToInflate.getLayoutParams());

        initializeViews(rootView);
        setupItems();
    }

    public void removeView() {
        parent.removeView(rootView);
        parent.removeView(poweredByView);
    }

    private View getViewToInflate() {
        rootView = activity.getLayoutInflater().inflate(R.layout.view_wait_screen_sms, null);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.BOTTOM;
        params.topMargin = 0;

        rootView.setLayoutParams(params);

        rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (IDnowSDK.getShowPoweredBy()) {
                    preparePoweredByLayout();
                }

                rootView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });

        return rootView;
    }

    private void preparePoweredByLayout() {
        poweredByView = activity.getLayoutInflater().inflate(R.layout.powered_by_layout, null);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.BOTTOM;
        params.bottomMargin = rootView.getHeight();

        poweredByView.setLayoutParams(params);

        parent.addView(poweredByView);
    }

    private void initializeViews(View rootView) {
        if (rootView != null) {
            busyVideoAnimation = rootView.findViewById(R.id.wait_fragment_busy_animation);
            busyTitle = rootView.findViewById(R.id.wait_screen_busy_info);
            smsTitle = rootView.findViewById(R.id.wait_screen_sms_title);
            description = rootView.findViewById(R.id.wait_screen_sms_description);

            mobileNumberEditText = rootView.findViewById(R.id.wait_screen_sms_edit_text);
            notifyBtn = rootView.findViewById(R.id.wait_screen_sms_notify_button);
            waitBtn = rootView.findViewById(R.id.wait_screen_sms_wait_button);
            waitClickableText = rootView.findViewById(R.id.wait_screen_sms_clickable_text);
        }
    }

    private void setupItems() {
        populateTextElements();
        setupPhoneNumberEditText();

        displayWaitingListScreen();
        setupPlaceInListButton();
        setupClickableText();
        setupWaitBtn();
    }

    private void populateTextElements() {
        busyTitle.setText(IDnowSDK.getInstance().getStringWithDefault(activity,Util_Strings.KEY_WAITING_SCREEN_AGENT_BUSY,Util_Strings.LOCAL_KEY_WAITING_SCREEN_AGENT_BUSY));
        smsTitle.setText(IDnowSDK.getInstance().getStringWithDefault(activity,Util_Strings.KEY_WAITING_SCREEN_SMS_TITLE,Util_Strings.LOCAL_KEY_WAITING_SCREEN_SMS_TITLE));
        description.setText(IDnowSDK.getInstance().getStringWithDefault(activity,Util_Strings.KEY_WAITING_SCREEN_MSG_WISH_NOTIFIED,Util_Strings.LOCAL_KEY_WAITING_SCREEN_MSG_WISH_NOTIFIED));
    }

    private void setupPhoneNumberEditText() {
        if(!Config.MASKED_USER_PHONE_NO.equals("")){
            mobileNumberEditText.setText(Config.MASKED_USER_PHONE_NO);
            mobileNumberEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View view, boolean b) {
                    if(b&&mobileNumberEditText.getText().toString().contains("***")){

                        mobileNumberEditText.getText().clear();
                    }
                    else {
                        if(!b&&mobileNumberEditText.getText().toString().equals("")) {
                            mobileNumberEditText.setText(Config.MASKED_USER_PHONE_NO);
                        }     }}
            });
        }
        else {
            mobileNumberEditText.setText(Config.USER_PHONE_NO);
        }
        //TODO we should align this with iOS, which currently are disabling this textview every time.
        if (Config.MOBILE_NUMBER_CHANGE_DISABLED) {
            mobileNumberEditText.setEnabled(false);
        }
        mobileNumberEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                notifyBtn.setEnabled(Util_Util.isPhoneValid(String.valueOf(s)));
                Util_UtilUI.setProceedButtonBackgroundSelector(notifyBtn);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void setupPlaceInListButton() {
        Util_UtilUI.setProceedButtonBackgroundSelector(notifyBtn);
//        notifyBtn.setText(activity.getString(R.string.sms_retrypushbutton_tile));
        notifyBtn.setText(IDnowSDK.getInstance().getStringWithDefault(activity,Util_Strings.KEY_WAITING_SCREEN_ACTION_ENROLL,Util_Strings.LOCAL_KEY_WAITING_SCREEN_ACTION_ENROLL));

        notifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displaySMSScreen();
            }
        });
    }

    private void setupNotifyBtn() {
        Util_UtilUI.setProceedButtonBackgroundSelector(notifyBtn);
        notifyBtn.setText(IDnowSDK.getInstance().getStringWithDefault(activity, Util_Strings.KEY_WAITNG_SCREEN_ACTION_NOTIFY_SMS,Util_Strings.LOCAL_KEY_WAITNG_SCREEN_ACTION_NOTIFY_SMS));
//        notifyBtn.setText(activity.getString(R.string.waiting_list_place_button_title));
        notifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callback != null) {
                    if(!mobileNumberEditText.getText().toString().contains("***")){
                        Config.USER_PHONE_NO = mobileNumberEditText.getText().toString();
                    }
                    Util_CustomLogData.setEventData(Util_CustomLogData.EVENT_WAITING_LIST_PUSH_SUCCESS_SCREEN_SHOWN,"EVENT_WAITING_LIST_PUSH_SUCCESS_SCREEN_SHOWN", "Waiting list (Push notification)", "Screen",null);
                    callback.onUpdateMobilePhoneNumber(Config.USER_PHONE_NO, UI_SMSWaitScreen.this);
                }
            }
        });
    }

    private void setupWaitBtn() {
        Util_UtilUI.setProceedButtonBackgroundSelector(waitBtn);
        waitBtn.setText(IDnowSDK.getInstance().getStringWithDefault(activity,Util_Strings.KEY_WAITING_SCREEN_OK_WAIT,Util_Strings.LOCAL_KEY_WAITING_SCREEN_OK_WAIT));
        waitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callback != null) {
//                    ((Activities_VideoLiveStreamActivity_Super) activity).identificationCanceledRESTCall();
//                    ((Activities_VideoLiveStreamActivity_Super) activity).returnFromSDK();
//                    ((Activities_VideoLiveStreamActivity_Super) activity).openPushSuccessPanel();
//                    ((Activities_VideoLiveStreamActivity_Super) activity).hideWaitingScreen();
                    ((Activities_VideoLiveStreamActivity_Super) activity).confirmWaitAndReturn();


                }
            }
        });
    }

    private void setupClickableText() {
        SpannableString content = new SpannableString(IDnowSDK.getInstance().getStringWithDefault(activity,Util_Strings.KEY_WAITING_SCREEN_ACTION_NO_WAIT,Util_Strings.LOCAL_KEY_WAITING_SCREEN_ACTION_NO_WAIT));
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        waitClickableText.setText(content);
        waitClickableText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callback != null) {
                    Util_CustomLogData.setEventData(EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_CROSS_BTN,"EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_CROSS_BTN", "Waiting list (Push notification)", "Button click events",null);
                    callback.onSMSFlowCompleted();
                }
            }
        });
    }

    private void displayWaitingListScreen() {

        if(Config.SHOULD_DISPLAY_WAITING_SCREEN) {
            busyVideoAnimation.setVisibility(View.VISIBLE);
            busyVideoAnimation.setAnimation("animate_agentsBusy.json");
            busyVideoAnimation.playAnimation();

            busyTitle.setVisibility(View.VISIBLE);

            smsTitle.setVisibility(View.GONE);
            description.setVisibility(View.GONE);

            mobileNumberEditText.setVisibility(View.GONE);
            waitBtn.setVisibility(View.GONE);

            notifyBtn.setText(IDnowSDK.getInstance().getStringWithDefault(activity,Util_Strings.KEY_WAITING_SCREEN_ACTION_ENROLL,Util_Strings.LOCAL_KEY_WAITING_SCREEN_ACTION_ENROLL));
            notifyBtn.setVisibility(View.VISIBLE);
            waitClickableText.setVisibility(View.VISIBLE);
        }
    }


    private void displaySMSScreen() {

        setupNotifyBtn();

        busyVideoAnimation.setVisibility(View.GONE);
        busyTitle.setVisibility(View.GONE);

        smsTitle.setText(IDnowSDK.getInstance().getStringWithDefault(activity,Util_Strings.KEY_WAITING_SCREEN_SMS_TITLE,Util_Strings.LOCAL_KEY_WAITING_SCREEN_SMS_TITLE));

        smsTitle.setVisibility(View.VISIBLE);
        description.setVisibility(View.VISIBLE);

        mobileNumberEditText.setVisibility(View.VISIBLE);
        waitBtn.setVisibility(View.GONE);

        notifyBtn.setVisibility(View.VISIBLE);
        waitClickableText.setVisibility(View.VISIBLE);
    }

    public void displayConfirmationScreen() {
        smsTitle.setText(IDnowSDK.getInstance().getStringWithDefault(activity,Util_Strings.KEY_WAITING_SCREEN_WAITING_LIST_CONFIRM,Util_Strings.LOCAL_KEY_WAITING_SCREEN_WAITING_LIST_CONFIRM));

        busyVideoAnimation.setVisibility(View.GONE);
        busyTitle.setVisibility(View.GONE);

        description.setText(IDnowSDK.getInstance().getStringWithDefault(activity,Util_Strings.KEY_WAITING_SCREEN_WAITING_LIST_DESC,Util_Strings.LOCAL_KEY_WAITING_SCREEN_WAITING_LIST_DESC));
        description.setVisibility(View.VISIBLE);

        mobileNumberEditText.setVisibility(View.GONE);
        waitClickableText.setVisibility(View.GONE);

        notifyBtn.setVisibility(View.GONE);
        waitBtn.setVisibility(View.VISIBLE);
    }

    public void playAnimation() {
        if (busyVideoAnimation.getVisibility() == View.VISIBLE) {
            busyVideoAnimation.setRepeatCount(ValueAnimator.INFINITE);
            busyVideoAnimation.playAnimation();
        }
    }
}
