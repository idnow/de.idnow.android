package de.idnow.sdk.util

internal data class RemoteAnimationsCollection(
    val animations: Map<String, String> = emptyMap()
) {
    fun find(key: String): String? {
        return animations[key]
    }
}
