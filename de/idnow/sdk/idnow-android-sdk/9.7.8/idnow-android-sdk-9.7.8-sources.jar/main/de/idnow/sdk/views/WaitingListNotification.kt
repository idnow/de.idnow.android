package de.idnow.sdk.views

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.EditText
import androidx.core.view.isVisible
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.databinding.ViewLiveScreenPushNotificationBinding
import de.idnow.sdk.util.Util_Strings

class WaitingListNotification @JvmOverloads constructor(
    context: Context,
    attributeSet: AttributeSet? = null,
) : AnimationAverseLinearLayout(context, attributeSet) {

    private val binding: ViewLiveScreenPushNotificationBinding
    val waitScreenEditText: EditText

    init {
        binding =
            ViewLiveScreenPushNotificationBinding.inflate(LayoutInflater.from(context), this, true)
        waitScreenEditText = binding.waitScreenSmsEditText

        binding.notifyViaPushTitle.text = Util_Strings.getStringWithDefault(
            context,
            Util_Strings.KEY_VIDEO_IDENT_WAITING_LIST_SUCCESS_PUSH_TITLE,
            Util_Strings.LOCAL_KEY_VIDEO_IDENT_WAITING_LIST_SUCCESS_PUSH_TITLE
        )
        binding.waitScreenSmsTitle.text = IDnowSDK.getInstance().getStringWithDefault(
            context,
            Util_Strings.KEY_WAITING_SCREEN_SMS_TITLE,
            Util_Strings.LOCAL_KEY_WAITING_SCREEN_SMS_TITLE
        )
        binding.waitScreenSmsDescription.text = IDnowSDK.getInstance().getStringWithDefault(
            context,
            Util_Strings.KEY_WAITING_SCREEN_MSG_WISH_NOTIFIED,
            Util_Strings.LOCAL_KEY_WAITING_SCREEN_MSG_WISH_NOTIFIED
        )
        binding.waitScreenSmsNotifyButton.text = IDnowSDK.getInstance().getStringWithDefault(
            context,
            Util_Strings.KEY_WAITNG_SCREEN_ACTION_NOTIFY_SMS,
            Util_Strings.LOCAL_KEY_WAITNG_SCREEN_ACTION_NOTIFY_SMS
        )
        binding.waitScreenSmsConfirmationTitle.text = IDnowSDK.getInstance().getStringWithDefault(
            context,
            Util_Strings.KEY_WAITING_SCREEN_WAITING_LIST_CONFIRM,
            Util_Strings.LOCAL_KEY_WAITING_SCREEN_WAITING_LIST_CONFIRM
        )
        binding.waitScreenSmsConfirmationDescription.text = IDnowSDK.getInstance().getStringWithDefault(
            context,
            Util_Strings.KEY_VIDEO_IDENT_WAITING_LIST_SUCCESS_SMS_MSG,
            Util_Strings.LOCAL_KEY_VIDEO_IDENT_WAITING_LIST_SUCCESS_SMS_MSG
        )
        binding.waitScreenSmsConfirmationDone.text = IDnowSDK.getInstance().getStringWithDefault(
            context,
            Util_Strings.KEY_WAITING_SCREEN_OK_WAIT,
            Util_Strings.LOCAL_KEY_WAITING_SCREEN_OK_WAIT
        )

        binding.sendButton.setOnClickListener {
            setPanelsVisibility(
                isUpperPanelVisible = false,
                isMiddlePanelVisible = true,
                isLowerPanelVisible = false
            )
        }
    }

    fun setNotifyViaPushDetailsText(text: String) {
        binding.notifyViaPushDetails.text = text
    }

    fun setUpperPanelVisible(isVisible: Boolean) {
        binding.notifyViaPushUpperPanel.isVisible = isVisible
    }

    fun setMiddlePanelVisible(isVisible: Boolean) {
        binding.notifyViaSMSPanel.isVisible = isVisible
    }

    fun setLowerPanelVisibility(isVisible: Boolean) {
        binding.notifyViaPushLowerPanel.isVisible = isVisible
    }

    fun setPanelsVisibility(
        isUpperPanelVisible: Boolean,
        isMiddlePanelVisible: Boolean,
        isLowerPanelVisible: Boolean
    ) {
        setUpperPanelVisible(isUpperPanelVisible)
        setMiddlePanelVisible(isMiddlePanelVisible)
        setLowerPanelVisibility(isLowerPanelVisible)
    }

    fun setWaitScreenSmsNotifyButtonOnClickListener(listener: OnClickListener) {
        binding.waitScreenSmsNotifyButton.setOnClickListener(listener)
    }

    fun setWaitScreenSmsConfirmationDoneOnClickListener(listener: OnClickListener) {
        binding.waitScreenSmsConfirmationDone.setOnClickListener(listener)
    }


}