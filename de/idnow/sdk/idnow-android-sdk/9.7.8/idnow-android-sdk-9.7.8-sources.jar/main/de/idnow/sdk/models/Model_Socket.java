package de.idnow.sdk.models;

public class Model_Socket {
    Model_Socket_Platform android;
    Model_Socket_Platform ios;

    public Model_Socket(Model_Socket_Platform android, Model_Socket_Platform ios) {
        this.android = android;
        this.ios = ios;
    }

    public Model_Socket_Platform getAndroid() {
        return android;
    }

    public void setAndroid(Model_Socket_Platform android) {
        this.android = android;
    }

    public Model_Socket_Platform getIos() {
        return ios;
    }

    public void setIos(Model_Socket_Platform ios) {
        this.ios = ios;
    }
}
