package de.idnow.sdk.util;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import de.idnow.sdk.Activities.Activities_VideoOverviewCheckActivity;

/**
 * @author Mathias Grasy
 * @version 1.0
 */
public class UI_CustomLinearLayoutOnClickListener implements OnClickListener
{

	public UI_CustomLinearLayoutOnClickListener()
	{
	}

	@Override
	public void onClick( View v )
	{

		ImageView buttonToCheck = ( ImageView ) v.getTag();

		if ( ( Boolean ) buttonToCheck.getTag() )
		{
			Util_UtilUI.setCheckMark( buttonToCheck, false );
			buttonToCheck.setTag( false );
		}
		else
		{
			Util_UtilUI.setCheckMark( buttonToCheck, true );
			buttonToCheck.setTag( true );
		}

		( (Activities_VideoOverviewCheckActivity) v.getContext() ).handleIdentificationButtonActivation();
	}
}
