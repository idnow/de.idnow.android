package de.idnow.sdk.Activities.callbacks;

public interface SendChatMessageCallback {
    void onSuccess();
    void onFailure();
}
