package de.idnow.sdk.util;

import android.annotation.SuppressLint;
import android.app.ForegroundServiceStartNotAllowedException;
import android.app.MissingForegroundServiceTypeException;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import static android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA;
import static android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;

public class IDnowForegroundService extends Service {

    private static final String TAG = "IDNOW_IDnowForegroundService";
    public static final String CHANNEL_ID = "11111";
    private static final String CHANNEL_NAME = "Identification Service";
    private final IDnowForegroundBinder iDnowForegroundBinder = new IDnowForegroundBinder();



    @SuppressLint("NewApi")
    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    public void onCreate() {
        super.onCreate();

        Util_Log.i(TAG, "onCreate: ");

        startMyOwnForeground(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q);
    }

    @SuppressLint("NewApi")
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void startMyOwnForeground(boolean hasForegroundServiceType){
        try
        {
            String NOTIFICATION_CHANNEL_ID = "de.idnow.sdk";
            NotificationChannel chan = new NotificationChannel(NOTIFICATION_CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_NONE);
            chan.setLightColor(Color.BLUE);
            chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            assert manager != null;
            manager.createNotificationChannel(chan);

            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);
            Notification notification = notificationBuilder.setOngoing(true)
                    .setSmallIcon(android.R.drawable.ic_dialog_alert)
                    .setContentTitle(CHANNEL_NAME)
                    .setPriority(NotificationManager.IMPORTANCE_MIN)
                    .setCategory(Notification.CATEGORY_SERVICE)
                    .build();

            if(hasForegroundServiceType) {
                startForeground(1, notification,FOREGROUND_SERVICE_TYPE_CAMERA);
                startForeground(2, notification,FOREGROUND_SERVICE_TYPE_MICROPHONE);
            }
            else {
                startForeground(1, notification);
            }
        }
        catch (Exception e){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    e instanceof ForegroundServiceStartNotAllowedException || e instanceof MissingForegroundServiceTypeException
            ) {// App not in a valid state to start foreground service
                // (e.g started from bg)
                Util_Log.e(TAG, "Starting foreground service failed", e);

            }
        }

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Util_Log.i(TAG, "onStartCommand: ");
        return super.onStartCommand(intent, flags, startId);
    }



    @Override
    public void onDestroy() {
        Util_Log.i(TAG, "onDestroy: ");
        super.onDestroy();
    }



    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Util_Log.i(TAG, "onBind: ");
        iDnowForegroundBinder.onBind(this);
        return iDnowForegroundBinder;
    }
}
