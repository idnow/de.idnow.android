package de.idnow.sdk.models;



/**
 * 
 * @date 21.11.2016
 * @author Mathias Grasy
 * @version 1.0
 * @brief is send to the server, when the user wants confirmation token to be send again to the email address
 */


public class Models_Email
{

	String	email;

	public Models_Email( String email )
	{
		this.email = email;
	}

	/**
	 * @return the email
	 */
	public String getEmail()
	{
		return email;
	}
}
