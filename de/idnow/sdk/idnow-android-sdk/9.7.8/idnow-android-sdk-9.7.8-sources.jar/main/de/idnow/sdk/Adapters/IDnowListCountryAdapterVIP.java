package de.idnow.sdk.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_Super;
import de.idnow.sdk.Activities.Fragment_IDDocument_list;
import de.idnow.sdk.R;
import de.idnow.sdk.util.Util_PhotoDataHolder;
import de.idnow.sdk.util.Util_Util;

public class IDnowListCountryAdapterVIP extends RecyclerView.Adapter<IDnowListCountryAdapterVIP.CountryViewHolder> {

    private final LayoutInflater layoutInflater;
    private ArrayList<String> listCountry = new ArrayList<>();
    private ArrayList<String> listCountryFilter = new ArrayList<>();
    private int selectedPosition = -1;
    private CountryItemClickListener countryItemClickListener;
    Context context;

    public IDnowListCountryAdapterVIP(@NonNull Context context, ArrayList<String> data) {
        layoutInflater = LayoutInflater.from(context);
        this.context = context;
        this.listCountry = data;
        this.listCountryFilter = data;
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }


    public void setCountryItemClickListener(CountryItemClickListener countryItemClickListener) {
        this.countryItemClickListener = countryItemClickListener;
    }

    public void setData(ArrayList<String> listCountries) {
        this.listCountry = listCountries;
        this.listCountryFilter = listCountries;
        notifyDataSetChanged();
    }

    public void clearSelection() {
        selectedPosition = -1;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CountryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = layoutInflater.inflate(R.layout.idnow_country_item_layout_vip, parent, false);
        return new CountryViewHolder(view);    }

    @Override
    public void onBindViewHolder(CountryViewHolder holder, int position) {

        String country = listCountryFilter.get(position);
        holder.countryText.setText(country);

    }

    @Override
    public int getItemCount() {
        return listCountryFilter.size();
    }

    public interface CountryItemClickListener {
        void onCountryItemClick(int position);
    }

    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                String charString = constraint.toString();
                if (charString.isEmpty()) {

                    listCountryFilter = listCountry;
                } else {
                    ArrayList<String> filteredList = new ArrayList<>();
                    for (String item : listCountry) {
                        if (item.toLowerCase().startsWith(charString.toLowerCase())) {
                            filteredList.add(item);
                        }
                    }

                    listCountryFilter = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = listCountryFilter;

                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                listCountryFilter = (ArrayList<String>) results.values;
                notifyDataSetChanged();
            }
        };
    }

    public class CountryViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView countryText;

        CountryViewHolder(View itemView) {
            super(itemView);
            countryText = itemView.findViewById(R.id.country_item);
            itemView.setOnClickListener(v -> {

                Util_Util.hideKeyBoard(context, (((Activities_VideoLiveStreamActivity_Super) context).searchCountryEdt));
                notifyDataSetChanged();

                Util_PhotoDataHolder.setSelectedCountry(countryText.getText().toString(), context);

                ((Activities_VideoLiveStreamActivity_Super) context).searchCountryEdt.setText(countryText.getText().toString());
                ((Activities_VideoLiveStreamActivity_Super) context).layout_countries_search.setBackgroundColor(0x00000000);
                ((Activities_VideoLiveStreamActivity_Super) context).search_bar_country.setBackground(context.getDrawable(R.drawable.vip_search_country_background));

                Fragment_IDDocument_list fragment_idDocument_list = new Fragment_IDDocument_list();

                ((Activities_VideoLiveStreamActivity_Super) context).list_country.setVisibility(View.GONE);
                ((Activities_VideoLiveStreamActivity_Super) context).id_selection_document_title.setVisibility(View.VISIBLE);
                ((Activities_VideoLiveStreamActivity_Super) context).listFragment.setVisibility(View.VISIBLE);

                ((Activities_VideoLiveStreamActivity_Super) context).showIntroFragment(fragment_idDocument_list);

            });
        }

        @Override
        public void onClick(View v) {

        }
    }
}
