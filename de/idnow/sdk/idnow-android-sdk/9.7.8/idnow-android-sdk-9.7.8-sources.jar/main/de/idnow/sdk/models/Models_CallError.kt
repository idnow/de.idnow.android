package de.idnow.sdk.models

data class Models_CallError(
    val errors: List<Models_RESTError>?
)
