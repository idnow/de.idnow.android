package de.idnow.sdk.models;

public class Models_CallQualityTest {
    private String sessionId;
    private String userVideoSessionToken;

    public Models_CallQualityTest(String sessionId, String userVideoSessionToken) {
        this.sessionId = sessionId;
        this.userVideoSessionToken = userVideoSessionToken;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getUserVideoSessionToken() {
        return userVideoSessionToken;
    }

    public void setUserVideoSessionToken(String userVideoSessionToken) {
        this.userVideoSessionToken = userVideoSessionToken;
    }
}
