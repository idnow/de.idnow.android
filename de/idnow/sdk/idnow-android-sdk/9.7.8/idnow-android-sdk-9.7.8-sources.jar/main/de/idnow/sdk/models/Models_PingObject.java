package de.idnow.sdk.models;



/**
 * 
 * @date 10.10.2014
 * @author Mathias Grasy
 * @version 1.0
 * @brief a ping object has to be send every 5 seconds to the server to keep the connection alive
 */


public class Models_PingObject
{
	String	command	= "ping";

	public Models_PingObject()
	{
		command = "ping";
	}

	public String getCommand()
	{
		return command;
	}

}
