package de.idnow.sdk.Activities;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.airbnb.lottie.LottieAnimationView;

import de.idnow.sdk.Activities.entry.Activities_EntryActivity;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.useCases.StartUseCase;
import de.idnow.sdk.util.IDnowErrorCode;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.Util_VideoStreamService;

public class Activities_HighCallVolumeActivity extends BaseActivity {
    private final String LOGTAG = "IDNOW_Activities_HighCallVolumeActivity";

    LottieAnimationView idnow_logo;
    TextView high_call_volume_image_desc,high_call_volume_title,high_call_volume_message,try_later_button,continue_button;
    Context context;

    private StartUseCase startUseCaseInstance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high_call_volume);

        idnow_logo = findViewById(R.id.idnow_logo);
        high_call_volume_image_desc = findViewById(R.id.high_call_volume_image_desc);
        high_call_volume_title = findViewById(R.id.high_call_volume_title);
        high_call_volume_message = findViewById(R.id.high_call_volume_message);
        try_later_button = findViewById(R.id.try_later_button);
        continue_button = findViewById(R.id.continue_button);
        idnow_logo.setAnimation("static_logo.json");

        if(IDnowSDK.getShowIDnowLogo()){
            idnow_logo.setVisibility(View.VISIBLE);
        }
        else {
            idnow_logo.setVisibility(View.GONE);
        }

        context = this;

        setTexts();

        if(Config.DARK_MODE){
            Util_UtilUI.setColorLottieAnimation(Color.WHITE,idnow_logo,"SecondaryVariant");

        }
        else {
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill,idnow_logo,"SecondaryVariant");
        }

        try_later_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IDnowSDK.setCallFromHighCallVolumeActivity(false, context);
                quitSdk();
            }
        });

        continue_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IDnowSDK.setCallFromHighCallVolumeActivity(true, context);
                provideStartUseCaseInstance().proceed();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        setResult(resultCode, data);
        finish();
    }

    private StartUseCase provideStartUseCaseInstance() {
        if (startUseCaseInstance == null) {
            StartUseCase.ResultCallback callback = new StartUseCase.ResultCallback() {

                @Override
                public void onLoadingStarted() { }

                @Override
                public void onResult(@NonNull StartUseCase.Result result) {
                    if (result instanceof StartUseCase.Result.Success) {
                        onStartSuccess((StartUseCase.Result.Success) result);
                    } else if (result instanceof StartUseCase.Result.Failure) {
                        Util_Log.e(LOGTAG, "Start identification failed with result: " + result);
                    }
                }
            };
            startUseCaseInstance = new StartUseCase(callback, this);
        }

        return startUseCaseInstance;
    }

    private void onStartSuccess(StartUseCase.Result.Success result) {
        if (result instanceof StartUseCase.Result.Success.NavigateToOverviewCheckScreen) {
            navigateToScreen(Activities_VideoOverviewCheckActivity.class);
        } else if (result instanceof StartUseCase.Result.Success.NavigateToBeforeStartScreen) {
            navigateToScreen(Activities_BeforeStartingActivity.class);
        } else if (result instanceof StartUseCase.Result.Success.NavigateToCqcScreen) {
            navigateToScreen(Util_VideoStreamService.getClassForCallQualityCheck());
        } else if (result instanceof StartUseCase.Result.Success.NavigateToLiveStreamScreen) {
            navigateToScreen(Util_VideoStreamService.getClassForVideoLiveStreaming());
        } else if (result instanceof StartUseCase.Result.Success.NavigateToDeviceSupportScreen) {
            navigateToScreen(Activities_DeviceSupportActivity.class);
        }
    }

    private void navigateToScreen(Class<?> screenClass) {
        Intent intent = new Intent(this, screenClass);
        startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
    }
    private void quitSdk() {
        Intent intent = getIntent();
        intent.putExtra(IDnowSDK.RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorHighCallVolumeTryLater);
        IDnowSDK.updateResultCode(IDnowSDK.RESULT_CODE_FAILED);
        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, getIntent());
        setResult(IDnowSDK.RESULT_CODE_FAILED, getIntent());
        finish();
    }

    private void setTexts() {
        continue_button.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_HIGHVOLUME_CONTINUE, Util_Strings.LOCAL_KEY_HIGHVOLUME_CONTINUE));
        try_later_button.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_HIGHVOLUME_TRYLATER, Util_Strings.LOCAL_KEY_HIGHVOLUME_TRYLATER));
        high_call_volume_image_desc.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_HIGHVOLUME_IMAGE_DESC, Util_Strings.LOCAL_KEY_HIGHVOLUME_IMAGE_DESC));
        high_call_volume_title.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_HIGHVOLUME_TITLE, Util_Strings.LOCAL_KEY_HIGHVOLUME_TITLE));
        high_call_volume_message.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_HIGHVOLUME_MESSAGE_, Util_Strings.LOCAL_KEY_HIGHVOLUME_MESSAGE));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        quitSdk();
        IDnowSDK.setCallFromHighCallVolumeActivity(false, this);
    }
}