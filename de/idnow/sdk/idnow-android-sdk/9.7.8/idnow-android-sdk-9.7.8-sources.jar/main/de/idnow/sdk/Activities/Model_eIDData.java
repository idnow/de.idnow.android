package de.idnow.sdk.Activities;

public class Model_eIDData {

    public String endPoint;
    public String companyID;
    public String transactionToken;

    public String getEndPoint() {
        return endPoint;
    }

    public String getCompanyID() {
        return companyID;
    }

    public String getTransactionToken() {
        return transactionToken;
    }

    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }

    public void setCompanyID(String companyID) {
        this.companyID = companyID;
    }

    public void setTransactionToken(String transactionToken) {
        this.transactionToken = transactionToken;
    }

    @Override
    public String toString() {
        return "Model_eIDData{" +
                "endPoint='" + endPoint + '\'' +
                ", companyID='" + companyID + '\'' +
                ", transactionToken='" + transactionToken + '\'' +
                '}';
    }
}
