package de.idnow.sdk.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import de.idnow.sdk.R;

/**
 * Created by lars.mehrtens on 04.03.18.
 */
public class CallQualityLightView extends View {
	private int circleColorInner = Color.RED;
	private int circleColorOuter = Color.GRAY;
	private Paint paint;

	public CallQualityLightView(Context context) {
		super(context);
		init(context, null);
	}

	public CallQualityLightView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context, attrs);
	}

	private void init(Context context, AttributeSet attrs) {
		paint = new Paint();
		paint.setAntiAlias(true);
	}

	public void setCircleColors(int circleColorInner, int circleColorOuter) {
		this.circleColorInner = circleColorInner;
		this.circleColorOuter = circleColorOuter;
		invalidate();
	}

	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);

		int w = getWidth();
		int h = getHeight();

		int pl = getPaddingLeft();
		int pr = getPaddingRight();
		int pt = getPaddingTop();
		int pb = getPaddingBottom();

		int usableWidthInner = w - (pl + pr);
		int usableHeightInner = h - (pt + pb);

		int usableWidthOuter = w - (pl + pr);
		int usableHeightOuter = h - (pt + pb);

		int radiusOuter = Math.min(usableWidthOuter, usableHeightOuter) / 2;
		int cxOuter = pl + (usableWidthOuter / 2);
		int cyOuter = pt + (usableHeightOuter / 2);

		paint.setColor(circleColorOuter);
		canvas.drawCircle(cxOuter, cyOuter, radiusOuter, paint);

		int radiusInner = Math.min(usableWidthInner-30, usableHeightInner-30) / 2;
		int cxInner = pl + (usableWidthInner / 2);
		int cyInner = pt + (usableHeightInner / 2);

		paint.setColor(circleColorInner);
		canvas.drawCircle(cxInner, cyInner, radiusInner, paint);
	}
}