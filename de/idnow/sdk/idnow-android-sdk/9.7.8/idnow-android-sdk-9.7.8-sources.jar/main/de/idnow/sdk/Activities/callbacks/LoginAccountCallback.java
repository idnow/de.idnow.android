package de.idnow.sdk.Activities.callbacks;

public interface LoginAccountCallback {
    void onLogin(Integer responseCode);
}
