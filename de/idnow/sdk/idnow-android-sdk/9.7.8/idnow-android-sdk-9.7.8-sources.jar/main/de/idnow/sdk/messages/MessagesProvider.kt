package de.idnow.sdk.messages

import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.util.Util_Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val LOGTAG = "IDNOW_MessagesProvider"

internal object MessagesProvider : BaseProvider() {
    private val coroutineScope = MainScope()
    private val coroutineDispatcher = Dispatchers.IO
    private var fetchJob: Job? = null

    fun reset() {
        fetchJob?.cancel()
        fetchJob = null
    }

    fun fetchAsync(onDone: (Map<String, String>) -> Unit) {
        fetchJob?.cancel()
        fetchJob = coroutineScope.launch(coroutineDispatcher) {
            performFetch(onDone)
        }
    }

    suspend fun fetch(onDone: (Map<String, String>) -> Unit) = withContext(coroutineDispatcher) {
        performFetch(onDone)
    }

    private suspend fun performFetch(onDone: (Map<String, String>) -> Unit) {
        try {
            val response = provideRestApiService().getMessages(
                companyShort = IDnowSDK.getCompanyId(),
                language = IDnowSDK.language
            )
            if (response.isSuccessful) {
                val tmpData = response.body()
                    ?: throw Exception("Response body was null, but it shouldn't have been")
                onDone(tmpData)
            }
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Error fetching messages", e)
        }
    }
}