package de.idnow.sdk.models;

/**
 * Created by lars.mehrtens on 07.02.18.
 */

public class Models_Candidate
{
	String	conferenceID;
	String	peerType;
	String	peerID;

	public Models_Candidate(String conferenceID, String peerType, String peerID)
	{
		this.conferenceID = conferenceID;
		this.peerType = peerType;
		this.peerID = peerID;
	}

	public String getConferenceID() {
		return conferenceID;
	}

	public void setConferenceID(String conferenceID) {
		this.conferenceID = conferenceID;
	}

	public String getPeerType() {
		return peerType;
	}

	public void setPeerType(String peerType) {
		this.peerType = peerType;
	}

	public String getPeerID() {
		return peerID;
	}

	public void setPeerID(String peerID) {
		this.peerID = peerID;
	}

}