package de.idnow.sdk.models;

public class Model_AgentFeedback {

    private int rating;
    private String reason;

    public Model_AgentFeedback() {
    }

    public Model_AgentFeedback(int rating, String reason) {
        this.rating = rating;
        this.reason = reason;
    }

    public int getRating() {
        return rating;
    }

    public String getReason() {
        return reason;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
