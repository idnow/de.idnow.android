package de.idnow.sdk.models;



/**
 * 
 * @date 10.10.2014
 * @author Mathias Grasy
 * @version 1.0
 * @brief used for sending/receiving a empty Json
 */


public class Models_EmptyJson
{

	public Models_EmptyJson()
	{

	}
}
