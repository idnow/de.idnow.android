package de.idnow.sdk.views

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.RelativeLayout
import de.idnow.sdk.R
import de.idnow.sdk.databinding.ViewUserConstentBinding
import de.idnow.sdk.util.Util_Strings
import de.idnow.sdk.util.Util_UtilUI

class ESignConsentView @JvmOverloads constructor(
    context: Context,
    attributeSet: AttributeSet? = null,
    defStyle: Int = 0
) : RelativeLayout(context, attributeSet, defStyle) {

    private var binding: ViewUserConstentBinding

    init {
        binding = ViewUserConstentBinding.inflate(LayoutInflater.from(context), this, true)

        binding.eSignUserConsentHeadline.text = Util_Strings.getStringWithDefault(
            context,
            Util_Strings.KEY_ESIGN_FORWARDING_HEADLINE,
            Util_Strings.LOCAL_ESIGN_FORWARDING_HEADLINE
        )

        binding.eSignUserConsentBody.text = Util_Strings.getStringWithDefault(
            context,
            Util_Strings.KEY_ESIGN_FORWARDING_BODY,
            Util_Strings.LOCAL_ESIGN_FORWARDING_BODY
        )

        binding.eSignUserConsentConfirm.text = Util_Strings.getStringWithDefault(
            context,
            Util_Strings.KEY_ESIGN_FORWARDING_CONTINUE,
            Util_Strings.LOCAL_ESIGN_FORWARDING_CONTINUE
        )

        binding.eSignUserConsentConfirm.setBackgroundResource(R.drawable.rounded_background_grey)

        Util_UtilUI.setProceedButtonBackgroundSelector(binding.eSignUserConsentConfirm);
    }

    fun confirmOnclickListener(l: OnClickListener) {
        binding.eSignUserConsentConfirm.setOnClickListener(l)
    }
}