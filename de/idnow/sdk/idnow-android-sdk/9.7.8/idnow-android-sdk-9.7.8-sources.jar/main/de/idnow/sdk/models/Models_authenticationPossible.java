package de.idnow.sdk.models;

public class Models_authenticationPossible {

    boolean authenticatedRequest;
    boolean expiredWalletExists;

    public Models_authenticationPossible(boolean authenticatedRequest) {
        this.authenticatedRequest = authenticatedRequest;
    }

    public Models_authenticationPossible(boolean authenticatedRequest, boolean expiredWalletExists) {
        this.authenticatedRequest = authenticatedRequest;
        this.expiredWalletExists = expiredWalletExists;
    }

    public void setAuthenticatedRequest(boolean authenticatedRequest) {
        this.authenticatedRequest = authenticatedRequest;
    }

    public boolean isAuthenticatedRequest() {
        return authenticatedRequest;
    }

    public boolean isExpiredWalletExists() {
        return expiredWalletExists;
    }

    public void setExpiredWalletExists(boolean expiredWalletExists) {
        this.expiredWalletExists = expiredWalletExists;
    }
}
