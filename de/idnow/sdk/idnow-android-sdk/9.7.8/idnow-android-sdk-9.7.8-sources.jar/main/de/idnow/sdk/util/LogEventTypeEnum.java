package de.idnow.sdk.util;

public enum LogEventTypeEnum {
    INFO("INFO"),
    DEBUG("DEBUG"),
    WARN("WARN"),
    ERROR("ERROR"),
    EXCEPTION("EXCEPTION");

    private final String text;

    /**
     * @param text
     */
    LogEventTypeEnum(final String text) {
        this.text = text;
    }

    /* (non-Javadoc)
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return text;
    }

    public String get() {
        return text;
    }
}
