package de.idnow.sdk.models;



/**
 * @author Mathias Grasy
 * @date 16.10.2014
 * @brief (short description)
 */


public class Models_DocumentDefinition
{
	boolean optional;
	String  name;
	String  identifier;

	public Models_DocumentDefinition( boolean optional, String name, String identifier )
	{
		this.optional = optional;
		this.name = name;
		this.identifier = identifier;
	}

	public boolean isOptional()
	{
		return optional;
	}

	public void setOptional( boolean optional )
	{
		this.optional = optional;
	}

	public String getName()
	{
		return name;
	}

	public void setName( String name )
	{
		this.name = name;
	}

	public String getIdentifier()
	{
		return identifier;
	}

	public void setIdentifier( String identifier )
	{
		this.identifier = identifier;
	}
}
