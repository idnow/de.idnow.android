package de.idnow.sdk.util;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@SuppressWarnings({"WeakerAccess"})
public class CommonUtils {

    private CommonUtils() {

    }

    public static final String EMPTY = "";
    public static final String SPACE = " ";
    public static final String COMMA = ",";

    /**
     * Check if object is {@code null}
     * @param t object to check
     * @param <T> Type of object
     * @return {@code true} if parameter is {@code null}
     */
    public static <T> boolean isNull(@Nullable T t) {
        return t == null;
    }



    /**
     * Check if object is not {@code null}
     * @param t object to check
     * @param <T> Type of object
     * @return {@code true} if parameter is not {@code null}
     *
     * @see CommonUtils#isNull(Object)
     */
    public static <T> boolean nonNull(@Nullable T t) {
        return !isNull(t);
    }


    /**
     * {@code null} safe size of list
     * @param list {@linkplain List} to get size, can be {@code null}
     * @param <T> Type of List
     * @return {@literal 0} if parameter {@linkplain CommonUtils#isEmpty(Collection)} is {@code true} else {@linkplain List#size()}
     */
    public static <T> int size(@Nullable List<T> list) {
        return isEmpty(list) ? 0 : list.size();
    }


    /**
     * {@code null} safe check if {@linkplain Collection} is empty
     * @param list {@linkplain Collection} to check, can be {@code null}
     * @param <T> Type of Collection
     * @return {@code true} if input is null or {@linkplain Collection#isEmpty()} returns {@code true}
     *
     * @see CommonUtils#isNull(Object)
     */
    public static <T> boolean isEmpty(@Nullable Collection<T> list) {
        return isNull(list) || list.isEmpty();
    }


    /**
     * {@code null} safe check if {@linkplain Map} is empty
     * @param map {@linkplain List} to check, can be {@code null}
     * @param <K> Type of Key
     * @param <V> Type of Value
     * @return {@code true} if input is null or {@linkplain Map#isEmpty()} returns {@code true}
     *
     * @see CommonUtils#isNull(Object)
     */
    public static <K, V> boolean isEmpty(@Nullable Map<K, V> map) {
        return isNull(map) || map.isEmpty();
    }

    /**
     * {@code null} safe check for String
     * @param checkString String to check, can be {@code null}
     * @param defaultString String to return if checkString is {@code null}, cannot be {@code null}
     * @return checkString if {@linkplain CommonUtils#isNull(Object)} is {@code false}, otherwise defaultString.
     *
     * @see CommonUtils#isNull(Object)
     */
    @NonNull
    public static String getOrDefault(@Nullable String checkString, @NonNull String defaultString) {
        return isBlank(checkString) ? defaultString : checkString;
    }


    /**
     * {@code null} safe check for String
     * @param checkString String to check, can be {@code null}
     * @return checkString if {@linkplain CommonUtils#isNull(Object)} is {@code false}, otherwise {@value #EMPTY}.
     *
     * @see CommonUtils#getOrDefault(String, String)
     */
    @NonNull
    public static String emptyIfNull(@Nullable String checkString) {
        return getOrDefault(checkString, EMPTY);
    }

    /**
     * {@code null} safe check for object returning default if {@code null}
     * @param checkObject object to check, can be {@code null}
     * @param defaultIfNull default value if checkObject is {@code null}. This cannot be null
     * @param <T> Type of object
     * @return checkObject if {@linkplain CommonUtils#nonNull(Object)} is {@code true} ; otherwise returns defaultIfNull
     */
    @NonNull
    public static <T> T getOrDefault(@Nullable T checkObject, @NonNull T defaultIfNull) {
        return nonNull(checkObject) ? checkObject : defaultIfNull;
    }

    /**
     * Check if String is {@code null} or of zero length
     * @param checkString String to check, can be {@code null}
     * @return {@code true} if {@linkplain CommonUtils#isNull(Object)} returns true OR returns {@linkplain String#isEmpty()}
     *
     * @see CommonUtils#isNull(Object)
     */
    public static boolean isEmpty(@Nullable String checkString) {
        return isNull(checkString) || checkString.isEmpty();
    }


    /**
     * {@code null} safe check for {@linkplain List} returning if {@code null}
     * @param list List to check, can be {@code null}
     * @param <T> Type of list
     * @return input list if not {@code null} else {@linkplain Collections#emptyList()}
     *
     * @see CommonUtils#getOrDefault(Object, Object)
     */
    public static <T> List<T> getOrEmpty(List<T> list) {
        return getOrDefault(list, Collections.emptyList());
    }

    /**
     * <p>Checks if a CharSequence is empty (""), null or whitespace only.</p>
     *
     * <p>Whitespace is defined by {@link Character#isWhitespace(char)}.</p>
     *
     *  Copied from Apache Commons-lang3.
     *
     * <pre>
     * isBlank(null)      = true
     * isBlank("")        = true
     * isBlank(" ")       = true
     * isBlank("bob")     = false
     * isBlank("  bob  ") = false
     * </pre>
     *
     * @param cs  the CharSequence to check, may be null
     * @return {@code true} if the CharSequence is null, empty or whitespace only
     * @since 2.0
     * @since 3.0 Changed signature from isBlank(String) to isBlank(CharSequence)
     */
    public static boolean isBlank(final CharSequence cs) {
        int strLen;
        if (cs == null || (strLen = cs.length()) == 0) {
            return true;
        }
        for (int i = 0; i < strLen; i++) {
            if (!Character.isWhitespace(cs.charAt(i))) {
                return false;
            }
        }
        return true;
    }
}
