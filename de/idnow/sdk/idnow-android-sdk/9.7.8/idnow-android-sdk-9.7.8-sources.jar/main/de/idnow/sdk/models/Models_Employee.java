package de.idnow.sdk.models;



/**
 * 
 * @date 10.10.2014
 * @author Mathias Grasy
 * @version 1.0
 * @brief received from the server with the socket response. contains information about the agent who is doing the identification
 */


public class Models_Employee
{

	String	firstname;
	String	lastname;
	int		id;
	String	email;

	public Models_Employee( int id, String firstname, String lastname, String email )
	{
		this.firstname = firstname;
		this.lastname = lastname;
		this.id = id;
		this.email = email;
	}

	public Models_Employee()
	{

	}

	public void setId( int id )
	{
		this.id = id;
	}

	public int getId()
	{
		return id;
	}

	public void setEmail( String email )
	{
		this.email = email;
	}

	public String getEmail()
	{
		return email;
	}

	public void setFirstname( String firstname )
	{
		this.firstname = firstname;
	}

	public String getFirstname()
	{
		return firstname;
	}

	public void setLastname( String lastname )
	{
		this.lastname = lastname;
	}

	public String getLastname()
	{
		return lastname;
	}
}
