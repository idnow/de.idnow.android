package de.idnow.sdk.models;

/**
 * Created by Mathias Grasy on 04.10.2016.
 */

public class Models_TextMessage
{
	String content;

	public Models_TextMessage( String content )
	{
		this.content = content;
	}
}
