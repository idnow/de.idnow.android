package de.idnow.sdk.Activities.callbacks;

public interface SaveAccountPasswordCallback {
    void onSaveAccountPassword();
}
