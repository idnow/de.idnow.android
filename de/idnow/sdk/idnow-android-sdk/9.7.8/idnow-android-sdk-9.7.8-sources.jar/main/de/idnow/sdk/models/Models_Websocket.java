package de.idnow.sdk.models;



/**
 * 
 * @date 10.10.2014
 * @author Mathias Grasy
 * @version 1.0
 * @brief received at the beginning of the call for initializing the websocket
 */


public class Models_Websocket
{

	String			command;
	Models_Employee	employee;

	public Models_Websocket( String command, Models_Employee employee )
	{
		this.command = command;
		this.employee = employee;
	}
}
