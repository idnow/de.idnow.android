package de.idnow.sdk.network;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Response;

public abstract class Callback<T> implements retrofit2.Callback<T> {

    public abstract void success(T resultObject, Response response) throws IOException;

    public abstract void failure(RetrofitError error);

    @Override
    public void onResponse(Call<T> call, Response<T> response) {
        if (response.isSuccessful()) {
            try {
                this.success(response.body(), response);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            this.failure(RetrofitError.from(response));
        }
    }

    @Override
    public void onFailure(Call<T> call, Throwable t) {
        this.failure(RetrofitError.from(t));
    }
}
