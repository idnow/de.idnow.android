package de.idnow.sdk.util.helper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.util.Base64
import androidx.core.graphics.scale
import de.idnow.sdk.Config
import de.idnow.sdk.util.Util_Log
import fm.liveswitch.VideoBuffer
import fm.liveswitch.VideoFormat
import java.io.ByteArrayOutputStream
import kotlin.math.roundToInt

internal object ImageHelper {
    private const val LOGTAG = "IDNOW_ImageHelper"
    fun extractBitmapFromVideoBuffer(
        videoBuffer: VideoBuffer,
        requiredWidth: Int,
        requiredHeight: Int
    ): Bitmap {
        val rotationRequired = videoBuffer.rotationRequired
        val videoBuffer: VideoBuffer = videoBuffer.convert(VideoFormat.getNv21())
        val yuvImage = YuvImage(
            videoBuffer.dataBuffer.data,
            ImageFormat.NV21,
            videoBuffer.width,
            videoBuffer.height,
            null
        )
        var bitmap = convertYuvToBitmap(yuvImage, videoBuffer.width, videoBuffer.height)
        bitmap = resizeBitmap(bitmap, requiredWidth, requiredHeight)

        return rotateBitmap(bitmap, rotationRequired)
    }

    fun convertYuvToBitmap(
        yuvImage: YuvImage,
        width: Int,
        height: Int
    ): Bitmap {
        val rawSsOs = ByteArrayOutputStream()
        val rect = Rect(0, 0, width, height)
        yuvImage.compressToJpeg(rect, 100, rawSsOs)

        val rotatedImage = rawSsOs.toByteArray()
        return BitmapFactory.decodeByteArray(rotatedImage, 0, rotatedImage.size)
    }

    fun resizeBitmap(
        bitmap: Bitmap,
        maxWidth: Int,
        maxHeight: Int
    ): Bitmap {
        var image = bitmap
        if (maxHeight > 0 && maxWidth > 0) {
            val width = image.getWidth()
            val height = image.getHeight()
            val ratioBitmap = width.toFloat() / height.toFloat()
            val ratioMax = maxWidth.toFloat() / maxHeight.toFloat()

            var finalWidth = maxWidth
            var finalHeight = maxHeight
            if (ratioMax > ratioBitmap) {
                finalWidth = (maxHeight.toFloat() * ratioBitmap).toInt()
            } else {
                finalHeight = (maxWidth.toFloat() / ratioBitmap).toInt()
            }
            image = image.scale(finalWidth, finalHeight)
            return image
        } else {
            return image
        }
    }

    fun rotateBitmap(bitmap: Bitmap, degrees: Int): Bitmap {
        val rotation = Matrix()
        rotation.postRotate(degrees.toFloat())

        return Bitmap.createBitmap(
            bitmap,
            0,
            0,
            bitmap.getWidth(),
            bitmap.getHeight(),
            rotation,
            true
        )
    }

    fun mirrorBitmap(bitmap: Bitmap): Bitmap {
        val matrix = Matrix()
        matrix.preScale(-1.0f, 1.0f)

        return Bitmap.createBitmap(
            bitmap,
            0,
            0,
            bitmap.getWidth(),
            bitmap.getHeight(),
            matrix,
            true
        )
    }

    fun cropBitmapToPreviewAspect(bitmap: Bitmap, previewWidth: Int, previewHeight: Int): Bitmap {
        val aspectPreview = previewWidth.toFloat() / previewHeight
        val aspectPhoto = bitmap.getWidth().toFloat() / bitmap.getHeight()

        var cropWidth = bitmap.getWidth()
        var cropHeight = bitmap.getHeight()

        if (aspectPhoto > aspectPreview) {
            cropWidth = (bitmap.getHeight() * aspectPreview).toInt()
        } else {
            cropHeight = (bitmap.getWidth() / aspectPreview).toInt()
        }

        val startX = (bitmap.getWidth() - cropWidth) / 2
        val startY = (bitmap.getHeight() - cropHeight) / 2

        return Bitmap.createBitmap(bitmap, startX, startY, cropWidth, cropHeight)
    }

    fun readAsBase64(
        filename: String,
        minQuality: Int
    ): ByteArray? {
        return readAsBase64(
            filename = filename,
            minQuality = minQuality,
            maxQuality = 100
        )
    }

    fun readAsBase64(
        filename: String,
        width: Int = 2592,
        height: Int = 1944,
        longestEdgeSize: Int = Config.SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE,
        maxQuality: Int = 100,
        minQuality: Int = 50
    ): ByteArray? {
        return readAsByteArray(
            filename = filename,
            requiredWidth = width,
            requiredHeight = height,
            longestEdgeSize = longestEdgeSize,
            maxQuality = maxQuality,
            minQuality = minQuality
        )?.let {
            Base64.encode(it, Base64.DEFAULT)
        }
    }

    private fun readAsByteArray(
        filename: String,
        requiredWidth: Int,
        requiredHeight: Int,
        longestEdgeSize: Int,
        minQuality: Int,
        maxQuality: Int,
    ): ByteArray? {
        val os: ByteArray? = try {
            readAsByteArray(
                filename = filename,
                requiredWidth = requiredWidth,
                requiredHeight = requiredHeight,
                longestEdgeSize = longestEdgeSize,
                quality = maxQuality
            )
        } catch (e: OutOfMemoryError) {
            minQuality.takeIf { it < maxQuality }?.let {
                try {
                    readAsByteArray(
                        filename = filename,
                        requiredWidth = requiredWidth,
                        requiredHeight = requiredHeight,
                        longestEdgeSize = longestEdgeSize,
                        quality = it
                    )
                } catch (e: Exception) {
                    Util_Log.e(LOGTAG, "Decode local image as byte array failed", e)
                    null
                }
            } ?: run {
                Util_Log.e(LOGTAG, "Decode local image as byte array failed", e)
                null
            }
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Decode local image as byte array failed", e)
            null
        }

        return os
    }

    private fun readAsByteArray(
        filename: String,
        requiredWidth: Int,
        requiredHeight: Int,
        longestEdgeSize: Int,
        quality: Int,
    ): ByteArray {
        val os = ByteArrayOutputStream()
        var bitmap: Bitmap? = null
        try {
            readBitmap(filename, requiredWidth, requiredHeight)
                .apply {
                    if (longestEdgeSize != 0)
                        scaleBitmap(this, longestEdgeSize)
                }.also { bitmap = it }
                .compress(Bitmap.CompressFormat.JPEG, quality, os)
        } catch (e: OutOfMemoryError) {
            throw e
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Convert image to byte array failed. Reason: compression", e)
        } finally {
            bitmap?.recycle()
            os.close()
        }

        return os.toByteArray()
    }

    private fun readBitmap(
        filePath: String,
        requiredWidth: Int,
        requiredHeight: Int
    ): Bitmap {
        // First decode with inJustDecodeBounds=true to check dimensions
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(filePath, options)

        // Calculate inSampleSize
        options.apply {
            inSampleSize = computeSampleSize(options, requiredWidth, requiredHeight)
            // Decode bitmap with inSampleSize set
            inJustDecodeBounds = false
            inPreferredConfig = Bitmap.Config.RGB_565
        }

        return BitmapFactory.decodeFile(filePath, options)
    }

    private fun computeSampleSize(
        options: BitmapFactory.Options,
        requiredWidth: Int,
        requiredHeight: Int
    ): Int {
        // Raw height and width of image
        val height = options.outHeight
        val width = options.outWidth
        var size = 1

        if (height > requiredHeight || width > requiredWidth) {
            // Calculate ratios of height and width to requested height and width
            val heightRatio = (height.toFloat() / requiredHeight.toFloat()).roundToInt()
            val widthRatio = (width.toFloat() / requiredWidth.toFloat()).roundToInt()
            // Choose the smallest ratio as inSampleSize value, this will guarantee
            // a final image with both dimensions larger than or equal to the
            // requested height and width.
            size = if (heightRatio < widthRatio) heightRatio else widthRatio
        }

        return size
    }

    fun scaleBitmap(bitmap: Bitmap, longestEdgeSize: Int): Bitmap {
        val scaledWidth: Int
        val scaledHeight: Int
        if (bitmap.getWidth() >= bitmap.getHeight()) {
            scaledWidth = longestEdgeSize
            scaledHeight = bitmap.getHeight() * longestEdgeSize / bitmap.getWidth()
        } else {
            scaledHeight = longestEdgeSize
            scaledWidth = bitmap.getWidth() * longestEdgeSize / bitmap.getHeight()
        }

        return bitmap.scale(scaledWidth, scaledHeight)
    }
}