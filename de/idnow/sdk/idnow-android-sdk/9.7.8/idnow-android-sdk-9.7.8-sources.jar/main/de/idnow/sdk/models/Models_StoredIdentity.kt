package de.idnow.sdk.models


data class Models_StoredIdentity(val android: StoredIdentityAndroid)

data class StoredIdentityAndroid(val agreements: List<String>)