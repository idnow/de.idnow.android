package de.idnow.sdk.models;

public class Model_VideoConfig {

    int video_height;
    int video_width;
    int video_frame_rate;
    int video_screenshot_height;
    int video_screenshot_width;
    int preEstablishRetryCount;
    boolean pvid_enabled;

    public Model_VideoConfig(int video_height, int video_width, int video_frame_rate, int video_screenshot_height, int video_screenshot_width, int preEstablishRetryCount, boolean pvid_enabled) {
        this.video_height = video_height;
        this.video_width = video_width;
        this.video_frame_rate = video_frame_rate;
        this.video_screenshot_height = video_screenshot_height;
        this.video_screenshot_width = video_screenshot_width;
        this.preEstablishRetryCount = preEstablishRetryCount;
        this.pvid_enabled = pvid_enabled;
    }

    public int getVideo_height() {
        return video_height;
    }

    public int getVideo_width() {
        return video_width;
    }

    public int getVideo_frame_rate() {
        return video_frame_rate;
    }

    public int getVideo_screenshot_height() {
        return video_screenshot_height;
    }

    public int getVideo_screenshot_width() {
        return video_screenshot_width;
    }

    public void setVideo_height(int video_height) {
        this.video_height = video_height;
    }

    public void setVideo_width(int video_width) {
        this.video_width = video_width;
    }

    public void setVideo_frame_rate(int video_frame_rate) {
        this.video_frame_rate = video_frame_rate;
    }

    public void setVideo_screenshot_height(int video_screenshot_height) {
        this.video_screenshot_height = video_screenshot_height;
    }

    public void setVideo_screenshot_width(int video_screenshot_width) {
        this.video_screenshot_width = video_screenshot_width;
    }

    public int getPreEstablishRetryCount() {
        return preEstablishRetryCount;
    }

    public void setPreEstablishRetryCount(int preEstablishRetryCount) {
        this.preEstablishRetryCount = preEstablishRetryCount;
    }

    public boolean isPvid_enabled() {
        return pvid_enabled;
    }

    public void setPvid_enabled(boolean pvid_enabled) {
        this.pvid_enabled = pvid_enabled;
    }
}
