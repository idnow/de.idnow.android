package de.idnow.sdk.views

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import android.widget.LinearLayout
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.core.view.ViewCompat
import de.idnow.sdk.R

open class BaseCircleIndicator : LinearLayout {
    protected var mIndicatorMargin = -1
    protected var mIndicatorWidth = -1
    protected var mIndicatorHeight = -1
    protected var mIndicatorBackgroundResId = 0
    protected var mIndicatorUnselectedBackgroundResId = 0
    protected var mIndicatorTintColor: ColorStateList? = null
    protected var mIndicatorTintUnselectedColor: ColorStateList? = null
    protected var mLastPosition = -1
    protected var background = -1
    protected var unselectedBackground = -1

    constructor(context: Context) : super(context) {
        init(context, null)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(context, attrs)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        init(context, attrs)
    }

    private fun init(context: Context, attrs: AttributeSet?) {
        if(attrs != null) {
            val typedArray = context.obtainStyledAttributes(attrs, R.styleable.BaseCircleIndicator)

            background = typedArray.getResourceId(
                R.styleable.BaseCircleIndicator_ci_drawable,
                0
            )
            unselectedBackground = typedArray.getResourceId(
                R.styleable.BaseCircleIndicator_ci_drawable_unselected,
                0
            )
            typedArray.recycle()
        }
        if (isInEditMode) {
            createIndicators(3, 1)
        }
        initialize()
    }

    fun initialize() {
        val miniSize = (TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            DEFAULT_INDICATOR_WIDTH.toFloat(), resources.displayMetrics
        ) + 0.5f).toInt()
        mIndicatorWidth = miniSize
        mIndicatorHeight = miniSize
        mIndicatorMargin = miniSize

        mIndicatorBackgroundResId = if (background == -1) R.drawable.rounded_white else background
        mIndicatorUnselectedBackgroundResId = if (unselectedBackground == -1) R.drawable.rounded_white else unselectedBackground
    }

    fun createIndicators(count: Int, currentPosition: Int) {
        // Diff View
        val childViewCount = childCount
        if (count < childViewCount) {
            removeViews(count, childViewCount - count)
        } else if (count > childViewCount) {
            val addCount = count - childViewCount
            val orientation = orientation
            for (i in 0 until addCount) {
                addIndicator(orientation)
            }
        }

        // Bind Style
        var indicator: View
        for (i in 0 until count) {
            indicator = getChildAt(i)
            if (currentPosition == i) {
                bindIndicatorBackground(indicator, mIndicatorBackgroundResId, mIndicatorTintColor)
            } else {
                bindIndicatorBackground(
                    indicator, mIndicatorUnselectedBackgroundResId,
                    mIndicatorTintUnselectedColor
                )
            }
        }
        mLastPosition = currentPosition
    }

    protected fun addIndicator(orientation: Int) {
        val indicator = View(context)
        val params = generateDefaultLayoutParams()
        params.width = mIndicatorWidth
        params.height = mIndicatorHeight
        if (orientation == HORIZONTAL) {
            params.leftMargin = mIndicatorMargin
            params.rightMargin = mIndicatorMargin
        } else {
            params.topMargin = mIndicatorMargin
            params.bottomMargin = mIndicatorMargin
        }
        addView(indicator, params)
    }

    fun animatePageSelected(position: Int) {
        if (mLastPosition == position) {
            return
        }
        val currentIndicator: View? = getChildAt(mLastPosition)
        if (mLastPosition >= 0 && currentIndicator != null) {
            bindIndicatorBackground(
                currentIndicator,
                mIndicatorUnselectedBackgroundResId,
                mIndicatorTintUnselectedColor
            )
        }
        val selectedIndicator = getChildAt(position)
        if (selectedIndicator != null) {
            bindIndicatorBackground(
                selectedIndicator, mIndicatorBackgroundResId,
                mIndicatorTintColor
            )

        }
        mLastPosition = position
    }

    protected fun changeIndicatorBackground() {
        val count = childCount
        if (count <= 0) {
            return
        }
        var currentIndicator: View
        for (i in 0 until count) {
            currentIndicator = getChildAt(i)
            if (i == mLastPosition) {
                bindIndicatorBackground(
                    currentIndicator, mIndicatorBackgroundResId,
                    mIndicatorTintColor
                )
            } else {
                bindIndicatorBackground(
                    currentIndicator, mIndicatorUnselectedBackgroundResId,
                    mIndicatorTintUnselectedColor
                )
            }
        }
    }

    private fun bindIndicatorBackground(
        view: View, @DrawableRes drawableRes: Int,
        tintColor: ColorStateList?
    ) {
        if (tintColor != null) {
            val indDrawable = ContextCompat.getDrawable(context, drawableRes)
            if(indDrawable != null) {
                val indicatorDrawable: Drawable = DrawableCompat.wrap(
                    indDrawable.mutate()
                )
                DrawableCompat.setTintList(indicatorDrawable, tintColor)
                ViewCompat.setBackground(view, indicatorDrawable)
            }

        } else {
            view.setBackgroundResource(drawableRes)
        }
    }

    companion object {
        private const val DEFAULT_INDICATOR_WIDTH = 5
    }
}
