package de.idnow.sdk.Activities.callbacks;

import de.idnow.sdk.network.RetrofitError;

public interface RequestVideoChatCallback {
    void onFailure(RetrofitError error, String result);
}
