package de.idnow.sdk.Activities.storedidentity

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import de.idnow.sdk.Config
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.models.Models_Consent
import de.idnow.sdk.network.Callback
import de.idnow.sdk.network.IDnowRestClient
import de.idnow.sdk.network.RetrofitError
import retrofit2.Response

class StoredIdentityViewModel : ViewModel() {

    private val _consentResult = MutableLiveData<ConsentResult>()
    val consentResult: LiveData<ConsentResult>
        get() = _consentResult

    fun sendConsent(consent: Boolean) {
        val endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken())
        val service = IDnowRestClient.getRestClient()
            .getCallsForEndpoint(endPoint, IDnowSDK.getInstance().appContext)


        val callback: Callback<Void> = object : Callback<Void>() {
            override fun success(resultObject: Void?, response: Response<*>?) {
                _consentResult.value = ConsentResult.Success(consent)
            }

            override fun failure(error: RetrofitError?) {
                _consentResult.value = ConsentResult.Failure
            }

        }
        service.sendUserConsent(
            IDnowSDK.getTransactionToken(),
            IDnowSDK.getCompanyId(),
            Models_Consent(consent),
            Config.IDENTIFICATION_SIGNATURE
        ).enqueue(callback)
    }
}

sealed class ConsentResult {
    class Success(val stored: Boolean) : ConsentResult()
    object Failure: ConsentResult()
}