package de.idnow.sdk.views.cameraCutoutOverlay

enum class CameraCutoutOverlayType {
    Document,
    Selfie
}