//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package de.idnow.sdk.models;

public enum DocumentType {
    PASSPORT,
    IDCARD,
    DRIVERS_LICENSE,
    RESIDENCE_PERMIT;

    DocumentType() {
    }
}
