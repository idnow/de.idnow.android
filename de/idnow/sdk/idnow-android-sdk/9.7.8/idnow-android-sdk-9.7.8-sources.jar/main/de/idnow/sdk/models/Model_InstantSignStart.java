package de.idnow.sdk.models;

import com.google.gson.annotations.SerializedName;

public class Model_InstantSignStart {

    @SerializedName("Identification-Signature")
    String Identification_Signature;

    String clientSecret;

    String sessionToken;

    @SerializedName("enableOTP")
    Models_EnableOTP enableOTP;

    public String getIdentification_Signature() {
        return Identification_Signature;
    }

    public void setIdentification_Signature(String identification_Signature) {
        Identification_Signature = identification_Signature;
    }

    public Model_InstantSignStart(String identification_Signature) {
        Identification_Signature = identification_Signature;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public String getSessionToken() {
        return sessionToken;
    }

    public void setSessionToken(String sessionToken) {
        this.sessionToken = sessionToken;
    }

    public Model_InstantSignStart(String identification_Signature, String clientSecret, Models_EnableOTP enableOTP) {
        Identification_Signature = identification_Signature;
        this.clientSecret = clientSecret;
        this.enableOTP = enableOTP;
    }

    public Models_EnableOTP getEnableOTP() {
        return enableOTP;
    }

    public void setEnableOTP(Models_EnableOTP enableOTP) {
        this.enableOTP = enableOTP;
    }


}
