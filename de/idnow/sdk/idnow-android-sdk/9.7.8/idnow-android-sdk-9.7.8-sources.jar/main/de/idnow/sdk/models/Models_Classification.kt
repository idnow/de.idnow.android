package de.idnow.sdk.models

data class Models_Classification(
    val country: String = "",
    val idType: String = "",
    val idSubtype: String = ""
)