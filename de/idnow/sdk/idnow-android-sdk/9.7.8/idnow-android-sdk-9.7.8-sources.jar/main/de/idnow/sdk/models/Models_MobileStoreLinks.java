package de.idnow.sdk.models;



/**
 * 
 * @date 02.02.2019
 * @author Souheib Selmi
 * @version 1.0
 */


public class Models_MobileStoreLinks
{

	String	androidPackage;

	public String getAndroidPackage() {
		return androidPackage;
	}

}
