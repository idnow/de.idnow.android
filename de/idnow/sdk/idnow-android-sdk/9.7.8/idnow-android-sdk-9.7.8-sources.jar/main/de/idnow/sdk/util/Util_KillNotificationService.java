package de.idnow.sdk.util;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

import de.idnow.sdk.Config;

/**
 * 
 * 
 * 
 * @author Mathias Grasy
 * @brief this class is needed to close the notification when the app gets killed via the taskmanager. this is handled with a service.
 */
public class Util_KillNotificationService extends Service
{

	public class KillBinder extends Binder
	{
		public final Service	service;

		public KillBinder( Service service )
		{
			this.service = service;
		}

	}

	private NotificationManager	mNM;
	private final IBinder		mBinder	= new KillBinder( this );

	@Override
	public IBinder onBind( Intent intent )
	{
		return mBinder;
	}

	@Override
	public int onStartCommand( Intent intent, int flags, int startId )
	{
		return Service.START_STICKY;
	}

	@Override
	public void onCreate()
	{
		mNM = ( NotificationManager ) getSystemService( NOTIFICATION_SERVICE );
		mNM.cancel( Config.NOTIFICATION_ID );
	}

}
