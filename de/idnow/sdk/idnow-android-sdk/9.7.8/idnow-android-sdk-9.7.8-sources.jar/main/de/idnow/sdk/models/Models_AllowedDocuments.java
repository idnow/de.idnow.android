package de.idnow.sdk.models;



/**
 * @date 16.10.2014
 * @author Mathias Grasy
 * @brief (short description)
 * 
 */


public class Models_AllowedDocuments
{
	String		country;
	Object[]	documents;

	/**
	 * @param country
	 * @param documents
	 */
	public Models_AllowedDocuments( String country, Object[] documents )
	{
		super();
		this.country = country;
		this.documents = documents;
	}

	/**
	 * @return the country
	 */
	public String getCountry()
	{
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry( String country )
	{
		this.country = country;
	}

	/**
	 * @return the documents
	 */
	public Object[] getDocuments()
	{
		return documents;
	}

	/**
	 * @param documents the documents to set
	 */
	public void setDocuments( String[] documents )
	{
		this.documents = documents;
	}

}
