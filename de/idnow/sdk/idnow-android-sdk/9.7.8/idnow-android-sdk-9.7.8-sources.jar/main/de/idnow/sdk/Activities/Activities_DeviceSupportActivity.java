package de.idnow.sdk.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

import androidx.annotation.Nullable;

import de.idnow.sdk.Activities.entry.Activities_EntryActivity;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.util.IDnowErrorCode;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_Util;

import static de.idnow.sdk.util.Util_Strings.KEY_DEVICE_SUPPORT_DESC;
import static de.idnow.sdk.util.Util_Strings.KEY_DEVICE_SUPPORT_FINISH;
import static de.idnow.sdk.util.Util_Strings.KEY_DEVICE_SUPPORT_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_DEVICE_SUPPORT_DESC;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_DEVICE_SUPPORT_FINISH;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_DEVICE_SUPPORT_TITLE;

public class Activities_DeviceSupportActivity extends BaseActivity {

    LottieAnimationView idnow_logo,resolution_animation;
    TextView title_requirement,text_try_again;
    Button button_finish;
    Context context;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(androidx.appcompat.R.style.Theme_AppCompat_Light_NoActionBar);
        setContentView(R.layout.activity_device_support);
        context = this;
        idnow_logo = findViewById(R.id.idnow_logo);
        resolution_animation = findViewById(R.id.resolution_animation);
        title_requirement = findViewById(R.id.title_requirement);
        text_try_again = findViewById(R.id.text_try_again);
        button_finish = findViewById(R.id.button_finish);

        title_requirement.setText(Util_Strings.getStringWithDefault(context, KEY_DEVICE_SUPPORT_TITLE, LOCAL_KEY_DEVICE_SUPPORT_TITLE));
        text_try_again.setText(Util_Strings.getStringWithDefault(context, KEY_DEVICE_SUPPORT_DESC, LOCAL_KEY_DEVICE_SUPPORT_DESC));
        button_finish.setText(Util_Strings.getStringWithDefault(context, KEY_DEVICE_SUPPORT_FINISH, LOCAL_KEY_DEVICE_SUPPORT_FINISH));


        idnow_logo.setAnimation("static_logo.json");
        resolution_animation.setAnimation("error_resolution.json");

        if(IDnowSDK.getShowIDnowLogo()){
            idnow_logo.setVisibility(View.VISIBLE);
        }
        else {
            idnow_logo.setVisibility(View.GONE);
        }

        button_finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!IDnowSDK.getOverrideEntryActivity()) {
                    Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity.class;
                }
                Intent intent = new Intent(context, Config.HOST_APP_START_ACTIVITY);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                intent.putExtra(IDnowSDK.RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorUnsupportedDevice);
                IDnowSDK.updateResultCode(IDnowSDK.RESULT_CODE_CANCEL);
                IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_CANCEL, getIntent());
                setResult(IDnowSDK.RESULT_CODE_CANCEL, getIntent());
                Util_Util.clearApplicationData(context);
                finish();
                if((!Config.BACK_TO_VID)||IDnowSDK.getOverrideEntryActivity()){
                    startActivity(intent);
                }
            }
        });

    }
}
