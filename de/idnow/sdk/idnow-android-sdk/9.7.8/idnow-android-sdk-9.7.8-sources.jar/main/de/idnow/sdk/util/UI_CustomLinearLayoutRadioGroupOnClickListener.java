package de.idnow.sdk.util;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

/**
 * @author Mathias Grasy
 * @version 1.0
 */
public class UI_CustomLinearLayoutRadioGroupOnClickListener implements OnClickListener
{

	private final View otherRadioGroupView;


	public UI_CustomLinearLayoutRadioGroupOnClickListener(View otherRadioGroupView)
	{
		this.otherRadioGroupView = otherRadioGroupView;
	}

	private void toggleCheckState(View v, boolean checked)
	{
		ImageView buttonToCheck = ( ImageView ) v.getTag();

		if ( !checked )
		{
			Util_UtilUI.setCheckMark( buttonToCheck, false );
			buttonToCheck.setTag( false );
		}
		else
		{
			Util_UtilUI.setCheckMark( buttonToCheck, true );
			buttonToCheck.setTag( true );
		}
	}

	@Override
	public void onClick( View v )
	{
		toggleCheckState(v, true);
		toggleCheckState( otherRadioGroupView, false );
	}
}
