package de.idnow.sdk.util;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import de.idnow.sdk.Activities.Activities_VideoOverviewCheckActivity;

/**
 * @author Mathias Grasy
 * @version 1.0
 * @brief click listener for checkboxes in OverviewCheckActivity
 */
class UI_CustomOnClickListener : OnClickListener {
    override fun onClick(v: View?) {
        v ?: return
        with(v.tag as Boolean) {
            Util_UtilUI.setCheckMark(v as ImageView, this.not())
            v.tag = this.not()
        }
        (v.context as Activities_VideoOverviewCheckActivity).handleIdentificationButtonActivation()
    }
}
