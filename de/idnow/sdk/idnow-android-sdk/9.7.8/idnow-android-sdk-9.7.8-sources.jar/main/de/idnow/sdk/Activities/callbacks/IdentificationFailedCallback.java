package de.idnow.sdk.Activities.callbacks;

public interface IdentificationFailedCallback {
    void onResult();
}
