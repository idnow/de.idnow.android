package de.idnow.sdk.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ScrollView;

/**
 * Created by lars.mehrtens on 04.03.18.
 */

public class LockableScrollView extends ScrollView {
	private boolean scrollable = true;

	public LockableScrollView(Context context) {
		super(context);
	}

	public LockableScrollView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public void setScrollingEnabled(boolean enabled) {
		scrollable = enabled;
	}

	public boolean isScrollable() {
		return scrollable;
	}

	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		switch (ev.getAction()) {
			case MotionEvent.ACTION_DOWN:
				// if we can scroll pass the event to the superclass
				if (scrollable) {
					return super.onTouchEvent(ev);
				} else {
					return scrollable;
				}
			default:
				return super.onTouchEvent(ev);
		}
	}

	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
 		if (!scrollable) {
			return false;
		} else {
			return super.onInterceptTouchEvent(ev);
		}
	}
}