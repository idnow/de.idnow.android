package de.idnow.sdk.models;

import com.google.gson.annotations.SerializedName;

public class Models_Request {
	public enum Status {
		UNKNOWN,
		REQUESTED_CHAT,
		ACCEPTED,
		RUNNING
	}

	private final String LOGTAG = "IDNOW_Models_Request";

	String status;
	String videoSession;
	String userVideoSessionToken;
	String videoserverUsed;

	String clientSecret;
	String sessionToken;

	// waiting queue
	int estimatedWaitingTime;
	int positionInQueue;
	@SerializedName("Identification-Signature")
	public String Identification_Signature;

	public static final int POSITION_NOT_INITIALIZED = -100;

	public Models_Request() {
		positionInQueue = POSITION_NOT_INITIALIZED;
	}

	public Models_Request(String videoSession, String userVideoSessionToken, String videoserverUsed, String Identification_Signature) {
		this.videoSession = videoSession;
		this.userVideoSessionToken = userVideoSessionToken;
		this.videoserverUsed = videoserverUsed;
		positionInQueue = POSITION_NOT_INITIALIZED;
		this.Identification_Signature = Identification_Signature;
	}

	public String getStatus() {
		return status;
	}

	public Status computeStatus() {
		for (Status value : Status.values()) {
			if (value.name().equalsIgnoreCase(status))
				return value;
		}

		return Status.UNKNOWN;
	}

	public String getVideoSession() {
		return videoSession;
	}

	public String getUserVideoSessionToken() {
		return userVideoSessionToken;
	}

	public String getVideoserverUsed() {
		return videoserverUsed;
	}

	public int getEstimatedWaitingTime() {
		return estimatedWaitingTime < 0 ? 0 : estimatedWaitingTime;
	}

	/**
	 * We can receive responses from the server where the position in the queue is not yet defined.
	 * In such a case the JSON parser will not set the field positionInQueue; in order to determine
	 * if the value was set from the JSON, this method can be used
	 *
	 * @return true in case the positionInQueue was initialized by the JSON response
	 */
	public boolean isPositionInitializedByResponse() {
		return positionInQueue != POSITION_NOT_INITIALIZED;
	}

	public static int getPositionNotInitialized() {
		return POSITION_NOT_INITIALIZED;
	}

	public int getPositionInQueue() {
		return positionInQueue < 0 ? 0 : positionInQueue;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public String getSessionToken() {
		return sessionToken;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getIdentification_Signature() {
		return Identification_Signature;
	}

	public void setIdentification_Signature(String identification_Signature) {
		Identification_Signature = identification_Signature;
	}

	@Override
	public String toString() {
		return "Models_Request{" +
				"LOGTAG='" + LOGTAG + '\'' +
				", status='" + status + '\'' +
				", videoSession='" + videoSession + '\'' +
				", userVideoSessionToken='" + userVideoSessionToken + '\'' +
				", videoserverUsed='" + videoserverUsed + '\'' +
				", clientSecret='" + clientSecret + '\'' +
				", estimatedWaitingTime=" + estimatedWaitingTime +
				", positionInQueue=" + positionInQueue +
				", Identification_Signature='" + Identification_Signature + '\'' +
				'}';
	}
}