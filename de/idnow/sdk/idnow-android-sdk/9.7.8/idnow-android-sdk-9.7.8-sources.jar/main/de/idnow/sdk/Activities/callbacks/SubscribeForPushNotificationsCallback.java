package de.idnow.sdk.Activities.callbacks;

public interface SubscribeForPushNotificationsCallback {
    void onSuccess(String companyId, String token);
    void onFailure();
}
