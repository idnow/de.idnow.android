package de.idnow.sdk.network

import android.os.Build
import de.idnow.sdk.BuildConfig
import de.idnow.sdk.Config
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.util.Util_Log
import okhttp3.ConnectionSpec
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.TlsVersion
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext

class IDNowOkHttpFactory {
    companion object {
        private const val LOGTAG = "IDNOW_IDNowOkHttpFactory"
        private const val DEFAULT_READ_TIMEOUT = 60
        private const val DEFAULT_CONNECT_TIMEOUT = 10
        private const val DEFAULT_WRITE_TIMEOUT = 10

        fun createOkHttpClient(): OkHttpClient? =
            createOkHttpClient(
                readTimeout = DEFAULT_READ_TIMEOUT,
                connectTimeout = DEFAULT_CONNECT_TIMEOUT,
                writeTimeout = DEFAULT_WRITE_TIMEOUT
            )

        fun createOkHttpClient(
            readTimeout: Int = DEFAULT_READ_TIMEOUT,
            connectTimeout: Int = DEFAULT_CONNECT_TIMEOUT,
            writeTimeout: Int = DEFAULT_WRITE_TIMEOUT,
            networkInterceptor: Interceptor? = null,
            logInterceptor: Interceptor? = null
        ): OkHttpClient? {
            val client: OkHttpClient.Builder?

            Util_Log.i(LOGTAG, "API LEVEL" + Build.VERSION.SDK_INT)

            try {
                val connectionSpec: ConnectionSpec =
                    ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS)
                        .tlsVersions(TlsVersion.TLS_1_2)
                        .cipherSuites(*provideCiphers())
                        .build()

                val keyManager = Config.CERTIFICATE_PROVIDER?.takeIf { it.featureCertificate() }
                    ?.let { IDNowKeyManager("client") }

                val sslContext = SSLContext.getInstance("SSL")
                    .apply {
                        init(
                            keyManager?.let { arrayOf(it) },
                            arrayOf(IDNowTrustManager),
                            SecureRandom()
                        )
                    }

                client = OkHttpClient.Builder()
                    .sslSocketFactory(sslContext.socketFactory, IDNowTrustManager)
                    .connectionSpecs(listOf(connectionSpec))
                    .readTimeout(readTimeout.toLong(), TimeUnit.SECONDS)
                    .connectTimeout(connectTimeout.toLong(), TimeUnit.SECONDS)
                    .writeTimeout(writeTimeout.toLong(), TimeUnit.SECONDS)
            } catch (e: Exception) {
                Util_Log.e(LOGTAG, "Create OkHttpClient failed", e)
                return null
            }

            networkInterceptor?.let(client::addInterceptor)
            logInterceptor?.takeIf { IDnowSDK.isLoggingEnabled() && BuildConfig.DEBUG }
                ?.let(client::addInterceptor)

            return client.build()
        }

        private fun provideCiphers(): Array<String> {
            return arrayOf(
                "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256",
                "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
                "TLS_RSA_WITH_AES_128_GCM_SHA256"
            )
        }
    }
}