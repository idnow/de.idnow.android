package de.idnow.sdk.models;


import com.google.gson.annotations.SerializedName;

import java.util.Arrays;

/**
 * @author Mathias Grasy
 * @date 16.10.2014
 * @brief (short description)
 */

public class Models_Settings {

    Models_Processsteps processsteps;
    public Models_Usersteps usersteps;

    // VideoOverviewCheckActivity: toggle visibility of recordingAgreement TextView and GTC TextView
    boolean showRecordingAgreement;
    boolean showGTC;

    String successURL;
    String failureURL;
    String fallbackURL;

    private int hologramsvideo = 0;

    String videoserver;

    // overwrite success, failure, fallback URLs -> if set, don't show the resultScreen at the end. link to an url instead.
    Models_AndroidURLs android;

    // video or photo
    String processtype;

    boolean identCodeRequired;
    boolean expiryDateRequired;
    private final boolean disabledMobileNumberChange;
    public boolean allowTextChat;
    private boolean enablePiPAndroid;

    String[] identCodeChannels;

    public Models_WaitingList waitingList;

    int reviewTimelimit;

    private final int screenshotUploadLongestEdgeSize;
    private final int videoMaxDimensionEdge;

    boolean verifyMobileNumber = false;
    boolean showDocusignPrivacyNotice = false;

    boolean enableIdentCodeAutoFill = false;
    boolean callQualityCheck = false;

    private final boolean showPoweredBy;
    private final boolean showIDnowLogo;

    private final boolean showHighCallVolume;
    private final boolean isautoident;
    private final boolean enableGoogleRating;
    private final boolean enableWaitingScreen;

    private Models_MobileStoreLinks mobileStoreLinks;
    private boolean enableAppRating;
    private boolean authenticatedSigning;

    private final Models_Sentry sentry;

    private boolean hashSigning;

    private boolean DTMAndPSM;
    private final String googleRatingLink;

    private final Model_VideoConfig model_videoConfig;

    private boolean createIdentRecordinAtrust;

    private final Model_VideoIdentPlus model_videoIdentPlus;

    private boolean videoIdentPlusEnabled;

    private Model_VideoIdentPlus videoIdentPlus;

    private boolean electronicID = false;

    private boolean enableAgentFeedback = false;

    private Model_CustomLogData insights;

    @SerializedName("mobile")
    private Models_Mobile mobile;

    private boolean authenticatedSigningHideOptionToContinueWithoutWallet;

    private boolean enableEIDRerouting;
    private boolean enableIDCaptureEID;
    private boolean enablePINChange;
    private boolean enabledEIDStandaloneAndroid;
    private Model_UserCancellation userCancellation;
    private boolean enableEIDQES;
    private boolean chooseEIDType;
    private String eIDTSP;
    private int enableWaitingScreenCustomisedTimer;
    private boolean enableWaitingScreenCustomisedAndroid;
    private Model_AuthadaConfig authadaConfig;
    private Model_Socket socket;
    private boolean enableBluetoothAudioAndroid;
    private boolean hidesUserPiiData;

    private Boolean showPrepareScreen;

    private boolean showNameVerificationScreen;
    /**
     * @param processsteps
     * @param processtype
     */

    private boolean languageSelectorAndroid = false;

    private boolean enableIdentForReuse = false;

    private Models_StoredIdentity stored_identity;

    public Models_Settings(Models_WaitingList waitingList, Models_Processsteps processsteps, Models_Usersteps usersteps, String processtype, boolean showRecordingAgreement, boolean showGTC, boolean verifyMobileNumber, String successURL,
                           String failureURL, String fallbackURL, Models_AndroidURLs android, String videoserver, boolean identCodeRequired, boolean expiryDateRequired, boolean checkBoxInstructionsScreen, int hologramsvideo, boolean disabledMobileNumberChange, int screenshotUploadLongestEdgeSize,
                           int videoMaxDimensionEdge, boolean showPoweredBy, boolean showHighCallVolume, boolean isautoident,
                           Models_MobileStoreLinks mobileStoreLinks, boolean enableGoogleRating,
                           boolean enableAppRating, boolean authenticatedSigning,
                           boolean hashSigning, Models_Sentry sentry, boolean enableWaitingScreen, String googleRatingLink, Model_VideoConfig model_videoConfig,
                           boolean createIdentRecordinAtrust, boolean electronicID, boolean videoIdentPlusEnabled, Model_VideoIdentPlus model_videoIdentPlus, boolean enableAgentFeedback, Model_CustomLogData insights, Models_Mobile mobile, boolean authenticatedSigningHideOptionToContinueWithoutWallet, Model_UserCancellation userCancellation, boolean enableIDCaptureEID, boolean enablePINChange, boolean enabledEIDStandaloneAndroid, boolean enableEIDRerouting, boolean enableEIDQES, boolean enableWaitingScreenCustomisedAndroid, int enableWaitingScreenCustomisedTimer, boolean showIDnowLogo, Model_AuthadaConfig authadaConfig, boolean hidesUserPiiData, boolean enableBluetoothAudioAndroid, Model_Socket socket, boolean showPrepareScreen, boolean chooseEIDType, String eIDTSP) {
        super();
        this.waitingList = waitingList;
        this.processsteps = processsteps;
        this.processtype = processtype;
        this.showGTC = showGTC;
        this.showRecordingAgreement = showRecordingAgreement;
        this.successURL = successURL;
        this.failureURL = failureURL;
        this.fallbackURL = fallbackURL;
        this.android = android;
        this.usersteps = usersteps;
        this.videoserver = videoserver;
        this.identCodeRequired = identCodeRequired;
        this.verifyMobileNumber = verifyMobileNumber;
        this.enableIdentCodeAutoFill = enableIdentCodeAutoFill;
        this.callQualityCheck = callQualityCheck;
        this.expiryDateRequired = expiryDateRequired;
        this.hologramsvideo = hologramsvideo;
        this.disabledMobileNumberChange = disabledMobileNumberChange;
        this.screenshotUploadLongestEdgeSize = screenshotUploadLongestEdgeSize;
        this.videoMaxDimensionEdge = videoMaxDimensionEdge;
        this.showPoweredBy = showPoweredBy;
        this.showIDnowLogo = showIDnowLogo;
        this.showHighCallVolume = showHighCallVolume;
        this.isautoident = isautoident;
        this.sentry = sentry;
        this.enableGoogleRating = enableGoogleRating;
        this.enableWaitingScreen = enableWaitingScreen;
        this.googleRatingLink = googleRatingLink;
        this.model_videoConfig = model_videoConfig;
        this.createIdentRecordinAtrust = createIdentRecordinAtrust;
        this.videoIdentPlusEnabled = videoIdentPlusEnabled;
        this.model_videoIdentPlus = model_videoIdentPlus;
        this.electronicID = electronicID;
        this.enableAgentFeedback = enableAgentFeedback;
        this.insights = insights;
        this.mobile = mobile;
        this.authenticatedSigningHideOptionToContinueWithoutWallet = authenticatedSigningHideOptionToContinueWithoutWallet;
        this.userCancellation = userCancellation;
        this.enableEIDRerouting = enableEIDRerouting;
        this.enableIDCaptureEID = enableIDCaptureEID;
        this.enablePINChange = enablePINChange;
        this.enabledEIDStandaloneAndroid = enabledEIDStandaloneAndroid;
        this.enableEIDQES = enableEIDQES;
        this.chooseEIDType = chooseEIDType;
        this.enableWaitingScreenCustomisedTimer = enableWaitingScreenCustomisedTimer;
        this.enableWaitingScreenCustomisedAndroid = enableWaitingScreenCustomisedAndroid;
        this.authadaConfig = authadaConfig;
        this.socket = socket;
        this.enableBluetoothAudioAndroid = enableBluetoothAudioAndroid;
        this.hidesUserPiiData = hidesUserPiiData;
        this.showPrepareScreen = showPrepareScreen;
        this.showNameVerificationScreen = showNameVerificationScreen;
        this.eIDTSP = eIDTSP;
    }

    public int getHologramsVideoLength() {
        return hologramsvideo;
    }

    public void setHologramsVideoLength(int hologramsvideo) {
        this.hologramsvideo = hologramsvideo;
    }

    public Models_Usersteps getUsersteps() {
        return usersteps;
    }

    public void setUsersteps(Models_Usersteps usersteps) {
        this.usersteps = usersteps;
    }

    public String getVideoserver() {
        return videoserver;
    }

    public void setVideoserver(String videoserver) {
        this.videoserver = videoserver;
    }

    /**
     * @return the android
     */
    public Models_AndroidURLs getAndroid() {
        return android;
    }

    /**
     * @param android the android to set
     */
    public void setAndroid(Models_AndroidURLs android) {
        this.android = android;
    }

    /**
     * @return the fallbackURL
     */
    public String getFallbackURL() {
        return fallbackURL;
    }

    /**
     * @param fallbackURL the fallbackURL to set
     */
    public void setFallbackURL(String fallbackURL) {
        this.fallbackURL = fallbackURL;
    }

    /**
     * @return the successURL
     */
    public String getSuccessURL() {
        return successURL;
    }

    /**
     * @param successURL the successURL to set
     */
    public void setSuccessURL(String successURL) {
        this.successURL = successURL;
    }

    /**
     * @return the failureURL
     */
    public String getFailureURL() {
        return failureURL;
    }

    /**
     * @param failureURL the failureURL to set
     */
    public void setFailureURL(String failureURL) {
        this.failureURL = failureURL;
    }

    /**
     * @return the showRecordingAgreement
     */
    public boolean showRecordingAgreement() {
        return showRecordingAgreement;
    }

    /**
     * @param showRecordingAgreement the showRecordingAgreement to set
     */
    public void setShowRecordingAgreement(boolean showRecordingAgreement) {
        this.showRecordingAgreement = showRecordingAgreement;
    }

    /**
     * @return the showGTC
     */
    public boolean showGTC() {
        return showGTC;
    }

    /**
     * @param showGTC the showGTC to set
     */
    public void setShowGTC(boolean showGTC) {
        this.showGTC = showGTC;
    }

    /**
     * @return the processteps
     */
    public Models_Processsteps getProcesssteps() {
        return processsteps;
    }

    /**
     * @param processsteps the processteps to set
     */
    public void setProcessteps(Models_Processsteps processsteps) {
        this.processsteps = processsteps;
    }

    /**
     * @return the processtype
     */
    public String getProcesstype() {
        return processtype;
    }

    /**
     * @param processtype the processtype to set
     */
    public void setProcesstype(String processtype) {
        this.processtype = processtype;
    }

    public boolean isIdentCodeRequired() {
        return identCodeRequired;
    }

    public boolean isVerifyMobileNumber() {
        return verifyMobileNumber;
    }

    public void setVerifyMobileNumber(boolean verifyMobileNumber) {
        this.verifyMobileNumber = verifyMobileNumber;
    }

    public boolean isShowDocusignPrivacyNotice() {
        return showDocusignPrivacyNotice;
    }

    public void setShowDocusignPrivacyNotice(boolean showDocusignPrivacyNotice) {
        this.showDocusignPrivacyNotice = showDocusignPrivacyNotice;
    }

    public void setIdentCodeRequired(boolean identCodeRequired) {
        this.identCodeRequired = identCodeRequired;
    }

    /**
     * if there is a identCodeChannels object, it offers the ways the ident code can be requested (SMS or Email). If no idenCodeChannels object is there,
     * SMS is selected by default.
     * <p>
     * example:
     * "identCodeChannels": [
     * "SMS",
     * "EMAIL"
     * ]
     *
     * @return
     */
    public String[] getIdentCodeChannels() {
        return identCodeChannels;
    }

    public int getReviewTimelimit() {
        return reviewTimelimit;
    }

    public void setReviewTimelimit(int reviewTimelimit) {
        this.reviewTimelimit = reviewTimelimit;
    }


    public Models_WaitingList getWaitingList() {
        return waitingList;
    }

    public boolean isEnableIdentCodeAutoFill() {
        return enableIdentCodeAutoFill;
    }

    public void setEnableIdentCodeAutoFill(boolean enableIdentCodeAutoFill) {
        this.enableIdentCodeAutoFill = enableIdentCodeAutoFill;
    }

    public boolean isCallQualityCheck() {
        return callQualityCheck;
    }

    public void setCallQualityCheck(boolean callQualityCheck) {
        this.callQualityCheck = callQualityCheck;
    }

    public boolean isExpiryDateRequired() {
        return expiryDateRequired;
    }

    public void setExpiryDateRequired(boolean expiryDateRequired) {
        this.expiryDateRequired = expiryDateRequired;
    }

    public boolean isDisabledMobileNumberChange() {
        return disabledMobileNumberChange;
    }

    public int getScreenshotUploadLongestEdgeSize() {
        return screenshotUploadLongestEdgeSize;
    }

    public int getVideoMaxDimensionEdge() {
        return videoMaxDimensionEdge;
    }

    public boolean getShowPoweredBy() {
        return showPoweredBy;
    }

    public boolean getShowHighCallVolume() {
        return showHighCallVolume;
    }

    public boolean isAutoIdent() {
        return isautoident;
    }

    public Models_MobileStoreLinks getMobileStoreLinks() {
        return mobileStoreLinks;
    }

    public boolean isEnableGoogleRating() {
        return enableGoogleRating;
    }

    public boolean isEnableAppRating() {
        return enableAppRating;
    }

    public boolean isEnableWaitingScreen() {
        return enableWaitingScreen;
    }

    public boolean isAuthenticatedSigning() {
        return authenticatedSigning;
    }

    public boolean isEnableBluetoothAudioAndroid() {
        return enableBluetoothAudioAndroid;
    }

    public Models_Sentry getSentry() {
        return sentry;
    }

    public boolean isHashSigning() {
        return hashSigning;
    }

    public boolean isDTMAndPSM() {
        return DTMAndPSM;
    }

    public String getGoogleRatingLink() {
        return googleRatingLink;
    }

    public Model_VideoConfig getModel_videoConfig() {
        return model_videoConfig;
    }

    public boolean getCreateIdentRecordinAtrust() {
        return createIdentRecordinAtrust;
    }

    public void setCreateIdentRecordinAtrust(boolean createIdentRecordinAtrust) {
        this.createIdentRecordinAtrust = createIdentRecordinAtrust;
    }

    public boolean isVideoIdentPlusEnabled() {
        return videoIdentPlusEnabled;
    }

    public void setVideoIdentPlusEnabled(boolean videoIdentPlusEnabled) {
        this.videoIdentPlusEnabled = videoIdentPlusEnabled;
    }

    public Model_VideoIdentPlus getVideoIdentPlus() {
        return videoIdentPlus;
    }

    public void setVideoIdentPlus(Model_VideoIdentPlus videoIdentPlus) {
        this.videoIdentPlus = videoIdentPlus;
    }

    public boolean isElectronicId() {
        return electronicID;
    }

    public void setElectronicID(boolean electronicID) {
        this.electronicID = electronicID;
    }

    public boolean isEnableAgentFeedback() {
        return enableAgentFeedback;
    }

    public void setEnableAgentFeedback(boolean enableAgentFeedback) {
        this.enableAgentFeedback = enableAgentFeedback;
    }

    public Model_CustomLogData getModel_customLogData() {
        return insights;
    }

    public void setModel_customLogData(Model_CustomLogData model_customLogData) {
        this.insights = model_customLogData;
    }

    public Models_Mobile getMobile() {
        return mobile;
    }

    public void setMobile(Models_Mobile mobile) {
        this.mobile = mobile;
    }

    public boolean isAuthenticatedSigningHideOptionToContinueWithoutWallet() {
        return authenticatedSigningHideOptionToContinueWithoutWallet;
    }

    public void setAuthenticatedSigningHideOptionToContinueWithoutWallet(boolean authenticatedSigningHideOptionToContinueWithoutWallet) {
        this.authenticatedSigningHideOptionToContinueWithoutWallet = authenticatedSigningHideOptionToContinueWithoutWallet;
    }

    public Model_UserCancellation getUserCancellation() {
        return userCancellation;
    }

    public void setUserCancellation(Model_UserCancellation userCancellation) {
        this.userCancellation = userCancellation;
    }

    public boolean isEnableIDCaptureEID() {
        return enableIDCaptureEID;
    }

    public void setEnableIDCaptureEID(boolean enableIDCaptureEID) {
        this.enableIDCaptureEID = enableIDCaptureEID;
    }

    public String getEIDTSP() {
        return eIDTSP;
    }

    public void setEIDTSP(String eidtsp) {
        this.eIDTSP = eidtsp;
    }

    public boolean isEnablePINChange() {
        return enablePINChange;
    }

    public boolean isEnabledEIDStandaloneAndroid() {
        return enabledEIDStandaloneAndroid;
    }

    public void setEnablePINChange(boolean enablePINChange) {
        this.enablePINChange = enablePINChange;
    }

    public boolean isEnableEIDRerouting() {
        return enableEIDRerouting;
    }

    public void setEnableEIDRerouting(boolean enableEIDRerouting) {
        this.enableEIDRerouting = enableEIDRerouting;
    }

    public boolean isEnableEIDQES() {
        return enableEIDQES;
    }

    public void setEnableEIDQES(boolean enableEIDQES) {
        this.enableEIDQES = enableEIDQES;
    }

    public boolean isChooseEIDType() {
        return chooseEIDType;
    }

    public void setChooseEIDType(boolean chooseEIDType) {
        this.chooseEIDType = chooseEIDType;
    }

    public boolean isEnableWaitingScreenCustomisedAndroid() {
        return enableWaitingScreenCustomisedAndroid;
    }

    public void setEnableWaitingScreenCustomisedAndroid(boolean enableWaitingScreenCustomisedAndroid) {
        this.enableWaitingScreenCustomisedAndroid = enableWaitingScreenCustomisedAndroid;
    }

    public int getEnableWaitingScreenCustomisedTimer() {
        return enableWaitingScreenCustomisedTimer;
    }

    public void setEnableWaitingScreenCustomisedTimer(int enableWaitingScreenCustomisedTimer) {
        this.enableWaitingScreenCustomisedTimer = enableWaitingScreenCustomisedTimer;
    }

    public boolean isShowIDnowLogo() {
        return showIDnowLogo;
    }

    public Model_AuthadaConfig getAuthadaConfig() {
        return authadaConfig;
    }

    public void setAuthadaConfig(Model_AuthadaConfig authadaConfig) {
        this.authadaConfig = authadaConfig;
    }

    public Model_Socket getSocket() {
        return socket;
    }

    public void setSocket(Model_Socket socket) {
        this.socket = socket;
    }

    public boolean isLanguageSelectorAndroid() {
        return languageSelectorAndroid;
    }

    public void setLanguageSelectorAndroid(boolean languageSelectorAndroid) {
        this.languageSelectorAndroid = languageSelectorAndroid;
    }

    public void setEnableIdentForReuse(boolean enableIdentForReuse) {
        this.enableIdentForReuse = enableIdentForReuse;
    }

    public boolean isEnableIdentForReuse() {
        return enableIdentForReuse;
    }

    public boolean isHidesUserPiiData() {
        return hidesUserPiiData;
    }

    public void setHidesUserPiiData(boolean hidesUserPiiData) {
        this.hidesUserPiiData = hidesUserPiiData;
    }

    public Models_StoredIdentity getStored_identity() {
        return stored_identity;
    }

    public void setStored_identity(Models_StoredIdentity stored_identity) {
        this.stored_identity = stored_identity;
    }

    public Boolean isShowPrepareScreen() {
        return showPrepareScreen;
    }

    public void setShowPrepareScreen(Boolean showPrepareScreen) {
        this.showPrepareScreen = showPrepareScreen;
    }


    public boolean isShowNameVerificationScreen() {
        return showNameVerificationScreen;
    }

    public void setShowNameVerificationScreen(boolean showNameVerificationScreen) {
        this.showNameVerificationScreen = showNameVerificationScreen;
    }

    @Override
    public String toString() {
        return "Models_Settings{" +
                "processsteps=" + processsteps +
                ", usersteps=" + usersteps +
                ", showRecordingAgreement=" + showRecordingAgreement +
                ", showGTC=" + showGTC +
                ", successURL='" + successURL + '\'' +
                ", failureURL='" + failureURL + '\'' +
                ", fallbackURL='" + fallbackURL + '\'' +
                ", hologramsvideo=" + hologramsvideo +
                ", videoserver='" + videoserver + '\'' +
                ", android=" + android +
                ", processtype='" + processtype + '\'' +
                ", identCodeRequired=" + identCodeRequired +
                ", expiryDateRequired=" + expiryDateRequired +
                ", disabledMobileNumberChange=" + disabledMobileNumberChange +
                ", allowTextChat=" + allowTextChat +
                ", identCodeChannels=" + Arrays.toString(identCodeChannels) +
                ", waitingList=" + waitingList +
                ", reviewTimelimit=" + reviewTimelimit +
                ", screenshotUploadLongestEdgeSize=" + screenshotUploadLongestEdgeSize +
                ", videoMaxDimensionEdge=" + videoMaxDimensionEdge +
                ", verifyMobileNumber=" + verifyMobileNumber +
                ", showDocusignPrivacyNotice=" + showDocusignPrivacyNotice +
                ", enableIdentCodeAutoFill=" + enableIdentCodeAutoFill +
                ", callQualityCheck=" + callQualityCheck +
                ", showPoweredBy=" + showPoweredBy +
                ", showIDnowLogo=" + showIDnowLogo +
                ", showHighCallVolume=" + showHighCallVolume +
                ", isautoident=" + isautoident +
                ", enableGoogleRating=" + enableGoogleRating +
                ", enableWaitingScreen=" + enableWaitingScreen +
                ", mobileStoreLinks=" + mobileStoreLinks +
                ", enableAppRating=" + enableAppRating +
                ", authenticatedSigning=" + authenticatedSigning +
                ", sentry=" + sentry +
                ", hashSigning=" + hashSigning +
                ", DTMAndPSM=" + DTMAndPSM +
                ", googleRatingLink='" + googleRatingLink + '\'' +
                ", model_videoConfig=" + model_videoConfig +
                ", createIdentRecordinAtrust=" + createIdentRecordinAtrust +
                ", model_videoIdentPlus=" + model_videoIdentPlus +
                ", videoIdentPlusEnabled=" + videoIdentPlusEnabled +
                ", videoIdentPlus=" + videoIdentPlus +
                ", electronicID=" + electronicID +
                ", enableAgentFeedback=" + enableAgentFeedback +
                ", insights=" + insights +
                ", mobile=" + mobile +
                ", authenticatedSigningHideOptionToContinueWithoutWallet=" + authenticatedSigningHideOptionToContinueWithoutWallet +
                ", enableEIDRerouting=" + enableEIDRerouting +
                ", enableIDCaptureEID=" + enableIDCaptureEID +
                ", enablePINChange=" + enablePINChange +
                ", enabledEIDStandaloneAndroid=" + enabledEIDStandaloneAndroid +
                ", userCancellation=" + userCancellation +
                ", enableEIDQES=" + enableEIDQES +
                ", enableWaitingScreenCustomisedTimer=" + enableWaitingScreenCustomisedTimer +
                ", enableWaitingScreenCustomisedAndroid=" + enableWaitingScreenCustomisedAndroid +
                ", authadaConfig=" + authadaConfig +
                ", socket=" + socket +
                ", enableBluetoothAudioAndroid=" + enableBluetoothAudioAndroid +
                ", hidesUserPiiData=" + hidesUserPiiData +
                ", showPrepareScreen=" + showPrepareScreen +
                ", languageSelectorAndroid=" + languageSelectorAndroid +
                '}';
    }

    public boolean isEnablePiPAndroid() {
        return enablePiPAndroid;
    }

    public void setEnablePiPAndroid(boolean enablePiPAndroid) {
        this.enablePiPAndroid = enablePiPAndroid;
    }
}
