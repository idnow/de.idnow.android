package de.idnow.sdk.Activities;

import static de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_CallQualityCheck.CallQualityResult.EXCELLENT;
import static de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_CallQualityCheck.CallQualityResult.MODERATE;
import static de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_CallQualityCheck.CallQualityResult.UNKNOWN;
import static de.idnow.sdk.Config.CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED;
import static de.idnow.sdk.util.Util_CustomLogData.EVENT_CQC_SCREEN_SHOWN;
import static de.idnow.sdk.util.Util_Strings.KEY_CQC_ACTIVE_AUDIO;
import static de.idnow.sdk.util.Util_Strings.KEY_CQC_ACTIVE_NETWORK;
import static de.idnow.sdk.util.Util_Strings.KEY_CQC_ACTIVE_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_CQC_ACTIVE_VIDEO;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_FINISH;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CQC_MODERATE_1;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CQC_MODERATE_2;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CQC_MODERATE_3;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_BAD;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_BAD_1;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_BAD_2;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_DESC;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_MODERATE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_OTHER_STATUS;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_CQC_ACTIVE_AUDIO;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_CQC_ACTIVE_NETWORK;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_CQC_ACTIVE_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_CQC_ACTIVE_VIDEO;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_FINISH;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_1;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_2;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_3;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_1;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_2;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_DESC;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_MODERATE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_OTHER_STATUS;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import de.idnow.sdk.Activities.entry.Activities_EntryActivity;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.Liveswitch.Conference;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Model_ConferenceCallQualityMetrics;
import de.idnow.sdk.models.Models_CallQualityTest;
import de.idnow.sdk.models.Models_ClientInfo;
import de.idnow.sdk.models.Models_NewMirrorConference;
import de.idnow.sdk.models.Models_SdpOffer;
import de.idnow.sdk.models.Models_StartObject;
import de.idnow.sdk.models.Models_StartObjectResult;
import de.idnow.sdk.network.Callback;
import de.idnow.sdk.network.IDnowRestClient;
import de.idnow.sdk.network.Network_RESTCalls;
import de.idnow.sdk.network.RetrofitError;
import de.idnow.sdk.network.connectivityService.ConnectivityService;
import de.idnow.sdk.util.Util_CustomLogData;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_Util;
import de.idnow.sdk.util.Util_UtilRetrofit;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.Util_VideoSessionConfig;
import de.idnow.sdk.util.Util_VideoStreamService;
import de.idnow.sdk.views.CallQualityLightView;
import de.idnow.sdk.views.LockableScrollView;
import fm.liveswitch.Candidate;
import fm.liveswitch.DataChannel;
import fm.liveswitch.DataChannelReceiveArgs;
import fm.liveswitch.Promise;
import fm.liveswitch.SessionDescription;
import fm.liveswitch.SessionDescriptionType;
import fm.liveswitch.sdp.Message;
import retrofit2.Call;
import retrofit2.Response;

public class Activities_VideoLiveStreamActivity_CallQualityCheck extends BaseActivity {
    private final static String LOGTAG = "IDNOW_Activities_VideoLiveStreamActivity_CallQualityCheck";

    private final Context context = this;
    private RelativeLayout container;
    private RelativeLayout containerSubscriber;
    private RelativeLayout callQualityCheckRunningLayout;
    private LinearLayout callQualityCheckResultLayout;
    private Button callQualityResultButton;
    private TextView callQualityRetryLink;
    private ProgressBar progressBarLoading;
    private ProgressBar callQualitySubscriberBar;
    private TextView callQualityProgressText;
    private TextView callQualityResultText;

    private Conference conference;

    private volatile Models_CallQualityTest callQualityTest;

    private ImageView callQualityImageConnection;
    private ImageView callQualityImageAudio;
    private ImageView callQualityImageVideo;

    private TextView callQualityTitleText;
    private TextView callQualityCheckBandwidthLabel;
    private TextView callQualityAudioLabel;
    private TextView callQualityVideoLabel;

    public ProgressBar progressBar;

    private LockableScrollView scrollView;

    /* Fiducia Attributes */

    private TextView title, description;
    private Button retrycqc, actioncqc;
    private LinearLayout linearlayoutAfterCQC;
    private View linedivider;
    private TextView description1, point1, point2, description2, description3, point3;
    private int remainingInternalTokenRetries;


    public enum CallQualityResult {
        UNKNOWN,
        POOR,
        MODERATE,
        EXCELLENT;

        public int getInt() {
            return ordinal();
        }
    }

    private int MAX_RECONNECTION_ATTEMPTS = 2;
    private int reconnectionAttemptCounter = 0;
    private int callQualitySampleCounter = 0;
    private List<Integer> callQualitySampleList;

    public RelativeLayout old_cqc, new_cqc, other_internet_connection;
    public LinearLayout good_internet_connection;

    public TextView connection_vip_title, connection_vip_desc, connection_vip_good_1, connection_vip_good_2, connection_vip_good_3, connection_vip_other_title, connection_vip_status,
            connection_vip_other_desc_1, connection_vip_troubleshooting, connection_vip_other_desc_2, connection_vip_other_desc_3, connection_vip_other_result;


    public Button connection_vip_other_button;

    public LottieAnimationView token_retries_agent_image, sfGifView, callQualityImageVideo_vip, callQualityImageAudio_vip, callQualityImageBandwith_vip, status_image, used_logo_cqc, used_logo_cqc_other, status_image_good;

    //token retries user feedback
    private LinearLayout token_retries_layout;
    private TextView token_retries_title, token_retries_message, secondary_button;
    private Button main_button;

    private final ArrayList<Call<?>> pendingApiCalls = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Config.REMAINING_TRIES = -1;

        Util_CustomLogData.setEventData(EVENT_CQC_SCREEN_SHOWN, "EVENT_CQC_SCREEN_SHOWN", "CQC", "Screen", null);

        Util_Log.d("COUNTLY LOG", "EVENT_CQC_SCREEN_SHOWN");

        callQualitySampleList = new ArrayList<>();

        setContentView(R.layout.activity_call_quality_check);

        old_cqc = findViewById(R.id.old_cqc);
        new_cqc = findViewById(R.id.new_cqc);
        used_logo_cqc = findViewById(R.id.used_logo_cqc);
        used_logo_cqc_other = findViewById(R.id.used_logo_cqc_other);

        // token retries layout user feedback
        token_retries_layout = findViewById(R.id.token_retries_layout);
        token_retries_title = findViewById(R.id.token_retries_title);
        token_retries_message = findViewById(R.id.token_retries_message);
        main_button = findViewById(R.id.main_button);
        secondary_button = findViewById(R.id.secondary_button);
        token_retries_agent_image = findViewById(R.id.token_retries_agent_image);

        token_retries_agent_image.setAnimation("static_agent_id_fail.json");
        used_logo_cqc.setAnimation("static_logo.json");
        used_logo_cqc_other.setAnimation("static_logo.json");

        if (IDnowSDK.getShowIDnowLogo()) {
            used_logo_cqc.setVisibility(View.VISIBLE);
            used_logo_cqc_other.setVisibility(View.VISIBLE);
        } else {
            used_logo_cqc.setVisibility(View.GONE);
            used_logo_cqc_other.setVisibility(View.GONE);
        }

        if (Config.DARK_MODE) {
            Util_UtilUI.setColorLottieAnimation(Color.WHITE, used_logo_cqc, "SecondaryVariant");
            Util_UtilUI.setColorLottieAnimation(Color.WHITE, token_retries_agent_image, "SecondaryVariant");
            Util_UtilUI.setColorLottieAnimation(Color.WHITE, used_logo_cqc_other, "SecondaryVariant");
        } else {
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, used_logo_cqc, "SecondaryVariant");
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, token_retries_agent_image, "SecondaryVariant");
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, used_logo_cqc_other, "SecondaryVariant");
        }

        if (Config.VIDEO_IDENT_PLUS) {

            old_cqc.setVisibility(View.GONE);
            new_cqc.setVisibility(View.VISIBLE);

            new_cqc.setVisibility(View.VISIBLE);

            good_internet_connection = findViewById(R.id.good_internet_connection);
            other_internet_connection = findViewById(R.id.other_internet_connection);
            callQualityImageVideo_vip = findViewById(R.id.callQualityImageVideo_vip);
            callQualityImageAudio_vip = findViewById(R.id.callQualityImageAudio_vip);
            callQualityImageBandwith_vip = findViewById(R.id.callQualityImageBandwidth_vip);
            connection_vip_other_title = findViewById(R.id.connection_vip_other_title);
            connection_vip_status = findViewById(R.id.connection_vip_status);
            connection_vip_other_desc_1 = findViewById(R.id.connection_vip_other_desc_1);
            connection_vip_other_desc_2 = findViewById(R.id.connection_vip_other_desc_2);
            connection_vip_other_desc_3 = findViewById(R.id.connection_vip_other_desc_3);
            connection_vip_other_button = findViewById(R.id.connection_vip_other_button);
            status_image_good = findViewById(R.id.status_image_good);

            callQualityImageVideo_vip.setAnimation("static_loading_round.json");
            callQualityImageVideo_vip.playAnimation();

            callQualityImageAudio_vip.setAnimation("static_loading_round.json");
            callQualityImageAudio_vip.playAnimation();

            callQualityImageBandwith_vip.setAnimation("static_loading_round.json");
            callQualityImageBandwith_vip.playAnimation();

            if (Config.DARK_MODE) {
                status_image_good.setAnimation("static_wifi_check.json");
                status_image_good.playAnimation();
            } else {
                status_image_good.setAnimation("static_wifi_check.json");
                status_image_good.playAnimation();
            }

            connection_vip_other_result = findViewById(R.id.connection_vip_other_result);
            connection_vip_title = findViewById(R.id.connection_vip_title);
            connection_vip_desc = findViewById(R.id.connection_vip_desc);
            connection_vip_good_1 = findViewById(R.id.connection_vip_good_1);
            connection_vip_good_2 = findViewById(R.id.connection_vip_good_2);
            connection_vip_good_3 = findViewById(R.id.connection_vip_good_3);
            connection_vip_other_title = findViewById(R.id.connection_vip_other_title);
            connection_vip_other_desc_1 = findViewById(R.id.connection_vip_other_desc_1);
            //	connection_vip_troubleshooting = findViewById(R.id.connection_vip_troubleshooting);

            connection_vip_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_CQC_ACTIVE_TITLE, LOCAL_KEY_CQC_ACTIVE_TITLE));
            connection_vip_desc.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_DESC, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_DESC));
            connection_vip_good_1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_CQC_ACTIVE_NETWORK, LOCAL_KEY_CQC_ACTIVE_NETWORK));
            connection_vip_good_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_CQC_ACTIVE_AUDIO, LOCAL_KEY_CQC_ACTIVE_AUDIO));
            connection_vip_good_3.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_CQC_ACTIVE_VIDEO, LOCAL_KEY_CQC_ACTIVE_VIDEO));


            status_image = findViewById(R.id.status_image);

            sfGifView = findViewById(R.id.loaderSpinner);
            sfGifView.setAnimation("loading.json");
            sfGifView.playAnimation();

            container = findViewById(R.id.callQualityPublisherView);
            containerSubscriber = findViewById(R.id.callQualityCheckSubscriberView);
            callQualityProgressText = findViewById(R.id.callQualityProgressText);
            callQualityResultText = findViewById(R.id.callQualityResultText);
            callQualitySubscriberBar = findViewById(R.id.callQualitySubscriberBar);
            callQualityCheckRunningLayout = findViewById(R.id.callQualityCheckRunningLayout);
            callQualityCheckResultLayout = findViewById(R.id.callQualityCheckResultLayout);
            callQualityCheckResultLayout.setVisibility(View.GONE);
            callQualityResultButton = findViewById(R.id.callQualityResultButton);

            callQualityRetryLink = findViewById(R.id.callQualityRetryLink);
            callQualityRetryLink.setPaintFlags(callQualityRetryLink.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

            good_internet_connection.setVisibility(View.VISIBLE);
            other_internet_connection.setVisibility(View.GONE);

            //createCallQualityTestConference();

        } else {

            old_cqc.setVisibility(View.VISIBLE);
            new_cqc.setVisibility(View.GONE);

            container = findViewById(R.id.callQualityPublisherView);
            containerSubscriber = findViewById(R.id.callQualityCheckSubscriberView);
            callQualityProgressText = findViewById(R.id.callQualityProgressText);
            callQualityResultText = findViewById(R.id.callQualityResultText);
            callQualitySubscriberBar = findViewById(R.id.callQualitySubscriberBar);
            callQualityCheckRunningLayout = findViewById(R.id.callQualityCheckRunningLayout);
            callQualityCheckResultLayout = findViewById(R.id.callQualityCheckResultLayout);
            callQualityCheckResultLayout.setVisibility(View.GONE);
            callQualityResultButton = findViewById(R.id.callQualityResultButton);
            callQualityRetryLink = findViewById(R.id.callQualityRetryLink);
            callQualityRetryLink.setPaintFlags(callQualityRetryLink.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

            if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                customiseCallQualityCheckScreenFiducia();
            }

            callQualityRetryLink.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    restartTest();
                }
            });

            scrollView = findViewById(R.id.callQualityCheckScollView);
            setScrollingEnabled(false);
            callQualitySubscriberBar.setVisibility(View.VISIBLE);
            callQualityProgressText.setVisibility(View.GONE);

            progressBarLoading = findViewById(R.id.callQualityLoadingSpinner);
            progressBarLoading.setVisibility(View.GONE);

            progressBar = findViewById(android.R.id.progress);
            progressBar.getIndeterminateDrawable().setColorFilter(getResources().getColor(R.color.primary), PorterDuff.Mode.MULTIPLY);
            progressBar.setVisibility(View.GONE);

            callQualityImageConnection = findViewById(R.id.callQualityImageBandwidth);
            Util_UtilUI.setTintedIcon(callQualityImageConnection, R.drawable.ic_network_check_black_36dp, R.color.call_quality_check_icon_desactivated_color);
            callQualityImageAudio = findViewById(R.id.callQualityImageAudio);
            Util_UtilUI.setTintedIcon(callQualityImageAudio, R.drawable.ic_mic_black_36dp, R.color.call_quality_check_icon_desactivated_color);
            callQualityImageVideo = findViewById(R.id.callQualityImageVideo);
            Util_UtilUI.setTintedIcon(callQualityImageVideo, R.drawable.ic_videocam_black_36dp, R.color.call_quality_check_icon_desactivated_color);

            callQualityTitleText = findViewById(R.id.callQualityTitleText);
            callQualityTitleText.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_CQC_ACTIVE_TITLE, Util_Strings.LOCAL_KEY_CQC_ACTIVE_TITLE));

            if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                callQualityTitleText.setTextColor(getResources().getColor(R.color.call_quality_title_text_color));
            }

            callQualityTitleText.setVisibility(View.VISIBLE);

            callQualityCheckBandwidthLabel = findViewById(R.id.callQualityCheckBandwidthLabel);
            callQualityCheckBandwidthLabel.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_CQC_ACTIVE_NETWORK, LOCAL_KEY_CQC_ACTIVE_NETWORK));
            callQualityCheckBandwidthLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));
            callQualityAudioLabel = findViewById(R.id.callQualityCheckAudioLabel);
            callQualityAudioLabel.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_CQC_ACTIVE_AUDIO, Util_Strings.LOCAL_KEY_CQC_ACTIVE_AUDIO));
            callQualityAudioLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));
            callQualityVideoLabel = findViewById(R.id.callQualityCheckVideoLabel);
            callQualityVideoLabel.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_CQC_ACTIVE_VIDEO, Util_Strings.LOCAL_KEY_CQC_ACTIVE_VIDEO));
            callQualityVideoLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));

            if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                progressBarLoading.setVisibility(View.GONE);
                progressBar.setVisibility(View.GONE);
                callQualitySubscriberBar.setIndeterminate(false);
                // callQualitySubscriberBar.setProgressTintList(ColorStateList.valueOf(R.color.call_quality_progressbar_color));


            }
        }
    }

    private void customiseCallQualityCheckScreenFiducia() {
        title = findViewById(R.id.title);
        description = findViewById(R.id.description);
        retrycqc = findViewById(R.id.retrycqc);
        actioncqc = findViewById(R.id.startident);
        linearlayoutAfterCQC = findViewById(R.id.linearlayoutAfterCQC);
        linedivider = findViewById(R.id.linedivider);
        description1 = findViewById(R.id.description1);
        point1 = findViewById(R.id.point1);

        description2 = findViewById(R.id.description2);
        point2 = findViewById(R.id.point2);

        description3 = findViewById(R.id.description3);
        point3 = findViewById(R.id.point3);

        callQualitySubscriberBar.setScaleY(4f);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        startTest();
    }

    @Override
    protected void onDestroy() {

        AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_NORMAL);

        Util_CustomLogData.endSession();

        super.onDestroy();
    }

    protected void setupConferenceAudio() {
        AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_IN_COMMUNICATION);
        boolean headset = am.isWiredHeadsetOn();
        float percent = 0.5f;
        if (!headset) {
            am.setSpeakerphoneOn(true);
            percent = 0.75f;
        }

        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        int currentVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        int maxVolume = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        float currentVolumePercent = 0.1f;
        if (currentVolume != 0 && maxVolume != 0) {
            currentVolumePercent = (float) currentVolume / maxVolume;
        }

        // if volume to low, set it to 75%
        if (currentVolumePercent < percent) {
            int newVolume = (int) (maxVolume * percent);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0);
        }

        try {
            float musicVolume = (float) am.getStreamVolume(AudioManager.STREAM_MUSIC);
            float musicPercent = musicVolume / ((float) am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
            int newVoiceVolume = (int) (am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL) * musicPercent);

            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, newVoiceVolume, 0);
        } catch (Exception e) {
            //ignore
        }

        // Request audio focus for playback
        int result = am.requestAudioFocus(null,
                // Use the music stream.
                AudioManager.STREAM_MUSIC,
                // Request permanent focus.
                AudioManager.AUDIOFOCUS_GAIN);

        if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            Util_Log.i(LOGTAG, "Focus request granted");
        } else {
            Util_Log.i(LOGTAG, "Focus request not granted");
        }
    }

    public void connectConference() {
        conference.connect(container, containerSubscriber).then(localMedia -> {
            localMedia.setAudioMuted(true);
            attachQualitySampleListener();
        });

        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        audioManager.setStreamMute(AudioManager.STREAM_MUSIC, true);
        audioManager.setStreamMute(AudioManager.STREAM_VOICE_CALL, true);
    }

    private void startTest() {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, this, 5, 5, 5);
        AtomicReference<Call<Models_CallQualityTest>> apiCallRef = new AtomicReference<>(null);
        Callback<Models_CallQualityTest> callback = new Callback<Models_CallQualityTest>() {

            @Override
            public void failure(RetrofitError error) {
                pendingApiCalls.remove(apiCallRef.get());
                if (!Config.VIDEO_IDENT_PLUS) {
                    progressBar.setVisibility(View.GONE);
                }

                String result = "";
                result = Util_UtilRetrofit.printRetrofitError(error);

                Util_Log.i(LOGTAG, "SDP Error: " + error.getMessage());
                Util_Log.i(LOGTAG, "SDP result: " + result);
                handleUnknownFailure(false);
            }

            @Override
            public void success(Models_CallQualityTest resultObject, Response response) {
                pendingApiCalls.remove(apiCallRef.get());
                if (!Config.VIDEO_IDENT_PLUS) {
                    progressBar.setVisibility(View.GONE);
                }
                Util_Log.i(LOGTAG, "Success creating test connection, sending SDP offer.");
                callQualityTest = resultObject;
                startConference();
            }
        };

        Models_ClientInfo clientInfo = Util_Util.getClientInfo();
        Models_NewMirrorConference mirrorConference = new Models_NewMirrorConference(clientInfo);
        String transactionToken = IDnowSDK.getTransactionToken();
        String companyId = IDnowSDK.getCompanyId();

        Call<Models_CallQualityTest> apiCall = service.startCallQualityTest(mirrorConference, companyId, transactionToken);
        apiCall.enqueue(callback);

        apiCallRef.set(apiCall);
        pendingApiCalls.add(apiCall);
    }

    private void stopTest() {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, this, 5, 5, 5);
        AtomicReference<Call<Boolean>> apiCallRef = new AtomicReference<>(null);
        Callback<Boolean> callback = new Callback<Boolean>() {

            @Override
            public void failure(RetrofitError error) {
                pendingApiCalls.remove(apiCallRef.get());
                String result = Util_UtilRetrofit.printRetrofitError(error);
                Util_Log.i(LOGTAG, "Failed to destroy video session: " + error.getMessage());
                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                    Util_Log.i(LOGTAG, result);
                }
                handleUnknownFailure(false);
            }

            @Override
            public void success(Boolean responseObject, Response response) {
                pendingApiCalls.remove(apiCallRef.get());
                Util_Log.i(LOGTAG, "Success destroying mirror connection.");
            }
        };

        String shortname = IDnowSDK.getCompanyId();
        String transactionToken = IDnowSDK.getTransactionToken();

        Models_ClientInfo clientInfo = Util_Util.getClientInfo();
        Models_NewMirrorConference mirrorConference = new Models_NewMirrorConference(clientInfo);
        Call<Boolean> apiCall = service.stopCallQualityTest(mirrorConference, shortname, transactionToken);
        apiCall.enqueue(callback);

        apiCallRef.set(apiCall);
        pendingApiCalls.add(apiCall);
    }

    private void cancelTest() {
        stopConference();
        cancelPendingApiCalls();
    }

    private void cancelPendingApiCalls() {
        for (Call<?> apiCall : pendingApiCalls) {
            try {
                if (apiCall != null)
                    apiCall.cancel();
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Cancel pending api call failed", e);
            }
        }
    }

    private void handleResult(int result, Boolean stopRequired) {
        detachQualitySampleListener();
        stopConference();

        if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
            showCheckResultScreenCustomise(result);
        } else {
            if (Config.VIDEO_IDENT_PLUS) {
                showCheckResultScreen_vip(result);
            } else {
                showCheckResultScreen(result);
            }
        }

        if (stopRequired) {
            stopTest();
        }
    }

    private void handleUnknownFailure(Boolean stopRequired) {
        handleResult(CallQualityResult.UNKNOWN.getInt(), stopRequired);
    }

    private void startConference() {
        try {
            conference = new CallQualityConference(this);
            conference.setSubscriberProgressBar(callQualitySubscriberBar);

            setupConferenceAudio();
            connectConference();
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Start conference failed", e);
            handleUnknownFailure(true);
        }
    }

    private void attachQualitySampleListener() {
        if (!Config.VIDEO_IDENT_PLUS) {
            runOnUiThread(() -> {
                callQualitySubscriberBar.setIndeterminate(false);
                callQualitySubscriberBar.setMax(100);
                callQualitySubscriberBar.setProgress(0);
            });
        }

        callQualitySampleCounter -= Config.CALL_QUALITY_ARGS_WARM_UP;
        Util_Log.d(LOGTAG, "Warm up: " + Config.CALL_QUALITY_ARGS_WARM_UP);
        final long startTime = SystemClock.uptimeMillis();

        if (conference.connectionHasDataStream()) {
            DataChannel dataChannel = conference.getDataChannel();
            dataChannel.setOnReceive(args -> onQualitySampleReceived(args, dataChannel, startTime));
        }
    }

    private void detachQualitySampleListener() {
        if (conference != null &&
                conference.getConnection() != null &&
                conference.connectionHasDataStream()) {
            DataChannel dataChannel = conference.getDataChannel();
            dataChannel.setOnReceive(null);
        }
    }

    private void stopConference() {
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        audioManager.setStreamMute(AudioManager.STREAM_MUSIC, false);
        audioManager.setStreamMute(AudioManager.STREAM_VOICE_CALL, false);

        if (conference != null) {
            try {
                conference
                        .stopConference()
                        .fail(e -> {
                            Util_Log.i(LOGTAG, "Stopped connection with error: " + e.getMessage());
                        });
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Stop conference failed", e);
            }
        }
    }

    public void onQualitySampleReceived(DataChannelReceiveArgs args, DataChannel dataChannel, long startTime) {
        if (args != null) {

            Util_Log.d(LOGTAG, "Call Quality data: " + args.getDataString());
            callQualitySampleCounter++;
            long now = SystemClock.uptimeMillis();
            long elapsed = now - startTime;
            if (callQualitySampleCounter >= 0 && callQualitySampleCounter < Config.CALL_QUALITY_ARGS_MAX && (elapsed <= Config.CALL_QUALITY_ARGS_TIMEOUT)) {
                float progress = ((float) callQualitySampleCounter / (float) Config.CALL_QUALITY_ARGS_MAX) * 100f;
                String dataJSON = args.getDataString();
                try {
                    Gson gson = new Gson();
                    Model_ConferenceCallQualityMetrics callQualityMetrics = gson.fromJson(dataJSON, Model_ConferenceCallQualityMetrics.class);
                    int video = callQualityMetrics.getCallQuality().getUser().getVideo().getQuality();
                    int audio = callQualityMetrics.getCallQuality().getUser().getAudio().getQuality();
                    Map qualitySample = new HashMap<String, Integer>();
                    qualitySample.put("video", video);
                    qualitySample.put("audio", audio);
                    int sampleCallQuality = Math.min(audio, video);
                    callQualitySampleList.add(sampleCallQuality);
                    Util_Log.i(LOGTAG, "Received call quality sample with video: " + video + " / audio: " + audio);
                    if (!Config.VIDEO_IDENT_PLUS) {
                        if (progress > 50) {
                            callQualitySubscriberBar.setProgress(100, true);
                        } else {
                            callQualitySubscriberBar.setProgress(Math.round(progress), true);
                        }
                    }

                    switchActiveIconAndLabelForProgress(progress);

                } catch (JsonSyntaxException e) {
                    Util_Log.e(LOGTAG, "Parse call quality data from json failed", e);
                }
            } else if ((callQualitySampleCounter >= 0 && callQualitySampleCounter >= Config.CALL_QUALITY_ARGS_MAX) || (elapsed >= Config.CALL_QUALITY_ARGS_TIMEOUT)) {
                int result = evaluateResultsForCurrentTest();
                boolean stopRequired = result < MODERATE.getInt();
                handleResult(result, stopRequired);
            }
        }
    }

    private void switchActiveIconAndLabelForProgress(final float progress) {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                if (progress == 0f) {

                    if (Config.VIDEO_IDENT_PLUS) {

                        sfGifView.playAnimation();

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                callQualityImageBandwith_vip.setAnimation("static_checkbox_round.json");
                                Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.cqc_bandwitch_color)), callQualityImageBandwith_vip, "Success");
                                callQualityImageBandwith_vip.playAnimation();
                            }
                        }, 500);

                    } else {
                        Util_UtilUI.setTintedIcon(callQualityImageConnection, R.drawable.ic_network_check_black_36dp, R.color.call_quality_check_icon_activated_color);
                        callQualityCheckBandwidthLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_activated_text_color));
                    }


                } else if (progress >= 30f && progress < 50f) {

                    if (Config.VIDEO_IDENT_PLUS) {

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                callQualityImageAudio_vip.setAnimation("static_checkbox_round.json");
                                Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.cqc_bandwitch_color)), callQualityImageAudio_vip, "Success");
                                callQualityImageAudio_vip.playAnimation();
                            }
                        }, 500);

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                callQualityImageVideo_vip.setAnimation("static_checkbox_round.json");
                                Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.cqc_bandwitch_color)), callQualityImageVideo_vip, "Success");
                                callQualityImageVideo_vip.playAnimation();
                            }
                        }, 2000);

                    } else {
                        Util_UtilUI.setTintedIcon(callQualityImageConnection, R.drawable.ic_network_check_black_36dp, R.color.call_quality_check_icon_desactivated_color);
                        callQualityCheckBandwidthLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));

                        Util_UtilUI.setTintedIcon(callQualityImageAudio, R.drawable.ic_mic_black_36dp, R.color.call_quality_check_icon_activated_color);
                        callQualityAudioLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_activated_text_color));
                    }


                } else if (progress >= 50f) {


                    if (Config.VIDEO_IDENT_PLUS) {
                        callQualityImageVideo_vip.setAnimation("static_checkbox_round.json");
                        Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.cqc_bandwitch_color)), callQualityImageVideo_vip, "Success");
                        callQualityImageVideo_vip.playAnimation();
                    } else {

                        Util_UtilUI.setTintedIcon(callQualityImageAudio, R.drawable.ic_mic_black_36dp, R.color.call_quality_check_icon_desactivated_color);
                        callQualityAudioLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));
                        Util_UtilUI.setTintedIcon(callQualityImageVideo, R.drawable.ic_videocam_black_36dp, R.color.call_quality_check_icon_activated_color);
                        callQualityVideoLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_activated_text_color));
                    }


                } else if (progress < 0f) {

                    if (Config.VIDEO_IDENT_PLUS) {

                        callQualityImageVideo_vip.setAnimation("static_loading_round.json");
                        callQualityImageVideo_vip.playAnimation();

                        callQualityImageBandwith_vip.setAnimation("static_loading_round.json");
                        callQualityImageBandwith_vip.playAnimation();

                        callQualityImageAudio_vip.setAnimation("static_loading_round.json");
                        callQualityImageAudio_vip.playAnimation();

                    } else {
                        Util_UtilUI.setTintedIcon(callQualityImageConnection, R.drawable.ic_network_check_black_36dp, R.color.call_quality_check_icon_desactivated_color);
                        callQualityCheckBandwidthLabel.setTextColor(getResources().getColor(R.color.light_gray));
                        Util_UtilUI.setTintedIcon(callQualityImageAudio, R.drawable.ic_mic_black_36dp, R.color.call_quality_check_icon_desactivated_color);
                        callQualityAudioLabel.setTextColor(getResources().getColor(R.color.light_gray));
                        Util_UtilUI.setTintedIcon(callQualityImageVideo, R.drawable.ic_videocam_black_36dp, R.color.call_quality_check_icon_desactivated_color);
                        callQualityVideoLabel.setTextColor(getResources().getColor(R.color.light_gray));
                    }
                }

                if (!Config.VIDEO_IDENT_PLUS) {
                    callQualityCheckRunningLayout.invalidate();

                }
            }
        });
    }

    private void resetUI() {
        callQualityResultButton.setEnabled(true);
        token_retries_layout.setVisibility(View.GONE);
        token_retries_agent_image.setAnimation("static_agent_id_fail.json");
        used_logo_cqc.setAnimation("static_logo.json");
        used_logo_cqc_other.setAnimation("static_logo.json");
        secondary_button.setVisibility(View.INVISIBLE);

        if (IDnowSDK.getShowIDnowLogo()) {
            used_logo_cqc.setVisibility(View.VISIBLE);
            used_logo_cqc_other.setVisibility(View.VISIBLE);
        } else {
            used_logo_cqc.setVisibility(View.GONE);
            used_logo_cqc_other.setVisibility(View.GONE);
        }

        if (Config.VIDEO_IDENT_PLUS) {
            old_cqc.setVisibility(View.GONE);
            new_cqc.setVisibility(View.VISIBLE);

            callQualityImageVideo_vip.setAnimation("static_loading_round.json");
            callQualityImageVideo_vip.playAnimation();
            callQualityImageAudio_vip.setAnimation("static_loading_round.json");
            callQualityImageAudio_vip.playAnimation();
            callQualityImageBandwith_vip.setAnimation("static_loading_round.json");
            callQualityImageBandwith_vip.playAnimation();
            status_image_good.playAnimation();
            sfGifView.playAnimation();
            callQualityCheckResultLayout.setVisibility(View.GONE);
            good_internet_connection.setVisibility(View.VISIBLE);
            other_internet_connection.setVisibility(View.GONE);
            callQualityCheckRunningLayout.setVisibility(View.VISIBLE);
            callQualityResultText.setVisibility(View.VISIBLE);
            callQualityRetryLink.setVisibility(View.GONE);
            callQualityRetryLink.setPaintFlags(callQualityRetryLink.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            callQualityResultButton.setVisibility(View.VISIBLE);
            connection_vip_other_desc_3.setVisibility(View.VISIBLE);
        } else {
            old_cqc.setVisibility(View.VISIBLE);
            new_cqc.setVisibility(View.GONE);

            callQualityCheckResultLayout.setVisibility(View.GONE);
            callQualityRetryLink.setPaintFlags(callQualityRetryLink.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            callQualitySubscriberBar.setVisibility(View.VISIBLE);
            callQualityProgressText.setVisibility(View.GONE);
            progressBarLoading.setVisibility(View.GONE);
            progressBar.setVisibility(View.GONE);
            Util_UtilUI.setTintedIcon(callQualityImageConnection, R.drawable.ic_network_check_black_36dp, R.color.call_quality_check_icon_desactivated_color);
            Util_UtilUI.setTintedIcon(callQualityImageAudio, R.drawable.ic_mic_black_36dp, R.color.call_quality_check_icon_desactivated_color);
            Util_UtilUI.setTintedIcon(callQualityImageVideo, R.drawable.ic_videocam_black_36dp, R.color.call_quality_check_icon_desactivated_color);
            callQualityTitleText.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_CQC_ACTIVE_TITLE, Util_Strings.LOCAL_KEY_CQC_ACTIVE_TITLE));
            callQualityTitleText.setVisibility(View.VISIBLE);
            callQualityCheckBandwidthLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));
            callQualityAudioLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));
            callQualityVideoLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));
            if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                linedivider.setVisibility(View.VISIBLE);
                linearlayoutAfterCQC.setVisibility(View.GONE);
                callQualityTitleText.setTextColor(getResources().getColor(R.color.call_quality_title_text_color));
                callQualitySubscriberBar.setIndeterminate(false);
                callQualitySubscriberBar.setScaleY(4f);
                retrycqc.setVisibility(View.VISIBLE);
                actioncqc.setVisibility(View.VISIBLE);
            } else {
                callQualitySubscriberBar.setProgress(0);
                callQualitySubscriberBar.setIndeterminate(true);
            }
            callQualityCheckRunningLayout.setVisibility(View.VISIBLE);
            callQualityResultText.setText("");
            callQualityResultText.setVisibility(View.GONE);
            callQualityRetryLink.setVisibility(View.GONE);
            callQualityResultButton.setVisibility(View.VISIBLE);
            setScrollingEnabled(false);
            switchActiveIconAndLabelForProgress(-1f);
        }

        callQualityResultButton.setVisibility(View.GONE);

        resetSuggestionBoxes();
    }

    private void restartTest() {
        resetUI();

        MAX_RECONNECTION_ATTEMPTS = 2;
        reconnectionAttemptCounter = 0;
        callQualitySampleCounter = 0;
        callQualitySampleList.clear();

        startTest();
    }

    public void showCheckResultScreenCustomise(final int result) {
        reconnectionAttemptCounter = 0;
        progressBar.setVisibility(View.GONE);

        runOnUiThread(() -> {

            CallQualityLightView lightOne = findViewById(R.id.callQualityLightOne);
            CallQualityLightView lightTwo = findViewById(R.id.callQualityLightTwo);
            CallQualityLightView lightThree = findViewById(R.id.callQualityLightThree);

            CallQualityResult callQuality = CallQualityResult.values()[result];
            Util_UtilUI.setProceedButtonBackgroundSelector(callQualityResultButton);

            callQualityResultButton.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.button.continue", null));

            callQualityResultButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    progressBar.setVisibility(View.VISIBLE);
                    callQualityResultButton.setEnabled(false);

                    markTestPassed(CallQualityResult.MODERATE);

                    makeStartRESTCall();
                }
            });

            switch (callQuality) {
                case UNKNOWN:
                    ShowPreCheckFails();
                    break;

                case POOR:
                    ShowPreCheckFails();
                    break;
                case MODERATE:
                    callQualityCheckRunningLayout.setVisibility(View.GONE);
                    scrollView.setVisibility(View.GONE);
                    linedivider.setVisibility(View.VISIBLE);

                    linearlayoutAfterCQC.setVisibility(View.VISIBLE);
                    title.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.title.moderate.short", null));
                    title.setTextColor(getResources().getColor(R.color.vr_color_text_title_moderate));

                    description.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.title.moderate", null));
                    displaySuggestionBoxesCustomise(MODERATE);

                    retrycqc.setVisibility(View.VISIBLE);

                    retrycqc.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.button.retest", null));

                    actioncqc.setVisibility(View.VISIBLE);
                    actioncqc.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.button.continue", null));

                    actioncqc.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.button.continue", null));

                    actioncqc.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            progressBar.setVisibility(View.VISIBLE);
                            callQualityResultButton.setEnabled(false);

                            markTestPassed(CallQualityResult.MODERATE);

                            makeStartRESTCall();
                        }
                    });

                    retrycqc.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            restartTest();
                        }
                    });

                    break;
                case EXCELLENT:
                    markTestPassed(EXCELLENT);
                    makeStartRESTCall();
                    break;
            }

            setScrollingEnabled(true);
        });
    }

    private void setScrollingEnabled(Boolean enabled) {
        runOnUiThread(() -> {
            if (scrollView != null) {
                scrollView.post(() -> scrollView.fullScroll(ScrollView.FOCUS_UP));
                scrollView.setScrollingEnabled(enabled);
            }
        });
    }

    private void ShowPreCheckFails() {
        callQualityCheckRunningLayout.setVisibility(View.GONE);
        callQualityCheckResultLayout.setVisibility(View.GONE);
        linedivider.setVisibility(View.GONE);
        retrycqc.setVisibility(View.GONE);
        actioncqc.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.button.continue", null));

        linearlayoutAfterCQC.setVisibility(View.VISIBLE);
        title.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.title.unknown.short", null));

        title.setTextColor(getResources().getColor(R.color.vr_color_text_title_failed));

        description.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.title.poor", null));

        displaySuggestionBoxesCustomise(UNKNOWN);

        retrycqc.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.button.retest", null));

        actioncqc.setVisibility(View.VISIBLE);

        actioncqc.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.button.retest", null));

        retrycqc.setVisibility(View.GONE);
        actioncqc.setVisibility(View.VISIBLE);

        actioncqc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ConnectivityService.INSTANCE.isOnline()) {
                    linearlayoutAfterCQC.setVisibility(View.GONE);
                    restartTest();
                } else {
                    Util_UtilUI.showNoConnectionDialog(context, false);
                }
            }
        });
    }

    public void showCheckResultScreen(final int result) {
        reconnectionAttemptCounter = 0;

        progressBar.setVisibility(View.GONE);

        runOnUiThread(() -> {
            callQualityCheckRunningLayout.setVisibility(View.GONE);
            callQualityCheckResultLayout.setVisibility(View.VISIBLE);

            CallQualityLightView lightOne = findViewById(R.id.callQualityLightOne);
            CallQualityLightView lightTwo = findViewById(R.id.callQualityLightTwo);
            CallQualityLightView lightThree = findViewById(R.id.callQualityLightThree);

            CallQualityResult callQuality = CallQualityResult.values()[result];

            Util_UtilUI.setProceedButtonBackgroundSelector(callQualityResultButton);
            callQualityResultButton.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.button.continue", null));
            callQualityResultButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    progressBar.setVisibility(View.VISIBLE);
                    callQualityResultButton.setEnabled(false);

                    markTestPassed(CallQualityResult.MODERATE);

                    makeStartRESTCall();
                }
            });

            displaySuggestionBoxes(callQuality);

            switch (callQuality) {
                case UNKNOWN:
                    lightOne.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_first_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightTwo.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_second_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightThree.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_third_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    callQualityResultText.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.title.unknown", null));
                    callQualityResultText.setVisibility(View.VISIBLE);

                    callQualityRetryLink.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.button.retest", null));
                    callQualityRetryLink.setVisibility(View.VISIBLE);
                    callQualityResultButton.setVisibility(View.GONE);
                    break;
                case POOR:
                    lightOne.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_first_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightTwo.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_second_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightThree.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_third_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    callQualityResultText.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.title.poor", null));
                    callQualityResultText.setVisibility(View.VISIBLE);

                    callQualityRetryLink.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.button.retest", null));
                    callQualityRetryLink.setVisibility(View.VISIBLE);
                    callQualityResultButton.setVisibility(View.GONE);
                    break;
                case MODERATE:
                    lightOne.setCircleColors(getResources().getColor(R.color.cqc_moderate_quality_first_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightTwo.setCircleColors(getResources().getColor(R.color.cqc_moderate_quality_second_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightThree.setCircleColors(getResources().getColor(R.color.cqc_moderate_quality_third_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    callQualityResultText.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.title.moderate", null));
                    callQualityResultText.setVisibility(View.VISIBLE);

                    callQualityRetryLink.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.button.retest", null));
                    callQualityRetryLink.setVisibility(View.VISIBLE);

                    callQualityResultButton.setVisibility(View.VISIBLE);

                    break;
                case EXCELLENT:
                    lightOne.setCircleColors(getResources().getColor(R.color.cqc_excellent_quality_first_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightTwo.setCircleColors(getResources().getColor(R.color.cqc_excellent_quality_second_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightThree.setCircleColors(getResources().getColor(R.color.cqc_excellent_quality_third_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    callQualityResultText.setText(IDnowSDK.getInstance().getStringWithDefault(Activities_VideoLiveStreamActivity_CallQualityCheck.this, "js.precheck.mobile.result.title.excellent", null));
                    callQualityResultText.setVisibility(View.VISIBLE);

                    callQualityResultButton.setVisibility(View.GONE);
                    callQualityRetryLink.setVisibility(View.GONE);

                    markTestPassed(EXCELLENT);

                    makeStartRESTCall();

                    break;
            }
            setScrollingEnabled(true);
        });
    }

    public void showCheckResultScreen_vip(final int result) {
        reconnectionAttemptCounter = 0;

        runOnUiThread(() -> {

            CallQualityResult callQuality = CallQualityResult.values()[result];

            switch (callQuality) {
                case UNKNOWN:
                    Config.CQC_STATUS = 1;
                    if (good_internet_connection != null) {
                        good_internet_connection.setVisibility(View.GONE);
                    }
                    if (other_internet_connection != null) {
                        other_internet_connection.setVisibility(View.VISIBLE);
                    }
                    connection_vip_other_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE));
                    connection_vip_status.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD));
                    connection_vip_other_desc_1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_1, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_1));
                    connection_vip_other_desc_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_2, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_2));
                    connection_vip_other_desc_3.setVisibility(View.GONE);
                    connection_vip_other_button.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON));
                    connection_vip_other_button.setOnClickListener(v -> restartTest());
                    status_image.setAnimation("static_wifi_check_problem.json");
                    status_image.playAnimation();
                    break;
                case POOR:
                    Config.CQC_STATUS = 1;
                    if (good_internet_connection != null) {
                        good_internet_connection.setVisibility(View.GONE);
                    }
                    if (other_internet_connection != null) {
                        other_internet_connection.setVisibility(View.VISIBLE);
                    }
                    connection_vip_other_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE));
                    connection_vip_status.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD));
                    connection_vip_other_button.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON, LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON));
                    connection_vip_other_desc_1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_1, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_1));
                    connection_vip_other_desc_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_2, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_2));
                    connection_vip_other_desc_3.setVisibility(View.GONE);
                    connection_vip_other_button.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON));
                    connection_vip_other_button.setOnClickListener(v -> restartTest());
                    status_image.setAnimation("static_wifi_check_problem.json");
                    status_image.playAnimation();
                    break;
                case MODERATE:
                    Config.CQC_STATUS = 2;
                    if (good_internet_connection != null) {
                        good_internet_connection.setVisibility(View.GONE);
                    }
                    if (other_internet_connection != null) {
                        other_internet_connection.setVisibility(View.VISIBLE);
                    }
                    connection_vip_other_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_OTHER_STATUS, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_OTHER_STATUS));
                    status_image.setAnimation("static_wifi_check_problem.json");
                    status_image.playAnimation();
                    connection_vip_status.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_MODERATE, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_MODERATE));
                    connection_vip_other_desc_1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CQC_MODERATE_1, LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_1));
                    connection_vip_other_desc_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CQC_MODERATE_2, LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_2));
                    connection_vip_other_desc_3.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CQC_MODERATE_3, LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_3));
                    connection_vip_other_button.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON, LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON));
                    connection_vip_other_button.setOnClickListener(v -> {
                        markTestPassed(CallQualityResult.MODERATE);
                        makeStartRESTCall();
                    });
                    break;
                case EXCELLENT:
                    Config.CQC_STATUS = 3;
                    status_image.setAnimation("static_wifi_check.json");
                    status_image.playAnimation();
                    markTestPassed(EXCELLENT);
                    makeStartRESTCall();
                    break;
            }
        });
    }


    private void displaySuggestionBoxes(CallQualityResult callQuality) {
        int boxesWithValues = 0;
        for (int i = 1; i <= 10; i++) {
            Resources res = getResources();
            int id = res.getIdentifier("callQualitySuggestionBox" + i, "id", context.getPackageName());
            TextView textView = findViewById(id);
            if (textView != null) {
                String label = null;
                if (callQuality.equals(CallQualityResult.MODERATE)) {
                    label = IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion" + i, null);
                } else if (callQuality.equals(CallQualityResult.POOR)) {
                    label = IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion.poor" + i, null);
                } else if (callQuality.equals(CallQualityResult.UNKNOWN)) {
                    label = IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion.unknown" + i, null);
                }

                if (label == null || TextUtils.isEmpty(label)) {
                    textView.setVisibility(View.GONE);
                } else {
                    textView.setText(label);
                    textView.setVisibility(View.VISIBLE);
                    boxesWithValues++;
                }
            }
        }

        if (boxesWithValues == 0) {
            LinearLayout callQualitySuggestionBoxContainer = findViewById(R.id.callQualitySuggestionBoxContainer);
            if (callQualitySuggestionBoxContainer != null) {
                callQualitySuggestionBoxContainer.setVisibility(View.GONE);
            }
        }
    }

    private void displaySuggestionBoxesCustomise(CallQualityResult callQuality) {

        int boxesWithValues = 0;
        String label = "";
        for (int i = 1; i <= 3; i++) {

            if (callQuality.equals(CallQualityResult.MODERATE)) {
                if (label.equals("")) {
                    label = IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion" + i, null);
                    point1.setText(R.string.filled_bullet);
                    description1.setText(label);
                } else {
                    label = label + "\n" + IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion" + i, null);
                    createListText(i, "js.precheck.mobile.suggestion");
                }

            } else if (callQuality.equals(CallQualityResult.POOR) || callQuality.equals(CallQualityResult.UNKNOWN)) {
                if (label.equals("")) {
                    label = IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion.poor" + i, null);
                    point1.setText(R.string.filled_bullet);
                    description1.setText(label);

                } else {
                    label = label + "\n" + IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion.poor" + i, null);
                    createListText(i, "js.precheck.mobile.suggestion.poor");
                }
            }

            if (label == null || TextUtils.isEmpty(label)) {
            } else {
                boxesWithValues++;
            }
        }

        if (boxesWithValues == 0) {
            LinearLayout callQualitySuggestionBoxContainer = findViewById(R.id.callQualitySuggestionBoxContainer);
            if (callQualitySuggestionBoxContainer != null) {
                callQualitySuggestionBoxContainer.setVisibility(View.GONE);
            }
        }
    }

    private void createListText(int i, String key) {

        if (i == 2) {
            point2.setText(R.string.filled_bullet);
            description2.setText(IDnowSDK.getInstance().getStringWithDefault(this, key + i, null));
        } else if (i == 3) {
            point3.setText(R.string.filled_bullet);
            description3.setText(IDnowSDK.getInstance().getStringWithDefault(this, key + i, null));
        }
    }

    private boolean shouldStartCQC() {
        return Config.CALL_QUALITY_CHECK_ENABLED && !Config.CALL_QUALITY_CHECK_PASSED;
    }

    private void proceedToIdent(boolean doRestCall) {
        if (shouldStartCQC()) {
            restartTest();
        } else {

            if (doRestCall) {
                makeStartRESTCall();
            }

            if (Config.HIDE_USERS_PII_DATA) {
                Util_Util.getMaskedData(this);
            } else {
                Intent intent = new Intent(context, Util_VideoStreamService.getClassForVideoLiveStreaming());
                startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
            }
        }
    }

    private final Runnable startRESTCallRunnable = new Runnable() {
        @Override
        public void run() {
            proceedToIdent(true);
        }
    };

    private void loadForcedWaitingScreen() {
        IDnowSDK.setForcedWaitingList(true);
        if (Config.HIDE_USERS_PII_DATA) {
            Util_Util.getMaskedData(this);
        } else {
            loadLiveScreen();
        }
    }

    private void loadLiveScreen() {
        Intent intent = new Intent(context, Util_VideoStreamService.getClassForVideoLiveStreaming());
        startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
    }

    private void makeStartRESTCall() {
        String localPhoneNumber;
        String localEmail;

        if (IDnowSDK.getInstance().isStartCallIssued() && (!Config.RESTART_VIDEO_IDENT)) {
            Util_Log.i(LOGTAG, "start-Call already done, not reissuing it.");
            proceedToIdent(false);
            return;
        }

        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());
        AtomicReference<Call<Models_StartObjectResult>> apiCallRef = new AtomicReference<>(null);
        Callback<Models_StartObjectResult> callback = new Callback<Models_StartObjectResult>() {

            @Override
            public void failure(RetrofitError error) {
                pendingApiCalls.remove(apiCallRef.get());
                String resultError, errorCause, errorType, errorID;

                resultError = Util_UtilRetrofit.printRetrofitError(error);
                errorCause = Util_UtilRetrofit.getErrorCauseRetrofit(resultError);
                errorType = Util_UtilRetrofit.getErrorTypeRetrofit(resultError);
                errorID = Util_UtilRetrofit.getErrorIdRetrofit(resultError);

                if (error != null && error.getResponse() != null && error.getResponse().getStatus() == 412) {
                    if (errorType != null && errorType.equals(IDnowSDK.DOCUSIGN_TOKEN_EXPIRING_SOON)) {
                        Util_UtilUI.showRESTCallErrorDialog(context, error.getResponse().getStatus(), false, startRESTCallRunnable, errorID, true, false, resultError);
                    } else {
                        remainingInternalTokenRetries = 0;
                        giveUserFeedback(remainingInternalTokenRetries);
                    }
                    return;
                }

                if (error != null && error.getResponse() != null) {
                    if (Config.WAITING_LIST_NOTIFICATIONS_ENABLED) {
                        loadForcedWaitingScreen();
                    } else if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                        showCheckResultScreenCustomise(CallQualityResult.UNKNOWN.getInt());
                    } else {
                        Util_UtilUI.showRESTCallErrorDialog(context, error.getResponse().getStatus(), true, startRESTCallRunnable, errorID, true, false, resultError);
                    }
                } else {
                    if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                        showCheckResultScreenCustomise(CallQualityResult.UNKNOWN.getInt());
                    } else {
                        // This branch will always throw NullPointerException if we try to getStatus of Response from 'error' -> passing '-1' displaying default message
                        //Util_UtilUI.showRESTCallErrorDialog( context, error.getResponse().getStatus(), true, startRESTCallRunnable, errorID, true, false, resultError );

                        Util_UtilUI.showRESTCallErrorDialog(context, -1, true, startRESTCallRunnable, errorID, true, false, resultError);
                    }
                }

                IDnowSDK.getInstance().setStartCallIssued(false);
            }

            @Override
            public void success(Models_StartObjectResult resultObject, Response response) {
                pendingApiCalls.remove(apiCallRef.get());
                if (resultObject.getEnableOTPForWallet() != null && Config.AUTHENTICATED_POSSIBLE || Config.AUTHENTICATED_SIGNED) {
                    Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTPForWallet().isSigning();
                    Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTPForWallet().isIdent();
                } else if (resultObject.getEnableOTP() != null) {
                    Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTP().isSigning();
                    Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTP().isIdent();
                }

                if (resultObject.mobile != null) {
                    Config.USER_PHONE_NO = resultObject.mobile;
                }

                if (resultObject.email != null) {
                    Config.EMAIL_ADDRESS = resultObject.email;
                }

                Config.IDENTIFICATION_SIGNATURE = resultObject.getRequest().getIdentification_Signature();

                Util_Log.d(LOGTAG, "success");

                // set the openTok configs
                Util_VideoSessionConfig.setSessionIdAndToken(resultObject);

                remainingInternalTokenRetries = resultObject.getRemainingInternalTokenRetries();
                Util_Log.d(LOGTAG, "remainingInternalTokenRetries = " + remainingInternalTokenRetries);

                if (resultObject.getRequest() != null) {
                    Config.E_SIGNING_SECRET = resultObject.getRequest().getClientSecret();
                    Config.USER_SESSION_TOKEN = resultObject.getRequest().getSessionToken();
                }

                if (remainingInternalTokenRetries == 1) {
                    giveUserFeedback(remainingInternalTokenRetries);
                } else {
                    IDnowSDK.getInstance().setStartCallIssued(true);
                    proceedToIdent(false);
                }
            }
        };

        Util_Log.d(LOGTAG, "Start Called!");

        if (!Config.USER_PHONE_NO.contains("***")) {
            localPhoneNumber = Config.USER_PHONE_NO;
        } else {
            localPhoneNumber = null;
        }

        if (!Config.EMAIL_ADDRESS.contains("***")) {
            localEmail = Config.EMAIL_ADDRESS;
        } else {
            localEmail = null;

        }

        Call<Models_StartObjectResult> apiCall = service.start(new Models_StartObject(IDnowSDK.getTransactionToken(),
                        localPhoneNumber,
                        localEmail,
                        Config.PREFERRED_LANG,
                        Util_Util.getClientInfo(),
                        null),
                IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken());
        apiCall.enqueue(callback);

        apiCallRef.set(apiCall);
        pendingApiCalls.add(apiCall);
    }

    private void giveUserFeedback(int remainingInternalTokenRetries) {

        switch (remainingInternalTokenRetries) {
            case 0:
                loadSpecificUI(remainingInternalTokenRetries);
                cancelAttemptUsing(main_button);
                break;
            case 1:
                loadSpecificUI(remainingInternalTokenRetries);
                proceedWithAttempt(remainingInternalTokenRetries);
                cancelAttemptUsing(secondary_button);
                break;
            default:
                break;
        }
    }

    private void cancelAttemptUsing(View button) {
        button.setOnClickListener(v -> {
            token_retries_layout.setVisibility(View.GONE);
            if (!IDnowSDK.getOverrideEntryActivity()) {
                Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity.class;
            }
            Intent intent = new Intent(this, Config.HOST_APP_START_ACTIVITY);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            this.finish();
            if ((!Config.BACK_TO_VID) || IDnowSDK.getOverrideEntryActivity()) {
                startActivity(intent);
            }
        });
    }

    private void proceedWithAttempt(int remainingInternalTokenRetries) {
        switch (remainingInternalTokenRetries) {
            case 0:
                cancelAttemptUsing(main_button);

                break;
            case 1:
                main_button.setOnClickListener(v -> {
                    if (Config.VIDEO_IDENT_PLUS) {
                        token_retries_layout.setVisibility(View.GONE);
                        old_cqc.setVisibility(View.GONE);
                        new_cqc.setVisibility(View.VISIBLE);
                    } else {
                        token_retries_layout.setVisibility(View.GONE);
                        old_cqc.setVisibility(View.VISIBLE);
                        new_cqc.setVisibility(View.GONE);
                    }

                    IDnowSDK.getInstance().setStartCallIssued(true);
                    proceedToIdent(false);
                });
                break;
            default:
                break;
        }
    }

    private void loadSpecificUI(int remainingInternalTokenRetries) {

        old_cqc.setVisibility(View.GONE);
        new_cqc.setVisibility(View.GONE);
        token_retries_layout.setVisibility(View.VISIBLE);

        Config.REMAINING_TRIES = remainingInternalTokenRetries;

        switch (remainingInternalTokenRetries) {
            case 0:
                token_retries_title.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_TITLE, LOCAL_KEY_USER_FEEDBACK_BLOCKED_TITLE));
                token_retries_message.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_MESSAGE, LOCAL_KEY_USER_FEEDBACK_BLOCKED_MESSAGE));
                main_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_FINISH, LOCAL_KEY_USER_FEEDBACK_BLOCKED_FINISH));
                secondary_button.setVisibility(View.GONE);
                break;
            case 1:
                token_retries_title.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TITLE, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TITLE));
                token_retries_message.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE));
                main_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN));
                secondary_button.setVisibility(View.VISIBLE);
                secondary_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER));
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IDnowSDK.getInstance().deliverResult(resultCode, data);
        setResult(resultCode, data);
        finish();
    }

    private void resetSuggestionBoxes() {
        for (int i = 1; i <= 10; i++) {
            Resources res = getResources();
            int id = res.getIdentifier("callQualitySuggestionBox" + i, "id", context.getPackageName());
            TextView textView = findViewById(id);
            if (textView != null) {
                String label = "";
                textView.setText(label);
                textView.setVisibility(View.GONE);
            }
        }
    }

    private int evaluateResultsForCurrentTest() {
        int sum = 0;
        for (int result : callQualitySampleList) {
            sum += result;
        }

        return sum == 0 ? 0 : sum / callQualitySampleList.size();
    }

    private void markTestPassed(CallQualityResult result) {
        Util_Log.i(LOGTAG, "Call quality was " + result.name() + ". Proceeding to identification.");
        Config.CALL_QUALITY_CHECK_PASSED = true;
    }

    @Override
    public void onBackPressed() {
        cancelTest();

        Config.CQC_STATUS = 0;
        Config.CALL_QUALITY_CHECK_PASSED = false;

        int resultCode = IDnowSDK.RESULT_CODE_CANCEL;

        Intent onBackPressedIntent = new Intent();
        onBackPressedIntent.putExtra(Config.EXTRA_RESPONSE_CODE, resultCode);
        IDnowSDK.getInstance().deliverResult(resultCode, onBackPressedIntent);
        setResult(resultCode, onBackPressedIntent);

        AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_NORMAL);

        super.onBackPressed();
    }

    public void postCandidate(final Candidate candidate) {
        Util_Log.i(LOGTAG, "----------> SENDING LOCAL CANDIDATE!");

        String endPoint = Config.CURRENT_SERVER.getVideoHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, this, 5, 5, 5);

        final String candidateJson = candidate.toJson();
        AtomicReference<Call<String>> apiCallRef = new AtomicReference<>(null);
        Callback<String> callback = new Callback<String>() {

            @Override
            public void failure(RetrofitError error) {
                pendingApiCalls.remove(apiCallRef.get());
                String result = Util_UtilRetrofit.printRetrofitError(error);
                Util_Log.i(LOGTAG, "Error sending candidate: " + error.getMessage());
                Util_Log.i(LOGTAG, "Result: " + result);
                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                    Util_Log.i(LOGTAG, result);
                }
                handleUnknownFailure(true);
            }

            @Override
            public void success(String result, Response response) {
                pendingApiCalls.remove(apiCallRef.get());
                Util_Log.i(LOGTAG, "<---------- RECEIVING LOCAL CANDIDATE!");
                Util_Log.i(LOGTAG, "Sent candidate " + candidateJson);
                Util_Log.i(LOGTAG, "Sent candidate response status: " + response.message());
            }
        };

        Call<String> apiCall = service.sendCandidate(candidate, callQualityTest.getSessionId(), "USER", callQualityTest.getUserVideoSessionToken());
        apiCall.enqueue(callback);

        apiCallRef.set(apiCall);
        pendingApiCalls.add(apiCall);
    }

    public Promise<SessionDescription> makeSendSdpOfferCall(SessionDescription sessionDescription) {
        Util_Log.i(LOGTAG, "-------> SENDING SDP TO SERVER");
        String endPoint = Config.CURRENT_SERVER.getVideoHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, this, 5, 5, 5);
        final Promise<SessionDescription> sessionDescriptionPromise = new Promise<>();
        AtomicReference<Call<Models_SdpOffer>> apiCallRef = new AtomicReference<>(null);
        Callback<Models_SdpOffer> callback = new Callback<Models_SdpOffer>() {

            @Override
            public void failure(RetrofitError error) {
                pendingApiCalls.remove(apiCallRef.get());
                String result = Util_UtilRetrofit.printRetrofitError(error);
                Util_Log.i(LOGTAG, "SDP Error: " + error.getMessage());
                Util_Log.i(LOGTAG, "SDP result: " + result);

                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                    Util_Log.i(LOGTAG, result);
                }

                handleUnknownFailure(true);
                sessionDescriptionPromise.reject(new RuntimeException("Could not receive SDP answer"));
            }

            @Override
            public void success(Models_SdpOffer resultObject, Response response) {
                pendingApiCalls.remove(apiCallRef.get());
                Util_Log.i(LOGTAG, "<------- RECEIVING SDP TO SERVER");

                Util_Log.i(LOGTAG, "Sent SDP: success");

                SessionDescription answer = new SessionDescription();
                answer.setType(resultObject.getIsOffer() ? SessionDescriptionType.Offer : SessionDescriptionType.Answer);
                answer.setSdpMessage(Message.parse(resultObject.getSdpMessage()));
                answer.setTieBreaker(resultObject.getTieBreaker());
                Util_Log.i(LOGTAG, "RECEIVED SDP: " + answer.toJson());


                sessionDescriptionPromise.resolve(answer);
            }
        };

        Util_Log.i(LOGTAG, "sendSdpOffer() CQC");
        Models_SdpOffer sdpOffer = new Models_SdpOffer(sessionDescription.getSdpMessage().toString(), sessionDescription.getIsOffer(), sessionDescription.getTieBreaker());
        Call<Models_SdpOffer> apiCall = service
                .sendSdpOffer(sdpOffer, callQualityTest.getSessionId(), callQualityTest.getUserVideoSessionToken());
        apiCall.enqueue(callback);

        apiCallRef.set(apiCall);
        pendingApiCalls.add(apiCall);

        return sessionDescriptionPromise;
    }

    class CallQualityConference extends Conference {
        @Override
        public Promise<SessionDescription> sendSdpOffer(SessionDescription sessionDescription) {
            return makeSendSdpOfferCall(sessionDescription);
        }

        @Override
        public void sendCandidate(Candidate candidate) {
            postCandidate(candidate);
        }

        CallQualityConference(Activity activity) {
            super(activity, false, Mode.CQC);
        }

    }

    @Override
    protected void onStart() {
        Util_CustomLogData.onStart(this);
        super.onStart();
    }

    @Override
    protected void onStop() {
        Util_CustomLogData.onStop();
        super.onStop();
    }
}
