/**
 * @date 15.10.2014
 * @author Mathias Grasy
 * @brief (short description)
 * 
 * description long
 */

package de.idnow.sdk.util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

/**
 * @date 15.10.2014
 * @author Mathias Grasy
 * @brief (short description)
 * 
 */
class UI_PhotoFocusArea extends View
{
	private boolean	haveTouch	= false;
	private Rect	touchArea;
	private final Paint	paint;

	public UI_PhotoFocusArea( Context context, AttributeSet attrs )
	{
		super( context, attrs );
		paint = new Paint();
		paint.setColor( 0xeed7d7d7 );
		paint.setStyle( Paint.Style.STROKE );
		paint.setStrokeWidth( 2 );
		haveTouch = false;
	}

	public void setHaveTouch( boolean val, Rect rect )
	{
		haveTouch = val;
		touchArea = rect;
	}

	@Override
	public void onDraw( Canvas canvas )
	{
		if ( haveTouch )
		{
			canvas.drawRect( touchArea.left, touchArea.top, touchArea.right, touchArea.bottom, paint );
		}
	}
}
