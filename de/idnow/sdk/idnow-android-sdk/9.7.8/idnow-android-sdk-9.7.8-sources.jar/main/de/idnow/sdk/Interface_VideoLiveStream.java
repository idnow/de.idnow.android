package de.idnow.sdk;

import android.content.Intent;
import android.os.Handler;

import de.idnow.sdk.util.camera.CameraType;

public interface Interface_VideoLiveStream {

    void setupImageStreamPush(byte[] imageString, String imageType);

    // VIDEO STREAM
    void startESigning();

    void signingCanceledRESTCall();

    void onEndCall(int result);

    void setCurrentStep(int step);

    void updateExplanationView(String websocketResponse);

    void identificationFailedRESTCall();

    void identificationCanceledRESTCall();

    void startActivityForResult(Intent intent, int result);

    void agentConnected();

    // CAMERA
    void requestCameraFocusCenter();

    void openCamera(CameraType type);

    void setCameraTorchEnabled(Boolean enabled);

    void takeScreenshot(String type);

    // OTHER
    Handler getHandler();

    void identificationCanceled();
}
