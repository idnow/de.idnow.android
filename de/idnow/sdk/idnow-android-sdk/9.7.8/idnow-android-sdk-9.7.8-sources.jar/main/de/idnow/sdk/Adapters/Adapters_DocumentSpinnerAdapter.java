package de.idnow.sdk.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import de.idnow.sdk.R;
import de.idnow.sdk.models.Models_PDFDocument;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_UtilUI;

import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_ESIGN_CONTRACTID_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_ESIGN_CONTRACTID_TITLE;

/**
 * Created by Mathias Grasy on 19.08.2015.
 */
public class Adapters_DocumentSpinnerAdapter extends ArrayAdapter<Models_PDFDocument>
{
	private final Models_PDFDocument[] values;
	private final Context              context;

	public Adapters_DocumentSpinnerAdapter( Context context, int resource, Models_PDFDocument[] values )
	{
		super( context, resource, values );
		this.context = context;
		this.values = values;
	}

	public int getCount()
	{
		return values.length;
	}

	public Models_PDFDocument getItem( int position )
	{
		return values[ position ];
	}

	public long getItemId( int position )
	{
		return position;
	}


	// And the "magic" goes here
	// This is for the "passive" state of the spinner
	@Override
	public View getView( int position, View convertView, ViewGroup parent )
	{
		convertView = LayoutInflater.from( context ).inflate( R.layout.view_spinner_item, parent, false );

		TextView title = convertView.findViewById( R.id.textViewTitle );
		title.setText( values[ position ].getName() );
		title.setTextColor( context.getResources().getColor( R.color.live_stream_document_spinner_item_title_text_color ) );

		TextView hash = convertView.findViewById( R.id.textViewHash );
		hash.setText( values[ position ].getDisplayHash() );

		TextView e_signature_hash = convertView.findViewById(R.id.e_signature_hash);
		e_signature_hash.setText(Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_ESIGN_CONTRACTID_TITLE,LOCAL_KEY_VIDEO_IDENT_ESIGN_CONTRACTID_TITLE));



		ImageView collapseButton = convertView.findViewById( R.id.collapseImageView );
		Util_UtilUI.setTintedIcon( collapseButton, R.drawable.action_collapse, R.color.live_stream_document_spinner_item_collapse_image_tint_color );

		return convertView;
	}

	// And here is when the "chooser" is popped up
	// Normally is the same view, but you can customize it if you want
	@Override
	public View getDropDownView( int position, View convertView, ViewGroup parent )
	{
		convertView = LayoutInflater.from( context ).inflate( R.layout.view_spinner_item, parent, false );

		TextView title = convertView.findViewById( R.id.textViewTitle );
		title.setText( values[ position ].getName() );
		title.setTextColor( context.getResources().getColor( R.color.live_stream_document_spinner_item_title_text_color ) );

		LinearLayout details = convertView.findViewById( R.id.linearLayoutDetails );
		details.setVisibility( View.GONE );

		ImageView collapseButton = convertView.findViewById( R.id.collapseImageView );
		collapseButton.setVisibility( View.GONE );

		return convertView;
	}
}
