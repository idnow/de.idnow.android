package de.idnow.sdk.util;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import com.google.gson.Gson;

import org.jetbrains.annotations.Nullable;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.models.Models_Documenttype;
import de.idnow.sdk.models.Models_HashMapWrapperStringBoolean;
import de.idnow.sdk.models.Models_PhotoDataHolderData;
import de.idnow.sdk.models.Models_Processsteps;

/**
 * @author Mathias Grasy
 * @date 16.10.2014
 * @brief dataholder for photo ident data
 */

@SuppressWarnings("WeakerAccess")
public
class Util_PhotoDataHolder {

    private static Map<String, List<String>> documentListToCountryname;
    private static final Map<String, List<String>> documentImagesToDocument = new HashMap<>();
    private static final Map<String, List<String>> documentImageTypesToDocument = new HashMap<>();

    private static List<String> countryList;
    private static List<String> countryISOCodeList;


    private static String selectedCountry = "";
    private static String selectedDocument = "";
    private static DocumentImages selectedDocumentImageType = null;

    private static Map<String, Boolean> imageDocumentTakenHashMap;
    private static Map<String, String> imageFilenameToImageDocumentHashMap;

    private static final String LOGTAG = "IDNOW_Util_PhotoDataHolder";

    private static Models_PhotoDataHolderData dataHolder;

    private static Map<DocumentTypes, String> getDocumentnameToDocumenttype;

    public static void initDocumentnameToDocumentType() {
        Context context = IDnowSDK.getInstance().getAppContext();
        getDocumentnameToDocumenttype = new HashMap<DocumentTypes, String>();
        getDocumentnameToDocumenttype.put(DocumentTypes.driverslicense, Util_PhotoStrings.getDriverslicense(context));
        getDocumentnameToDocumenttype.put(DocumentTypes.idcard, Util_PhotoStrings.getIdcard(context));
        getDocumentnameToDocumenttype.put(DocumentTypes.passport, Util_PhotoStrings.getPassport(context));
        getDocumentnameToDocumenttype.put(DocumentTypes.residencepermit, Util_PhotoStrings.getResidencepermit(context));
    }

    public enum DocumentTypes {
        idcard, passport, residencepermit, driverslicense
    }

    public enum DocumentImages {
        idfrontside, idbackside, idholograms, facefrontside, driversfrontside, driversbackside, driversholograms, residencefrontside, residencebackside, residenceholograms, passportfrontside, passportbackside, passportholograms,
        // TODO
        videoHolograms, face, agent

    }

    public static void updateHashMap(@Nullable Util_PhotoDataHolder.DocumentImages imageType, boolean value, Context context) {
        if (imageType != null) {


            Map<String, Boolean> imageDocumentTakenHashMap = new HashMap<>();

            imageDocumentTakenHashMap.put(imageType.toString(), value);

            Gson gson = new Gson();
            Models_HashMapWrapperStringBoolean wrapper = new Models_HashMapWrapperStringBoolean(imageDocumentTakenHashMap);
            String serializedMap = gson.toJson(wrapper);

            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().putString(Util_PhotoStrings.SHARED_PREFS_KEY, serializedMap).apply();
        }

    }


    public static void initPhotoData(Models_Processsteps progresssteps) {
        countryList = new ArrayList<String>();
        countryISOCodeList = new ArrayList<String>();
        documentListToCountryname = new HashMap<String, List<String>>();
        documentImagesToDocument.clear();
        documentImageTypesToDocument.clear();

        initDocumentnameToDocumentType();


        initDocumentData(progresssteps.getDriverslicense(), progresssteps);
        initDocumentData(progresssteps.getIddocument(), progresssteps);

    }


    private static void initDocumentData(@Nullable Models_Documenttype document, @NonNull Models_Processsteps progresssteps) {

        if (document != null) {
            if (document.getAlloweddocuments() != null) {
                // prepare image list

                List<String> imageTypeList = new ArrayList<String>();
                String[] currentDoctypeImages = document.getImages();

                for (String img : currentDoctypeImages) {
                    Util_Log.d(LOGTAG, "Add image type " + mapStringToDocumentImageType(img).toString());
                    imageTypeList.add(mapStringToDocumentImageType(img).toString());
                }
                if (progresssteps.getFacecheck() != null) {
                    imageTypeList.add(mapStringToDocumentImageType(progresssteps.getFacecheck().getImages()[0]).toString());
                }

                // get all countries
                for (int i = 0; i < document.getAlloweddocuments().length; i++) {
                    String countryName = Util_Util.getCountrynameToISOCode(document.getAlloweddocuments()[i].getCountry());

                    if (!countryList.contains(countryName)) {
                        countryList.add(countryName);
                        countryISOCodeList.add(document.getAlloweddocuments()[i].getCountry());
                    }

                    Object[] documents = document.getAlloweddocuments()[i].getDocuments();

                    initCountryHashMaps(documents, countryName);

                    for (Object s : documents) {
                        DocumentTypes doctypes = mapStringToDocumentType(s.toString());
                        String currentDocument = getDocumentnameToDocumenttype.get(doctypes);

                        if (documentImageTypesToDocument.get(currentDocument) == null) {
                            documentImageTypesToDocument.put(currentDocument, imageTypeList);
                            Util_Log.d(LOGTAG, "Add images to " + currentDocument);
                        }

                    }
                }
            }
        }
    }


    /**
     * types: idcard, passport, residencepermit, driverslicense;
     *
     * @param string
     * @return
     */
    static DocumentTypes mapStringToDocumentType(String string) {
        if (string.equals(Util_PhotoStrings.SERVER_STRING_IDCARD)) {
            return DocumentTypes.idcard;
        } else if (string.equals(Util_PhotoStrings.SERVER_STRING_PASSPORT)) {
            return DocumentTypes.passport;
        } else if (string.equals(Util_PhotoStrings.SERVER_STRING_RESISTENCE_PERMIT)) {
            return DocumentTypes.residencepermit;
        } else {
            return DocumentTypes.driverslicense;
        }
    }


    /**
     * types: idfrontside, idbackside, idholograms, facefrontside, driversfrontside, driversbackside, driversholograms;
     *
     * @param string
     * @return
     */
    static DocumentImages mapStringToDocumentImageType(String string) {
        if (string.equals(Util_PhotoStrings.SERVER_STRING_IDFRONTSIDE)) {
            return DocumentImages.idfrontside;
        } else if (string.equals(Util_PhotoStrings.SERVER_STRING_IDBACKSIDE)) {
            return DocumentImages.idbackside;
        } else if (string.equals(Util_PhotoStrings.SERVER_STRING_IDHOLOGRAMS)) {
            return DocumentImages.idholograms;
        } else if (string.equals(Util_PhotoStrings.SERVER_STRING_FACE)) {
            return DocumentImages.facefrontside;
        } else if (string.equals(Util_PhotoStrings.SERVER_STRING_DRIVERSFRONTSIDE)) {
            return DocumentImages.driversfrontside;
        } else if (string.equals(Util_PhotoStrings.SERVER_STRING_DRIVERSBACKSIDE)) {
            return DocumentImages.driversbackside;
        } else if (string.equals(Util_PhotoStrings.SERVER_STRING_DRIVERSHOLOGRAMS)) {
            return DocumentImages.driversholograms;
        } else if (string.equals(Util_PhotoStrings.SERVER_STRING_HOLOGRAMS_VIDEO)) {
            return DocumentImages.videoHolograms;
        } else {
            return DocumentImages.passportholograms;
        }

    }

    public static @NonNull String getServerStringFromDocumentImageType(@Nullable DocumentImages imageType) {

        if (imageType != null) {
            switch (imageType) {
                case idbackside:
                    return Util_PhotoStrings.SERVER_STRING_IDBACKSIDE;
                case idfrontside:
                    return Util_PhotoStrings.SERVER_STRING_IDFRONTSIDE;
                case face:
                    return Util_PhotoStrings.SERVER_STRING_SELFIE;
                case idholograms:
                    return Util_PhotoStrings.SERVER_STRING_IDHOLOGRAMS;
                case facefrontside:
                    return Util_PhotoStrings.SERVER_STRING_FACE;
                case driversbackside:
                    return Util_PhotoStrings.SERVER_STRING_DRIVERSBACKSIDE;
                case driversfrontside:
                    return Util_PhotoStrings.SERVER_STRING_DRIVERSFRONTSIDE;
                case driversholograms:
                    return Util_PhotoStrings.SERVER_STRING_DRIVERSHOLOGRAMS;

                case videoHolograms:
                    return Util_PhotoStrings.SERVER_STRING_HOLOGRAMS_VIDEO;
                default:
                    return "UNDEFINDED";
            }
        }

        return "UNDEFINDED";

    }


    /**
     * initializes the documentListToCountryname list
     *
     * @param documents
     * @param countryName
     */
    static void initCountryHashMaps(Object[] documents, String countryName) {
        List<String> documentList = new ArrayList<String>();

        for (Object s : documents) {
            DocumentTypes doctype = mapStringToDocumentType(s.toString());
            if (doctype != null) {
                documentList.add(getDocumentnameToDocumenttype.get(doctype));
            }
        }

        // country is not in the hashmap yet -> store the country and its list in the hashmap
        if (documentListToCountryname.get(countryName) == null) {
            documentListToCountryname.put(countryName, documentList);
        }

        // country is already in the hashmap -> update its list in the hashmap
        else {
            List<String> currentList = documentListToCountryname.get(countryName);
            currentList.addAll(documentList);
            documentListToCountryname.put(countryName, currentList);
        }
    }


    // ==============================================
    // GETTER- & SETTER-SHARED PREFERENCES METHODS
    // ==============================================

    // all these methods take care of storing the static variables into the shared preferences. if one of the variables get null, all data is
    // loaded out of the shared preferences. each time a variable is changed during runtime a new data object is instantiated and stored into the
    // shared preferences. this permanent data storing is used because the LiveswitchController sometimes gets closed by the system and as a consequence of this the
    // hashmaps are empty when resuming the LiveswitchController.

    /**
     * @return the documentListToCountryname
     */
    public static Map<String, List<String>> getDocumentListToCountryname(Context context) {
        initDataHolder();

        if (dataHolder.getDocumentListToCountryname() == null) {
            loadDataFromSharedPrefs(context);
        }

        return dataHolder.getDocumentListToCountryname();
    }


    public static Map<String, List<String>> getDocumentImageTypesToDocument(Context context) {
        initDataHolder();

        if (dataHolder.getDocumentImageTypesToDocument() == null) {
            loadDataFromSharedPrefs(context);
        }
        return dataHolder.getDocumentImageTypesToDocument();
    }


    /**
     * @return the countryList
     */
    public static List<String> getCountryList(Context context) {
        initDataHolder();

        if (dataHolder.getCountryList() == null) {
            loadDataFromSharedPrefs(context.getApplicationContext());
        }

        List<String> countryList = dataHolder.getCountryList();
        Collator coll = Collator.getInstance(context.getApplicationContext().getResources().getConfiguration().locale);
        coll.setStrength(Collator.SECONDARY);
        Collections.sort(countryList, coll);

        return countryList;
    }

    /**
     * @param countryList the countryList to set
     */
    public static void setCountryList(ArrayList<String> countryList, Context context) {
        Util_PhotoDataHolder.countryList = countryList;
        saveDataInSharedPrefs(context);
    }

    /**
     * @return the countryISOCodeList
     */
    public static List<String> getCountryISOCodeList(Context context) {
        initDataHolder();

        if (dataHolder.getCountryISOCodeList() == null) {
            loadDataFromSharedPrefs(context);
        }
        return dataHolder.getCountryISOCodeList();
    }

    /**
     * @param countryISOCodeList the countryISOCodeList to set
     */
    public static void setCountryISOCodeList(ArrayList<String> countryISOCodeList, Context context) {
        Util_PhotoDataHolder.countryISOCodeList = countryISOCodeList;
        saveDataInSharedPrefs(context);
    }

    /**
     * /**
     *
     * @return the selectedCountry
     */
    public static String getSelectedCountry(Context context) {
        initDataHolder();

        if (dataHolder.getSelectedCountry().equals("")) {
            loadDataFromSharedPrefs(context);
        }
        return dataHolder.getSelectedCountry();
    }

    /**
     * @param selectedCountry the selectedCountry to set
     */
    public static void setSelectedCountry(String selectedCountry, Context context) {
        Util_PhotoDataHolder.selectedCountry = selectedCountry;

        // saveDataInSharedPrefs( context );
    }


    public static void initDataHolder() {
        dataHolder = new Models_PhotoDataHolderData(documentListToCountryname, documentImageTypesToDocument, countryList, countryISOCodeList, selectedCountry, selectedDocument, imageDocumentTakenHashMap, imageFilenameToImageDocumentHashMap, selectedDocumentImageType != null ? selectedDocumentImageType.toString() : "");
    }

    public static void saveDataInSharedPrefs(Context context) {
        // create new dataholder instance
        initDataHolder();

        Gson gson = new Gson();
        String serializedMap = gson.toJson(dataHolder);

        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(Util_PhotoStrings.SHARED_PREFS_KEY_DATA, serializedMap).apply();
    }

    public static void loadDataFromSharedPrefs(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        Gson gson = new Gson();

        String wrapperStr = prefs.getString(Util_PhotoStrings.SHARED_PREFS_KEY_DATA, "");
        dataHolder = gson.fromJson(wrapperStr, Models_PhotoDataHolderData.class);

    }
}
