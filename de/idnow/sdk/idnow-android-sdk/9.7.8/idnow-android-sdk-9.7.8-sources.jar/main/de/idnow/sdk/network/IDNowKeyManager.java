package de.idnow.sdk.network;

import java.io.IOException;
import java.net.Socket;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.X509KeyManager;

import android.content.Context;
import android.security.KeyChain;
import android.security.KeyChainException;

/**
 * class provides certificate chain and private key for establishing ssl connection
 */
public class IDNowKeyManager implements X509KeyManager {
    private final X509Certificate[] certChain;
    private final PrivateKey privateKey;
    private final String alias;

    public IDNowKeyManager(String alias) throws CertificateException, IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        this.alias = alias;

        IDNowDefaultSSLCredentialProvider keyStoreProvider = new IDNowDefaultSSLCredentialProvider();
        this.certChain = keyStoreProvider.provideClientAuthCertificateChain();
        this.privateKey = keyStoreProvider.provideClientAuthPrivateKey();
    }

    @Override
    public String chooseClientAlias(String[] arg0, Principal[] arg1, Socket arg2) {
        return alias;
    }

    @Override
    public X509Certificate[] getCertificateChain(String alias) {
        if (this.alias.equals(alias)) {
            return certChain;
        }

        return null;
    }

    @Override
    public PrivateKey getPrivateKey(String alias) {
        if (this.alias.equals(alias)) {
            return privateKey;
        }

        return null;
    }

    // Methods unused (for client SSLSocket callbacks)
    @Override public final String chooseServerAlias(String keyType, Principal[] issuers, Socket socket) {
        throw new UnsupportedOperationException();
    }

    @Override public final String[] getClientAliases(String keyType, Principal[] issuers) {
        throw new UnsupportedOperationException();
    }

    @Override public final String[] getServerAliases(String keyType, Principal[] issuers) {
        throw new UnsupportedOperationException();
    }
}
