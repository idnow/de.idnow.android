package de.idnow.sdk.util;

import android.content.Context;

import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
public enum Enum_WaitScreens {

    FIRST_SCREEN {
        @Override
        public String getVideoPath(Context context) {
            return null;
        }

        @Override
        public String getDescription(Context context) {
            return IDnowSDK.getInstance().getStringWithDefault(context,
                    Util_Strings.KEY_WAITING_SCREEN_AGENT_CONNECTING,
                    Util_Strings.LOCAL_KEY_WAITING_SCREEN_AGENT_CONNECTING);
        }
    },

    SECOND_SCREEN {
        @Override
        public String getVideoPath(Context context) {
            return "animate_ID_scan.json";
        }

        @Override
        public String getDescription(Context context) {
            return IDnowSDK.getInstance().getStringWithDefault(context,
                    Util_Strings.KEY_WAITING_SCREEN_IDENT_DOCUMENT_MSG,
                    Util_Strings.LOCAL_KEY_WAITING_SCREEN_IDENT_DOCUMENT_MSG);
        }
    },

    THIRD_SCREEN {
        @Override
        public String getVideoPath(Context context) {
            return "animate_clipboard.json";
        }

        @Override
        public String getDescription(Context context) {
            return IDnowSDK.getInstance().getStringWithDefault(context,
                    Util_Strings.KEY_WAITING_SCREEN_VERIFY_MSG,
                    Util_Strings.LOCAL_KEY_WAITING_SCREEN_VERIFY_MSG);
        }
    },

    FOURTH_SCREEN {
        @Override
        public String getVideoPath(Context context) {
            return "animate_selfie.json";
        }

        @Override
        public String getDescription(Context context) {
            return IDnowSDK.getInstance().getStringWithDefault(context,
                    Util_Strings.KEY_WAITING_SCREEN_SELFIE_MSG,
                    Util_Strings.LOCAL_KEY_WAITING_SCREEN_SELFIE_MSG);
        }
    };

    public abstract String getVideoPath(Context context);
    public abstract String getDescription(Context context);
}
