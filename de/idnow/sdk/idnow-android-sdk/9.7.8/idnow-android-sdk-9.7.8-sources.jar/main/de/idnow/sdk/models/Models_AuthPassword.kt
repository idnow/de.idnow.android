package de.idnow.sdk.models

import com.google.gson.annotations.SerializedName
import de.idnow.sdk.util.Util_Strings

data class Models_AuthPassword(
    @SerializedName(Util_Strings.LOGIN_PASSWORD_JSON_KEY)
    val password: String
)
