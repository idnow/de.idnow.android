package de.idnow.sdk.Activities.agentlanguage

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import de.idnow.sdk.util.Util_Log

class AgentLanguageViewModel : ViewModel() {

    private val _languageSpoken = MutableLiveData<String>()
    val languageSpoken: LiveData<String>
        get() = _languageSpoken

    private val _languageSpokenName = MutableLiveData<String>()
    val languageSpokenName: LiveData<String>
        get() = _languageSpokenName

    private val _languages = MutableLiveData<List<Language>>()
    val languages: LiveData<List<Language>>
        get() = _languages

    fun setup(mapperList: MutableList<Language>) {
        _languages.value = mapperList
    }

    fun setLanguageSpoken(language: Language): Boolean {
        return try {
            _languageSpoken.value = language.code.lowercase()
            _languageSpokenName.value = language.name
            true
        } catch (e: java.lang.IllegalArgumentException) {
            Util_Log.i("Agent Language", "${language.name} is not a supported language!")
            false
        }
    }

    data class Language(
        val code: String,
        val name: String
    )
}
