package de.idnow.sdk.models;

public class Models_Sentry {

    Models_Dsn dns;

    public Models_Sentry() {
    }

    public Models_Dsn getDsn() {
        return dns;
    }
}
