package de.idnow.sdk.models;

/**
 * Sent to server within the start call
 */
public class Models_ClientInfo {
    String language;
    String locale;
    String screenWidth;
    String screenHeight;
    String clientVersion;
    String frontCameraWidth;
    String frontCameraHeight;
    String backCameraWidth;
    String backCameraHeight;
    boolean flashLight;
    String connectionType;
    String osVersion;
    String deviceInfo;
    String timezone;
    String os;
    String sdkVersion;
    String customerapp;
    String mobileAppVersion;

    public Models_ClientInfo(String language, String locale, String screenWidth, String screenHeight, String clientVersion, String frontCameraWidth, String frontCameraHeight, String backCameraWidth, String backCameraHeight, boolean flashLight, String connectionType, String osVersion, String deviceInfo, String timezone, String os, String sdkVersion, String customerApp, String mobileAppVersion) {
        this.language = language;
        this.locale = locale;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.clientVersion = clientVersion;
        this.frontCameraWidth = frontCameraWidth;
        this.frontCameraHeight = frontCameraHeight;
        this.backCameraWidth = backCameraWidth;
        this.backCameraHeight = backCameraHeight;
        this.flashLight = flashLight;
        this.connectionType = connectionType;
        this.osVersion = osVersion;
        this.deviceInfo = deviceInfo;
        this.timezone = timezone;
        this.os = os;
        this.sdkVersion = sdkVersion;
        this.customerapp = customerApp;
        this.mobileAppVersion = mobileAppVersion;
    }
}
