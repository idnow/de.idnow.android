package de.idnow.sdk.models;



/**
 * 
 * @date 10.10.2014
 * @author Mathias Grasy
 * @version 1.0
 * @brief is send to the server when the agent requests a screenshot
 */


public class Models_Screenshot
{

	String	screenshot;
	String	type;

	public Models_Screenshot( String screenshot, String type )
	{
		this.screenshot = screenshot;
		this.type = type;
	}

	/**
	 * @return the screenshot
	 */
	public String getScreenshot()
	{
		return screenshot;
	}

	/**
	 * @param screenshot the screenshot to set
	 */
	public void setScreenshot( String screenshot )
	{
		this.screenshot = screenshot;
	}

	/**
	 * @return the type
	 */
	public String getType()
	{
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType( String type )
	{
		this.type = type;
	}
}
