package de.idnow.sdk.models;



/**
 * @author Mathias Grasy
 * @version 1.0
 * @brief is received from the server with the getCustomer call
 */


public class Models_Customer
{
	String              token;
	String              internalToken;
	String              status;
	String              email;
	String              mobile;
	String              custom1;
	String              custom2;
	String              custom3;
	String              custom4;
	String              custom5;
	String              testRobotType;
	int					remainingInternalTokenRetries;
	Models_Request      request;
	Models_URL_Settings settings;
	String redirectUrl;

	String preferredLang;

	String processType;

	String firstName;

	String lastName;

	boolean				waitingListNotified;
	boolean				waitingListEnrolled;

	boolean 			preEstablishVideoConnection;

	/**
	 * @param token
	 * @param status
	 * @param email
	 * @param mobile
	 * @param custom1
	 * @param custom2
	 * @param custom3
	 * @param custom4
	 * @param custom5
	 * @param request
	 */
	public Models_Customer( String token, String internalToken, String status, String email, String mobile, String custom1, String custom2, String custom3, String custom4,
							String custom5, int remainingInternalTokenRetries, String testRobotType, Models_Request request, Models_URL_Settings settings,String redirectUrl,String processType, String firstName, String lastName  )
	{
		this.token = token;
		this.internalToken = internalToken;
		this.status = status;
		this.email = email;
		this.mobile = mobile;
		this.custom1 = custom1;
		this.custom2 = custom2;
		this.custom3 = custom3;
		this.custom4 = custom4;
		this.custom5 = custom5;
		this.remainingInternalTokenRetries = remainingInternalTokenRetries;
		this.request = request;
		this.settings = settings;
		this.testRobotType = testRobotType;
		this.redirectUrl = redirectUrl;
		this.processType = processType;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public Models_Customer()
	{

	}

	public Models_URL_Settings getSettings()
	{
		return settings;
	}

	public void setSettings( Models_URL_Settings settings )
	{
		this.settings = settings;
	}

	/**
	 * @return the token
	 */
	public String getToken()
	{
		return token;
	}

	/**
	 * @param token the token to set
	 */
	public void setToken( String token )
	{
		this.token = token;
	}

	/**
	 * @return the internalToken
	 */
	public String getInternalToken()
	{
		return internalToken;
	}

	/**
	 * @param internalToken the internalToken to set
	 */
	public void setInternalToken( String internalToken )
	{
		this.internalToken = internalToken;
	}

	/**
	 * @return the status
	 */
	public String getStatus()
	{
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus( String status )
	{
		this.status = status;
	}

	/**
	 * @return the email
	 */
	public String getEmail()
	{
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail( String email )
	{
		this.email = email;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile()
	{
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile( String mobile )
	{
		this.mobile = mobile;
	}

	/**
	 * @return the custom1
	 */
	public String getCustom1()
	{
		return custom1;
	}

	/**
	 * @param custom1 the custom1 to set
	 */
	public void setCustom1( String custom1 )
	{
		this.custom1 = custom1;
	}

	/**
	 * @return the custom2
	 */
	public String getCustom2()
	{
		return custom2;
	}

	/**
	 * @param custom2 the custom2 to set
	 */
	public void setCustom2( String custom2 )
	{
		this.custom2 = custom2;
	}

	/**
	 * @return the custom3
	 */
	public String getCustom3()
	{
		return custom3;
	}

	/**
	 * @param custom3 the custom3 to set
	 */
	public void setCustom3( String custom3 )
	{
		this.custom3 = custom3;
	}

	/**
	 * @return the custom4
	 */
	public String getCustom4()
	{
		return custom4;
	}

	/**
	 * @param custom4 the custom4 to set
	 */
	public void setCustom4( String custom4 )
	{
		this.custom4 = custom4;
	}

	/**
	 * @return the custom5
	 */
	public String getCustom5()
	{
		return custom5;
	}

	/**
	 * @param custom5 the custom5 to set
	 */
	public void setCustom5( String custom5 )
	{
		this.custom5 = custom5;
	}

	public int getRemainingInternalTokenRetries() {
		return remainingInternalTokenRetries;
	}

	public void setRemainingInternalTokenRetries(int remainingInternalTokenRetries) {
		this.remainingInternalTokenRetries = remainingInternalTokenRetries;
	}

	/**
	 * @return the request
	 */
	public Models_Request getRequest()
	{
		return request;
	}

	/**
	 * @param request the request to set
	 */
	public void setRequest( Models_Request request )
	{
		this.request = request;
	}

	public boolean isWaitingListNotified() {
		return waitingListNotified;
	}

	public boolean isWaitingListEnrolled() {
		return waitingListEnrolled;
	}

	public String getTestRobotType() { return testRobotType; }

	public void setTestRobotType(String testRobotType) { this.testRobotType = testRobotType; }


	public String getRedirectUrl() {
		return redirectUrl;
	}

	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

	public boolean isPreEstablishVideoConnection() {
		return preEstablishVideoConnection;
	}

	public void setPreEstablishVideoConnection(boolean preEstablishVideoConnection) {
		this.preEstablishVideoConnection = preEstablishVideoConnection;
	}

	public String getPreferredLang() {
		return preferredLang;
	}

	public void setPreferredLang(String preferredLang) {
		this.preferredLang = preferredLang;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
}
