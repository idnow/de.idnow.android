package de.idnow.sdk.views

import android.R
import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Build
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.webkit.WebSettings
import android.widget.AdapterView
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.core.view.isVisible
import de.idnow.sdk.Adapters.Adapters_DocumentSpinnerAdapter
import de.idnow.sdk.Config
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.databinding.ViewPdfWebviewBinding
import de.idnow.sdk.network.IDNowWebViewClient
import de.idnow.sdk.util.Util_UtilUI


class PDFWebView @JvmOverloads constructor(
    context: Context,
    attributeSet: AttributeSet? = null,
    defStyle: Int = 0
) : LinearLayout(context, attributeSet, defStyle) {

    private val binding: ViewPdfWebviewBinding =
        ViewPdfWebviewBinding.inflate(LayoutInflater.from(context), this, true)

    init {

        binding.webViewPdf.webViewClient = IDNowWebViewClient().apply {
            setOnLoadingStateChangedAction(::onLoadingStateChanged)
        }
    }

    fun initDocumentsSpinner() {
        val spinner = binding.documentSpinner

        // Create an ArrayAdapter using the string array and a default spinner layout
        val adapter = Adapters_DocumentSpinnerAdapter(
            context,
            R.layout.simple_spinner_item,
            Config.PDF_DOCUMENTS
        )
        // Apply the adapter to the spinner
        spinner.adapter = adapter
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View,
                position: Int,
                id: Long
            ) {
                if (Config.PDF_DOCUMENTS != null && Config.PDF_DOCUMENTS.size > position && Config.PDF_DOCUMENTS[position].documentDefinition != null) {
                    getPDFToDocument(Config.PDF_DOCUMENTS[position].documentDefinition.identifier)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun getPDFToDocument(document: String) {
        val documentUrl =
            Uri.parse(Config.CURRENT_SERVER.getWebHost(IDnowSDK.getTransactionToken()))
                .buildUpon()
                .appendPath("api")
                .appendPath("v1")
                .appendPath(IDnowSDK.getCompanyId())
                .appendPath("identifications")
                .appendPath(IDnowSDK.getTransactionToken())
                .appendPath("documents")
                .appendPath(document)
                .appendPath("data")
                .appendQueryParameter("X-Client-Secret", Config.E_SIGNING_SECRET)
                .build()
                .toString()

        initPDF(documentUrl)
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun initPDF(urlToLoad: String) {
        val settings: WebSettings = binding.webViewPdf.settings
        settings.javaScriptEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        allowFileAccess(true)
        settings.setSupportZoom(true)
        settings.domStorageEnabled = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        val htmlFile = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            "file:///android_asset/pdfviewer.html"
        } else {
            "file:///android_asset/pdfviewer_legacy.html"
        }

        binding.webViewPdf.clearHistory()
        binding.webViewPdf.loadUrl("$htmlFile?$urlToLoad")
    }

    fun allowFileAccess(allow: Boolean) {
        val settings: WebSettings = binding.webViewPdf.settings
        settings.allowFileAccessFromFileURLs = allow
        settings.allowUniversalAccessFromFileURLs = allow
    }

    fun removeMargins() {
        setMargins()
    }

    fun setMarginBottom(dp: Int) {
        setMargins(bottom = Util_UtilUI.getPxFromDp(context, dp))
    }

    private fun setMargins(
        left: Int = 0,
        top: Int = 0,
        right: Int = 0,
        bottom: Int = 0
    ) {
        val pdfParams = binding.webViewPdf.layoutParams as FrameLayout.LayoutParams
        pdfParams.setMargins(left, top, right, bottom)
        binding.webViewPdf.layoutParams = pdfParams
    }

    fun setSpinnerVisible(isVisible: Boolean) {
        binding.documentSpinner.isVisible = isVisible
    }

    private fun onLoadingStateChanged(state: Boolean) = binding.apply {
        webViewPdf.isVisible = state.not()
        loadingSpinner.isVisible = state
    }
}