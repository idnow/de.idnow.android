package de.idnow.sdk.Activities.callbacks;

import java.io.FileNotFoundException;
import java.io.IOException;

import okhttp3.Response;

public interface GetTspDocCallback {
    void onSuccess(Response response) throws IOException;
    void onFailure();
}
