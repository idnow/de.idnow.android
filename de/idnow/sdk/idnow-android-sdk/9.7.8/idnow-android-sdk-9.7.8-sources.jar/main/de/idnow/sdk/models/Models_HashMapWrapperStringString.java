/**
 * @date 24.10.2014
 * @author Mathias Grasy
 * @brief (short description)
 * 
 * description long
 */

package de.idnow.sdk.models;

import java.util.Map;



/**
 * @date 24.10.2014
 * @author Mathias Grasy
 * @brief (short description)
 * 
 */


public class Models_HashMapWrapperStringString
{

	private Map<String, String>	map;

	/**
	 * @param map
	 */
	public Models_HashMapWrapperStringString( Map<String, String> map )
	{
		super();
		this.map = map;
	}

	/**
	 * @return the map
	 */
	public Map<String, String> getMap()
	{
		return map;
	}

	/**
	 * @param map the map to set
	 */
	public void setMap( Map<String, String> map )
	{
		this.map = map;
	}

}
