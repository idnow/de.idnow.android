package de.idnow.sdk.network

import android.annotation.SuppressLint
import android.net.http.X509TrustManagerExtensions
import de.idnow.sdk.CertificateProvider
import de.idnow.sdk.Config
import de.idnow.sdk.util.Util_Log
import java.security.GeneralSecurityException
import java.security.KeyStore
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.security.cert.CertificateEncodingException
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/**
 * class implements trust manager for all http connections, validates server certificate
 * using CertificateProvider
 */
@SuppressLint("CustomX509TrustManager")
object IDNowTrustManager : X509TrustManager {
    private const val LOGTAG = "IDNOW_IDNowTrustManager"
    private val systemTrustManager: X509TrustManager by lazy { createSystemTrustManager() }
    private val systemTrustManagerExt: X509TrustManagerExtensions
            by lazy { X509TrustManagerExtensions(systemTrustManager) }

    @Throws(CertificateException::class)
    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        systemTrustManager.checkClientTrusted(chain, authType)
    }

    @Throws(CertificateException::class)
    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        Config.CERTIFICATE_PROVIDER?.let {
            if (checkServerTrusted(it, chain.orEmpty()).not())
                throw CertificateException("Invalid server certificate")
        } ?: run {
            systemTrustManagerExt.checkServerTrusted(
                chain,
                authType,
                Config.GET_CURRENT_SERVER_API_HOST()
            )
        }
    }

    override fun getAcceptedIssuers(): Array<X509Certificate> =
        systemTrustManager.acceptedIssuers

    @Throws(GeneralSecurityException::class)
    private fun createSystemTrustManager(): X509TrustManager {
        val trustManagerFactory =
            TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        trustManagerFactory.init(null as KeyStore?)
        val trustManagers = trustManagerFactory.trustManagers

        return trustManagers[0] as X509TrustManager
    }

    fun checkServerTrusted(
        certProvider: CertificateProvider,
        chain: Array<out X509Certificate>
    ): Boolean {
        if (!certProvider.featureServerCert() && !certProvider.featureFingerPrint())
            return false

        var hasValidCertFingerprint = false
        if (certProvider.featureFingerPrint()) {
            try {
                val fingerprints = certProvider.provideServerFingerPrintByteStreams()
                    ?: run {
                        Util_Log.e(LOGTAG, "Server fingerprint was not provided")
                        return false
                    }
                val digest = MessageDigest.getInstance("SHA-256")
                for (cert in chain) {
                    val certFingerprint = digest.digest(cert.encoded)
                    if (fingerprints.any { it.contentEquals(certFingerprint) }) {
                        hasValidCertFingerprint = true
                        break
                    }
                }
            } catch (e: NoSuchAlgorithmException) {
                Util_Log.e(LOGTAG, "Cannot encode server fingerprint", e)
                return false
            } catch (e: CertificateEncodingException) {
                Util_Log.e(LOGTAG, "Cannot encode server fingerprint", e)
                return false
            }
        }

        var hasValidCert = false
        if (certProvider.featureServerCert()) {
            val serverCerts: Array<ByteArray> = certProvider.provideServerCertificateBytestreams()
                ?: run {
                    Util_Log.e(LOGTAG, "Server certificates not provided")
                    return false
                }
            for (cert in chain) {
                try {
                    val certEncoded = cert.encoded
                    if (serverCerts.any { it.contentEquals(certEncoded) })
                        hasValidCert = true
                } catch (e: CertificateEncodingException) {
                    Util_Log.e(LOGTAG, "Cannot encode server certificate", e)
                    return false
                }
            }
        }

        return hasValidCert || hasValidCertFingerprint
    }
}