package de.idnow.sdk.Activities.callbacks;

public interface SigningCanceledCallback {
    void onResult();
}
