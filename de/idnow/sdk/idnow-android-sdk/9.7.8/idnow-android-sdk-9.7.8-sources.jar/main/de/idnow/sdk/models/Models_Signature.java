package de.idnow.sdk.models;



/**
 * Created by Mathias Grasy on 04.02.2016.
 */

public class Models_Signature
{

	String description;
	String type;
	String camera;
	String title;

	public Models_Signature( String description, String type, String camera, String title )
	{
		this.description = description;
		this.type = type;
		this.camera = camera;
		this.title = title;
	}


	public String getDescription()
	{
		return description;
	}

	public void setDescription( String description )
	{
		this.description = description;
	}

	public String getType()
	{
		return type;
	}

	public void setType( String type )
	{
		this.type = type;
	}

	public String getCamera()
	{
		return camera;
	}

	public void setCamera( String camera )
	{
		this.camera = camera;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle( String title )
	{
		this.title = title;
	}
}
