package de.idnow.sdk.util.camera;

public class IDnowCameraData {
    public int orientation;
    public CameraType type = CameraType.BACK;
    public int width = -1;
    public int height = -1;
}
