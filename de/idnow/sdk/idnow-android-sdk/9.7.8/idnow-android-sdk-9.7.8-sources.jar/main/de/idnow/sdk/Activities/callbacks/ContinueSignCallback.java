package de.idnow.sdk.Activities.callbacks;

public interface ContinueSignCallback {
    void onContinueSign();
}
