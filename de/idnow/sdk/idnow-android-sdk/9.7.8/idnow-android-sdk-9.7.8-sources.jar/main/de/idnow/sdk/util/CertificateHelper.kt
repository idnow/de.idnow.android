package de.idnow.sdk.util

import android.util.Base64
import java.io.ByteArrayInputStream
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate

class CertificateHelper {
    companion object {
        private const val HASH_ALGORITHM = "SHA-256"

        //Load a certificate from a base64 string
        fun readFromBase64(value: String): X509Certificate {
            val bytes = base64ToByteArray(value)
            return readFromBytes(bytes)
        }

        //Load a certificate from a byte array
        fun readFromBytes(bytes: ByteArray?): X509Certificate {
            val certificateFactory = CertificateFactory.getInstance("X.509")
            return certificateFactory.generateCertificate(ByteArrayInputStream(bytes)) as X509Certificate
        }

        //Compare two certificates by their fingerprints
        fun compare(cert1: X509Certificate, cert2: X509Certificate): Boolean =
            getFingerprint(cert1).contentEquals(getFingerprint(cert2))

        //Checks certificate validity
        fun checkValidity(certificate: X509Certificate): Boolean {
            try {
                certificate.checkValidity()
                return true
            } catch (e: Exception) {
                return false
            }
        }

        // Get the SHA-256 fingerprint of a certificate
        private fun getFingerprint(certificate: X509Certificate): ByteArray {
            val digest = MessageDigest.getInstance(HASH_ALGORITHM)
            return digest.digest(certificate.encoded)
        }

        // Decode Base64 string to byte array
        private fun base64ToByteArray(base64String: String?): ByteArray {
            return Base64.decode(base64String, Base64.DEFAULT)
        }
    }
}
