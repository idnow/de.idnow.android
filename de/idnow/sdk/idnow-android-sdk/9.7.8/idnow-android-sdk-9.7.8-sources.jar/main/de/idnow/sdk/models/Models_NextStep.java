package de.idnow.sdk.models;



/**
 * @author Mathias Grasy
 * @version 1.0
 * @brief received from the server as part of the WebSocketResponse for signature
 */


public class Models_NextStep
{
	String stepName;
	String title;
	String employeeMessage;
	String camera;

	public Models_NextStep( String stepName )
	{
		this.stepName = stepName;
	}

	public Models_NextStep( String stepName, String title, String employeeMessage, String cameraToUse )
	{
		this.stepName = stepName;
		this.title = title;
		this.employeeMessage = employeeMessage;
		this.camera = cameraToUse;
	}

	public Models_NextStep()
	{

	}

	public String getStepName()
	{
		return stepName;
	}

	public void setStepName( String stepName )
	{
		this.stepName = stepName;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle( String title )
	{
		this.title = title;
	}

	public String getEmployeeMessage()
	{
		return employeeMessage;
	}

	public void setEmployeeMessage( String employeeMessage )
	{
		this.employeeMessage = employeeMessage;
	}

	public String getCameraToUse() {
		return camera;
	}

	public void setCameraToUse(String cameraToUse) {
		this.camera = cameraToUse;
	}
}
