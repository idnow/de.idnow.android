package de.idnow.sdk.Activities.storedidentity

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import de.idnow.sdk.R


class AgreementsAdapter : RecyclerView.Adapter<AgreementsAdapter.AgreementsVH>() {

    private var internalAgreements = mutableListOf<String>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AgreementsVH {
        return AgreementsVH(
            LayoutInflater
                .from(parent.context)
                .inflate(R.layout.agreements_row, parent, false),
        )
    }

    override fun onBindViewHolder(holder: AgreementsVH, position: Int) {
        holder.bind(internalAgreements[position])
    }

    override fun getItemCount(): Int {
        return internalAgreements.size
    }

    fun addAll(agreements: List<String>) {
        internalAgreements.addAll(agreements)
        notifyItemRangeInserted(0, agreements.size)
    }

    class AgreementsVH(
        itemView: View,
    ) : RecyclerView.ViewHolder(itemView) {
        fun bind(item: String) = with(itemView) {

            val agreement = findViewById<TextView>(R.id.text)
            agreement.text = item
        }
    }

}