package de.idnow.sdk.util;

import android.content.Context;
import android.util.AttributeSet;
import android.view.animation.Interpolator;
import android.widget.Scroller;

import androidx.viewpager.widget.ViewPager;

import java.lang.reflect.Field;

public class ViewPagerCustomDuration extends ViewPager {

    private static final String LOGTAG = "IDNOW_ViewPagerCustomDuration";
    private ScrollerCustomDuration mScroller = null;
    private int scrollDurationInMs = 200;

    public ViewPagerCustomDuration(Context context) {
        super(context);
        postInitViewPager();
    }

    public ViewPagerCustomDuration(Context context, AttributeSet attrs) {
        super(context, attrs);
        postInitViewPager();
    }

    private void postInitViewPager() {
        try {
            Field scroller = ViewPager.class.getDeclaredField("mScroller");
            scroller.setAccessible(true);
            Field interpolator = ViewPager.class.getDeclaredField("sInterpolator");
            interpolator.setAccessible(true);

            mScroller = new ScrollerCustomDuration(getContext(),
                    (Interpolator) interpolator.get(null));
            scroller.set(this, mScroller);
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Post init ViewPager failed", e);
        }
    }

    public void setScrollDuration(int scrollDurationInMs) {
        mScroller.setScrollDuration(scrollDurationInMs);
    }

    public class ScrollerCustomDuration extends Scroller {

        public ScrollerCustomDuration(Context context, Interpolator interpolator) {
            super(context, interpolator);
        }

        public void setScrollDuration(int scrollDurationInMs) {
            ViewPagerCustomDuration.this.scrollDurationInMs = scrollDurationInMs;
        }

        @Override
        public void startScroll(int startX, int startY, int dx, int dy, int duration) {
            super.startScroll(startX, startY, dx, dy, scrollDurationInMs);
        }

    }
}
