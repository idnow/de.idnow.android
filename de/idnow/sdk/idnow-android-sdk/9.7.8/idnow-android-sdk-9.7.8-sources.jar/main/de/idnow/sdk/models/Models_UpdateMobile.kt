package de.idnow.sdk.models

import com.google.gson.annotations.SerializedName
import de.idnow.sdk.util.Util_Strings

data class Models_UpdateMobile(
    @SerializedName(Util_Strings.LOGIN_MOBILE_JSON_KEY)
    val mobile: String
)
