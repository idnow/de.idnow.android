package de.idnow.sdk.util;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_Super;
import de.idnow.sdk.R;

/**
 * @author Mathias Grasy
 * @version 1.0
 * @brief click listener for checkboxes in eSigning native view
 */
public class UI_CustomOnClickListenerCheckMark implements OnClickListener {
    private final String LOGTAG = "IDNOW_UI_CustomOnClickListenerCheckMark";

    public UI_CustomOnClickListenerCheckMark() {
    }

    @Override
    public void onClick(View v) {
        ImageView view = v.findViewById(R.id.eSigningCheckMark);
        try {
            if ((Boolean) view.getTag()) {
                Util_UtilUI.setCheckMark(view, false);
                view.setTag(false);
            } else {
                Util_UtilUI.setCheckMark(view, true);
                view.setTag(true);
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "OnClick failed", e);
        }

        ((Activities_VideoLiveStreamActivity_Super) view.getContext()).handleCheckMarkClicked(view);

    }
}
