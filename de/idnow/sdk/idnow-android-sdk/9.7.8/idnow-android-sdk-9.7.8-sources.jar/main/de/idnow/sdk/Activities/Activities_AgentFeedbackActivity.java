package de.idnow.sdk.Activities;

import static de.idnow.sdk.util.Util_Strings.KEY_AGENT_FEEDBACK_DESC;
import static de.idnow.sdk.util.Util_Strings.KEY_AGENT_FEEDBACK_NOT_NOW;
import static de.idnow.sdk.util.Util_Strings.KEY_AGENT_FEEDBACK_OPTION;
import static de.idnow.sdk.util.Util_Strings.KEY_AGENT_FEEDBACK_SEND;
import static de.idnow.sdk.util.Util_Strings.KEY_AGENT_FEEDBACK_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_AGENT_FEEDBACK_VERY_BAD;
import static de.idnow.sdk.util.Util_Strings.KEY_AGENT_FEEDBACK_VERY_GOOD;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_AGENT_FEEDBACK_DESC;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_AGENT_FEEDBACK_NOT_NOW;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_AGENT_FEEDBACK_OPTION;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_AGENT_FEEDBACK_SEND;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_AGENT_FEEDBACK_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_AGENT_FEEDBACK_VERY_BAD;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_AGENT_FEEDBACK_VERY_GOOD;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.Interface_VideoLiveStream;
import de.idnow.sdk.util.camera.CameraType;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Model_AgentFeedback;
import de.idnow.sdk.network.Callback;
import de.idnow.sdk.network.IDnowRestClient;
import de.idnow.sdk.network.Network_RESTCalls;
import de.idnow.sdk.network.RetrofitError;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_Util;
import de.idnow.sdk.util.Util_UtilUI;
import retrofit2.Call;
import retrofit2.Response;

public class Activities_AgentFeedbackActivity extends Activities_VideoLiveStreamActivity_Super implements Interface_VideoLiveStream {

    LottieAnimationView logo_screen_feedback,feedback_very_bad_icon, feedback_bad_icon, feedback_normal_icon, feedback_good_icon, feedback_very_good_icon;

    TextView feedback_title,feedback_description1, feedback_very_bad, feedback_very_good,feedback_description2, feedback_cancel;

    Button feedback_button;

    EditText feedback_text;

    Context context;

    LinearLayout rateAgent_view,userAbort_view;

    int rating;

    private static final String LOGTAG = "IDNOW_Activities_AgentFeedbackActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_feedback);

        context = this;

        logo_screen_feedback = findViewById(R.id.logo_screen_feedback);
        feedback_bad_icon = findViewById(R.id.feedback_bad_icon);
        feedback_very_bad_icon = findViewById(R.id.feedback_very_bad_icon);
        feedback_normal_icon = findViewById(R.id.feedback_normal_icon);
        feedback_good_icon = findViewById(R.id.feedback_good_icon);
        feedback_very_good_icon = findViewById(R.id.feedback_very_good_icon);
        rateAgent_view = findViewById(R.id.rateAgent_view);
        userAbort_view = findViewById(R.id.userAbort_view);

        feedback_very_bad_icon.setAnimation("static_rate_angry_selected.json");
        feedback_bad_icon.setAnimation("static_rate_sad_selected.json");
        feedback_normal_icon.setAnimation("static_rate_neutral_selected.json");
        feedback_good_icon.setAnimation("static_rate_smile_selected.json");
        feedback_very_good_icon.setAnimation("static_rate_happy_selected.json");
        setColorIcons(Color.parseColor("#D0D0D0"),feedback_very_bad_icon);
        setColorIcons(Color.parseColor("#D0D0D0"),feedback_bad_icon);
        setColorIcons(Color.parseColor("#D0D0D0"),feedback_normal_icon);
        setColorIcons(Color.parseColor("#D0D0D0"),feedback_good_icon);
        setColorIcons(Color.parseColor("#D0D0D0"),feedback_very_good_icon);

        feedback_title = findViewById(R.id.feedback_title);
        feedback_description1 = findViewById(R.id.feedback_description1);
        feedback_description2 = findViewById(R.id.feedback_description2);
        feedback_very_bad = findViewById(R.id.feedback_very_bad);
        feedback_very_good = findViewById(R.id.feedback_very_good);
        feedback_cancel = findViewById(R.id.feedback_cancel);
        feedback_text = findViewById(R.id.feedback_text);
        feedback_button = findViewById(R.id.feedback_button);

        rateAgent_view.setVisibility(View.VISIBLE);
        userAbort_view.setVisibility(View.GONE);

        feedback_text.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return false;
            }
        });

        feedback_text.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });


        Util_Util.hideSoftKeyboard(Activities_AgentFeedbackActivity.this);


        feedback_button.setEnabled(false);
        Util_UtilUI.setProceedButtonBackgroundSelector( feedback_button );

        if(Config.VIDEO_IDENT_PLUS) {

            logo_screen_feedback.setAnimation("static_logo.json");

            if (Config.DARK_MODE) {
                Util_UtilUI.setColorLottieAnimation(Color.WHITE, logo_screen_feedback, "SecondaryVariant");
            } else {
                Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, logo_screen_feedback, "SecondaryVariant");
            }
        }

        if(IDnowSDK.getShowIDnowLogo()){
            logo_screen_feedback.setVisibility(View.VISIBLE);
        }
        else {
            logo_screen_feedback.setVisibility(View.GONE);
        }

        feedback_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_AGENT_FEEDBACK_TITLE, LOCAL_KEY_AGENT_FEEDBACK_TITLE));
        feedback_description1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_AGENT_FEEDBACK_DESC, LOCAL_KEY_AGENT_FEEDBACK_DESC));
        feedback_description2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_AGENT_FEEDBACK_OPTION, LOCAL_KEY_AGENT_FEEDBACK_OPTION));
        feedback_very_good.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_AGENT_FEEDBACK_VERY_GOOD, LOCAL_KEY_AGENT_FEEDBACK_VERY_GOOD));
        feedback_cancel.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_AGENT_FEEDBACK_NOT_NOW, LOCAL_KEY_AGENT_FEEDBACK_NOT_NOW));
        feedback_button.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_AGENT_FEEDBACK_SEND, LOCAL_KEY_AGENT_FEEDBACK_SEND));
        feedback_very_bad.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_AGENT_FEEDBACK_VERY_BAD, LOCAL_KEY_AGENT_FEEDBACK_VERY_BAD));

        feedback_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Config.AGENT_CONNECTED = false;
                finish();
            }
        });

        feedback_very_bad_icon.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
               // feedback_very_bad_icon.setImageResource(R.drawable.agent_angry);
                rating = 1;

                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_activated) ),feedback_very_bad_icon);

                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_bad_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_normal_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_good_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_very_good_icon);
                feedback_button.setEnabled(true);
                Util_UtilUI.setProceedButtonBackgroundSelector( feedback_button );

                return false;
            }
        });

        feedback_bad_icon.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                rating = 2;

                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_activated) ),feedback_bad_icon);

                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_very_bad_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_normal_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_good_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_very_good_icon);

                feedback_button.setEnabled(true);
                Util_UtilUI.setProceedButtonBackgroundSelector( feedback_button );
                return false;
            }
        });

        feedback_normal_icon.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                rating = 3;

                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_activated) ),feedback_normal_icon);

                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_very_bad_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_bad_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_good_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_very_good_icon);
                feedback_button.setEnabled(true);
                Util_UtilUI.setProceedButtonBackgroundSelector( feedback_button );

                return false;
            }
        });

        feedback_good_icon.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                rating = 4;

                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_activated) ),feedback_good_icon);

                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_very_bad_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_bad_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_normal_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_very_good_icon);
                feedback_button.setEnabled(true);
                Util_UtilUI.setProceedButtonBackgroundSelector( feedback_button );

                return false;
            }
        });

        feedback_very_good_icon.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                rating = 5;

                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_activated) ),feedback_very_good_icon);

                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_very_bad_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_bad_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_normal_icon);
                setColorIcons(Color.parseColor(getResources().getString(R.color.agent_desactivated) ),feedback_good_icon);
                feedback_button.setEnabled(true);
                Util_UtilUI.setProceedButtonBackgroundSelector( feedback_button );

                return false;
            }
        });


        feedback_button = findViewById(R.id.feedback_button);

        feedback_button.setOnClickListener(view -> {
            Config.AGENT_CONNECTED = false;
            agentFeedbackRestCall(feedback_text.getText().toString(),rating);
        });

    }

    private void setColorIcons(int animationViewColor,LottieAnimationView animationViewLottie){
        Util_UtilUI.setColorLottieAnimation(animationViewColor,animationViewLottie,"rateStatus" );
    }

    private void agentFeedbackRestCall(String reason, int rating) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint( endPoint, IDnowSDK.getInstance().getAppContext() );

        Callback<Void> callback = new Callback<Void>() {
            @Override
            public void failure( RetrofitError error ) {
                Util_UtilUI.showAgentRatingFailedErrorDialog(context);
            }

            @Override
            public void success(Void unused, Response response) {
                finish();
            }
        };

        Call<Void> result = service
                .agentFeedback( new Model_AgentFeedback(rating,reason), IDnowSDK.getTransactionToken(  ), IDnowSDK.getCompanyId());
        result.enqueue(callback);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void setupImageStreamPush(byte[] imageString, String imageType) {

    }

    @Override
    public void takeScreenshot(String type) {
    }

    @Override
    public void startESigning() {

    }

    @Override
    protected int getCurrentRetryCount() {
        return 0;
    }

    @Override
    protected void disconnectVideoConnection() {

    }

    @Override
    protected void establishVideoConnection() {

    }

    @Override
    public void signingCanceledRESTCall() {

    }

    @Override
    public void onEndCall(int result) {
        showResultActivity(result);

    }

    @Override
    public void setCurrentStep(int step) {

    }

    @Override
    public void updateExplanationView(String websocketResponse) {

    }

    @Override
    public void identificationFailedRESTCall() {

    }

    @Override
    public void identificationCanceledRESTCall() {

    }

    @Override
    public void agentConnected() {

    }

    @Override
    public void requestCameraFocusCenter() {

    }

    @Override
    public void openCamera(CameraType type) {

    }

    @Override
    public void setCameraTorchEnabled(Boolean enabled) {

    }

    @Override
    public Handler getHandler() {
        return null;
    }

    @Override
    public void identificationCanceled() {

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
