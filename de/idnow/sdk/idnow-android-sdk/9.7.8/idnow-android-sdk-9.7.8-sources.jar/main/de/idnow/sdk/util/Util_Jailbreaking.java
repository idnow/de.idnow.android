package de.idnow.sdk.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

/**
 * Created by Mathias Grasy on 15.06.2016.
 */
public class Util_Jailbreaking
{

	/**
	 * checks if the device is rooted. takes therefore 4 root-checks. if at least one the checks is valid -> device is rooted
	 *
	 * @return
	 */
	public static boolean isDeviceRooted()
	{
		return checkRootMethod1() || checkRootMethod2() || checkRootMethod3() || checkRootMethod4();
	}

	private static boolean checkRootMethod1()
	{
		String buildTags = android.os.Build.TAGS;
		return buildTags != null && buildTags.contains( "test-keys" );
	}

	private static boolean checkRootMethod2()
	{
		String[] paths = { "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su",
				"/system/bin/failsafe/su", "/data/local/su" };
		for ( String path : paths )
		{
			if ( new File( path ).exists() )
			{
				return true;
			}
		}
		return false;
	}

	private static boolean checkRootMethod3()
	{
		Process process = null;
		try
		{
			process = Runtime.getRuntime().exec( new String[]{ "/system/xbin/which", "su" } );
			BufferedReader in = new BufferedReader( new InputStreamReader( process.getInputStream() ) );
            return in.readLine() != null;
        }
		catch ( Throwable t )
		{
			return false;
		}
		finally
		{
			if ( process != null )
			{
				process.destroy();
			}
		}
	}


	private static boolean findBinary( String binaryName )
	{
		boolean found = false;
		if ( !found )
		{
			String[] places = { "/sbin/", "/system/bin/", "/system/xbin/",
					"/data/local/xbin/", "/data/local/bin/",
					"/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/" };
			for ( String where : places )
			{
				if ( new File( where + binaryName ).exists() )
				{
					found = true;

					break;
				}
			}
		}
		return found;
	}

	/**
	 * checks if the device is rooted
	 *
	 * @return
	 */
	private static boolean checkRootMethod4()
	{
		return findBinary( "su" );
	}
}
