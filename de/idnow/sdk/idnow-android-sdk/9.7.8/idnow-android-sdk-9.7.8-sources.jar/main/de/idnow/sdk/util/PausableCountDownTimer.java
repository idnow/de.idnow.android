package de.idnow.sdk.util;

import android.os.CountDownTimer;

public class PausableCountDownTimer {

    private final ITimerStatus callback;

    private long remainingTime;
    private boolean isPaused;

    private AppTimer appTimer;

    public PausableCountDownTimer(ITimerStatus callback) {
        this.callback = callback;
    }

    public void startTimer(long millisInFuture) {
        startTimer(millisInFuture, 500);
    }

    public void startTimer(long millisInFuture, long timeDownInterval) {
        appTimer = new AppTimer(millisInFuture, timeDownInterval);
        appTimer.start();
    }

    public void pause() {
        if (appTimer == null) {
            throw new IllegalStateException("Attempting to pause a null timer.");
        }
        isPaused = true;
        appTimer.cancel();
    }

    public void resume() {
        if (isPaused) {
            isPaused = false;
            startTimer(remainingTime);
        }
    }

    private class AppTimer extends CountDownTimer {
        AppTimer(long millisInFuture, long timeDownInterval) {
            super(millisInFuture, timeDownInterval);
        }

        public void onTick(long millisUntilFinished) {
            remainingTime = millisUntilFinished;
        }

        public void onFinish() {
            if (callback != null) {
                callback.onTimerFinished();
            }
        }
    }

    public interface ITimerStatus {
        void onTimerFinished();
    }
}
