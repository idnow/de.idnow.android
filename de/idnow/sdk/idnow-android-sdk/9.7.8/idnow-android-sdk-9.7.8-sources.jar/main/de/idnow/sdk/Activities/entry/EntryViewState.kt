package de.idnow.sdk.Activities.entry

data class EntryViewState(
    val isLoading: Boolean = false,
    val showIdMethod: Boolean = false,
    val isDarkModeAllowed: Boolean = true,
    val showEidLogo: Boolean = false,
    val showPoweredByLogo: Boolean = false,
    val pageTitle: String = "",
    val vidTitle: String = "",
    val vidDescription: String = "",
    val vidTime: String = "",
    val eidTitle: String = "",
    val eidDescription: String = "",
    val eidTime: String = "",
    val showNameCheck: Boolean = false,
    val nameCheckTitleLabel: String = "",
    val nameCheckDescriptionLabel: String = "",
    val nameCheckNameLabel: String = "",
    val nameCheckNameValue: String = "",
    val nameCheckContinueLabel: String = "",
    val nameCheckQuitLabel: String = ""
)