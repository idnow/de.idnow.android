package de.idnow.sdk.network.connectivityService

import android.Manifest
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.annotation.RequiresPermission
import de.idnow.sdk.network.connectivityService.models.ConnectivityState
import de.idnow.sdk.network.connectivityService.models.NetworkType
import de.idnow.sdk.util.Util_Log
import kotlinx.coroutines.flow.MutableStateFlow

internal object ConnectivityService : ConnectivityManager.NetworkCallback() {
    private const val LOG_TAG = "IDNOW_ConnectivityService"

    //TODO: This is only used in video livestream activity. When we will switch there to kotlin,
    // then the listener needs to be removed
    interface Listener {
        fun onConnectivityStateChanged(isOnline: Boolean)
    }

    private val state: MutableStateFlow<ConnectivityState> = MutableStateFlow(ConnectivityState())
    private lateinit var connectivityManager: ConnectivityManager
    private val listeners: MutableList<Listener> = mutableListOf()
    private var isInitialized = false

    @RequiresPermission(Manifest.permission.ACCESS_NETWORK_STATE)
    @Synchronized
    fun init(context: Context) {
        if (isInitialized)
            return

        connectivityManager =
            context.applicationContext.getSystemService(ConnectivityManager::class.java)
        resolveInitialState()
        connectivityManager.registerDefaultNetworkCallback(this)
        isInitialized = true
    }

    fun registerListener(listener: Listener) {
        listeners.add(listener)
        listener.onConnectivityStateChanged(getState().isOnline())
    }

    fun unregisterListener(listener: Listener) {
        listeners.remove(listener)
    }

    private fun getState(): ConnectivityState =
        state.value

    override fun onAvailable(network: Network) {
        super.onAvailable(network)
        addAvailableNetwork(network)
    }

    override fun onLost(network: Network) {
        super.onLost(network)
        removeAvailableNetwork(network)
    }

    override fun onCapabilitiesChanged(
        network: Network,
        networkCapabilities: NetworkCapabilities
    ) {
        super.onCapabilitiesChanged(network, networkCapabilities)
        refreshState(networkCapabilities)
    }

    fun isOnline(): Boolean =
        getState().isOnline()

    fun getConnectionType(): String =
        getState().mainNetworkType.desc

    private fun resolveInitialState() {
        val activeNetwork = connectivityManager.activeNetwork
        if (activeNetwork != null) {
            addAvailableNetwork(activeNetwork)
            refreshState(connectivityManager.getNetworkCapabilities(activeNetwork))
        }
    }

    private fun refreshState(activeNetworkInfo: NetworkCapabilities?) {
        val networkType = activeNetworkInfo.getNetworkType()
        val hasInternetAccess = activeNetworkInfo.hasInternetAccess()

        onStateChange {
            copy(
                hasInternetAccess = hasInternetAccess,
                mainNetworkType = networkType,
            )
        }
    }

    private fun onStateChange(reducer: ConnectivityState.() -> ConnectivityState) {
        val actualState = state.value
        val newState = actualState.reducer()
        if (actualState == newState)
            return

        if (actualState.isOnline() != newState.isOnline()) {
            listeners.forEach { it.onConnectivityStateChanged(newState.isOnline()) }
        }

        state.value = newState
        Util_Log.i(LOG_TAG, "State updated: $newState")
    }

    private fun NetworkCapabilities?.hasInternetAccess(): Boolean {
        return this?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true &&
                hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun NetworkCapabilities?.getNetworkType(): NetworkType {
        return when {
            this == null -> NetworkType.Unknown
            hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkType.WiFi
            hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkType.Cellular
            else -> NetworkType.Unknown
        }
    }

    private fun removeAvailableNetwork(network: Network) {
        val activeNetworks = getState().networks.toMutableSet().apply { remove(network) }

        onStateChange {
            copy(
                networks = activeNetworks,
                hasInternetAccess = if (activeNetworks.isNotEmpty()) hasInternetAccess else false,
                mainNetworkType = if (activeNetworks.isNotEmpty()) mainNetworkType else NetworkType.Unknown,
            )
        }
    }

    private fun addAvailableNetwork(network: Network) {
        val activeNetworks = getState().networks
        if (activeNetworks.contains(network))
            return

        onStateChange {
            copy(networks = activeNetworks + network)
        }
    }
}