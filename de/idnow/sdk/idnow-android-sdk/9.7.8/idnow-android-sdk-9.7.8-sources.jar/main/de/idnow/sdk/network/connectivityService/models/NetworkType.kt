package de.idnow.sdk.network.connectivityService.models

internal enum class NetworkType(val desc: String) {
    WiFi("WIFI"),
    Cellular("Mobile Data"),
    Unknown("TelephonyManager.NETWORK_TYPE_UNKNOWN")
}
