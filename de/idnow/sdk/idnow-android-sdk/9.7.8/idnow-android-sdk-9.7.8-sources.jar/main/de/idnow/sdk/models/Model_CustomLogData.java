package de.idnow.sdk.models;

import com.google.gson.annotations.SerializedName;

public class Model_CustomLogData {
    @SerializedName("appKey")
    private String appKey;
    @SerializedName("url")
    private String url;

    public String getAppKey(){
        return appKey;
    }
    public String getServerURL(){
        return url;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public void setServerURL(String url) {
        this.url = url;
    }
}
