package de.idnow.sdk.models;

import com.google.gson.annotations.SerializedName;

public class Models_OTPForWallet {

    @SerializedName("ident")
    public boolean ident;
    @SerializedName("signing")
    public boolean signing;

    public Models_OTPForWallet(boolean ident, boolean signing) {
        this.ident = ident;
        this.signing = signing;
    }

    public boolean isIdent() {
        return ident;
    }

    public void setIdent(boolean ident) {
        this.ident = ident;
    }

    public boolean isSigning() {
        return signing;
    }

    public void setSigning(boolean signing) {
        this.signing = signing;
    }
}
