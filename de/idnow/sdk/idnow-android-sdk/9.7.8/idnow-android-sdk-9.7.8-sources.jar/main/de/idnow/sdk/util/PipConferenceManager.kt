package de.idnow.sdk.util

import android.app.Activity
import android.app.Application
import android.app.Application.ActivityLifecycleCallbacks
import android.content.Intent
import android.os.Bundle
import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_LIVESWITCH

internal object PipConferenceManager {
    private var isConferenceStarted = false
    private var conferenceActivityId: Int = 0
    private val conferenceActivityClass = Activities_VideoLiveStreamActivity_LIVESWITCH::class.java
    private val callback: ActivityLifecycleCallbacks by lazy(PipConferenceManager::createLifecycleCallback)
    private val activityStack: MutableList<Activity> = mutableListOf()

    @Synchronized
    fun initialize(application: Application) {
        reset(application)
        application.registerActivityLifecycleCallbacks(callback)
    }

    private fun reset(application: Application) {
        isConferenceStarted = false
        activityStack.clear()
        application.unregisterActivityLifecycleCallbacks(callback)
    }

    private fun createLifecycleCallback(): ActivityLifecycleCallbacks {
        return object : ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                activityStack.add(activity)
                if (activity::class.java == conferenceActivityClass) {
                    if (isConferenceStarted && activity.hashCode() != conferenceActivityId) {
                        activity.finishAndRemoveTask()
                        return
                    }
                    isConferenceStarted = true
                    conferenceActivityId = activity.hashCode()
                }
            }

            override fun onActivityStarted(activity: Activity) {}

            override fun onActivityResumed(activity: Activity) {
                if (activity::class.java == conferenceActivityClass || !isConferenceStarted)
                    return

                val conferenceActivity =
                    activityStack.firstOrNull { it::class.java == conferenceActivityClass }
                        ?: return

                if (conferenceActivity.isInPictureInPictureMode.not())
                    return

                val startIntent = Intent(activity, conferenceActivityClass)
                activity.startActivity(startIntent)
            }

            override fun onActivityPaused(activity: Activity) {}

            override fun onActivityStopped(activity: Activity) {}

            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

            override fun onActivityDestroyed(activity: Activity) {
                activityStack.remove(activity)
                if (activity::class.java == conferenceActivityClass) {
                    if (conferenceActivityId != 0 && activity.hashCode() == conferenceActivityId) {
                        isConferenceStarted = false
                        conferenceActivityId = 0
                    }
                }
            }
        }
    }
}