package de.idnow.sdk.network

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.http.SslError
import android.webkit.ClientCertRequest
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import de.idnow.sdk.Config
import de.idnow.sdk.util.Util_Log
import java.security.PrivateKey
import java.security.cert.X509Certificate

/**
 * WebView client that adds mTLS support for network connections using CertProvider
 */

private const val LOG_TAG = "IDNOW_IDNowWebViewClient"

open class IDNowWebViewClient : WebViewClient() {

    private var onLoadingStateChanged: ((Boolean) -> Unit)? = null

    fun setOnLoadingStateChangedAction(action: (Boolean) -> Unit) {
        onLoadingStateChanged = action
    }

    override fun onReceivedClientCertRequest(view: WebView?, request: ClientCertRequest?) {
        val credentialProvider = IDNowDefaultSSLCredentialProvider()
        var privateKey: PrivateKey? = null
        var certChain: Array<X509Certificate>? = null
        try {
            privateKey = credentialProvider.provideClientAuthPrivateKey()
            certChain = credentialProvider.provideClientAuthCertificateChain()
        } catch (e: Exception) {
            Util_Log.e(LOG_TAG, "Provide auth data failed", e)
        }

        if (privateKey == null || certChain == null) {
            super.onReceivedClientCertRequest(view, request)
            return
        }

        request?.proceed(privateKey, certChain)
    }

    @SuppressLint("WebViewClientOnReceivedSslError")
    override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
        val provider = Config.CERTIFICATE_PROVIDER
        if (provider == null || android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q) {
            super.onReceivedSslError(view, handler, error)
            return
        }

        val cert = error?.certificate?.x509Certificate
        if (cert != null && IDNowTrustManager.checkServerTrusted(provider, arrayOf(cert))) {
            handler?.proceed()
        } else {
            Util_Log.d(LOG_TAG, "Untrusted certificate: ${error.toString()}")
            handler?.cancel()
        }
    }

    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)
        onLoadingStateChanged?.invoke(true)
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        onLoadingStateChanged?.invoke(false)
    }
}
