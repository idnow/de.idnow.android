package de.idnow.sdk.network;


import java.io.BufferedReader;
import java.io.InputStreamReader;

import de.idnow.sdk.util.Util_Log;
import okhttp3.ResponseBody;

public class RetrofitError {

    private final Response response;

    public Response getResponse() {
        return response;
    }

    private RetrofitErrorBody body;

    public RetrofitErrorBody getBody() {
        return body;
    }

    private String message;

    public String getMessage() {
        return message;
    }

    private String localizedMessage;

    public String getLocalizedMessage() {
        return localizedMessage;
    }

    private Throwable cause;

    public Throwable getCause() {
        return this.cause;
    }

    public RetrofitError() {
        this.response = new Response();
    }

    public static RetrofitError from(Throwable t) {
        RetrofitError instance = new RetrofitError();
        instance.message = t.getMessage();
        instance.localizedMessage = t.getLocalizedMessage();
        instance.cause = t;
        return instance;
    }

    public static <T> RetrofitError from(retrofit2.Response<T> response) {
        RetrofitError instance = new RetrofitError();
        instance.response.status = response.code();

        RetrofitErrorBody body = RetrofitErrorBody.from(response.errorBody());
        instance.response.body = body;
        instance.body = body;

        return instance;
    }

    public static class Response {

        private RetrofitErrorBody body;

        public RetrofitErrorBody getBody() {
            return body;
        }

        public int status;

        public int getStatus() {
            return status;
        }
    }

    public static class RetrofitErrorBody {
        String message = "";

        public String getMessage() {
            return message;
        }

        public static RetrofitErrorBody from(ResponseBody errorBody) {
            if (errorBody == null) {
                return null;
            }

            // Try to get response body
            BufferedReader reader;
            StringBuilder sb = new StringBuilder();
            try {
                reader = new BufferedReader(new InputStreamReader(errorBody.byteStream()));
                String line;

                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            } catch (Exception e) {
                Util_Log.e("IDNOW_RetrofitError", "Read error body failed", e);
                return null;
            }

            RetrofitErrorBody instance = new RetrofitErrorBody();
            instance.message = sb.toString();

            return instance;
        }
    }
}
