package de.idnow.sdk.util.permissionsManager

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.util.AppPreferences
import de.idnow.sdk.util.IDnowErrorCode
import de.idnow.sdk.util.Util_Strings
import de.idnow.sdk.util.Util_Util
import de.idnow.sdk.util.Util_UtilUI

internal class AppPermissionsManager(
    private val activity: AppCompatActivity
) {
    private lateinit var requestPermissionLauncher: ActivityResultLauncher<String>
    private var onSuccessCallback: (() -> Unit)? = null
    private var checkPermissionsOnResume = false
    private val appPreferences: AppPreferences by lazy { AppPreferences(activity) }

    private val pendingPermissions: ArrayDeque<String> = ArrayDeque()
    private var currentPermission: String? = null

    fun init() {
        requestPermissionLauncher = activity.registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            handleSinglePermissionResult(granted)
        }
    }

    fun checkPermissionsGranted(): Boolean =
        findNotGrantedPermissions().isEmpty()

    fun request(onSuccess: () -> Unit) {
        onSuccessCallback = onSuccess

        val necessaryPermissions = findNotGrantedPermissions()
        if (necessaryPermissions.isEmpty()) {
            onPermissionsGranted()
            return
        }
        showRequestPermissionsDialog(necessaryPermissions)
    }

    fun onResume() {
        if (checkPermissionsOnResume) {
            checkPermissionsOnResume = false
            if (checkPermissionsGranted()) {
                onPermissionsGranted()
            } else {
                showPermissionsNotGrantedDialog(findNotGrantedPermissions().first())
            }
        }
    }

    private fun onPermissionsGranted() {
        onSuccessCallback?.invoke()
        onSuccessCallback = null
        pendingPermissions.clear()
        currentPermission = null
    }

    private fun findNotGrantedPermissions(): List<String> {
        return provideNecessaryPermissions()
            .filter { activity.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    private fun shouldShowRequestPermissionRationale(permissions: List<String>): Boolean =
        permissions.any { activity.shouldShowRequestPermissionRationale(it) }

    private fun provideNecessaryPermissions(): List<String> {
        return mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        ).apply {
            if (Build.VERSION.SDK_INT >= 31)
                add(Manifest.permission.BLUETOOTH_CONNECT)
        }
    }

    private fun providePermissionRequestDescription(permission: String): String {
        return when (permission) {
            Manifest.permission.CAMERA ->
                Util_Strings.getStringWithDefault(
                    activity,
                    Util_Strings.KEY_VIDEO_IDENT_PER_CAMERA,
                    Util_Strings.LOCAL_KEY_VIDEO_IDENT_PER_CAMERA
                )

            Manifest.permission.RECORD_AUDIO ->
                Util_Strings.getStringWithDefault(
                    activity,
                    Util_Strings.KEY_VIDEO_IDENT_PER_AUDIO,
                    Util_Strings.LOCAL_KEY_VIDEO_IDENT_PER_AUDIO
                )

            Manifest.permission.BLUETOOTH_CONNECT -> "Bluetooth"

            else -> throw IllegalArgumentException("Invalid permission")
        }
    }

    private fun showPermissionsNotGrantedDialog(permissionNotGranted: String?) {
        Util_UtilUI.showMessageOK(
            activity,
            Util_Strings.getStringWithDefault(
                Util_Strings.KEY_VIDEO_IDENT_PER_FAILED_BREAK,
                Util_Strings.LOCAL_KEY_VIDEO_IDENT_PER_FAILED_BREAK
            )
        ) { _, _ ->
            val cancelIntent = Intent()
            cancelIntent.putExtra(
                IDnowSDK.RESULT_DATA_ERROR,
                IDnowSDK.getInstance().appContext.getString(IDnowSDK.MESSAGE_USER_CANCELED)
            )
            cancelIntent.putExtra(
                IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN,
                IDnowSDK.getTransactionToken()
            )
            getResultErrorCodeForPermission(permissionNotGranted)?.let {
                cancelIntent.putExtra(IDnowSDK.RESULT_ERROR_CODE, it)
            }
            IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_CANCEL, cancelIntent)
            Util_Util.clearApplicationData(activity.applicationContext)
            activity.setResult(IDnowSDK.RESULT_CODE_CANCEL, cancelIntent)
            activity.finish()
        }
    }

    private fun getResultErrorCodeForPermission(permissionNotGranted: String?): IDnowErrorCode? {
        return when (permissionNotGranted) {
            Manifest.permission.CAMERA -> IDnowErrorCode.IDnowErrorCameraAccessNotGranted
            Manifest.permission.RECORD_AUDIO -> IDnowErrorCode.IDnowErrorMicrophoneAccessNotGranted
            else -> null
        }
    }

    private fun showRequestPermissionsDialog(permissions: List<String>) {
        val message = provideRequestPermissionsDialogMessage(permissions)
        val action = provideRequestPermissionsDialogConfirmAction(permissions)
        Util_UtilUI.showMessageOKCancel(activity, message) { _, _ ->
            action()
        }
    }

    private fun provideRequestPermissionsDialogMessage(permissions: List<String>): String {
        return StringBuilder()
            .append(
                Util_Strings.getStringWithDefault(
                    activity,
                    Util_Strings.KEY_VIDEO_IDENT_PER_VIDEO,
                    Util_Strings.LOCAL_KEY_VIDEO_IDENT_PER_VIDEO
                )
            ).apply {
                permissions.forEachIndexed { idx, perm ->
                    append(providePermissionRequestDescription(perm))
                    if (idx < permissions.lastIndex)
                        appendLine()
                }
            }.append(
                Util_Strings.getStringWithDefault(
                    activity,
                    Util_Strings.KEY_VIDEO_IDENT_PER_INTRO_END,
                    Util_Strings.LOCAL_KEY_VIDEO_IDENT_PER_INTRO_END
                )
            ).toString()
    }

    private fun provideRequestPermissionsDialogConfirmAction(permissions: List<String>): () -> Unit {
        resolvePermissionStatus(permissions)
        val permStatus = appPreferences.getPermissionStatus()

        return if (permStatus in listOf(
                PermissionStatus.DENIED_CAN_ASK_AGAIN,
                PermissionStatus.UNKNOWN
            )
        ) {
            {
                pendingPermissions.clear()
                pendingPermissions.addAll(permissions)
                requestNextPermission()
            }
        } else {
            {
                checkPermissionsOnResume = true
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val uri = Uri.fromParts("package", activity.application.packageName, null)
                intent.setData(uri)
                activity.startActivity(intent)
            }
        }
    }

    private fun resolvePermissionStatus(permissions: List<String>) {
        val rationaleRequested = shouldShowRequestPermissionRationale(permissions)
        if (rationaleRequested)
            appPreferences.setPermissionStatus(PermissionStatus.DENIED_CAN_ASK_AGAIN)
    }

    private fun requestNextPermission() {
        if (pendingPermissions.isEmpty()) {
            onPermissionsGranted()
            return
        }
        currentPermission = pendingPermissions.removeFirst()
        requestPermissionLauncher.launch(currentPermission!!)
    }

    private fun handleSinglePermissionResult(granted: Boolean) {
        if (granted) {
            requestNextPermission()
        } else {
            val canAskAgain =
                currentPermission?.let { activity.shouldShowRequestPermissionRationale(it) }
                    ?: false
            val status = appPreferences.getPermissionStatus()
            val nextStatus = when {
                !canAskAgain -> PermissionStatus.DENIED_PERMANENTLY
                status == PermissionStatus.UNKNOWN -> PermissionStatus.DENIED_CAN_ASK_AGAIN
                status == PermissionStatus.GRANTED -> PermissionStatus.DENIED_CAN_ASK_AGAIN
                status == PermissionStatus.DENIED_CAN_ASK_AGAIN -> PermissionStatus.DENIED_PERMANENTLY
                else -> status
            }
            appPreferences.setPermissionStatus(nextStatus)
            showPermissionsNotGrantedDialog(currentPermission)
            pendingPermissions.clear()
            currentPermission = null
        }
    }
}