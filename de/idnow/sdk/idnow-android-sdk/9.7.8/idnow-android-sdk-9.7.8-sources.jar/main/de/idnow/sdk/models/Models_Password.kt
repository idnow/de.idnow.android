package de.idnow.sdk.models;

import com.google.gson.annotations.SerializedName
import de.idnow.sdk.util.Util_Strings

data class Models_Password(
    @SerializedName(Util_Strings.LOGIN_PASSWORD)
    val password: String,
    @SerializedName(Util_Strings.LOGIN_PASSWORD_CONFIRMED_PASSWORD)
    val confirmedPassword: String
)
