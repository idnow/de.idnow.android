package de.idnow.sdk.Activities.callbacks;

import de.idnow.sdk.util.Util_PhotoDataHolder;

public interface ClassificationCallback {
    void onDismissProgress();
    void onShowBottomSheet();
    void onShowDocumentClassification();

    void onUpdateErrorScreen(boolean captureId);

    void onSendDocumentSuccess();

    void onSendUploadPhotoSuccess(Util_PhotoDataHolder.DocumentImages imageType);
}
