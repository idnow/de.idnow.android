package de.idnow.sdk.network;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;

import de.idnow.sdk.CertificateProvider;
import de.idnow.sdk.Config;

/**
 * This class is used to create the private key and certificate from the byte stream contained in
 * the certificate provided by the customer app.
 */
public class IDNowDefaultSSLCredentialProvider {
    public PrivateKey provideClientAuthPrivateKey()
            throws NoSuchAlgorithmException, InvalidKeySpecException {
        CertificateProvider certificateProvider = Config.CERTIFICATE_PROVIDER;
        if (certificateProvider == null || !certificateProvider.featureCertificate()) {
            return null;
        }

        byte[] privateKeyAsBytes = certificateProvider.providePrivateKeyBytestream();
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKeyAsBytes);

        return keyFactory.generatePrivate(keySpec);
    }

    public X509Certificate[] provideClientAuthCertificateChain() throws CertificateException, IOException {
        CertificateProvider certificateProvider = Config.CERTIFICATE_PROVIDER;
        if (certificateProvider == null || !certificateProvider.featureCertificate()) {
            return null;
        }

        CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
        Certificate certificateChain;
        try (InputStream stream = new ByteArrayInputStream(certificateProvider.provideCertificateBytestream())) {
            certificateChain = certificateFactory.generateCertificate(stream);
        }

        return new X509Certificate[]{(X509Certificate) certificateChain};
    }
}
