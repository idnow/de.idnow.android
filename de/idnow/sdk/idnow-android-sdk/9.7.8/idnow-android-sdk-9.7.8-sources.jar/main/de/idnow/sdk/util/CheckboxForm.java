package de.idnow.sdk.util;

import de.idnow.sdk.R;

public enum CheckboxForm {

    OVAL(R.drawable.oval_icon_checked, R.drawable.oval_icon), SQUARE(R.drawable.square_icon_checked, R.drawable.square_icon);

    CheckboxForm(int checked, int unchecked){
        this.unchecked = unchecked;
        this.checked = checked;
    }
    private final int checked;
    private final int unchecked;

    public int checked() {
        return checked;
    }

    public int unchecked() {
        return unchecked;
    }
}
