package de.idnow.sdk.models

data class Model_ConferenceCallQualityMetrics(
    val callQuality: CallQualityMetrics = CallQualityMetrics()
)

data class CallQualityMetrics(
    val user: CallUserQualityMetrics = CallUserQualityMetrics()
)

data class CallUserQualityMetrics(
    val video: CallStreamQuality = CallStreamQuality(),
    val audio: CallStreamQuality = CallStreamQuality()
)

data class CallStreamQuality(
    val quality: Int = 0
)