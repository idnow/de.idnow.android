package de.idnow.sdk.Adapters;

import android.content.Context;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

import de.idnow.sdk.R;
import de.idnow.sdk.models.Models_ChatMessage;

/**
 * Created by Mathias Grasy on 23.09.2016.
 */

public class Adapter_TextChat extends BaseAdapter
{

	Context                       context;
	ArrayList<Models_ChatMessage> chatMessages;

	Drawable backgroundSelf, backgroundAgent;

	public Adapter_TextChat( Context context, ArrayList<Models_ChatMessage> chatMessages )
	{
		this.context = context;
		this.chatMessages = chatMessages;

		backgroundSelf = context.getResources().getDrawable( R.drawable.chat_bubble_self );
		backgroundSelf.mutate().setColorFilter( context.getResources().getColor( R.color.primary ), Mode.SRC_IN );

		backgroundAgent = context.getResources().getDrawable( R.drawable.chat_bubble_agent );
		backgroundAgent.mutate().setColorFilter( context.getResources().getColor( R.color.chat_message_agent_background ), Mode.SRC_IN );

	}

	@Override
	public int getCount()
	{
		return chatMessages.size();
	}

	@Override
	public Object getItem( int position )
	{
		return chatMessages.get( position );
	}

	@Override
	public int getItemViewType( int position )
	{
		if ( chatMessages.get( position ).getOriginator().toLowerCase().equals( "user" ) )
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}

	@Override
	public int getViewTypeCount()
	{
		return 2;
	}

	@Override
	public long getItemId( int position )
	{
		return position;
	}

	@Override
	public View getView( int position, View convertView, ViewGroup parent )
	{
		View v;

		if ( getItemViewType( position ) == 1 )
		{

			v = LayoutInflater.from( context ).inflate( R.layout.view_chat_agent_text_message, null, false );
			TextView messageTextView = v.findViewById( R.id.messageText );
			TextView timeTextView = v.findViewById( R.id.timeText );
			RelativeLayout background = v.findViewById( R.id.bubble );

			messageTextView.setText( chatMessages.get( position ).getText() );
			timeTextView.setText( chatMessages.get( position ).getName() + " " + context.getText( R.string.idnow_chat_sender_agent_at ) + " " + chatMessages.get( position ).getDate() );
			background.setBackground( backgroundAgent );

			return v;
		}

		else
		{
			v = LayoutInflater.from( context ).inflate( R.layout.view_chat_self_text_message, null, false );
			TextView messageTextView = v.findViewById( R.id.messageText );
			TextView timeTextView = v.findViewById( R.id.timeText );
			RelativeLayout background = v.findViewById( R.id.bubble );

			messageTextView.setText( chatMessages.get( position ).getText() );
			timeTextView.setText( chatMessages.get( position ).getName() + " " + chatMessages.get( position ).getDate() );
			background.setBackground( backgroundSelf );

			return v;
		}
	}

}
