package de.idnow.sdk.models;

public class Models_WaitingListNotification
{
	final String channel;
	final boolean enabled;

	public Models_WaitingListNotification(String channel, boolean enabled)
	{
		super();
		this.channel = channel;
		this.enabled = enabled;
	}

	public String getChannel() {
		return channel;
	}

	public boolean isEnabled() {
		return enabled;
	}
}
