package de.idnow.sdk.util;

import android.os.Binder;

import java.lang.ref.WeakReference;

public class IDnowForegroundBinder extends Binder {

    private WeakReference<IDnowForegroundService> weakService;

    /**
     * Inject service instance to weak reference.
     */
    public void onBind(IDnowForegroundService service) {
        this.weakService = new WeakReference<>(service);
    }

    public IDnowForegroundService getService() {
        return weakService == null ? null : weakService.get();
    }

}