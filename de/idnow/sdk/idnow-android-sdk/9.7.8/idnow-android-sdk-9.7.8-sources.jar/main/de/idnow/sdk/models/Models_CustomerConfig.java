package de.idnow.sdk.models;

/**
 * Created by lars.mehrtens on 23.01.18.
 */

public class Models_CustomerConfig {
}
