package de.idnow.sdk.models;

import java.util.Date;



/**
 * 
 * @date 10.10.2014
 * @author Mathias Grasy
 * @version 1.0
 * @brief currently not in use
 */


public class Models_Message
{
	private String	message;
	private String	author;
	private long	time;

	public Models_Message()
	{
		this( "", "" );
	}

	public Models_Message( String author, String message )
	{
		this.author = author;
		this.message = message;
		this.time = new Date().getTime();
	}

	public String getMessage()
	{
		return message;
	}

	public String getAuthor()
	{
		return author;
	}

	public void setAuthor( String author )
	{
		this.author = author;
	}

	public void setMessage( String message )
	{
		this.message = message;
	}

	public long getTime()
	{
		return time;
	}

	public void setTime( long time )
	{
		this.time = time;
	}
}
