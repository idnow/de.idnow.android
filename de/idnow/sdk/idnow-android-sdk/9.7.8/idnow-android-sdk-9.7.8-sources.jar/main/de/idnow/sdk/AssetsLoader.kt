package de.idnow.sdk

import de.idnow.sdk.messages.AnimationsCollectionProvider
import de.idnow.sdk.messages.MessagesProvider

internal object AssetsLoader {
    fun loadMessagesAsync(forceFromBackend: Boolean) {
        if (forceFromBackend) {
            resetMessages()
        }
        if (Config.MESSAGES == null)
            MessagesProvider.fetchAsync(::updateMessages)
    }

    suspend fun loadMessages(forceFromBackend: Boolean) {
        if (forceFromBackend) {
            resetMessages()
        }
        if (Config.MESSAGES == null)
            MessagesProvider.fetch(::updateMessages)
    }

    suspend fun loadLottieAnimations() {
        if (Config.REMOTE_ANIMATIONS == null)
            AnimationsCollectionProvider.fetch {
                Config.REMOTE_ANIMATIONS = it
            }
    }

    private fun resetMessages() {
        MessagesProvider.reset()
        Config.MESSAGES = null
    }

    private fun updateMessages(data: Map<String, String>) {
        Config.MESSAGES = data
    }
}