package de.idnow.sdk.models;

public class Model_UserCancellation {

    public String [] reasons;
    public boolean enabled ;

    public Model_UserCancellation(String[] reasons, boolean enabled) {
        this.reasons = reasons;
        this.enabled = enabled;
    }

    public Model_UserCancellation() {
    }

    public String[] getReasons() {
        return reasons;
    }

    public void setReasons(String[] reasons) {
        this.reasons = reasons;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

}
