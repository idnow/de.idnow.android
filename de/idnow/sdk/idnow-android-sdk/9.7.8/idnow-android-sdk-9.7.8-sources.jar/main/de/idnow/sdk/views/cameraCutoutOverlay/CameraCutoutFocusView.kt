package de.idnow.sdk.views.cameraCutoutOverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Build
import android.util.AttributeSet
import android.view.View
import androidx.core.view.updateLayoutParams

internal class CameraCutoutFocusView : View {
    private var overlayType: CameraCutoutOverlayType = CameraCutoutOverlayType.Document
    private var clipOutPath: Path = Path()

    constructor(context: Context?) : super(context)

    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs)

    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    constructor(
        context: Context?,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(context, attrs, defStyleAttr, defStyleRes)

    fun setOverlayType(type: CameraCutoutOverlayType) {
        if (type == overlayType)
            return

        overlayType = type
        invalidate()
    }

    fun setCutoutRect(
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
        radius: Float
    ) {
        clipOutPath = Path().apply {
            if (overlayType == CameraCutoutOverlayType.Document) {
                addRoundRect(
                    left,
                    top,
                    right,
                    bottom,
                    radius,
                    radius,
                    Path.Direction.CW
                )
            } else {
                addOval(
                    left,
                    top,
                    right,
                    bottom,
                    Path.Direction.CW
                )
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawOverlay()
    }

    private val paint = Paint().apply {
        color = Color.parseColor("#777777")
        setAlpha(0.651F)
    }

    private fun Canvas.drawOverlay() {
        updateLayoutParams {
            width = -1
            height = -1
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            clipOutPath(clipOutPath)
        } else {
            clipPath(clipOutPath)
        }

        drawRect(
            0F,
            0f,
            width.toFloat(),
            height.toFloat(),
            paint
        )
    }
}