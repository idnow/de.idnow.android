package de.idnow.sdk.Activities;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import de.idnow.sdk.R;

public class IDnowFragmentManager {

 /*   public static void hideFragment(Activities_TakePhotoActivity activity, Class<? extends Fragment> fragmentClass) {
        String fragmentTAG = fragmentClass.getSimpleName();

        FragmentManager fragmentManager = activity.getSupportFragmentManager();

        Fragment fragment = fragmentManager.findFragmentByTag(fragmentTAG);

        if (fragment != null) {
            fragmentManager.beginTransaction().remove(fragment).commitAllowingStateLoss();
        }

    }

    public static void showFragment(Activities_TakePhotoActivity activity, Class<? extends Fragment> fragmentClass) {
        showFragment(activity, fragmentClass, null);
    }

    public static void showFragment(Activities_TakePhotoActivity activity, Class<? extends Fragment> fragmentClass, Bundle args) {
        showFragment(activity, fragmentClass, args, true, 0, 0);
    }

    public static void showFragment(Activities_TakePhotoActivity activity, Class<? extends Fragment> fragmentClass, Bundle args, boolean canBack, int enterAnimation, int exitAnimation) {
        showFragment(activity, R.id.listFragment, fragmentClass, args, canBack, enterAnimation, exitAnimation);
    }

    public static void showFragment(Activities_TakePhotoActivity activity, int rootView, Class<? extends Fragment> fragmentClass, Bundle args, boolean canBack, int enterAnimation, int exitAnimation) {
        FragmentManager fragmentManager = activity.getSupportFragmentManager();
        FragmentTransaction ft = fragmentManager.beginTransaction();

        String fragmentTAG = fragmentClass.getSimpleName();

        Fragment fragment = fragmentManager.findFragmentByTag(fragmentTAG);
        if (fragment == null) {

            if (enterAnimation > 0 && exitAnimation > 0) {
                ft.setCustomAnimations(enterAnimation, exitAnimation);
            }

            try {
                fragment = fragmentClass.newInstance();
                if (args != null) {
                    fragment.setArguments(args);
                }

                if (canBack) {
                    ft.add(rootView, fragment, fragmentTAG)
                            .addToBackStack(fragmentTAG).commitAllowingStateLoss();
                } else {
                    ft.replace(rootView, fragment, fragmentTAG)
                            .addToBackStack("fragment")
                            .commitAllowingStateLoss();
                }
            } catch (Throwable e) {
                throw new RuntimeException((e));
            }
        } else {

            if (args != null) {
                if (fragment.getArguments() != null) {
                    fragment.getArguments().clear();
                    fragment.getArguments().putAll(args);
                }
            } else if (fragment.getArguments() != null) {
                fragment.getArguments().clear();
            }

            if (canBack) {
                //when remove, we don't need animation
                ft.remove(fragment).setTransition(FragmentTransaction.TRANSIT_NONE).commitNowAllowingStateLoss();

                if (enterAnimation > 0 && exitAnimation > 0) {
                    ft.setCustomAnimations(enterAnimation, exitAnimation);
                }

                ft.add(rootView, fragment, fragmentTAG)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .commitAllowingStateLoss();
            } else {

                if (enterAnimation > 0 && exitAnimation > 0) {
                    ft.setCustomAnimations(enterAnimation, exitAnimation);
                }

                ft.replace(rootView, fragment, fragmentTAG)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .addToBackStack("fragment")
                        .commitAllowingStateLoss();
            }
        }
    }

    public static <T extends Fragment> T findFragment(Activities_TakePhotoActivity activity, Class<? extends Fragment> fragmentClass) {
        FragmentManager fragmentManager = activity.getSupportFragmentManager();

        String fragmentTAG = fragmentClass.getSimpleName();

        return (T) fragmentManager.findFragmentByTag(fragmentTAG);
    }

    public static void clearFragment(Activities_TakePhotoActivity activity,Class<? extends Fragment> fragmentClass) {

        String fragmentTAG = fragmentClass.getSimpleName();

        FragmentManager fragmentManager = activity.getSupportFragmentManager();

        fragmentManager.popBackStack(fragmentTAG, FragmentManager.POP_BACK_STACK_INCLUSIVE);


    }


  */


    public static void hideFragment(Activities_VideoLiveStreamActivity_Super activity, Class<? extends Fragment> fragmentClass) {
        String fragmentTAG = fragmentClass.getSimpleName();

        FragmentManager fragmentManager = activity.getSupportFragmentManager();

        Fragment fragment = fragmentManager.findFragmentByTag(fragmentTAG);

        if (fragment != null) {
            fragmentManager.beginTransaction().remove(fragment).commitAllowingStateLoss();
        }

    }

    public static void showFragment(Activities_VideoLiveStreamActivity_Super activity, Class<? extends Fragment> fragmentClass) {
        showFragment(activity, fragmentClass, null);
    }

    public static void showFragment(Activities_VideoLiveStreamActivity_Super activity, Class<? extends Fragment> fragmentClass, Bundle args) {
        showFragment(activity, fragmentClass, args, true, 0, 0);
    }

    public static void showFragment(Activities_VideoLiveStreamActivity_Super activity, Class<? extends Fragment> fragmentClass, Bundle args, boolean canBack, int enterAnimation, int exitAnimation) {
        showFragment(activity, R.id.listFragment, fragmentClass, args, canBack, enterAnimation, exitAnimation);
    }

    public static void showFragment(Activities_VideoLiveStreamActivity_Super activity, int rootView, Class<? extends Fragment> fragmentClass, Bundle args, boolean canBack, int enterAnimation, int exitAnimation) {
        FragmentManager fragmentManager = activity.getSupportFragmentManager();
        FragmentTransaction ft = fragmentManager.beginTransaction();

        String fragmentTAG = fragmentClass.getSimpleName();

        Fragment fragment = fragmentManager.findFragmentByTag(fragmentTAG);
        if (fragment == null) {

            if (enterAnimation > 0 && exitAnimation > 0) {
                ft.setCustomAnimations(enterAnimation, exitAnimation);
            }

            try {
                fragment = fragmentClass.newInstance();
                if (args != null) {
                    fragment.setArguments(args);
                }

                if (canBack) {
                    ft.add(rootView, fragment, fragmentTAG)
                            .addToBackStack(fragmentTAG).commitAllowingStateLoss();
                } else {
                    ft.replace(rootView, fragment, fragmentTAG)
                            .addToBackStack("fragment")
                            .commitAllowingStateLoss();
                }
            } catch (Throwable e) {
                throw new RuntimeException((e));
            }
        } else {

            if (args != null) {
                if (fragment.getArguments() != null) {
                    fragment.getArguments().clear();
                    fragment.getArguments().putAll(args);
                }
            } else if (fragment.getArguments() != null) {
                fragment.getArguments().clear();
            }

            if (canBack) {
                //when remove, we don't need animation
                ft.remove(fragment).setTransition(FragmentTransaction.TRANSIT_NONE).commitNowAllowingStateLoss();

                if (enterAnimation > 0 && exitAnimation > 0) {
                    ft.setCustomAnimations(enterAnimation, exitAnimation);
                }

                ft.add(rootView, fragment, fragmentTAG)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .commitAllowingStateLoss();
            } else {

                if (enterAnimation > 0 && exitAnimation > 0) {
                    ft.setCustomAnimations(enterAnimation, exitAnimation);
                }

                ft.replace(rootView, fragment, fragmentTAG)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .addToBackStack("fragment")
                        .commitAllowingStateLoss();
            }
        }
    }
}
