package de.idnow.sdk.Adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import de.idnow.sdk.util.Enum_WaitScreens;
import de.idnow.sdk.Fragment_WaitScreenItem;

public class Adapter_WaitScreenViewPager extends FragmentStatePagerAdapter {

    public Adapter_WaitScreenViewPager(FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return Fragment_WaitScreenItem.newInstance(position);
    }

    @Override
    public int getCount() {
        return Enum_WaitScreens.values().length;
    }
}
