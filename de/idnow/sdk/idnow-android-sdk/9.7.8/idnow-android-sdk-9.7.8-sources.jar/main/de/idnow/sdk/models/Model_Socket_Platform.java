package de.idnow.sdk.models;

public class Model_Socket_Platform {
    int socketReconnectInterval;
    int socketReconnectAttempts;
    boolean enabled;

    public Model_Socket_Platform(int socketReconnectInterval, int socketReconnectAttempts, boolean enabled) {
        this.socketReconnectInterval = socketReconnectInterval;
        this.socketReconnectAttempts = socketReconnectAttempts;
        this.enabled = enabled;
    }

    public int getSocketReconnectInterval() {
        return socketReconnectInterval;
    }

    public void setSocketReconnectInterval(int socketReconnectInterval) {
        this.socketReconnectInterval = socketReconnectInterval;
    }

    public int getSocketReconnectAttempts() {
        return socketReconnectAttempts;
    }

    public void setSocketReconnectAttempts(int socketReconnectAttempts) {
        this.socketReconnectAttempts = socketReconnectAttempts;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
