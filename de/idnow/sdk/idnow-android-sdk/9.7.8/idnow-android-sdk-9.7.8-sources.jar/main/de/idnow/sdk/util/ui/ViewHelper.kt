package de.idnow.sdk.util.ui

import android.annotation.SuppressLint
import android.content.Context
import android.view.View
import android.view.ViewGroup
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.marginBottom
import androidx.core.view.marginLeft
import androidx.core.view.marginRight
import androidx.core.view.marginTop
import androidx.core.view.updateLayoutParams
import de.idnow.sdk.util.Util_Log

@Suppress("Unused")
object ViewHelper {
    private const val LOG_TAG = "IDNOW_ViewHelper"

    fun applySafeMargins(view: View) = adjust(
        view = view,
        typeMask = WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout(),
        useMargins = true
    )

    fun applySafeTopMargins(view: View) = adjust(
        view = view,
        typeMask = WindowInsetsCompat.Type.statusBars()
                or WindowInsetsCompat.Type.displayCutout(),
        useMargins = true
    )

    fun applySafeBotMargins(view: View) = adjust(
        view = view,
        typeMask = WindowInsetsCompat.Type.navigationBars(),
        useMargins = true
    )

    fun applySafePadding(view: View) = adjust(
        view = view,
        typeMask = WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout(),
        useMargins = false
    )

    fun applySafeTopPadding(view: View) = adjust(
        view = view,
        typeMask = WindowInsetsCompat.Type.statusBars()
                or WindowInsetsCompat.Type.displayCutout(),
        useMargins = false
    )

    fun applySafeBotPadding(view: View) = adjust(
        view = view,
        typeMask = WindowInsetsCompat.Type.navigationBars(),
        useMargins = false
    )

    private fun adjust(
        view: View,
        @WindowInsetsCompat.Type.InsetsType typeMask: Int,
        useMargins: Boolean
    ) {
        val orgLeft = if (useMargins) view.marginLeft else view.paddingLeft
        val orgRight = if (useMargins) view.marginRight else view.paddingRight
        val orgTop = if (useMargins) view.marginTop else view.paddingTop
        val orgBottom = if (useMargins) view.marginBottom else view.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            val bars = insets.getInsets(typeMask)
            val updLeft = orgLeft + bars.left
            val updRight = orgRight + bars.right
            val updTop = orgTop + bars.top
            val barsBottom = bars.bottom.takeIf { it != 0 } ?: view.context.getNavigationBarDefaultHeight()
            val updBottom = orgBottom + barsBottom
            Util_Log.d(
                LOG_TAG,
                "Insets: top=${bars.top} bottom=${barsBottom} left=${bars.left} right=${bars.right}"
            )
            if (useMargins) {
                v.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                    leftMargin = updLeft
                    topMargin = updTop
                    rightMargin = updRight
                    bottomMargin = updBottom
                }
            } else {
                v.setPadding(updLeft, updTop, updRight, updBottom)
            }
            insets
        }
    }

    @SuppressLint("InternalInsetResource", "DiscouragedApi")
    private fun Context.getNavigationBarDefaultHeight(): Int {
        val resId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId) else 0
    }
}