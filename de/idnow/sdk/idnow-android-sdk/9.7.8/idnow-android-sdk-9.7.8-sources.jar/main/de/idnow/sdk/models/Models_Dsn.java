package de.idnow.sdk.models;

public class Models_Dsn {

    String android;

    public Models_Dsn() {
    }

    public String getAndroid() {
        return android;
    }
}
