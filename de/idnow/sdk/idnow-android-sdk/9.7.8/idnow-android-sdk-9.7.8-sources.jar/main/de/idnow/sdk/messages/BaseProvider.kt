package de.idnow.sdk.messages

import de.idnow.sdk.Config
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.network.IDnowRestClient
import de.idnow.sdk.network.Network_RESTCallsKt

internal abstract class BaseProvider {
    protected fun provideRestApiService(): Network_RESTCallsKt {
        val endpoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken())
        return IDnowRestClient.getRestClient().getCallsForEndpointKt(
            endpoint,
            IDnowSDK.getInstance().appContext
        )
    }
}