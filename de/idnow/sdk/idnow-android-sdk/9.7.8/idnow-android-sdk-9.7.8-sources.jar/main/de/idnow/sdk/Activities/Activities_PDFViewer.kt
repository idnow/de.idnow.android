package de.idnow.sdk.Activities

import android.os.Build
import android.os.Bundle
import de.idnow.sdk.Config
import de.idnow.sdk.R
import de.idnow.sdk.util.Util_CustomWebView

class Activities_PDFViewer : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pdf_viewer)
        with(findViewById<Util_CustomWebView>(R.id.pdfView)) {
            clearHistory()
            getSettings().apply {
                loadsImagesAutomatically = true
                javaScriptEnabled = true
                allowFileAccess = true
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true
                builtInZoomControls = true
                displayZoomControls = false
                setSupportZoom(true)
            }
            val htmlFile = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                "file:///android_asset/pdfviewer.html?"
            } else {
                "file:///android_asset/pdfviewer_legacy.html?"
            }
            clearHistory()
            loadUrl("$htmlFile${Config.URL_DOCUMENT_NAMIRIAL}")
        }
    }
}