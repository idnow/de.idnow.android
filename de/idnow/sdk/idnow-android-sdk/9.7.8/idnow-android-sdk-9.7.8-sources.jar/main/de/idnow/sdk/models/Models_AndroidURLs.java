/**
 * @date 08.12.2014
 * @author Mathias Grasy
 * @brief (short description)
 * <p/>
 * description long
 */

package de.idnow.sdk.models;


/**
 * @author Mathias Grasy
 * @date 08.12.2014
 * @brief (short description)
 */


public class Models_AndroidURLs
{

	String successURL;
	String failureURL;
	String successMessage;
	String failureMessage;
	String fallbackURL;
	String terms;

	/**
	 * @param successURL
	 * @param failureURL
	 * @param fallbackURL
	 */
	public Models_AndroidURLs( String successURL, String failureURL, String fallbackURL, String successMessage, String terms, String failureMessage )
	{
		super();
		this.successURL = successURL;
		this.failureURL = failureURL;
		this.fallbackURL = fallbackURL;
		this.successMessage = successMessage;
		this.failureMessage = failureMessage;
		this.terms = terms;
	}

	public String getTerms()
	{
		return terms;
	}

	public void setTerms( String terms )
	{
		this.terms = terms;
	}

	/**
	 * @return the successMessage
	 */
	public String getSuccessMessage()
	{
		return successMessage;
	}

	/**
	 * @param successMessage the successMessage to set
	 */
	public void setSuccessMessage( String successMessage )
	{
		this.successMessage = successMessage;
	}

	/**
	 * @return the successURL
	 */
	public String getSuccessURL()
	{
		return successURL;
	}

	/**
	 * @param successURL the successURL to set
	 */
	public void setSuccessURL( String successURL )
	{
		this.successURL = successURL;
	}

	/**
	 * @return the failureURL
	 */
	public String getFailureURL()
	{
		return failureURL;
	}

	/**
	 * @param failureURL the failureURL to set
	 */
	public void setFailureURL( String failureURL )
	{
		this.failureURL = failureURL;
	}

	/**
	 * @return the fallbackURL
	 */
	public String getFallbackURL()
	{
		return fallbackURL;
	}

	/**
	 * @param fallbackURL the fallbackURL to set
	 */
	public void setFallbackURL( String fallbackURL )
	{
		this.fallbackURL = fallbackURL;
	}

	public String getFailureMessage()
	{
		return failureMessage;
	}
}
