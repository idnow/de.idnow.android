package de.idnow.sdk.views.cameraCutoutOverlay

import android.animation.Animator
import android.animation.Animator.AnimatorListener
import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import androidx.core.view.isVisible
import de.idnow.sdk.R
import de.idnow.sdk.databinding.CameraOverlayCutoutBinding

class CameraCutoutOverlayView : FrameLayout {
    private lateinit var overlayType: CameraCutoutOverlayType
    private var marginTopPercent = 0F
    private var marginBottomPercent = 0F
    private var marginStartPercent = 0F
    private var marginEndPercent = 0F

    private lateinit var binding: CameraOverlayCutoutBinding

    constructor(context: Context) : super(context) {
        init(null)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(attrs)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context, attrs, defStyleAttr
    ) {
        init(attrs)
    }

    constructor(
        context: Context, attrs: AttributeSet?, defStyleAttr: Int, defStyleRes: Int
    ) : super(context, attrs, defStyleAttr, defStyleRes) {
        init(attrs)
    }

    private fun init(attrs: AttributeSet?) {
        readOverlayTypeAttr(attrs)
        readMarginsAttr(attrs)
        binding = CameraOverlayCutoutBinding.inflate(
            LayoutInflater.from(context), this, true
        )
        binding.cameraView.setOverlayType(overlayType)
        setupImage()

        binding.cameraView.invalidate()
        binding.cameraView.requestLayout()
    }

    private fun readOverlayTypeAttr(attrs: AttributeSet?) {
        val styleableAttrs = context.theme.obtainStyledAttributes(
            attrs ?: return, R.styleable.CameraCutoutOverlayView, 0, 0
        )
        try {
            val typeIdx = styleableAttrs.getInt(
                R.styleable.CameraCutoutOverlayView_pictureType, CameraCutoutOverlayType.Document.ordinal
            )
            overlayType = CameraCutoutOverlayType.entries.toTypedArray()[typeIdx]
        } finally {
            styleableAttrs.recycle()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        setupGuideLines()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        setupCameraView()
    }

    private fun setupCameraView() {
        binding.cameraView.setOverlayType(overlayType)
        var start = marginStartPercent * binding.root.measuredWidth
        var top = marginTopPercent * binding.root.measuredHeight
        var end = binding.root.measuredWidth - (binding.root.measuredWidth * marginEndPercent)
        var bottom =
            binding.root.measuredHeight - (binding.root.measuredHeight * marginBottomPercent)

        val wphr =
            binding.image.drawable.intrinsicWidth.toFloat() / binding.image.drawable.intrinsicHeight.toFloat()
        val hpwr =
            binding.image.drawable.intrinsicHeight.toFloat() / binding.image.drawable.intrinsicWidth.toFloat()

        var tmpWidth = binding.image.measuredWidth.toFloat()
        var tmpHeight = binding.image.measuredHeight.toFloat()
        var tmpWphr = tmpWidth / tmpHeight
        var tmpHpwr = tmpHeight / tmpWidth
        var iterationCount = 0
        val maxIterationCount = 100
        while ((tmpWphr != wphr) || (tmpHpwr != hpwr)) {
            iterationCount++
            if (tmpHpwr != hpwr) {
                //aflam inaltimea
                tmpHeight = minOf(hpwr * tmpWidth, binding.image.measuredHeight.toFloat())
                tmpHpwr = tmpHeight / tmpWidth
                tmpWphr = tmpWidth / tmpHeight
            }

            if (tmpWphr != wphr) {
                //aflam lungimea
                tmpWidth = minOf(wphr * tmpHeight, binding.image.measuredWidth.toFloat())
                tmpHpwr = tmpHeight / tmpWidth
                tmpWphr = tmpWidth / tmpHeight
            }


            if (iterationCount == maxIterationCount) break
        }

        val tmpHMargin = (end.toInt() - start.toInt() - tmpWidth.toInt()) / 2
        start += tmpHMargin
        end -= tmpHMargin

        val tmpVMargin = (bottom.toInt() - top.toInt() - tmpHeight.toInt()) / 2
        top += tmpVMargin
        bottom -= tmpVMargin

        //remove white margins
        start += 2.5F
        end -= 2.5F
        top += 2.5F
        bottom -= 2.5F

        binding.cameraView.setCutoutRect(start, top, end, bottom, 40F)
        binding.cameraView.invalidate()
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        setupCameraView()
    }

    private fun readMarginsAttr(attrs: AttributeSet?) {
        val styleableAttrs = context.theme.obtainStyledAttributes(
            attrs ?: return, R.styleable.CameraCutoutOverlayView, 0, 0
        )
        try {
            marginTopPercent = styleableAttrs.getFloat(
                R.styleable.CameraCutoutOverlayView_marginTopPercent, marginTopPercent
            )
            marginBottomPercent = styleableAttrs.getFloat(
                R.styleable.CameraCutoutOverlayView_marginBottomPercent, marginBottomPercent
            )
            marginStartPercent = styleableAttrs.getFloat(
                R.styleable.CameraCutoutOverlayView_marginStartPercent, marginStartPercent
            )
            marginEndPercent = styleableAttrs.getFloat(
                R.styleable.CameraCutoutOverlayView_marginEndPercent, marginEndPercent
            )
        } finally {
            styleableAttrs.recycle()
        }
    }

    fun updateMargins(
        topPercent: Float = marginTopPercent,
        bottomPercent: Float = marginBottomPercent,
        startPercent: Float = marginStartPercent,
        endPercent: Float = marginEndPercent
    ) {
        marginTopPercent = topPercent
        marginBottomPercent = bottomPercent
        marginStartPercent = startPercent
        marginEndPercent = endPercent

        setupGuideLines()
    }

    fun setType(type: CameraCutoutOverlayType) {
        overlayType = type
        setupImage()
        setupCameraView()
    }

    private fun setupGuideLines() = binding.apply {
        topGuideLine.setGuidelinePercent(marginTopPercent)
        bottomGuideLine.setGuidelinePercent(1F - marginBottomPercent)
        startGuideLine.setGuidelinePercent(marginStartPercent)
        endGuideLine.setGuidelinePercent(1F - marginEndPercent)
        middleGuideLine.setGuidelinePercent(marginTopPercent + (1F - marginBottomPercent - marginTopPercent) / 2F)
    }

    private fun setupImage() {
        binding.image.setImageResource(
            if (overlayType == CameraCutoutOverlayType.Document) R.drawable.camera_overlay_document_cutout
            else R.drawable.camera_overlay_selfie_cutout
        )
    }

    fun setAnimation(path: String, scale: Float = 1F) {
        binding.animation.apply {
            removeAllAnimatorListeners()
            cancelAnimation()
            isVisible = false
            setAnimation(path)
            scaleX = scale
            scaleY = scale
        }
    }

    fun playAnimation(
        onFinished: () -> Unit
    ) {
        binding.animation.apply {
            removeAllAnimatorListeners()
            addAnimatorListener(object : AnimatorListener {
                override fun onAnimationStart(animation: Animator) {}

                override fun onAnimationEnd(animation: Animator) {
                    binding.animation.isVisible = false
                    onFinished()
                }

                override fun onAnimationCancel(animation: Animator) {}

                override fun onAnimationRepeat(animation: Animator) {}
            })
            isVisible = true
            playAnimation()
        }
    }
}