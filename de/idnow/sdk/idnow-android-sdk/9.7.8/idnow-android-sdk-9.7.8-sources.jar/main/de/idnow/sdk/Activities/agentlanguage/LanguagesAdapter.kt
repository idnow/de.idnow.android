package de.idnow.sdk.Activities.agentlanguage

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import de.idnow.sdk.R

class LanguagesAdapter :
    ListAdapter<AgentLanguageViewModel.Language, LanguagesAdapter.LanguagesVH>(DiffCallback()) {

    private var internalLanguages = mutableListOf<AgentLanguageViewModel.Language>()

    private var listener: ((AgentLanguageViewModel.Language) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LanguagesVH {
        return LanguagesVH(
            LayoutInflater
                .from(parent.context)
                .inflate(R.layout.row_language, parent, false),
            listener
        )
    }

    override fun onBindViewHolder(holder: LanguagesVH, position: Int) {
        holder.bind(internalLanguages[position])
    }

    override fun getItemCount(): Int {
        return internalLanguages.size
    }

    fun addAll(languages: List<AgentLanguageViewModel.Language>) {
        internalLanguages.addAll(languages)
        notifyItemRangeInserted(0, languages.size)
    }

    fun removeAll() {
        val size = itemCount
        internalLanguages.clear()
        notifyItemRangeRemoved(0, size)
    }

    fun setListener(listener: ((AgentLanguageViewModel.Language) -> Unit)) {
        this.listener = listener
    }

    class LanguagesVH(
        itemView: View,
        var listener: ((AgentLanguageViewModel.Language) -> Unit)? = null
    ) : ViewHolder(itemView) {
        fun bind(item: AgentLanguageViewModel.Language) = with(itemView) {

            val countryName = findViewById<TextView>(R.id.countryName)
            countryName.text = item.name

            setOnClickListener {
                listener?.invoke(item)
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<AgentLanguageViewModel.Language>() {
        override fun areItemsTheSame(
            oldItem: AgentLanguageViewModel.Language,
            newItem: AgentLanguageViewModel.Language
        ): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(
            oldItem: AgentLanguageViewModel.Language,
            newItem: AgentLanguageViewModel.Language
        ): Boolean {
            return oldItem.name == newItem.name &&
                    oldItem.code == newItem.code
        }
    }
}