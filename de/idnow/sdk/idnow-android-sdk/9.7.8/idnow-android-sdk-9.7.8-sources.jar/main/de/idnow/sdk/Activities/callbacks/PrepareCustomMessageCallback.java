package de.idnow.sdk.Activities.callbacks;

public interface PrepareCustomMessageCallback {
    void onMessage(String message);
}
