package de.idnow.sdk.Activities.storedidentity

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import de.idnow.sdk.Activities.Activities_ResultActivity
import de.idnow.sdk.Activities.BaseActivity
import de.idnow.sdk.Activities.entry.Activities_EntryActivity
import de.idnow.sdk.Config
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.R
import de.idnow.sdk.util.Util_Strings
import de.idnow.sdk.util.Util_Strings.KEY_IDENTITY_AGREEMENTS_TITLE
import de.idnow.sdk.util.Util_Strings.KEY_IDENTITY_CONFIRM
import de.idnow.sdk.util.Util_Strings.KEY_IDENTITY_DECLINE
import de.idnow.sdk.util.Util_Strings.KEY_IDENTITY_DESCRIPTION
import de.idnow.sdk.util.Util_Strings.KEY_IDENTITY_NOTE
import de.idnow.sdk.util.Util_Strings.KEY_IDENTITY_TITLE
import de.idnow.sdk.util.Util_Strings.LOCAL_KEY_AGREEMENTS_TITLE
import de.idnow.sdk.util.Util_Strings.LOCAL_KEY_IDENTITY_CONFIRM
import de.idnow.sdk.util.Util_Strings.LOCAL_KEY_IDENTITY_DECLINE
import de.idnow.sdk.util.Util_Strings.LOCAL_KEY_IDENTITY_DESCRIPTION
import de.idnow.sdk.util.Util_Strings.LOCAL_KEY_IDENTITY_NOTE
import de.idnow.sdk.util.Util_Strings.LOCAL_KEY_IDENTITY_TITLE

class StoredIdentityActivity: BaseActivity() {

    private lateinit var viewModel: StoredIdentityViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stored_identity)
        
        viewModel = ViewModelProvider(this).get(StoredIdentityViewModel::class.java)

        viewModel.consentResult.observe(this) {
            val result = Intent(this, Activities_ResultActivity::class.java)

            if (Config.IS_IDNOW_HOST_APP) {
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }
            intent.putExtra("isConsent", true)
            when(it) {
                is ConsentResult.Success -> {
                    intent.putExtra("consent", it.stored)
                }
                else -> {
                    intent.putExtra("consent", false)
                }
            }

            IDnowSDK.getInstance().deliverResult(IDnowSDK.REQUEST_ID_NOW_SDK, intent)
            setResult(IDnowSDK.REQUEST_ID_NOW_SDK, intent)
            finish()
            startActivity(result)
        }


        val logo = findViewById<LottieAnimationView>(R.id.logo)
        val title = findViewById<TextView>(R.id.title)
        val description = findViewById<TextView>(R.id.description)
        val agreementsTitle = findViewById<TextView>(R.id.agreementsListTitle)
        val confirmButton = findViewById<Button>(R.id.confirmButton)
        val cancelButton = findViewById<Button>(R.id.quitButton)
        val explanation = findViewById<TextView>(R.id.explanation)
        val poweredBy = findViewById<LottieAnimationView>(R.id.poweredByView)
        val agreementsRV = findViewById<RecyclerView>(R.id.agreementsList)

        val agreementsAdapter = AgreementsAdapter()

        val agreementsKeys: MutableList<String> = mutableListOf()
        Config.AGREEMENTS.forEach { agreement ->
            agreementsKeys.add("js.mobile.stored.identity.$agreement")
        }
        val agreementsTexts = agreementsKeys.map {
            Util_Strings.getStringWithDefault(this, it, null)
        }
        agreementsAdapter.addAll(agreementsTexts)
        agreementsRV.adapter = agreementsAdapter
        agreementsRV.layoutManager = LinearLayoutManager(this)

        logo.isVisible = IDnowSDK.getShowIDnowLogo()
        title.text = Util_Strings.getStringWithDefault(this, KEY_IDENTITY_TITLE, LOCAL_KEY_IDENTITY_TITLE)
        description.text = Util_Strings.getStringWithDefault(this, KEY_IDENTITY_DESCRIPTION, LOCAL_KEY_IDENTITY_DESCRIPTION)
        agreementsTitle.text = Util_Strings.getStringWithDefault(this, KEY_IDENTITY_AGREEMENTS_TITLE, LOCAL_KEY_AGREEMENTS_TITLE)
        confirmButton.text = Util_Strings.getStringWithDefault(this, KEY_IDENTITY_CONFIRM, LOCAL_KEY_IDENTITY_CONFIRM)
        cancelButton.text = Util_Strings.getStringWithDefault(this, KEY_IDENTITY_DECLINE, LOCAL_KEY_IDENTITY_DECLINE)
        explanation.text = Util_Strings.getStringWithDefault(this, KEY_IDENTITY_NOTE, LOCAL_KEY_IDENTITY_NOTE)
        poweredBy.isVisible = IDnowSDK.getShowPoweredBy()

        confirmButton.setOnClickListener {
            viewModel.sendConsent(true)
        }

        cancelButton.setOnClickListener {
            viewModel.sendConsent(false)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        if (!IDnowSDK.getOverrideEntryActivity()) {
            Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity::class.java
        }
        val intent = Intent(this, Config.HOST_APP_START_ACTIVITY)
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        finish()
        if (!Config.BACK_TO_VID || IDnowSDK.getOverrideEntryActivity()) {
            startActivity(intent)
        }
        Config.BACK_TO_VID = false
    }
}