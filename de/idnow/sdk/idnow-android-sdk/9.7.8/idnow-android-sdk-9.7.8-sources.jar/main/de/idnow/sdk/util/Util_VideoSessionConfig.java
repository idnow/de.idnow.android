package de.idnow.sdk.util;

import de.idnow.sdk.Config;
import de.idnow.sdk.models.Models_StartObjectResult;

/**
 * @author Mathias Grasy
 * @version 1.0
 * @brief config for the opentok sdk or the liveswitch sdk.
 */
public class Util_VideoSessionConfig
{

	// Replace with a generated Session ID
	private static       String SESSION_ID = "";
	// Replace with a generated token (from the dashboard or using an OpenTok server SDK)
	private static       String TOKEN      = "";

	// Subscribe to a stream published by this client. Set to false to subscribe
	// to other clients' streams only.
	public static final boolean SUBSCRIBE_TO_SELF = false;

	public synchronized static void setSessionIdAndToken( Models_StartObjectResult resultObject )
	{
		Util_Log.i("","Setting session token: " + resultObject.request.getVideoSession());
		Util_Log.i("","Setting user token: " + resultObject.request.getUserVideoSessionToken());

		Util_VideoSessionConfig.SESSION_ID = resultObject.request.getVideoSession();
		Util_VideoSessionConfig.TOKEN = resultObject.request.getUserVideoSessionToken();

		String videoserver = resultObject.request != null && resultObject.request.getVideoserverUsed() != null ? resultObject.request.getVideoserverUsed() : null;

		/*if ( "DISABLED".equals( videoserver ) )*/
		Config.VIDEOSERVER_DISABLED = !"IDNOW".equals(videoserver);

	}

	public synchronized static String getSessionId() {
		return SESSION_ID;
	}

	public synchronized static String getToken() {
		return TOKEN;
	}
}
