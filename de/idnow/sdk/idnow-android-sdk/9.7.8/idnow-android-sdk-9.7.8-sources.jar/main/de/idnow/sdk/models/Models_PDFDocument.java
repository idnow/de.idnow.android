package de.idnow.sdk.models;


/**
 * @author Mathias Grasy
 * @date 16.10.2014
 * @brief (short description)
 */


public class Models_PDFDocument
{

	String                    name;

	String                    status;
	String                    version;
	String                    hash;
	String                    displayHash;
	Models_DocumentDefinition documentDefinition;

	public Models_PDFDocument( String name,String status, String version, String hash, String displayHash, Models_DocumentDefinition documentDefinition )
	{
		this.name = name;
		this.status = status;
		this.version = version;
		this.hash = hash;
		this.displayHash = displayHash;
		this.documentDefinition = documentDefinition;
	}

	public Models_DocumentDefinition getDocumentDefinition()
	{
		return documentDefinition;
	}

	public void setDocumentDefinition( Models_DocumentDefinition documentDefinition )
	{
		this.documentDefinition = documentDefinition;
	}

	public String getName()
	{
		return name;
	}

	public void setName( String name )
	{
		this.name = name;
	}

	public String getVersion()
	{
		return version;
	}

	public void setVersion( String version )
	{
		this.version = version;
	}

	public String getHash()
	{
		return hash;
	}

	public void setHash( String hash )
	{
		this.hash = hash;
	}

	public String getDisplayHash()
	{
		return displayHash;
	}

	public void setDisplayHash( String displayHash )
	{
		this.displayHash = displayHash;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
