package de.idnow.sdk.models;

public class Models_RegistrationeSign {

    String email;
    public String mobile;

    public Models_RegistrationeSign() {
    }

    public Models_RegistrationeSign(String email, String mobile) {
        this.email = email;
        this.mobile = mobile;
    }
}
