package de.idnow.sdk.network;

import android.content.Context;

import java.io.IOException;

import de.idnow.sdk.Interface_VideoLiveStream;
import de.idnow.sdk.util.LogEventTypeEnum;
import de.idnow.sdk.util.Util_Log;

import static de.idnow.sdk.util.IDnowExternalLog.logExternally;

public class Network_WebSocketService {

    public static final String LOGTAG = "IDNOW_Network_WebSocketService";

    private Network_WebSocketService() {
    }

    private static Network_WebSocketService instance;
    public static Network_WebSocketService getInstance() {
        if (instance == null) {
            instance = new Network_WebSocketService();
        }
        return instance;
    }

    private Network_OkHttpWebSocket socket = null;

    public synchronized void create(Context context, Runnable connectedCallback, Runnable errorCallback, boolean useLongPolling){

        Util_Log.i(LOGTAG, "Create");
        if (socket != null) {
            socket.close();
            socket = null;
        }

        socket = new Network_OkHttpWebSocket(context, connectedCallback, errorCallback, useLongPolling);
        if (sink != null){
            socket.setSink(sink);
        }
    }

    public Boolean isRunning(){
        if(socket != null){
            return socket.isRunning();
        }else{
            return false;
        }
    }

    private Interface_VideoLiveStream sink;

    public synchronized void setSink(Interface_VideoLiveStream sink){
        this.sink = sink;
        if (socket != null){
            socket.setSink(sink);
        }
    }

    public synchronized void removeSink(){
        this.sink = null;
        if (socket != null){
            socket.removeSink();
        }
    }

    public synchronized void run() throws RuntimeException{

        Util_Log.i(LOGTAG, "Run");
        if (socket != null) {
            try {
                socket.run();

            } catch (IOException e) {
                Util_Log.e(LOGTAG, "Start websocket failed", e);
                logExternally(socket.getContext(), "Network WebSocketService : " + e.getMessage(), LogEventTypeEnum.ERROR.get());
                throw new RuntimeException(e);
            }
        }
    }


    public synchronized void close() {

        Util_Log.i(LOGTAG, "Close");
        if (socket != null) {

            Thread thread = new Thread() {
                @Override
                public void run() {

                    if (socket != null) {
                        socket.close();
                    }
                    socket = null;
                }
            };
            thread.start();
        }

    }

}
