package de.idnow.sdk.Activities.callbacks;

import de.idnow.sdk.util.UI_SMSWaitScreen;

public interface UpdateMobileNumberCallback {
    void onSuccess(UI_SMSWaitScreen ui_smsWaitScreen);
    void onFailure();
}
