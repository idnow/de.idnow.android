package de.idnow.sdk.util;

import static de.idnow.sdk.IDnowSDK.getTransactionToken;

import android.app.Activity;
import android.content.res.Configuration;
import android.text.TextUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import de.idnow.insights.DeviceId;
import de.idnow.insights.Insights;
import de.idnow.insights.InsightsConfig;
import de.idnow.sdk.BuildConfig;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.models.Model_CustomLogData;

public class Util_CustomLogData {

    public static final String EVENT_UNKNOWN = "Unknow Event";

    public static final String EVENT_IDENT_STARTED = "Ident Started";
    public static final String EVENT_TOKEN_SCREEN_SHOWN = "Token Screen shown";
    public static final String EVENT_IDENTIFICATION_METHOD_TIME_SPENT = "Time spent - Identification method screen";

    public static final String EVENT_IDENTIFICATION_METHOD_SHOWN = "Identification method screen shown";

    public static final String EVENT_TNC_SHOWN = "TnC screen shown";

    public static final String EVENT_CQC_SCREEN_SHOWN = "CQC screen shown";

    public static final String EVENT_INSTRUCTION_SCREEN_SHOWN = "Instructions screen shown - VIP+";

    public static final String EVENT_MANUAL_DOC_CLASSIFICATION_SHOWN = "Manual Document Classification screen shown - VIP+";

    public static final String EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_SHOWN = "Waiting list screen shown";

    public static final String EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_CROSS_BTN = "Waiting list cross button clicked";

    public static final String EVENT_WAITING_LIST_PUSH_SUCCESS_SCREEN_SHOWN = "Waiting list success screen shown";

    public static final String EVENT_AGENT_CONNECTED_SCREEN_SHOWN = "Agent connected screen shown";

    public static final String EVENT_SECURITY_STEPS_SCREEN_SHOWN = "Security steps screen shown";

    public static final String EVENT_IDENTIFICATION_COMPLETE_SCREEN_SHOWN = "Identification complete screen - shown";

    public static final String EVENT_IDENTIFICATION_STATUS_SCREEN_SHOWN = "Identification status screen shown";

    public static final String EVENT_WAITING_FOR_AN_AGENT_SCREEN_SHOWN = "Waiting for an agent screen shown";

    public static final String EVENT_SECURITY_STEPS_FRONT_OF_ID_SCREEN_SHOWN = "Security steps front of ID screen shown";

    public static final String EVENT_SECURITY_STEPS_CODE_CONFIRM_BTN = "Security steps screen - Code confirm button clicked";

    public static final String EVENT_ESIGN_CONTRACT_SIGN_SCREEN_SHOWN = "eSign contract screen is shown";
    private static final String LOGTAG = "IDNOW_Util_CustomLogData";

    public static AtomicBoolean enabled = new AtomicBoolean(false);

    public static void initLog(Activity activity, Model_CustomLogData modelCustomLog) {
        if (!Config.LOG_INITIATED) {
            init(activity, modelCustomLog);
            setUser(IDnowSDK.getCompanyId(), BuildConfig.CURRENT_VERSION, IDnowSDK.getTransactionToken());
            startSession();
            // recordEvent(EVENT_IDENT_STARTED);
        }
    }

    public static void init(Activity activity, Model_CustomLogData modelCustomLog) {
        InsightsConfig insightsConfig = new InsightsConfig(activity, modelCustomLog.getAppKey(), modelCustomLog.getServerURL());
        insightsConfig.setLoggingEnabled(true);
        insightsConfig.setDeviceId(getTransactionToken());
        insightsConfig.setLoggingEnabled(IDnowSDK.isLoggingEnabled());
        insightsConfig.enableCrashReporting();
        //insightsConfig.setAutoTrackingExceptions(new Class[]{Activities_EntryActivity.class}).setTrackOrientationChanges(true).setRecordAllThreadsWithCrash().setViewTracking(true).setAutoTrackingUseShortName(true);
        //insightsConfig.enableManualSessionControl();
        insightsConfig.setUpdateSessionTimerDelay(10);

        try {
            Util_Log.i(LOGTAG, "init");
            Insights.sharedInstance().init(insightsConfig);
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Initialize insights failed", e);
        }
        Insights.sharedInstance().changeDeviceIdWithoutMerge(DeviceId.Type.DEVELOPER_SUPPLIED, IDnowSDK.getTransactionToken());
        enabled.set(true);
        Config.LOG_INITIATED = true;
    }


    public static void initLogg(Activity activity, Model_CustomLogData modelCustomLog) {
        InsightsConfig insightsConfig = new InsightsConfig(activity, modelCustomLog.getAppKey(), modelCustomLog.getServerURL());
        insightsConfig.setLoggingEnabled(true);
        insightsConfig.setDeviceId(getTransactionToken());
        insightsConfig.enableCrashReporting();

        try {
            Insights.sharedInstance().init(insightsConfig);
        } catch (Exception e) {

        }
        Insights.sharedInstance().changeDeviceIdWithoutMerge(DeviceId.Type.DEVELOPER_SUPPLIED, IDnowSDK.getTransactionToken());
        enabled.set(true);
    }


    public static void mergeWithoutChange(String identToken) {
        try {
            Insights.sharedInstance().changeDeviceIdWithoutMerge(DeviceId.Type.DEVELOPER_SUPPLIED, identToken);
        } catch (IllegalStateException e) {
            //init was not called before
        }
    }

    public static void startSession() {
        if (enabled.get()) {
            try {
                Util_Log.i(LOGTAG, "StartSession");
                Insights.sharedInstance().sessions().beginSession();
            } catch (IllegalStateException e) {
                Util_Log.e(LOGTAG, "Start session failed", e);
            }
            updateSession();
        }
    }

    public static void updateSession() {
        try {
            Util_Log.i(LOGTAG, "UpdateSession");
            Insights.sharedInstance().sessions().updateSession();
        } catch (IllegalStateException e) {
            //init was not called before
            Util_Log.e(LOGTAG, "Update session failed", e);
        }
    }

    public static void endSession() {
        if (Config.LOG_INITIATED) {
            try {
                Util_Log.i(LOGTAG, "endSession");
                Insights.sharedInstance().sessions().endSession();
            } catch (IllegalStateException e) {
                Util_Log.e(LOGTAG, "End session failed. Reason: not open", e);
            } catch (NullPointerException e) {
                Util_Log.e(LOGTAG, "End session failed. Reason: is null", e);
            }

            updateSession();
            Config.LOG_INITIATED = false;
        }
    }


    public static void setUser(String shortname, String sdkVersion, String token) {
        if (enabled.get()) {
            String osVersion = String.valueOf(android.os.Build.VERSION.SDK_INT);
            HashMap<String, String> data = new HashMap<>();
            Insights.userData.setProperty("OS_Version", osVersion);
            Insights.userData.setProperty("SDK", sdkVersion);
            Insights.userData.setProperty("Shortname", shortname);
            Insights.userData.setProperty("Token", token);
            // Insights.userData.setCustomUserData(data);
            Insights.userData.setUserData(data);
            Util_Log.i(LOGTAG, "setUser");

            Insights.userData.save();
        }
    }

    public static void disable() {
        enabled.set(false);
    }

    public static void onCreate(Activity activity) {
        if (enabled.get()) {
            Util_Log.i(LOGTAG, "onCreate");
            Insights.onCreate(activity);
        }
    }

    public static void onStart(Activity activity) {
        if (enabled.get()) {
            try {
                Util_Log.i(LOGTAG, "onStart");
                Insights.sharedInstance().onStart(activity);
            } catch (IllegalStateException e) {
                //activity has already called before once onStart
                Util_Log.e(LOGTAG, "Start failed", e);
            }
        }
    }

    public static void onStop() {
        if (enabled.get()) {
            try {
                Util_Log.i(LOGTAG, "onStop");
                Insights.sharedInstance().onStop();
            } catch (IllegalStateException e) {
                //activity has already called before once onStop
                Util_Log.e(LOGTAG, "Stop failed", e);
            }
        }
    }

    public static void startEvent(String eventName) {
        if (enabled.get()) {
            if (!TextUtils.isEmpty(eventName)) {
                Util_Log.i(LOGTAG, "startEvent");

                Insights.sharedInstance().events().startEvent(eventName);
            }
        }
    }

    public static void endEvent(String eventName) {
        if (enabled.get()) {
            if (!TextUtils.isEmpty(eventName)) {
                try {
                    Util_Log.i(LOGTAG, "endEvent");

                    Insights.sharedInstance().events().endEvent(eventName);
                } catch (IllegalStateException e) {
                    //init was not called before
                }
            }
        }
    }

    public static void recordEvent(String event) {
        if (enabled.get() && !TextUtils.isEmpty(event)) {
            try {

                Insights.sharedInstance().events().recordEvent(event);
            } catch (IllegalStateException e) {
                //init was not called before
            }
        }
    }

    public static void recordEvent(String event, int count) {
        if (enabled.get() && !TextUtils.isEmpty(event)) {
            try {
                Insights.sharedInstance().events().recordEvent(event, count);
            } catch (IllegalStateException e) {
                //init was not called before
            }
        }
    }

    public static void recordEvent(String event, String message) {
        if (enabled.get() && !TextUtils.isEmpty(event)) {
            Map<String, Object> segmentation = new HashMap<>();
            segmentation.put("message", message);
            try {

                Insights.sharedInstance().events().recordEvent(event, segmentation);
            } catch (IllegalStateException e) {
                //init was not called before
            }
        }
    }

    public static void recordEvent(String event, Map<String, Object> segmentation) {
        if (enabled.get() && !TextUtils.isEmpty(event)) {
            try {
                Util_Log.i(LOGTAG, "recordEvent");

                Insights.sharedInstance().events().recordEvent(event, segmentation);
            } catch (IllegalStateException e) {
                //init was not called before
                Util_Log.e(LOGTAG, "Record event failed", e);
            }
        }
    }

    private static void setUser(String identID) {
        HashMap<String, String> data = new HashMap<>();
        data.put("username", identID);
        Insights.userData.save();
    }

    public static void setCustomData(String OS_version, String SDK_Version, String Shortname, String Token) {
        HashMap<String, String> data = new HashMap<>();
        data.put("OS_version", OS_version);
        data.put("SDK_Version", SDK_Version);
        data.put("Shortname", Shortname);
        data.put("Token", Token);
        Insights.userData.setCustomUserData(data);
        Insights.userData.save();
    }

    public static void setEventData(String segEvent, String segEventName, String segCategory, String segType, String segEventTime) {
        String event = "Event";
        String event_name = "Event_Name";
        String category = "Category";
        String type = "Type";

        Map<String, Object> segMap = new HashMap<>();
        segMap.put(event, segEvent);
        segMap.put(event_name, segEventName);
        segMap.put(category, segCategory);
        segMap.put(type, segType);

        Util_CustomLogData.recordEvent(segEvent, segMap);
        Util_CustomLogData.startEvent(segEvent);

        Util_Log.i(LOGTAG, "setEventData: " + segEventName);

    }

    public static void onConfigurationChanged(Configuration newConfig) {
        if (enabled.get()) {
            try {
                Insights.sharedInstance().onConfigurationChanged(newConfig);
                Util_Log.i(LOGTAG, "onConfigurationChanged");

            } catch (IllegalStateException e) {
                //activity has already called before once onConfigurationChanged
            }
        }
    }

}
