package de.idnow.sdk.Activities;

import static android.view.MotionEvent.ACTION_DOWN;
import static de.idnow.sdk.util.Util_Strings.KEY_EMAIL_FORMAT;
import static de.idnow.sdk.util.Util_Strings.KEY_LABEL_PHONE_VALIDATION_CORRECTED;
import static de.idnow.sdk.util.Util_Strings.KEY_LABEL_PHONE_VALIDATION_ERROR;
import static de.idnow.sdk.util.Util_Strings.KEY_LABEL_PRIVACY_POLICY;
import static de.idnow.sdk.util.Util_Strings.KEY_LABEL_TERMS;
import static de.idnow.sdk.util.Util_Strings.KEY_LABEL_TERMS_OF_USE;
import static de.idnow.sdk.util.Util_Strings.KEY_LINK_PRIVACY_POLICY;
import static de.idnow.sdk.util.Util_Strings.KEY_LINK_TERMS_OF_USE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_COMMON_ERROR;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_AGREEMENT_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_DESC;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_INVALID;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_NO_PRESENT;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_DESC;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_PLACEHOLDER;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EXPIRTY_DATE_TODAY;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICENSE_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICNESE_DESC;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_DESC;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_NOTIF_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CONSENT;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_TERMS;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_REQUIRED_EMAIL;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_REQUIRED_FIELD;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_EMAIL_FORMAT;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_COMMON_ERROR;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_AGREEMENT_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_DESC;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_INVALID;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_NO_PRESENT;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_DESC;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_PLACEHOLDER;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EXPIRTY_DATE_TODAY;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICENSE_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICNESE_DESC;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_DESC;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CONSENT;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_TERMS;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD;
import static de.idnow.sdk.util.Util_Strings.LOCAL_LABEL_PHONE_VALIDATION_CORRECTED;
import static de.idnow.sdk.util.Util_Strings.LOCAL_LABEL_PHONE_VALIDATION_ERROR;
import static de.idnow.sdk.util.Util_Strings.LOCAL_LABEL_PRIVACY_POLICY;
import static de.idnow.sdk.util.Util_Strings.LOCAL_LABEL_TERMS;
import static de.idnow.sdk.util.Util_Strings.LOCAL_LABEL_TERMS_OF_USE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_LINK_PRIVACY_POLICY;
import static de.idnow.sdk.util.Util_Strings.LOCAL_LINK_TERMS_OF_USE;
import static de.idnow.sdk.util.Util_Util.getPhoneCountryCode;
import static de.idnow.sdk.util.Util_Util.getPhoneRegionCode;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.text.style.UnderlineSpan;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import de.idnow.sdk.Activities.callbacks.IdentificationCanceledCallback;
import de.idnow.sdk.Adapters.CustomAdapter;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Model_Countries;
import de.idnow.sdk.models.Model_Country;
import de.idnow.sdk.util.ClickableTextView;
import de.idnow.sdk.util.UI_CustomLinearLayoutOnClickListener;
import de.idnow.sdk.util.UI_CustomOnClickListener;
import de.idnow.sdk.util.Util_CustomLogData;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_Util;
import de.idnow.sdk.util.Util_UtilUI;

/**
 * @author Mathias Grasy
 * @version 1.0
 * @brief checkbox-overview about things you have to have to get through the identification process (like a valid passport and a mobile phone).
 */
public class Activities_VideoOverviewCheckActivity extends Activities_VideoOverviewCheckActivity_Super implements DatePickerDialog.OnDateSetListener, View.OnTouchListener {

	private final String LOGTAG = "IDNOW_Activities_VideoOverviewCheckActivity";

	private ImageView imageViewMobileNr, imageViewId, imageViewApproval, imageViewRecording, imageViewEmail, skipExpiryDateImageView;
	private TextView textViewApprovalHelp, textViewIdHelp, textViewTerms,step_intro_text,text_step_email;
	private LinearLayout idExplanationLinearLayout, approvalExplanationLinearLayout, recordingAgreementLinearLayout;

	private LinearLayout emailContainer;
	private LinearLayout phoneNrContainer;
	private LinearLayout phoneNrCheckBoxContainer;
	private EditText checkScreenDocumentDateText;
	private LinearLayout skipExpiryDateLayout;
	private ScrollView checkScreenScrollViewVIPlus;
	private ScrollView checkScreenScrollViewVI;

	private Intent onActivityResultIntent;

	// Video Ident Plus

	private LinearLayout emailContainer_vip;
	private LinearLayout phoneNrContainer_vip;
	private TextView checkScreenMobileNumberHeader_vip,checkScreenEMailHeader_vip,overview_title_vip,description_phoneNR_vip,description_email_vip,consent_vip,description_consent_vip,textViewTermsOfUse_vip,textViewPrivacyPolicy_vip;

	ArrayList<Model_Country> countryList = new ArrayList<>() ;
	ArrayList<String> dial_code_list = new ArrayList<>();
	String dial_code_country;
	String code_country;

	public FrameLayout parent;
	public RelativeLayout layout_overview_video_ident,layout_overview_video_ident_plus;

	public LottieAnimationView token_retries_agent_image;
	private MotionEvent ev;

	VideoLiveStreamManager videoLiveStreamManager;

	IdentificationCanceledCallback identificationCanceledCallback;



	// ============================
	// LIFECYCLE
	// ============================

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );

		Util_Log.d("COUNTLY LOG","EVENT_TNC_SHOWN");

		if(Config.VIDEO_IDENT_PLUS){
			overrideContentView(R.layout.activity_overview_check);
			if(Config.CHECK_SCREEN_BOX_PHONENUMBER_REQUIRED) {
				TextView textView = findViewById(R.id.checkScreenMobileNumberHeader_vip);
				textView.setText(textView.getText() != null ? textView.getText() + "*" : "");
			}

			if(Config.CHECK_SCREEN_BOX_EMAIL_REQUIRED) {
				TextView textView = findViewById(R.id.checkScreenEMailHeader_vip);
				textView.setText(textView.getText() != null ? textView.getText() + "*" : "");
			}

			if(Config.CHECK_SCREEN_BOX_CONSENT_REQUIRED) {
				TextView textView = findViewById(R.id.checkScreenConsentHeader_vip);
				textView.setText(textView.getText() != null ? textView.getText() + "*" : "");
			}

		}
		else {

			step_intro_text = findViewById(R.id.step_intro_text);

			if(step_intro_text!=null){
				Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_MOBILE_CONSENT_TITLE,LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_TITLE);
			}

			text_step_email = findViewById(R.id.text_step_email);
			if(text_step_email!=null){
				text_step_email.setText(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_DESC,LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_DESC));
			}

			if(Config.CHECK_BOX_ORIENTATION_RIGHT&&!Config.VIDEO_IDENT_PLUS) {
				overrideContentView(R.layout.activity_overview_check_right);
			} else {
				overrideContentView(R.layout.activity_overview_check);
			}

			if (Config.CHECK_SCREEN_LINES_LONG) {
				View lineOne = findViewById(R.id.partialWidthLineOne);
				lineOne.setVisibility(View.GONE);
				lineOne = findViewById(R.id.wholeWidthLineOne);
				lineOne.setVisibility(View.VISIBLE);

				if (Config.IDENT_CODE_BY_EMAIL) {
					View lineTwo = findViewById(R.id.partialWidthLineTwo);
					lineTwo.setVisibility(View.GONE);
					lineTwo = findViewById(R.id.wholeWidthLineTwo);
					lineTwo.setVisibility(View.VISIBLE);
				}

				View lineThree = findViewById(R.id.partialWidthLineThreeDocumentDate);
				lineThree.setVisibility(View.GONE);
				lineThree = findViewById(R.id.wholeWidthLineThree);
				lineThree.setVisibility(View.VISIBLE);

				View lineFour = findViewById(R.id.partialWidthLineFour);
				lineFour.setVisibility(View.GONE);
				lineFour = findViewById(R.id.wholeWidthLineFour);
				lineFour.setVisibility(View.VISIBLE);
			}

			if (Config.SHOW_TOKEN_DURING_CHECK_SCREEN) {
				LinearLayout identTokenLayout = findViewById(R.id.linearLayoutCheckScreenIdentToken);
				identTokenLayout.setVisibility(View.VISIBLE);

				TextView tokenText = findViewById(R.id.checkScreenIdentToken);
				tokenText.setText(IDnowSDK.getTransactionToken());
			}

			TextView text_mobile_nr = findViewById(R.id.text_mobile_nr);

			if(text_mobile_nr!=null){
				text_mobile_nr.setText(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_DESC,LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_DESC));
			}

			if(Config.CHECK_SCREEN_BOX_PHONENUMBER_REQUIRED) {
				TextView textView = findViewById(R.id.checkScreenMobileNumberHeader);
				if(textView!=null){
					textView.setText(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_TITLE,LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_TITLE));
				}

				textView.setText(textView.getText() != null ? textView.getText() + "*" : "");
			}

			if(Config.CHECK_SCREEN_BOX_EMAIL_REQUIRED) {
				TextView textView = findViewById(R.id.checkScreenEMailHeader);
				textView.setText(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_TITLE,LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_TITLE));
				textView.setText(textView.getText() != null ? textView.getText() + "*" : "");
			}

			TextView documentHeaderTextView = findViewById(R.id.checkScreenDocumentHeader);
			documentHeaderTextView.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICENSE_TITLE, LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICENSE_TITLE));
			if(Config.CHECK_SCREEN_BOX_DOCUMENT_REQUIRED) {
				documentHeaderTextView.setText(documentHeaderTextView.getText() != null ? documentHeaderTextView.getText() + "*" : "");
			}

			TextView documentTextView = findViewById(R.id.checkScreenDocumentText);
			documentTextView.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICNESE_DESC, LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICNESE_DESC));

			if(Config.CHECK_SCREEN_BOX_CONSENT_REQUIRED) {
				TextView textView = findViewById(R.id.checkScreenConsentHeader);
				textView.setText(textView.getText() != null ? textView.getText() + "*" : "");
			}

			if(Config.CHECK_SCREEN_EXPIRY_DATE_REQUIRED) {
				OnClickListener expiryDateListener = new OnClickListener() {
					@Override
					public void onClick(View v) {
						final Calendar c = Calendar.getInstance();
						int year = c.get(Calendar.YEAR);
						int month = c.get(Calendar.MONTH);
						int day = c.get(Calendar.DAY_OF_MONTH);

						new DatePickerDialog(context, Activities_VideoOverviewCheckActivity.this, year, month, day).show();
					}
				};

				LinearLayout linLayoutIdExplanation = findViewById(R.id.linLayoutIdExplanation);
				linLayoutIdExplanation.setOnClickListener(expiryDateListener);

				LinearLayout documentLayout = findViewById(R.id.checkScreenDocumentLayout);
				documentLayout.setVisibility(View.GONE);

				LinearLayout documentDateLayout = findViewById(R.id.checkScreenDocumentDateLayout);
				documentDateLayout.setVisibility(View.VISIBLE);

				TextView checkScreenDocumentDateHeader = findViewById(R.id.checkScreenDocumentDateHeader);
				checkScreenDocumentDateHeader.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_TITLE, LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_TITLE));

				TextView checkScreenDocumentDateTextView = findViewById(R.id.checkScreenDocumentDateTextView);
				checkScreenDocumentDateTextView.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_DESC, LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_DESC));

				checkScreenDocumentDateText = findViewById(R.id.checkScreenDocumentDateText);
				checkScreenDocumentDateText.setOnClickListener(null);
				checkScreenDocumentDateText.setOnClickListener(expiryDateListener);

				skipExpiryDateLayout = findViewById(R.id.skipExpiryDateLayout);
				skipExpiryDateImageView = findViewById(R.id.skipExpiryDateImageView);

				TextView checkScreenDocumentDateNotPresentTextView = findViewById(R.id.checkScreenDocumentDateNotPresentTextView);
				checkScreenDocumentDateNotPresentTextView.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_NO_PRESENT, LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_NO_PRESENT));

				skipExpiryDateLayout.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Boolean checkBoxValue = skipExpiryDateImageView != null && skipExpiryDateImageView.getTag() != null ? Boolean.valueOf(skipExpiryDateImageView.getTag().toString()) : Boolean.valueOf(false);
						if(!checkBoxValue) {
							checkScreenDocumentDateText.setText("");
							checkScreenDocumentDateText.setError(null);
							skipExpiryDateImageView.setTag(true);
							Util_UtilUI.setCheckMark(skipExpiryDateImageView, true);
							imageViewId.setTag(true);
							Util_UtilUI.setCheckMark(imageViewId, true);
						} else if (checkBoxValue) {
							checkScreenDocumentDateText.setError(null);
							skipExpiryDateImageView.setTag(false);
							Util_UtilUI.setCheckMark(skipExpiryDateImageView, false);
							imageViewId.setTag(false);
							Util_UtilUI.setCheckMark(imageViewId, false);
							checkScreenDocumentDateText.requestFocus();
						}

						handleIdentificationButtonActivation();
					}
				});

				imageViewId.setClickable(true);
				imageViewId.setOnClickListener(expiryDateListener);
			} else {
				LinearLayout documentLayout = findViewById(R.id.checkScreenDocumentLayout);
				documentLayout.setVisibility(View.VISIBLE);
			}
		}

		parent = findViewById(R.id.main);

		layout_overview_video_ident = findViewById(R.id.layout_overview_video_ident);
		layout_overview_video_ident_plus = findViewById(R.id.layout_overview_video_ident_plus);

		checkScreenScrollViewVIPlus = findViewById(R.id.checkScreenScrollView_plus);
		checkScreenScrollViewVI = findViewById(R.id.checkScreenScrollView);

		ViewTreeObserver observerViPlus = checkScreenScrollViewVIPlus.getViewTreeObserver();
		observerViPlus.addOnGlobalLayoutListener(() -> {
			int viewHeight = checkScreenScrollViewVIPlus.getMeasuredHeight();
			int contentHeight = checkScreenScrollViewVIPlus.getChildAt(0).getHeight();
			if(viewHeight - contentHeight < 0) {
				// scrollable
				checkScreenScrollViewVIPlus.setOverScrollMode(View.OVER_SCROLL_NEVER);
			}
			else {
				checkScreenScrollViewVIPlus.setOnTouchListener((v, event) -> true);
			}
		});

		ViewTreeObserver observerVi = checkScreenScrollViewVI.getViewTreeObserver();
		observerVi.addOnGlobalLayoutListener(() -> {
			int viewHeight = checkScreenScrollViewVI.getMeasuredHeight();
			int contentHeight = checkScreenScrollViewVI.getChildAt(0).getHeight();
			if(viewHeight - contentHeight < 0) {
				// scrollable
				checkScreenScrollViewVI.setOverScrollMode(View.OVER_SCROLL_NEVER);
			}
			else {
				checkScreenScrollViewVI.setOnTouchListener((v, event) -> true);
			}
		});

		token_retries_agent_image = findViewById(R.id.token_retries_agent_image);
		token_retries_agent_image.setAnimation("static_agent_id_fail.json");
		token_retries_agent_image.playAnimation();

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {

		super.onActivityResult(requestCode, resultCode, intent);
        onActivityResultIntent = intent;

		if (IDnowSDK.RESULT_CODE == IDnowSDK.RESULT_CODE_CANCEL) {
			this.onBackPressed();
		}
		if (IDnowSDK.RESULT_CODE == IDnowSDK.RESULT_CODE_FAILED) {
            this.onBackPressed();
		} else if (IDnowSDK.RESULT_CODE == IDnowSDK.RESULT_CODE_SUCCESS || (resultCode == IDnowSDK.RESULT_CODE_SUCCESS)) {
			setResult(IDnowSDK.RESULT_CODE, intent);
			IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE, intent);
			Util_Util.clearApplicationData(context);
			finish();
		} else {
			if (requestCode == IDnowSDK.REQUEST_ID_NOW_SDK) {
				if (resultCode != IDnowSDK.RESULT_CODE_INTERNAL && resultCode != IDnowSDK.RESULT_CODE_CANCEL) {
					// Means some important callback from the SDK came along. Pass it on and terminate
					IDnowSDK.getInstance().deliverResult(resultCode, intent);
					setResult(resultCode, intent);
					Util_Util.clearApplicationData(context);
					finish();
				} else {
					// Usually just a back button press in the called activity
					// Do nothing.
				}
			}
		}

	}

	@Override
	public void onBackPressed()
	{
		Config.BACK_TO_VID = false;
		Intent backPressedIntent = new Intent();

		if(Config.INSTANT_SIGN){
			videoLiveStreamManager = new VideoLiveStreamManager(getApplicationContext());
			identificationCanceledCallback = new IdentificationCanceledCallback() {
				@Override
				public void onFailure() {

				}

				@Override
				public void onSuccess() {

				}
			};
			videoLiveStreamManager.identificationCanceledRESTCall(null, identificationCanceledCallback);
		}


		if((IDnowSDK.RESULT_CODE != IDnowSDK.RESULT_CODE_FAILED)){
			IDnowSDK.RESULT_CODE = IDnowSDK.RESULT_CODE_CANCEL;
		}

		if(IDnowSDK.RESULT_CODE==IDnowSDK.RESULT_CODE_CANCEL){
			backPressedIntent.putExtra( IDnowSDK.RESULT_DATA_ERROR, getString( IDnowSDK.MESSAGE_USER_CANCELED ) );
		}
		else {
			if(onActivityResultIntent!=null && onActivityResultIntent.hasExtra(IDnowSDK.RESULT_ERROR_CODE)) {
                setResult(IDnowSDK.RESULT_CODE, onActivityResultIntent);
				IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE, onActivityResultIntent);
				finish();
                return;
			} else {
                backPressedIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, getString(IDnowSDK.MESSAGE_ID_FAILED));
			}
		}
        Util_CustomLogData.endSession();
		backPressedIntent.putExtra( IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken() );
		IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE, backPressedIntent);
		Util_Util.clearApplicationData(context);
		setResult( IDnowSDK.RESULT_CODE, backPressedIntent );
		IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE, backPressedIntent);
        finish();
	}

	// =====================
	// ACTIVITY METHODS
	// =====================

	@Override
	public void initLayout() {
		Util_Util.setActivityTitle(context);
        consent_vip = findViewById(R.id.checkScreenConsentHeader_vip);
		step_intro_text = findViewById(R.id.step_intro_text);
        description_consent_vip = findViewById(R.id.description_consent_vip);

		Util_Util.setActivityTitle( context );

		phoneNrContainer = findViewById(R.id.phoneNrContainer);
		emailContainer = findViewById(R.id.emailContainer);
		phoneNrCheckBoxContainer = findViewById(R.id.phoneNrCheckBoxContainer);


		if(Config.IDENT_CODE_BY_EMAIL&&!Config.IDENT_CODE_BY_SMS){
			phoneNrContainer.setVisibility(View.GONE);
			emailContainer.setVisibility(View.VISIBLE);
			phoneNrCheckBoxContainer.setVisibility(View.GONE);
		}

		textViewApprovalHelp = findViewById( R.id.textViewApprovalHelp );
		textViewApprovalHelp.setPaintFlags( textViewApprovalHelp.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG );
		textViewApprovalHelp.setOnClickListener( new OnClickListener()
		{

			@Override
			public void onClick( View v )
			{
				Intent helpDataIntent = new Intent( context, Activities_HelpDataActivity.class );
				startActivityForResult( helpDataIntent, IDnowSDK.REQUEST_ID_NOW_SDK );
			}
		} );

		textViewIdHelp = findViewById( R.id.textViewIdHelp );
		textViewIdHelp.setPaintFlags( textViewIdHelp.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG );
		textViewIdHelp.setOnClickListener( new OnClickListener()
		{

			@Override
			public void onClick( View v )
			{
				Intent helpIDIntent = new Intent( context, Activities_HelpIDActivity.class );
				startActivityForResult( helpIDIntent, IDnowSDK.REQUEST_ID_NOW_SDK );
			}
		} );

		imageViewApproval = findViewById( R.id.imageViewApproval );
		imageViewId = findViewById( R.id.imageViewId );
		imageViewEmail = findViewById( R.id.imageViewEmail );
		imageViewMobileNr = findViewById( R.id.imageViewMobileNr );
		if(Config.MOBILE_NUMBER_CHANGE_DISABLED){
			imageViewMobileNr.setVisibility(View.VISIBLE);
		}
		else {
			imageViewMobileNr.setVisibility(View.INVISIBLE);
		}
		if(Config.CHECKBOX_INSTRUCTIONS_SCREEN) {
			imageViewId.setVisibility(View.VISIBLE);
			imageViewMobileNr.setVisibility(View.VISIBLE);
		} else {
			imageViewId.setVisibility(View.INVISIBLE);
			imageViewMobileNr.setVisibility(View.INVISIBLE);
		}

		imageViewRecording = findViewById( R.id.imageViewRecording );
		TextView second_step_recording_title = findViewById(R.id.second_step_recording_title);

		if(second_step_recording_title!=null){
			second_step_recording_title.setText(Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_AGREEMENT_TITLE,LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_AGREEMENT_TITLE));
		}
		// tint the empty check mark circle in branding color
		Util_UtilUI.setCheckMark( imageViewApproval, false );
		Util_UtilUI.setCheckMark( imageViewId, false );
		Util_UtilUI.setCheckMark( imageViewMobileNr, false );
		Util_UtilUI.setCheckMark( imageViewRecording, false );

		handleGTCFlag();

		idExplanationLinearLayout = findViewById( R.id.linLayoutIdExplanation );
		idExplanationLinearLayout.setTag( imageViewId );
		if(Config.CHECKBOX_INSTRUCTIONS_SCREEN) {
			idExplanationLinearLayout.setOnClickListener( new UI_CustomLinearLayoutOnClickListener() );
			imageViewId.setTag( false );
		} else {
			imageViewId.setTag(true);
		}

		recordingAgreementLinearLayout = findViewById( R.id.linLayoutRecordingAgreement );
		if ( Config.SHOW_RECORDING_AGREEMENT )
		{
			recordingAgreementLinearLayout.setTag( imageViewRecording );
			recordingAgreementLinearLayout.setOnClickListener( new UI_CustomLinearLayoutOnClickListener() );
			recordingAgreementLinearLayout.setVisibility( View.VISIBLE );
			imagesToCheckList.add( imageViewRecording );
		}
		else
		{
			recordingAgreementLinearLayout.setVisibility( View.GONE );
		}

		imagesToCheckList.add( imageViewId );
		if(Config.IDENT_CODE_REQUIRED){
			imagesToCheckList.add( imageViewMobileNr );
		}

		imageViewApproval.setOnClickListener( new UI_CustomOnClickListener() );
		imageViewId.setOnClickListener( new UI_CustomOnClickListener() );
		// don't allow the user to press the "start identification button". at first the user has to add a phone number and check the 2 radiobuttons
		imageViewApproval.setTag( false );
		imageViewMobileNr.setTag( false );
		imageViewRecording.setTag( false );

		Util_UtilUI.setProceedButtonBackgroundSelector( nextButton );
		nextButton.setEnabled( false );

		nextButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				boolean validPhone = true;
				boolean validEmail = true;

				if(!editTextMobileNr.getText().toString().contains("***")&&!editTextMobileNr.getText().toString().equals("")){
					validPhone = Util_Util.isPhoneValid(editTextMobileNr.getText().toString());
				}

				if(!editTextEmail.getText().toString().contains("***")&&!editTextEmail.getText().toString().equals("")){
					validEmail = Util_Util.isValidEmail(editTextEmail.getText().toString());
				}



				if (Config.IDENT_CODE_BY_SMS && !Config.IDENT_CODE_BY_EMAIL) {
					if ((!Util_UtilUI.isEditTextEmpty(editTextMobileNr, true, Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REQUIRED_FIELD, LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD)) && validPhone) || !Config.IDENT_CODE_REQUIRED) {
						Config.USER_PHONE_NO = editTextMobileNr.getText().toString();
						handleNextButtonClicked();
					}
					else {
						Util_UtilUI.setCheckMark(imageViewMobileNr, false);
						imageViewMobileNr.setTag(false);

					}
				} else if (Config.IDENT_CODE_BY_EMAIL && !Config.IDENT_CODE_BY_SMS) {
					if ((!Util_UtilUI.isEditTextEmpty(editTextEmail, true, Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REQUIRED_EMAIL, LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD)) && validEmail) || !Config.IDENT_CODE_REQUIRED) {
						Config.EMAIL_ADDRESS =  editTextEmail.getText().toString();
						handleNextButtonClicked();
					}
					else {
						Util_UtilUI.setCheckMark(imageViewEmail, false);
						imageViewEmail.setTag(false);
					}
				} else {
					if ((!Util_UtilUI.isEditTextEmpty(editTextMobileNr, true, Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REQUIRED_FIELD, LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD)) && validPhone) || !Config.IDENT_CODE_REQUIRED) {
						if (!Util_UtilUI.isEditTextEmpty(editTextEmail, true, Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REQUIRED_EMAIL, LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD)) && validEmail) {
							Config.EMAIL_ADDRESS =  editTextEmail.getText().toString();
							Config.USER_PHONE_NO = editTextMobileNr.getText().toString();
							handleNextButtonClicked();

						}
						else {
							Util_UtilUI.setCheckMark(imageViewEmail, false);
							imageViewEmail.setTag(false);
						}
					}
					else {
						Util_UtilUI.setCheckMark(imageViewMobileNr, false);
						imageViewMobileNr.setTag(false);
					}
				}
			}
		});

		handleTermsOfUseUrlsAndTexts();
		customizeCheckboxesAndHeadersStyle();

		if(Config.HIDE_USERS_PII_DATA&&!Config.USER_PHONE_NO.equals("")){
			imageViewMobileNr.setVisibility(View.VISIBLE);
			Util_UtilUI.setCheckMark(imageViewMobileNr, true);
			imageViewMobileNr.setTag(true);

		}
		else {
			imageViewMobileNr.setVisibility(View.VISIBLE);
			Util_UtilUI.setCheckMark(imageViewMobileNr, false);
			imageViewMobileNr.setTag(false);

		}

		if(Config.HIDE_USERS_PII_DATA&&!Config.EMAIL_ADDRESS.equals("")){
			imageViewEmail.setVisibility(View.VISIBLE);
			Util_UtilUI.setCheckMark(imageViewEmail, true);
			imageViewEmail.setTag(true);

		}
		else {
			imageViewEmail.setVisibility(View.VISIBLE);
			Util_UtilUI.setCheckMark(imageViewEmail, false);
			imageViewEmail.setTag(false);

		}

		if(!Config.USER_PHONE_NO.equals("")){
			if(Config.HIDE_USERS_PII_DATA){
				editTextMobileNr.setText(Config.MASKED_USER_PHONE_NO);
			}
			else {
				editTextMobileNr.setText(Config.USER_PHONE_NO);
			}
		}
		if(!Config.EMAIL_ADDRESS.equals("")){
			if(Config.HIDE_USERS_PII_DATA){
				editTextEmail.setText(Config.MASKED_EMAIL_ADDRESS);
			}
			else {
				editTextEmail.setText(Config.EMAIL_ADDRESS);

			}
		}
		if(Config.IDENT_CODE_BY_SMS && !Config.IDENT_CODE_BY_EMAIL){
			phoneNrContainer.setVisibility(View.VISIBLE);
			emailContainer.setVisibility(View.GONE);
			handlePhoneNumerVI();
		}
		else if(!Config.IDENT_CODE_BY_SMS && Config.IDENT_CODE_BY_EMAIL){
			phoneNrContainer.setVisibility(View.GONE);
			emailContainer.setVisibility(View.VISIBLE);
			handleEmailVI();
		}
		else {
			phoneNrContainer.setVisibility(View.VISIBLE);
			emailContainer.setVisibility(View.VISIBLE);
			handlePhoneNumerVI();
			handleEmailVI();

		}

		if(!Config.IDENT_CODE_REQUIRED) {
			// Pretend user entered a valid phone number
			if(Config.CHECKBOX_INSTRUCTIONS_SCREEN) {
				imageViewMobileNr.setVisibility( View.VISIBLE );
			}

			phoneNrContainer.setVisibility(View.GONE);
			phoneNrCheckBoxContainer.setVisibility(View.GONE);
		}
	}

	private void handleEmailVI() {
		if (editTextEmail != null) {
			editTextEmail.setHint(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_PLACEHOLDER, LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_PLACEHOLDER));
		}

		if (Config.IDENT_CODE_BY_EMAIL) {
			emailContainer.setVisibility(View.VISIBLE);

			imagesToCheckList.add(imageViewEmail);

			imageViewEmail.setTag(false);

			imageViewEmail.setVisibility(View.VISIBLE);


			if(!editTextEmail.getText().toString().equals("")){
				if(!editTextEmail.getText().toString().contains("***")){
					if (Util_Util.isValidEmail(Config.EMAIL_ADDRESS)) {
						Util_UtilUI.setCheckMark(imageViewEmail, true);
						imageViewEmail.setTag(true);
						imageViewEmail.setVisibility(View.VISIBLE);
						handleIdentificationButtonActivation();
					}
				}
				else {
					Util_UtilUI.setCheckMark(imageViewEmail, true);
					imageViewEmail.setTag(true);
				}
			}
			else {
				Util_UtilUI.setCheckMark(imageViewEmail, false);
				imageViewEmail.setTag(false);
			}
			editTextEmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
				public void onFocusChange(View view, boolean b) {
					if (Config.HIDE_USERS_PII_DATA) {
						if (editTextEmail.getText().toString().contains("***") && b) {
							editTextEmail.getText().clear();
						} else if (!b && editTextEmail.getText().toString().equals("")) {
							editTextEmail.setText((Config.MASKED_EMAIL_ADDRESS));
							Util_UtilUI.setCheckMark(imageViewEmail, true);
							imageViewEmail.setTag(true);
							editTextEmail.setError(null);
						}
					}
				}
			});
			editTextEmail.addTextChangedListener(new TextWatcher() {
				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
					if (Config.HIDE_USERS_PII_DATA && !Config.RESET_FIELD_EMAIL && !Config.EMAIL_ADDRESS.equals("")) {
						editTextEmail.getText().clear();
						Config.RESET_FIELD_EMAIL = true;
						Util_UtilUI.setCheckMark(imageViewEmail, false);
						handleIdentificationButtonActivation();
					} else {
						if (Util_Util.isValidEmail(String.valueOf(s))) {
							// the checked state is stored in the tag
							if (!((Boolean) imageViewEmail.getTag())) {
								Util_UtilUI.setCheckMark(imageViewEmail, true);
								imageViewEmail.setTag(true);
								imageViewEmail.setVisibility(View.VISIBLE);

								handleIdentificationButtonActivation();
							}
						} else {
							editTextEmail.setError(getString(R.string.wrong_entry));

							if ((Boolean) imageViewEmail.getTag()) {
								Util_UtilUI.setCheckMark(imageViewEmail, false);
								imageViewEmail.setTag(false);
								imageViewEmail.setVisibility(View.VISIBLE);

								handleIdentificationButtonActivation();
							}
						}
					}
				}

				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				}

				@Override
				public void afterTextChanged(Editable s) {
				}
			});
		}
	}

	private void handlePhoneNumerVI() {
		String phoneNo = Config.USER_PHONE_NO;
		boolean isPoneNoEmptyOrNull = phoneNo == null || phoneNo.equals("null") || phoneNo.isEmpty();
		if (!isPoneNoEmptyOrNull && Config.IDENT_CODE_REQUIRED) {
			if(!editTextMobileNr.getText().toString().contains("***")){
				if (Config.VERIFY_PHONE_NO) {
					verifyMobileNumberFormat();
				} else {
					editTextMobileNr.setText(Config.USER_PHONE_NO);
					if (Util_Util.isPhoneValid(editTextMobileNr.getText().toString())) {
						imageViewMobileNr.setVisibility(View.VISIBLE);
						Util_UtilUI.setCheckMark(imageViewMobileNr, true);
						imageViewMobileNr.setTag(true);
						if (Config.CHECKBOX_INSTRUCTIONS_SCREEN) {
							imageViewMobileNr.setVisibility(View.VISIBLE);
						}
					} else {
						displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_COMMON_ERROR, LOCAL_KEY_VIDEO_IDENT_COMMON_ERROR), Util_Strings.getStringWithDefault(this, KEY_LABEL_PHONE_VALIDATION_ERROR, LOCAL_LABEL_PHONE_VALIDATION_ERROR));
						editTextMobileNr.setError(getString(R.string.wrong_entry));
					}
				}
			}
			else {
				Util_UtilUI.setCheckMark(imageViewMobileNr, true);
				imageViewMobileNr.setTag(true);
			}
		}
		else {
			Util_UtilUI.setCheckMark(imageViewMobileNr, false);
			imageViewMobileNr.setTag(false);
		}

		editTextMobileNr.clearFocus();
		editTextMobileNr.setOnFocusChangeListener(new View.OnFocusChangeListener() {
			@Override
			public void onFocusChange(View view, boolean hasFocus) {

				if (!Config.HIDE_USERS_PII_DATA) {
					if (!hasFocus) {
						String number = editTextMobileNr.getText().toString();
						if (number != null && Util_Util.isPhoneValid(number)) {
							// Number is valid, should convert into e164
							String finalNumber = Util_Util.formatValidE164(number, Locale.getDefault());
							if (finalNumber == null) {
								displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_COMMON_ERROR, LOCAL_KEY_VIDEO_IDENT_COMMON_ERROR), Util_Strings.getStringWithDefault(getApplicationContext(), KEY_LABEL_PHONE_VALIDATION_ERROR, LOCAL_LABEL_PHONE_VALIDATION_ERROR));
							} else {
								if (!editTextMobileNr.getText().toString().equals(finalNumber)) {
									displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_NOTIF_TITLE, LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE), Util_Strings.getStringWithDefault(getApplicationContext(), KEY_LABEL_PHONE_VALIDATION_CORRECTED, LOCAL_LABEL_PHONE_VALIDATION_CORRECTED));
								}

								editTextMobileNr.setText(finalNumber);
								Config.USER_PHONE_NO = finalNumber;
								return;
							}
						}

						displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_COMMON_ERROR, LOCAL_KEY_VIDEO_IDENT_COMMON_ERROR), Util_Strings.getStringWithDefault(getApplicationContext(), KEY_LABEL_PHONE_VALIDATION_ERROR, LOCAL_LABEL_PHONE_VALIDATION_ERROR));
					}

				} else {
					if (editTextMobileNr.getText().toString().contains("***") && hasFocus) {
						editTextMobileNr.getText().clear();
						imageViewMobileNr.setVisibility(View.INVISIBLE);
						Util_UtilUI.setCheckMark(imageViewMobileNr, false);
						imageViewMobileNr.setTag(false);


					} else if (!hasFocus && editTextMobileNr.getText().toString().equals("")) {

						editTextMobileNr.setText((Config.MASKED_USER_PHONE_NO));

						Util_UtilUI.setCheckMark(imageViewMobileNr, true);
						imageViewMobileNr.setTag(true);
						if (Config.CHECKBOX_INSTRUCTIONS_SCREEN) {
							imageViewMobileNr.setVisibility(View.VISIBLE);
						}
						handleIdentificationButtonActivation();
						editTextMobileNr.setError(null);
					}
				}

			}
		});

		editTextMobileNr.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				if (Config.HIDE_USERS_PII_DATA && !Config.RESET_FIELD && !Config.USER_PHONE_NO.equals("")) {
					editTextMobileNr.getText().clear();
					Config.RESET_FIELD = true;
					imageViewMobileNr.setVisibility(View.INVISIBLE);
					Util_UtilUI.setCheckMark(imageViewMobileNr, false);
					handleIdentificationButtonActivation();
				} else {
					if (Util_Util.isPhoneValid(String.valueOf(s))) {
						// the checked state is stored in the tag
						if (!((Boolean) imageViewMobileNr.getTag())) {
							Util_UtilUI.setCheckMark(imageViewMobileNr, true);
							imageViewMobileNr.setTag(true);
							if (Config.CHECKBOX_INSTRUCTIONS_SCREEN) {
								imageViewMobileNr.setVisibility(View.VISIBLE);
							}
							handleIdentificationButtonActivation();
						}
					} else {
						editTextMobileNr.setError(getString(R.string.wrong_entry));

						if ((Boolean) imageViewMobileNr.getTag()) {
							Util_UtilUI.setCheckMark(imageViewMobileNr, false);
							imageViewMobileNr.setTag(false);
							imageViewMobileNr.setVisibility(View.INVISIBLE);

							handleIdentificationButtonActivation();
						}
					}
				}


			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
				if (Config.HIDE_USERS_PII_DATA && !Config.RESET_FIELD && !Config.USER_PHONE_NO.equals("")) {
					editTextMobileNr.getText().clear();
					Config.RESET_FIELD = true;
					Util_UtilUI.setCheckMark(imageViewMobileNr, false);
					handleIdentificationButtonActivation();
				}
			}
		});
	}


	public String loadJSONFromAsset() {
		String json = null;
		try {
			InputStream is = getApplicationContext().getAssets().open("countrylist.json");
			int size = is.available();
			byte[] buffer = new byte[size];
			is.read(buffer);
			is.close();
			json = new String(buffer, StandardCharsets.UTF_8);
		} catch (IOException ex) {
			Util_Log.e(LOGTAG, "Load country list json from assets failed", ex);
			return null;
		}
		return json;
	}

	@Override
	public void initVideoIdent() {
		super.initVideoIdent();

		Util_Util.setActivityTitle( context );

		emailContainer_vip = findViewById(R.id.emailContainer_vip);
		phoneNrContainer_vip = findViewById(R.id.phoneContainer_vip);
		checkScreenMobileNumberHeader_vip = findViewById(R.id.checkScreenMobileNumberHeader_vip);
		checkScreenEMailHeader_vip = findViewById(R.id.checkScreenEMailHeader_vip);
		checkScreenMobileNumberHeader_vip.setText(Util_Strings.getStringWithDefault(context,Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_TITLE,Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_TITLE));
		checkScreenEMailHeader_vip.setText(Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_TITLE,LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_TITLE));
		overview_title_vip = findViewById(R.id.overview_title_vip);

		description_phoneNR_vip = findViewById(R.id.description_phoneNR_vip);
		description_email_vip = findViewById(R.id.description_email_vip);
		description_phoneNR_vip.setText(Util_Strings.getStringWithDefault(context,Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_DESC,Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_DESC));
		description_email_vip.setText(Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_DESC,LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_DESC));
		consent_vip = findViewById(R.id.checkScreenConsentHeader_vip);
		description_consent_vip = findViewById(R.id.description_consent_vip);
		textViewTermsOfUse_vip = findViewById(R.id.textViewTermsOfUse_vip);
		textViewPrivacyPolicy_vip = findViewById(R.id.textViewPrivacyPolicy_vip);
		consent_vip.setText(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_PLUS_CONSENT,LOCAL_KEY_VIDEO_IDENT_PLUS_CONSENT));
		overview_title_vip.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TERMS, LOCAL_KEY_VIDEO_IDENT_PLUS_TERMS));
		description_consent_vip.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_LABEL_TERMS, LOCAL_LABEL_TERMS));
		textViewTermsOfUse_vip.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_LINK_TERMS_OF_USE, LOCAL_LINK_TERMS_OF_USE));
		textViewPrivacyPolicy_vip.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_LABEL_PRIVACY_POLICY, LOCAL_LABEL_PRIVACY_POLICY));


		try {
			Model_Countries countries = new Gson().fromJson(loadJSONFromAsset(), Model_Countries.class);
			countryList.addAll(countries.getCountries());

			for(Model_Country country : countryList){
				Util_Log.d("Details-->", country.getName());
				dial_code_list.add(country.getDial_code());
			}
		} catch (JsonSyntaxException e) {
			Util_Log.e(LOGTAG, "Parse countries json failed", e);
		}

		nextButton_vip.setEnabled( false );
		if (Config.HIDE_USERS_PII_DATA&&!Config.USER_PHONE_NO.equals("")){
			checkbox_phone_vip.setChecked(true);
		}
		else {
			checkbox_phone_vip.setClickable(false);
		}

		Util_UtilUI.setProceedButtonBackgroundSelector( nextButton_vip );

		handleTermsOfUseUrlsAndTexts();

		nextButton_vip.setOnClickListener( new OnClickListener()
		{
			@Override
			public void onClick( View v )
			{
				boolean validPhone = true;
				boolean validEmail = true;

				if (!editTextMobileNr_vip.getText().toString().contains("***")&&!editTextMobileNr_vip.getText().toString().equals("")){
					validPhone = Util_Util.isPhoneValid(editTextMobileNr_vip.getText().toString());
				}

				if(!editTextEmail_vip.getText().toString().contains("***")&&!editTextEmail_vip.getText().toString().equals("")){
					validEmail = Util_Util.isValidEmail(editTextEmail_vip.getText().toString());
				}

				Config.RESET_FIELD = false;
				Config.RESET_FIELD_EMAIL = false;

				if(Config.IDENT_CODE_BY_SMS&&!Config.IDENT_CODE_BY_EMAIL){
					if ((!Util_UtilUI.isEditTextEmpty(editTextMobileNr_vip, true, Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_REQUIRED_FIELD,LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD)) && validPhone) || !Config.IDENT_CODE_REQUIRED)
					{
						Config.USER_PHONE_NO = editTextMobileNr_vip.getText().toString();

						handleNextButtonClicked();
					}
				}
				else if (Config.IDENT_CODE_BY_EMAIL&&!Config.IDENT_CODE_BY_SMS) {
					if ((!Util_UtilUI.isEditTextEmpty(editTextEmail_vip, true, Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REQUIRED_EMAIL, LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD)) && validEmail) || !Config.IDENT_CODE_REQUIRED) {
						Config.EMAIL_ADDRESS = editTextEmail_vip.getText().toString();
						handleNextButtonClicked();
					}
					else {
						checkbox_email_vip.setChecked(false);
					}
				}
				else {

					if ((!Util_UtilUI.isEditTextEmpty(editTextMobileNr_vip, true, Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_REQUIRED_FIELD,LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD)) && validPhone) || !Config.IDENT_CODE_REQUIRED)
					{

						if (!Util_UtilUI.isEditTextEmpty(editTextEmail_vip, true, Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REQUIRED_EMAIL, LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD)) && validEmail) {
							Config.USER_PHONE_NO = editTextMobileNr_vip.getText().toString();
							Config.EMAIL_ADDRESS = editTextEmail_vip.getText().toString();
							handleNextButtonClicked();

						}
						else {
							checkbox_email_vip.setChecked(false);
						}
					}
					else {
						checkbox_phone_vip.setChecked(false);

					}
				}
			}
		});

		if(!Config.USER_PHONE_NO.equals("")){
			if(Config.HIDE_USERS_PII_DATA){
				editTextMobileNr_vip.setText(Config.MASKED_USER_PHONE_NO);
			}
			else {
				editTextMobileNr_vip.setText(Config.USER_PHONE_NO);
			}
		}
		if(!Config.EMAIL_ADDRESS.equals("")){
			if(Config.HIDE_USERS_PII_DATA){
				editTextEmail_vip.setText(Config.MASKED_EMAIL_ADDRESS);
			}
			else {
				editTextEmail_vip.setText(Config.EMAIL_ADDRESS);
			}
		}

		if(Config.IDENT_CODE_BY_SMS && Config.IDENT_CODE_BY_EMAIL) {
			phoneNrContainer_vip.setVisibility(View.VISIBLE);
			emailContainer_vip.setVisibility(View.VISIBLE);
			phoneNumberVipHandling();
			emailVipHandling();
		}
		else if(Config.IDENT_CODE_BY_SMS && !Config.IDENT_CODE_BY_EMAIL){
			phoneNrContainer_vip.setVisibility(View.VISIBLE);
			emailContainer_vip.setVisibility(View.GONE);
			phoneNumberVipHandling();
		} else if(!Config.IDENT_CODE_BY_SMS && Config.IDENT_CODE_BY_EMAIL) {
			phoneNrContainer_vip.setVisibility(View.GONE);
			emailContainer_vip.setVisibility(View.VISIBLE);
			emailVipHandling();
		} else if(!Config.IDENT_CODE_BY_SMS && !Config.IDENT_CODE_BY_EMAIL) {
			phoneNrContainer_vip.setVisibility(View.GONE);
			emailContainer_vip.setVisibility(View.GONE);
		}
		else {
			phoneNrContainer_vip.setVisibility(View.VISIBLE);
			emailContainer_vip.setVisibility(View.GONE);
			phoneNumberVipHandling();
		}

		checkbox_consent_vip.setOnCheckedChangeListener((buttonView, isChecked) ->
				handleIdentificationButtonActivation()
		);

		handleIdentificationButtonActivation();
		handleGTCFlag();
	}

	private void handleGTCFlag() {
		approvalExplanationLinearLayout = findViewById( R.id.linLayoutApprovalExplanation );
		if (Config.SHOW_GTC) {
			approvalExplanationLinearLayout.setTag(imageViewApproval);
			if (!Config.ONE_LINE_AGB) {
				approvalExplanationLinearLayout.setOnClickListener(new UI_CustomLinearLayoutOnClickListener());
			}
			approvalExplanationLinearLayout.setVisibility(View.VISIBLE);
			imagesToCheckList.add(imageViewApproval);
		} else {
			LinearLayout titleConsentVip = findViewById(R.id.title_consent_vip);
			titleConsentVip.setVisibility(View.GONE);
			description_consent_vip.setVisibility(View.GONE);
			approvalExplanationLinearLayout.setVisibility(View.GONE);
		}
	}

	public void phoneNumberVipHandling() {
		sCountry.setTag("init");
		String phoneNo = Config.USER_PHONE_NO;
		boolean isPoneNoEmptyOrNull = phoneNo == null || phoneNo.equals("null") || phoneNo.isEmpty();
		if (!isPoneNoEmptyOrNull && Config.IDENT_CODE_REQUIRED) {
			if (!editTextMobileNr_vip.getText().toString().contains("***")) {
				if (Config.VERIFY_PHONE_NO) {
					verifyMobileNumberFormat();
				} else {
					editTextMobileNr_vip.setText(Config.USER_PHONE_NO);
					if (Util_Util.isPhoneValid(editTextMobileNr_vip.getText().toString())) {
						checkbox_phone_vip.setChecked(true);
					} else {
						displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_NOTIF_TITLE, LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE), Util_Strings.getStringWithDefault(this, KEY_LABEL_PHONE_VALIDATION_ERROR, LOCAL_LABEL_PHONE_VALIDATION_ERROR));
						editTextMobileNr_vip.setError(getString(R.string.wrong_entry));
						checkbox_phone_vip.setChecked(true);
					}

				}
			} else {
				checkbox_phone_vip.setChecked(true);
			}
		} else {
			checkbox_phone_vip.setChecked(false);
		}

		CustomAdapter customAdapter = new CustomAdapter(getApplicationContext(), countryList);

		sCountry.setAdapter(customAdapter);

		String phoneNumber = Config.USER_PHONE_NO;

		code_country = getPhoneRegionCode(phoneNumber) != null ? getPhoneRegionCode(phoneNumber) : "";
		dial_code_country = "+" + getPhoneCountryCode(phoneNumber);

		int pos = -1;

		for (int i = 0; i < countryList.size(); i++) {
			if (code_country.equals(countryList.get(i).getCode())) {
				pos = i;
				break;
			}
		}

		if (code_country.equals("")) {
			// only for Great Britain phone number or same country code
			sCountry.setSelection(countryList.size() - 1);
		} else {
			if (pos >= 0) {
				sCountry.setSelection(pos);
			} else {
				sCountry.setSelection(dial_code_list.indexOf(dial_code_country));
			}
		}


		sCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

				editTextMobileNr_vip.setOnTouchListener(new View.OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						return false;
					}
				});

				sCountry.setOnTouchListener(new View.OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						Config.PHONE_NUMBER_MAN_CHANGED = false;
						return false;
					}
				});

				if (!Config.PHONE_NUMBER_MAN_CHANGED) {

					String dial_code_frm_list = null;
					dial_code_frm_list = countryList.get(position).getDial_code();
					dial_code_country = "+" + getPhoneCountryCode(editTextMobileNr_vip.getText().toString());
					if (!Config.HIDE_USERS_PII_DATA) {
						Config.USER_PHONE_NO = editTextMobileNr_vip.getText().toString().replace(dial_code_country, dial_code_frm_list);
						editTextMobileNr_vip.setText(Config.USER_PHONE_NO);
					} else {
						if (sCountry.getTag() != "init") {
							Config.RESET_FIELD = true;
							editTextMobileNr_vip.setText(dial_code_frm_list);
						}
						sCountry.setTag("");
					}

					Config.PHONE_NUMBER_MAN_CHANGED = true;

				}

			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		editTextMobileNr_vip.clearFocus();
		editTextMobileNr_vip.setOnFocusChangeListener(new View.OnFocusChangeListener() {
			@Override
			public void onFocusChange(View view, boolean hasFocus) {
				if (Config.HIDE_USERS_PII_DATA && !hasFocus && editTextMobileNr_vip.getText().toString().equals("")) {

					editTextMobileNr_vip.setText((Config.MASKED_USER_PHONE_NO));
					checkbox_phone_vip.setChecked(true);
					editTextMobileNr_vip.setError(null);

					handleIdentificationButtonActivation();
				}

				if (!Config.HIDE_USERS_PII_DATA) {
					if (!hasFocus) {
						String number = editTextMobileNr_vip.getText().toString();
						if (number != null && Util_Util.isPhoneValid(number)) {
							// Number is valid, should convert into e164
							String finalNumber = Util_Util.formatValidE164(number, Locale.getDefault());
							if (finalNumber == null) {
								displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REQUIRED_FIELD, LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD), Util_Strings.getStringWithDefault(getApplicationContext(), KEY_LABEL_PHONE_VALIDATION_ERROR, LOCAL_LABEL_PHONE_VALIDATION_ERROR));
							} else {
								if (!editTextMobileNr_vip.getText().toString().equals(finalNumber)) {
									displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_NOTIF_TITLE, LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE), Util_Strings.getStringWithDefault(getApplicationContext(), KEY_LABEL_PHONE_VALIDATION_CORRECTED, LOCAL_LABEL_PHONE_VALIDATION_CORRECTED));
								}

								editTextMobileNr_vip.setText(finalNumber);
								Config.USER_PHONE_NO = finalNumber;
								return;
							}
						}
					}
				} else {
					if (editTextMobileNr_vip.getText().toString().contains("***") && hasFocus) {
						editTextMobileNr_vip.getText().clear();
					}
				}
			}
		});
		editTextMobileNr_vip.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				if (s.length() > 1 && s.toString().endsWith("+")) {
					String result = s.toString().substring(0, s.length() - 1);
					editTextMobileNr_vip.setText(result);
					return;
				}
				if (Config.HIDE_USERS_PII_DATA && !Config.RESET_FIELD && !Config.USER_PHONE_NO.equals("")) {
					editTextMobileNr_vip.getText().clear();
					Config.RESET_FIELD = true;
				} else {
					String partialPhone = s + "";

					code_country = getPhoneRegionCode(partialPhone) != null ? getPhoneRegionCode(partialPhone) : "";
					dial_code_country = "+" + getPhoneCountryCode(partialPhone);

					int pos = -1;

					for (int i = 0; i < countryList.size(); i++) {
						if (code_country.equals(countryList.get(i).getCode())) {
							pos = i;
							break;
						}
					}

					if (pos >= 0) {
						sCountry.setSelection(pos);
					} else {
						sCountry.setSelection(dial_code_list.indexOf(dial_code_country));
					}

					if (Util_Util.isPhoneValid(String.valueOf(s))) {
						checkbox_phone_vip.setChecked(true);
					} else {
						editTextMobileNr_vip.setError(getString(R.string.wrong_entry));
						checkbox_phone_vip.setChecked(false);
						nextButton_vip.setEnabled(false);
					}
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
				if (Config.HIDE_USERS_PII_DATA && !Config.RESET_FIELD && !Config.USER_PHONE_NO.equals("")) {
					editTextMobileNr_vip.getText().clear();
					Config.RESET_FIELD = true;
				} else {
					if (Util_Util.isPhoneValid(String.valueOf(s))) {
						checkbox_phone_vip.setChecked(true);
						editTextMobileNr_vip.setError(null);
					} else {
						editTextMobileNr_vip.setError(getString(R.string.wrong_entry));
						checkbox_phone_vip.setChecked(false);
						nextButton_vip.setEnabled(false);
					}
				}
			}
		});

	}
	public void emailVipHandling() {
		// preselection
		editTextEmail_vip.setText( Config.EMAIL_ADDRESS );

		if(!editTextEmail_vip.getText().toString().equals("")){
			if(!editTextEmail_vip.getText().toString().contains("***")){
				if ( Util_Util.isValidEmail(editTextEmail_vip.getText().toString()) )
				{
					checkbox_email_vip.setChecked(true);
				}else {
					displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_NOTIF_TITLE,LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE), Util_Strings.getStringWithDefault(this, KEY_EMAIL_FORMAT, LOCAL_KEY_EMAIL_FORMAT));
					editTextMobileNr_vip.setError(getString( R.string.wrong_entry ));
					checkbox_email_vip.setChecked(false);
				}
			}else {
				checkbox_email_vip.setChecked(true);
			}		}
		else {
			checkbox_email_vip.setChecked(false);
		}

		editTextEmail_vip.setOnFocusChangeListener(new View.OnFocusChangeListener() {
			@Override
			public void onFocusChange(View view, boolean hasFocus) {
				if(Config.HIDE_USERS_PII_DATA&&!hasFocus&& editTextEmail_vip.getText().toString().equals("")){
					editTextEmail_vip.setText((Config.MASKED_EMAIL_ADDRESS));
					checkbox_email_vip.setChecked(true);
					editTextEmail_vip.setError(null);
				}

				if(!Config.HIDE_USERS_PII_DATA){
					if(!hasFocus) {
						String email = editTextEmail_vip.getText().toString();
						if(email != null && Util_Util.isValidEmail(email)) {
							editTextEmail_vip.setText(email);
							Config.EMAIL_ADDRESS = email;
						}
					}
				}
				else{
					if(editTextEmail_vip.getText().toString().contains("***")&&hasFocus){
						editTextEmail_vip.getText().clear();
					}
				}
			}
		});


		checkbox_email_vip.setOnCheckedChangeListener((buttonView, isChecked) -> {
			if (editTextEmail_vip.getText().toString().isEmpty())
				checkbox_email_vip.setChecked(false);

			handleIdentificationButtonActivation();
		});

		editTextEmail_vip.addTextChangedListener( new TextWatcher()
		{
			@Override
			public void onTextChanged( CharSequence s, int start, int before, int count )
			{
				if(Config.HIDE_USERS_PII_DATA&&!Config.RESET_FIELD_EMAIL&&!Config.EMAIL_ADDRESS.equals("")){
					editTextEmail_vip.getText().clear();
					Config.RESET_FIELD_EMAIL=true;
				}
				else {
					if ( Util_Util.isValidEmail( String.valueOf( s ) ) )
					{
						checkbox_email_vip.setChecked(true);
					}
					else
					{
						editTextEmail_vip.setError( getString( R.string.wrong_entry ) );

						checkbox_email_vip.setChecked(false);

						nextButton_vip.setEnabled(false);
						Util_UtilUI.setProceedButtonBackgroundSelector( nextButton_vip );

					}
				}


			}

			@Override
			public void beforeTextChanged( CharSequence s, int start, int count, int after )
			{
			}

			@Override
			public void afterTextChanged( Editable s )
			{
				if(Config.HIDE_USERS_PII_DATA&&!Config.RESET_FIELD_EMAIL&&!Config.EMAIL_ADDRESS.equals("")){
					editTextEmail_vip.getText().clear();
					Config.RESET_FIELD_EMAIL=true;
				}
				else {
					if(editTextEmail_vip.getText().toString().equals("")){
						checkbox_email_vip.setChecked(false);
					}
				}
			}
		} );
	}
	private void verifyMobileNumberFormat() {

		if(Config.VIDEO_IDENT_PLUS){

			String e164 = Util_Util.formatValidE164(String.valueOf(Config.USER_PHONE_NO), Locale.getDefault());

			editTextMobileNr_vip.setText(Config.USER_PHONE_NO);

			if (e164 != null && !e164.equals(Config.USER_PHONE_NO)) {
				if (Util_Util.isPhoneValid(e164)) {
					editTextMobileNr_vip.setText(e164);
					displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_NOTIF_TITLE,LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE), Util_Strings.getStringWithDefault(this, KEY_LABEL_PHONE_VALIDATION_CORRECTED, LOCAL_LABEL_PHONE_VALIDATION_CORRECTED));
				} else {
					handleInvalidPhoneNumber();
				}

			} else if (e164 == null) {
				handleInvalidPhoneNumber();
			} else {
				// Input OK
				editTextMobileNr_vip.setText(e164);
				Config.USER_PHONE_NO = e164;
				checkbox_phone_vip.setChecked(true);
			}



		}
		else {
			String e164 = Util_Util.formatValidE164(String.valueOf(Config.USER_PHONE_NO), Locale.getDefault());
			editTextMobileNr.setText(Config.USER_PHONE_NO);

			if (e164 != null && !e164.equals(Config.USER_PHONE_NO)) {
				if (Util_Util.isPhoneValid(e164)) {
					editTextMobileNr.setText(e164);
					displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_NOTIF_TITLE,LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE), Util_Strings.getStringWithDefault(this, KEY_LABEL_PHONE_VALIDATION_CORRECTED, LOCAL_LABEL_PHONE_VALIDATION_CORRECTED));
				} else {
					handleInvalidPhoneNumber();
				}

			} else if (e164 == null) {
				handleInvalidPhoneNumber();
			} else {
				// Input OK
				editTextMobileNr.setText(e164);
				Config.USER_PHONE_NO = e164;
				Util_UtilUI.setCheckMark(imageViewMobileNr, true);
				imageViewMobileNr.setTag(true);
				if(Config.CHECKBOX_INSTRUCTIONS_SCREEN) {
					imageViewMobileNr.setVisibility( View.VISIBLE );
				}
			}
		}
	}
	private void handleInvalidPhoneNumber() {
		imageViewMobileNr.setTag(false);
		imageViewMobileNr.setVisibility(View.VISIBLE);
		editTextMobileNr.setError(getString(R.string.wrong_entry));
		displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_COMMON_ERROR,LOCAL_KEY_VIDEO_IDENT_COMMON_ERROR), Util_Strings.getStringWithDefault(this, KEY_LABEL_PHONE_VALIDATION_ERROR, LOCAL_LABEL_PHONE_VALIDATION_ERROR));
		editTextMobileNr.requestFocus();
	}

	private void displayInvalidNumberDialog(String title, String message) {


		if(Config.VIDEO_IDENT_PLUS){
			AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle))
					.setTitle(title)
					.setMessage(message)
					.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int id) {
							dialog.cancel();
							editTextMobileNr_vip.requestFocus();
							editTextMobileNr_vip.postDelayed(new Runnable() {

								@Override
								public void run() {
									InputMethodManager keyboard = (InputMethodManager)
											getSystemService(Context.INPUT_METHOD_SERVICE);
									if(keyboard != null) {
										keyboard.showSoftInput(editTextMobileNr_vip, 0);
									}
								}
							},300);
						}
					});

			alertDialogBuilder.show();
		}
		else {
			AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle))
					.setTitle(title)
					.setMessage(message)
					.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int id) {
							dialog.cancel();
							editTextMobileNr.requestFocus();
							editTextMobileNr.postDelayed(new Runnable() {

								@Override
								public void run() {
									InputMethodManager keyboard = (InputMethodManager)
											getSystemService(Context.INPUT_METHOD_SERVICE);
									if(keyboard != null) {
										keyboard.showSoftInput(editTextMobileNr, 0);
									}
								}
							},300);
						}
					});

			alertDialogBuilder.show();
		}


	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		View view = getCurrentFocus();

		if (ev.getAction() == ACTION_DOWN) {
			if (view != null && view instanceof EditText) {
				Rect r = new Rect();
				view.getGlobalVisibleRect(r);
				int rawX = (int)ev.getRawX();
				int rawY = (int)ev.getRawY();
				if (!r.contains(rawX, rawY)) {
					view.clearFocus();
				}
			}
		}

		return super.dispatchTouchEvent(ev);
	}

	private void handleTermsOfUseUrlsAndTexts() {

		textViewTerms = findViewById(R.id.textViewTerms);
		final String termsUrl = Util_Strings.getStringWithDefault(this, KEY_LINK_TERMS_OF_USE, LOCAL_LINK_TERMS_OF_USE);
		final String privacyUrl = Util_Strings.getStringWithDefault(this, KEY_LINK_PRIVACY_POLICY, LOCAL_LINK_PRIVACY_POLICY);

		TextView textViewTermsOfUse = null;
		TextView textViewPrivacyPolicy = null;

		if(Config.VIDEO_IDENT_PLUS){
			textViewTermsOfUse = findViewById(R.id.textViewTermsOfUse_vip);
			textViewPrivacyPolicy = findViewById(R.id.textViewPrivacyPolicy_vip);
		}
		else {
			textViewTermsOfUse = findViewById(R.id.textViewTermsOfUse);
			textViewPrivacyPolicy = findViewById(R.id.textViewPrivacyPolicy);
		}

		if (Config.ONE_LINE_AGB) {
			textViewTerms.setVisibility(View.GONE);
			textViewTermsOfUse.setVisibility(View.GONE);
			textViewPrivacyPolicy.setVisibility(View.GONE);

			ClickableTextView oneLineAGB = findViewById(R.id.oneLineAGB);
			oneLineAGB.setVisibility(View.VISIBLE);

			String message = Util_Strings.getStringWithDefault(this, KEY_LABEL_TERMS, null);
			String agbName = Util_Strings.getStringWithDefault(this, KEY_LABEL_TERMS_OF_USE, null);
			String privacyName = Util_Strings.getStringWithDefault(this, KEY_LABEL_PRIVACY_POLICY, null);

			SpannableString ss = new SpannableString(message);
			ClickableSpan clickableSpanAgb = new ClickableSpan() {
				@Override
				public void onClick(View textView) {
					Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(termsUrl));
					startActivity(browserIntent);
				}
			};
			int agbStart = message.indexOf(agbName);
			ss.setSpan(clickableSpanAgb, agbStart, agbStart + agbName.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

			ClickableSpan clickableSpanPrivPolicy = new ClickableSpan() {
				@Override
				public void onClick(View textView) {
					Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(privacyUrl));
					startActivity(browserIntent);
				}
			};
			int privacyStart = message.indexOf(privacyName);
			ss.setSpan(clickableSpanPrivPolicy, privacyStart, privacyStart + privacyName.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
			oneLineAGB.setText(ss);
			oneLineAGB.setMovementMethod(LinkMovementMethod.getInstance());
		} else {

			textViewTerms.setText(Util_Strings.getStringWithDefault(this, KEY_LABEL_TERMS, LOCAL_LABEL_TERMS));

			String termsText = Util_Strings.getStringWithDefault(this, KEY_LABEL_TERMS_OF_USE, LOCAL_LABEL_TERMS_OF_USE);
			String termsFormattedText = "<a href=\"" + termsUrl + "\">" + termsText + "</a>";

			Spannable s = (Spannable) Html.fromHtml(termsFormattedText);
			for (URLSpan u: s.getSpans(0, s.length(), URLSpan.class)) {
				s.setSpan(new UnderlineSpan() {
					public void updateDrawState(TextPaint tp) {
						tp.setUnderlineText(false);
					}
				}, s.getSpanStart(u), s.getSpanEnd(u), 0);
			}
			textViewTermsOfUse.setText(s);
			textViewTermsOfUse.setMovementMethod(LinkMovementMethod.getInstance());

			final Uri termsUri = Uri.parse(termsUrl);
			textViewTermsOfUse.setOnClickListener(v -> {
				Intent browserIntent = new Intent(Intent.ACTION_VIEW, termsUri);
				startActivity(browserIntent);
			});
			// styling the link
			textViewTermsOfUse.setLinkTextColor(getResources().getColor(R.color.overview_screen_consent_terms_of_service_text_color));

			String privacyText = Util_Strings.getStringWithDefault(this, KEY_LABEL_PRIVACY_POLICY, LOCAL_LABEL_PRIVACY_POLICY);
			String privacyFormattedText = "<a href=\"" + privacyUrl + "\">" + privacyText + "</a>";

			s = (Spannable) Html.fromHtml(privacyFormattedText);
			for (URLSpan u: s.getSpans(0, s.length(), URLSpan.class)) {
				s.setSpan(new UnderlineSpan() {
					public void updateDrawState(TextPaint tp) {
						tp.setUnderlineText(false);
					}
				}, s.getSpanStart(u), s.getSpanEnd(u), 0);
			}
			textViewPrivacyPolicy.setText(s);
			textViewPrivacyPolicy.setMovementMethod(LinkMovementMethod.getInstance());

			final Uri privacyPolicyUrl = Uri.parse(privacyUrl);
			textViewPrivacyPolicy.setOnClickListener(v -> {
				Intent browserIntent = new Intent(Intent.ACTION_VIEW, privacyPolicyUrl);
				startActivity(browserIntent);
			});
			// styling the link
			textViewPrivacyPolicy.setLinkTextColor(getResources().getColor(R.color.overview_screen_consent_privacy_policy_text_color));
		}
	}

	private void customizeCheckboxesAndHeadersStyle() {
		if (Config.HEADER_BOLDED) {
			List<Integer> headers = Arrays.asList(R.id.checkScreenMobileNumberHeader, R.id.checkScreenEMailHeader, R.id.checkScreenDocumentDateHeader, R.id.checkScreenDocumentHeader, R.id.checkScreenConsentHeader);
			for (Integer header : headers) {
				TextView textView = findViewById(header);
				textView.setTypeface(textView.getTypeface(), Typeface.BOLD);
			}
		}
		if (Config.CHECK_BOX_ORIENTATION_TOP) {
			List<Integer> checkboxes = Arrays.asList(R.id.imageViewMobileNr, R.id.imageViewEmail, R.id.imageViewId, R.id.skipExpiryDateImageView, R.id.imageViewApproval, R.id.imageViewRecording);
			for (Integer checkbox : checkboxes) {
				ImageView view = findViewById(checkbox);
				LinearLayout.LayoutParams layout = (LinearLayout.LayoutParams) view.getLayoutParams();
				layout.gravity = layout.gravity | Gravity.TOP;
				view.setLayoutParams(layout);
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu( Menu menu )
	{
		if ( IDnowSDK.calledFromIDnowApp( context ) )
		{
			MenuInflater menuInflater = getMenuInflater();
			menuInflater.inflate( R.menu.sdk_main_menu, menu );
			return true;
		}
		return false;
	}

	@Override
	public boolean onOptionsItemSelected( MenuItem item )
	{

		// Switch not possible in library.
		if ( item.getItemId() == R.id.menu_legalnotices )
		{
			Intent legalNoticesIntent = new Intent( context, Activities_LegalNoticesActivity.class );
			startActivityForResult( legalNoticesIntent, IDnowSDK.REQUEST_ID_NOW_SDK );
			return true;
		}
		return super.onOptionsItemSelected( item );
	}

	@Override
	public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
		String dateText = String.format("%02d", dayOfMonth) + "/" + String.format("%02d", month+1) + "/" + year;
		checkScreenDocumentDateText.setText(dateText);
		skipExpiryDateImageView.setTag(false);
		Util_UtilUI.setCheckMark(skipExpiryDateImageView, false);

		if(TextUtils.isEmpty(checkScreenDocumentDateText.getText())) {
			return;
		}

		Calendar today = Calendar.getInstance();
		today.set(Calendar.HOUR_OF_DAY, 0);
		today.set(Calendar.MINUTE, 0);
		today.set(Calendar.SECOND, 0);
		today.set(Calendar.MILLISECOND, 0);

		try {
			if(new SimpleDateFormat("dd/MM/yyyy").parse(dateText).after(today.getTime())) {
				Util_UtilUI.setCheckMark(imageViewId, true);
				imageViewId.setTag(true);
				checkScreenDocumentDateText.setError(null);
			} else if(new SimpleDateFormat("dd/MM/yyyy").parse(dateText).getTime() == today.getTimeInMillis()) {
				Util_UtilUI.setCheckMark( imageViewId, false);
				imageViewId.setTag(false);
				checkScreenDocumentDateText.setError(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EXPIRTY_DATE_TODAY,LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EXPIRTY_DATE_TODAY));
				checkScreenDocumentDateText.requestFocus();
			} else {
				Util_UtilUI.setCheckMark( imageViewId, false);
				imageViewId.setTag(false);
				checkScreenDocumentDateText.setError(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_INVALID,LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_INVALID));
				checkScreenDocumentDateText.requestFocus();
			}
		} catch (ParseException e) {
			Util_Log.e(LOGTAG, "Parse date time text failed", e);
			Util_UtilUI.setCheckMark( imageViewId, false);
			imageViewId.setTag(false);
			checkScreenDocumentDateText.setError(getString(R.string.wrong_entry));
		}

		handleIdentificationButtonActivation();
	}

	@Override
	public boolean onTouch(View view, MotionEvent motionEvent) {
		return false;
	}
}
