package de.idnow.sdk.Adapters;

import static de.idnow.sdk.util.Util_PhotoDataHolder.DocumentImages.face;
import static de.idnow.sdk.util.Util_PhotoDataHolder.DocumentImages.idbackside;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_Super;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Models_DocumentInfo;
import de.idnow.sdk.network.Callback;
import de.idnow.sdk.network.IDnowRestClient;
import de.idnow.sdk.network.Network_RESTCalls;
import de.idnow.sdk.network.RetrofitError;
import de.idnow.sdk.util.Util_PhotoDataHolder;
import de.idnow.sdk.util.Util_PhotoStrings;
import de.idnow.sdk.util.Util_Util;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.helper.ImageHelper;
import retrofit2.Response;


public class IDnowListDocumentAdapter extends RecyclerView.Adapter<IDnowListDocumentAdapter.DocumentViewHolder> {

    private final String LOGTAG = "IDNOW_IDnowListDocumentAdapter";

    private final LayoutInflater layoutInflater;
    private List<String> listDocuments = new ArrayList<>();
    private final int selectedPosition = -1;
    private DocumentItemClickListener documentItemClickListener;
    public Context context;

    public Models_DocumentInfo models_documentInfo = new Models_DocumentInfo();


    public IDnowListDocumentAdapter(@NonNull Context context, List<String> data) {

        layoutInflater = LayoutInflater.from(context);
        this.listDocuments = data;
        this.context = context;
    }

    public void setDocumentItemClickListener(DocumentItemClickListener documentItemClickListener) {
        this.documentItemClickListener = documentItemClickListener;
    }

    @NonNull
    @Override
    public DocumentViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = layoutInflater.inflate(R.layout.idnow_document_item_layout, viewGroup, false);
        return new DocumentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DocumentViewHolder documentViewHolder, int i) {
        String document = listDocuments.get(i);

        documentViewHolder.documentText.setText(document);

        if(Config.DARK_MODE){
            Util_UtilUI.setColorLottieAnimation(R.color.text_color_coba,documentViewHolder.documentImage,"Primary");
            if((document.equals(Util_PhotoStrings.getIdcard(context)))){
                documentViewHolder.documentImage.setAnimation("static_badge_id_card.json");
                documentViewHolder.documentImage.playAnimation();
            }
            else
               if(document.equals(Util_PhotoStrings.getResidencepermit(context))){
                documentViewHolder.documentImage.setAnimation("static_badge_residency_permit.json");
                documentViewHolder.documentImage.playAnimation();
            }
            else if(document.equals(Util_PhotoStrings.getPassport(context))){
                documentViewHolder.documentImage.setAnimation("static_badge_passport.json");
                documentViewHolder.documentImage.playAnimation();
            }
            else {
                documentViewHolder.documentImage.setAnimation("static_badge_driving_license.json");
                documentViewHolder.documentImage.playAnimation();
            }
        }
        else {
            if((document.equals(Util_PhotoStrings.getIdcard(context)))){
                documentViewHolder.documentImage.setAnimation("static_badge_id_card.json");
                documentViewHolder.documentImage.playAnimation();
                Util_UtilUI.setColorLottieAnimation(Color.GRAY,documentViewHolder.documentImage,"Primary");
            }
             else if(document.equals(Util_PhotoStrings.getResidencepermit(context))){
                documentViewHolder.documentImage.setAnimation("static_badge_residency_permit.json");
                documentViewHolder.documentImage.playAnimation();
                Util_UtilUI.setColorLottieAnimation(Color.GRAY,documentViewHolder.documentImage,"Primary");
            }
            else if(document.equals(Util_PhotoStrings.getPassport(context))){
                documentViewHolder.documentImage.setAnimation("static_badge_passport.json");
                documentViewHolder.documentImage.playAnimation();
                Util_UtilUI.setColorLottieAnimation(Color.GRAY,documentViewHolder.documentImage,"Primary");
            }
            else {
                documentViewHolder.documentImage.setAnimation("static_badge_driving_license.json");
                documentViewHolder.documentImage.playAnimation();
                Util_UtilUI.setColorLottieAnimation(Color.GRAY,documentViewHolder.documentImage,"Primary");
            }
        }

    }

    @Override
    public int getItemCount() {
        return listDocuments.size();    }

    public interface DocumentItemClickListener {
        void onDocumentItemClick(int position);
    }

    class DocumentViewHolder extends RecyclerView.ViewHolder {
        TextView documentText;
        LottieAnimationView documentImage;

        DocumentViewHolder(View itemView) {
            super(itemView);
            documentText = itemView.findViewById(R.id.document_item);
            documentImage = itemView.findViewById(R.id.document_image);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    models_documentInfo.setIdCountry(getCountryCode(Config.VIDEO_IDENT_PLUS_COUNTRY));

                    if(documentText.getText().toString().equals(context.getString(R.string.photo_ident_ic_card))){
                        models_documentInfo.setIdType("idcard");
                    }
                    else
                    if(documentText.getText().toString().equals(context.getString(R.string.photo_ident_residence_permit))){
                        models_documentInfo.setIdType("residencepermit");
                    }
                    else
                    if(documentText.getText().toString().equals(context.getString(R.string.photo_ident_driving_license))){
                        models_documentInfo.setIdType("driverslicense");
                    }
                    else
                    if(documentText.getText().toString().equals(context.getString((R.string.photo_ident_passport)))){
                        models_documentInfo.setIdType("passport");
                    }
                    else {
                        models_documentInfo.setIdType(documentText.getText().toString());
                    }
                    sendIDInfo(models_documentInfo);

                }
            });
        }

        private void sendIDInfo(Models_DocumentInfo models_documentInfo)
        {
            String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
            Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

            Callback<Object> callback = new Callback<Object>()
            {
                @Override
                public void failure( RetrofitError error )
                {
                    ((Activities_VideoLiveStreamActivity_Super)context).updateErrorScreen(false);

                }

                @Override
                public void success( Object resultObject, Response response )
                {
                    Util_Util.hideSoftKeyboard(((Activities_VideoLiveStreamActivity_Super)context));

                    if(Config.MISSING_IMAGES.equals(2)){
                        if(((Activities_VideoLiveStreamActivity_Super)context).video_ident_plus_layout_retry_flow!=null&&((Activities_VideoLiveStreamActivity_Super)context).video_ident_plus_layout!=null){
                            ((Activities_VideoLiveStreamActivity_Super)context).video_ident_plus_layout_retry_flow.setVisibility(View.GONE);
                            ((Activities_VideoLiveStreamActivity_Super)context).video_ident_plus_layout.setVisibility(View.VISIBLE);
                        }
                    }

                    if(Config.MISSING_IMAGES.equals(1)||Config.MISSING_IMAGES.equals(0)){

                        if(Config.ONLY_BACK_SIDE_NULL){

                            ((Activities_VideoLiveStreamActivity_Super)context).sendUploadPhoto(ImageHelper.INSTANCE.readAsBase64(((Activities_VideoLiveStreamActivity_Super)context).selfiefilename, 90), face);

                        }
                        else {
                            ((Activities_VideoLiveStreamActivity_Super)context).sendUploadPhoto(ImageHelper.INSTANCE.readAsBase64(((Activities_VideoLiveStreamActivity_Super)context).backfilename, 90), idbackside);
                        }
                    }
                    else {
                            ((Activities_VideoLiveStreamActivity_Super)context).dismissProgressDialog();

                        if(documentText.getText().toString().equals(context.getString(R.string.photo_ident_passport))){
                            Config.DOCUMENT_TYPES = Util_PhotoDataHolder.DocumentTypes.passport;
                            if(Config.VIDEO_IDENT_PLUS_SELFIE_IMAGE){
                                ((Activities_VideoLiveStreamActivity_Super)context).setRightScreen(Util_PhotoDataHolder.DocumentImages.face,false);
                            }else {
                                ((Activities_VideoLiveStreamActivity_Super)context).setRightScreen(Util_PhotoDataHolder.DocumentImages.agent,false);
                            }
                        }
                        else {
                            ((Activities_VideoLiveStreamActivity_Super)context).setRightScreen(Util_PhotoDataHolder.DocumentImages.idbackside,false);
                        }
                    }




                }
            };


        retrofit2.Call<Object> result = service.uploadDocumentInfo(models_documentInfo,IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        result.enqueue(callback);

        }



        public String getCountryCode(String countryName) {

            // Get all country codes in a string array.
            String[] isoCountryCodes = Locale.getISOCountries();
            Map<String, String> countryMap = new HashMap<>();
            Locale locale;
            String name;

            // Iterate through all country codes:
            for (String code : isoCountryCodes) {
                // Create a locale using each country code
                locale = new Locale("", code);
                // Get country name for each code.
                name = locale.getDisplayCountry();
                // Map all country names and codes in key - value pairs.
                countryMap.put(name, code);
            }

            // Return the country code for the given country name using the map.
            // Here you will need some validation or better yet
            // a list of countries to give to user to choose from.
            return countryMap.get(countryName); // "NL" for Netherlands.
        }
    }
}
