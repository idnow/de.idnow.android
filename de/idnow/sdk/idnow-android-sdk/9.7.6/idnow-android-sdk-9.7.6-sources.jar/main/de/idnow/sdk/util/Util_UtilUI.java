package de.idnow.sdk.util;

import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP;
import static de.idnow.sdk.IDnowSDK.RESULT_CODE_CANCEL;
import static de.idnow.sdk.IDnowSDK.RESULT_ERROR_CODE;
import static de.idnow.sdk.IDnowSDK.RESULT_SERVER_STATUS_CODE;
import static de.idnow.sdk.util.IDnowExternalLog.logExternally;
import static de.idnow.sdk.util.Util_Strings.*;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.hardware.Camera;
import android.net.Uri;
import android.provider.Settings;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.SimpleLottieValueCallback;

import de.idnow.sdk.Activities.Activities_AgentFeedbackActivity;
import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_LIVESWITCH;
import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_Super;
import de.idnow.sdk.Activities.Activities_VideoOverviewCheckActivity;
import de.idnow.sdk.Activities.entry.Activities_EntryActivity;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.Interface_VideoLiveStream;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Models_MobileStoreLinks;
import de.idnow.sdk.util.ui.ViewHelper;


/**
 * @author Mathias Grasy
 * @version 1.0
 */
public class Util_UtilUI {
    private static final String LOGTAG = "IDNOW_Util_UtilUI";
    private static String errorDialogMessage = "";

    public static Point getDisplayDimensions(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        return size;
    }

    public static int getPxFromDp(Context context, int dp) {
        Resources r = context.getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }

    /**
     * gets called by getWebsocketRestCall()
     *
     * @param context
     * @param closeActivityWhenFailure
     */
    public static void showLiveStreamErrorDialog(final Context context, final boolean closeActivityWhenFailure) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTION_ERROR_TITLE, LOCAL_KEY_VIDEO_IDENT_CONNECTION_ERROR_TITLE))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTION_ERROR_DESC, LOCAL_KEY_VIDEO_IDENT_CONNECTION_ERROR_DESC))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.cancel();
                        if (closeActivityWhenFailure && context instanceof Interface_VideoLiveStream) {
                            ((Interface_VideoLiveStream) context).identificationFailedRESTCall();
                        }
                    }

                });

        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    private static int getStyle() {
        int style;

        if (!Config.DARK_MODE_ENABLED_CUSTOMER) {
            style = R.style.IDnowAlertDialogStyleForcedDark;
        } else {
            style = R.style.IDnowAlertDialogStyle;
        }
        return style;
    }

    public static void showBluetoothNotPossible(final Context context, final boolean closeActivityWhenFailure) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTION_ERROR_TITLE, LOCAL_KEY_VIDEO_IDENT_CONNECTION_ERROR_TITLE))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_BLUETOOTH_ERROR, LOCAL_KEY_VIDEO_IDENT_BLUETOOTH_ERROR))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        IDnowSDK.getInstance().setResultErrorCode(IDnowErrorCode.IDnowErrorUnsupportedBluetoothHeadset);
                        IDnowSDK.getInstance().setStartCallIssued(false);
                        Config.CALL_QUALITY_CHECK_PASSED = false;
                        if (closeActivityWhenFailure && context instanceof Interface_VideoLiveStream) {
                            ((Interface_VideoLiveStream) context).identificationFailedRESTCall();
                        }
                    }

                });

        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }


    private static void showAlertDialogIfActivityIsInTheProcessOfFinishing(final Context context, AlertDialog alertDialog) {
        if (context instanceof Activity && !((Activity) context).isFinishing()) {
            Util_UtilUI.showBrandedDialog(alertDialog);
        }
    }

    public static void showMessageOKCancel(final Context context, String message, DialogInterface.OnClickListener okListener) {
        AlertDialog alertDialog = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setMessage(message)
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), okListener)
                .setCancelable(false)
                .setNegativeButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_CANCEL, LOCAL_KEY_VIDEO_IDENT_COMMON_CANCEL), new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Intent backPressedIntent = new Intent();
                        backPressedIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, context.getString(IDnowSDK.MESSAGE_USER_CANCELED));
                        backPressedIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        if (context instanceof Activity) {
                            Activity activity = (Activity) context;
                            activity.setResult(IDnowSDK.RESULT_CODE_CANCEL, backPressedIntent);
                            IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_CANCEL, backPressedIntent);
                            Util_Util.clearApplicationData(context);
                            activity.finish();
                        }
                    }
                }).create();

        Util_UtilUI.showBrandedDialog(alertDialog, null);
    }

    public static void showDocumentNotUploaded(final Context context, String message) {
        AlertDialog alertDialog = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_ERROR, LOCAL_KEY_VIDEO_IDENT_COMMON_ERROR))
                .setMessage(message)
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        Intent backPressedIntent = new Intent();
                        backPressedIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, context.getString(IDnowSDK.MESSAGE_USER_CANCELED));
                        backPressedIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        if (context instanceof Activity) {
                            Activity activity = (Activity) context;
                            activity.setResult(IDnowSDK.RESULT_CODE_CANCEL, backPressedIntent);
                            IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_CANCEL, backPressedIntent);
                            Util_Util.clearApplicationData(context);
                            activity.finish();
                        }
                    }

                }).create();
        Util_UtilUI.showBrandedDialog(alertDialog, null);
    }

    public static void showMessageOK(Context context, String message, DialogInterface.OnClickListener okListener) {
        AlertDialog alertDialog = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setMessage(message)
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_CANCEL, LOCAL_KEY_VIDEO_IDENT_COMMON_CANCEL), okListener).create();

        Util_UtilUI.showBrandedDialog(alertDialog, null);
    }

    /**
     * when device version is 4.0.3 or 4.0.4 pdf.js will not work. instead a blank page is shown. inform the user about this circumstance by displaying a dialog
     *
     * @param context
     */
    public static void showPDFWarningDialog(final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ESIGN_CONTRACT_WARNING_TITLE, LOCAL_KEY_VIDEO_IDENT_ESIGN_CONTRACT_WARNING_TITLE))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ESIGN_CONTRACT_WARNING_CONTENT, LOCAL_KEY_VIDEO_IDENT_ESIGN_CONTRACT_WARNING_CONTENT))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_CONTINUE, LOCAL_KEY_VIDEO_IDENT_COMMON_CONTINUE), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        if (Config.INSTANT_SIGN) {
                            ((Activities_VideoOverviewCheckActivity) context).updatePhoneNumber(Config.USER_PHONE_NO);

                        } else {
                            ((Activities_VideoOverviewCheckActivity) context).makeStartRESTCall(true);
                            dialog.cancel();
                        }
                    }

                })
                .setNegativeButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_CANCEL, LOCAL_KEY_VIDEO_IDENT_COMMON_CANCEL), new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ((Activities_VideoOverviewCheckActivity) context).progressBar.setVisibility(View.GONE);
                        dialog.cancel();
                    }
                });

        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showCameraFailedErrorDialog(final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CAMERA_ERROR, LOCAL_KEY_VIDEO_IDENT_CAMERA_ERROR))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CAMERA_ERROR_DESC, LOCAL_KEY_VIDEO_IDENT_CAMERA_ERROR_DESC))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        Intent noConnectionIntent = new Intent();
                        noConnectionIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, context.getResources().getString(R.string.dialog_error_camera_content));
                        noConnectionIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        noConnectionIntent.putExtra(RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorNoInternetConnection);
                        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, noConnectionIntent);
                        ((Activity) context).setResult(IDnowSDK.RESULT_CODE_FAILED, noConnectionIntent);
                        ((Activities_VideoLiveStreamActivity_Super) context).finish();
                    }

                });

        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }


    public static AlertDialog showLiveswitchConnectionLossDialog(final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_LIVESWITCH_CONNECTION_ERROR, LOCAL_KEY_VIDEO_IDENT_LIVESWITCH_CONNECTION_ERROR))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_LIVESWITCH_CONNECTION_ERROR_ABORT, LOCAL_KEY_VIDEO_IDENT_LIVESWITCH_CONNECTION_ERROR_ABORT), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        // if user wants to abort the process, he has to confirm once more he really wants to abort
                        showCancelIdentificationDialog(context, true);
                    }

                });

        // create alert dialog
        final AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        return alertDialog;
    }

    public static AlertDialog showWaitingScreenDialog(final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_CUSTOMISED_WAITING_SCREEN_POPUP_TITLE, LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_POPUP_TITLE))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_CUSTOMISED_WAITING_SCREEN_POPUP_DESC, LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_POPUP_DESC))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_CUSTOMISED_WAITING_SCREEN_POPUP_QUIT, LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_POPUP_QUIT), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        IDnowSDK.getInstance().setStartCallIssued(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).stopTimer();
                        if (context instanceof Interface_VideoLiveStream) {
                            ((Interface_VideoLiveStream) context).identificationCanceled();
                        }
                    }

                })
                .setNegativeButton(Util_Strings.getStringWithDefault(context, KEY_CUSTOMISED_WAITING_SCREEN_POPUP_WAIT, LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_POPUP_WAIT), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        // if user wants to abort the process, he has to confirm once more he really wants to abort
                    }

                });

        // create alert dialog
        final AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.setCanceledOnTouchOutside(false);

        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialog);

        return alertDialog;
    }

    public static void showMatchingValidationError(final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()));
        builder.setTitle(getStringWithDefault(context, KEY_VIDEO_IDENT_RESULT_FAILED_TITLE, LOCAL_KEY_VIDEO_IDENT_RESULT_FAILED_TITLE))
                .setMessage(getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_MATCHING_VALIDATION, LOCAL_KEY_VIDEO_IDENT_ERROR_MATCHING_VALIDATION))
                .setPositiveButton(getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(context, Config.HOST_APP_START_ACTIVITY);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP);

                        IDnowSDK.updateResultCode(IDnowSDK.RESULT_CODE_CANCEL);
                        IDnowSDK.getInstance().deliverResult(RESULT_CODE_CANCEL, intent);

                        Activity activity = (Activity) context;
                        activity.setResult(IDnowSDK.RESULT_CODE_CANCEL, intent);
                        activity.finish();

                        if (activity instanceof Activities_VideoLiveStreamActivity_LIVESWITCH)
                            Util_IdentSessionAssistant.getInstance().indicateSessionStopped(IDnowSDK.SessionType.VIDEO_IDENT);

                        context.startActivity(intent);
                    }
                });

        AlertDialog alertDialog = builder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        showBrandedDialog(alertDialog);
    }

    public static void showNoConnectionDialog(final Context context, final boolean closeActivityWhenFailure) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()));
        alertDialogBuilder.setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_NETWORK_CONNECTION_FAILURE, LOCAL_KEY_VIDEO_IDENT_NETWORK_CONNECTION_FAILURE))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.cancel();
                        if (closeActivityWhenFailure) {
                            Intent noConnectionIntent = new Intent();
                            noConnectionIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, context.getString(IDnowSDK.MESSAGE_ID_FAILED_NO_CONNECTION));
                            noConnectionIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                            noConnectionIntent.putExtra(RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorNoInternetConnection);
                            if (context instanceof Activity) {
                                Activity activity = (Activity) context;
                                IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, noConnectionIntent);
                                activity.setResult(IDnowSDK.RESULT_CODE_FAILED, noConnectionIntent);
                                activity.finish();
                            }
                        }
                    }
                });

        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showLinkAutoIdent(final Models_MobileStoreLinks models_mobileStoreLinks, String message_autoident, final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()));
        alertDialogBuilder.setMessage(message_autoident)
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_YES, LOCAL_KEY_VIDEO_IDENT_COMMON_YES), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + models_mobileStoreLinks.getAndroidPackage())));
                        Intent restCallErrorIntent = new Intent();
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorTokenNotSupported);
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, context.getResources().getString(IDnowSDK.MESSAGE_ID_FAILED));
                        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).setResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).finish();
                    }

                })
                .setNegativeButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_NO, LOCAL_KEY_VIDEO_IDENT_COMMON_NO), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        Intent restCallErrorIntent = new Intent();
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorTokenNotSupported);
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, context.getResources().getString(IDnowSDK.MESSAGE_ID_FAILED));
                        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).setResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).finish();
                    }
                });
        alertDialogBuilder.setCancelable(false);
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showAgentRatingFailedErrorDialog(final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_AGENT_FEEDBACK_DIALOG_TITLE, LOCAL_KEY_AGENT_FEEDBACK_DIALOG_TITLE))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_AGENT_FEEDBACK_DIALOG_CONTENT, LOCAL_KEY_AGENT_FEEDBACK_DIALOG_CONTENT))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        IDnowSDK.getInstance().setStartCallIssued(false);
                        Config.CALL_QUALITY_CHECK_PASSED = false;
                        if (context instanceof Activities_AgentFeedbackActivity) {
                            ((Activities_AgentFeedbackActivity) context).openResultActivity(IDnowSDK.RESULT_CODE_FAILED);
                        }
                    }
                })
                .setNegativeButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN, LOCAL_KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });


        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    /**
     * is called by REST calls that failed
     *
     * @param context
     * @param responseCode
     * @param retryAllowed
     * @param runnable                  to call when user selected the "retry" option
     * @param id
     * @param finishActivityAfterDialog
     * @param resultError
     */
    public static void showRESTCallErrorDialog(final Context context, final int responseCode, boolean retryAllowed, final Runnable runnable, String id, boolean finishActivityAfterDialog, final boolean activeVideoCall, String resultError) {
        errorDialogMessage = Util_Strings.getErrorMessageForResponseCode(context, responseCode, id, resultError);

        if (responseCode == 400) {
            //
        } else if (responseCode == 404) {
            //
        } else if (responseCode == 410) {
            retryAllowed = false;
        } else if (responseCode == 412) {
            retryAllowed = false;
        }

        // if server returns error code 500, don't allow a retry
        else if (responseCode == 500) {
            retryAllowed = false;
        } else if (responseCode == 503) {
            retryAllowed = false;
        }

        final boolean finishActivity = finishActivityAfterDialog;


        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()));
        alertDialogBuilder.setTitle(R.string.result_screen_status_failed)
                .setMessage(errorDialogMessage)
                .setCancelable(false)
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.cancel();
                        if (finishActivity) {
                            if (activeVideoCall) {
                                if (context instanceof Interface_VideoLiveStream) {
                                    ((Interface_VideoLiveStream) context).identificationFailedRESTCall();
                                }
                            } else {
                                IDnowSDK.updateResultCode(IDnowSDK.RESULT_CODE_FAILED);
                                Intent restCallErrorIntent = new Intent();
                                restCallErrorIntent.putExtra(IDnowSDK.RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorServer);
                                restCallErrorIntent.putExtra(IDnowSDK.RESULT_SERVER_STATUS_CODE, responseCode);
                                restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                                restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, errorDialogMessage);
                                if (responseCode == 404) {
                                    IDnowSDK.updateResultCode(IDnowSDK.RESULT_CODE_WRONG_IDENT);
                                    IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_WRONG_IDENT, restCallErrorIntent);
                                    ((Activity) context).setResult(IDnowSDK.RESULT_CODE_WRONG_IDENT, restCallErrorIntent);
                                } else {
                                    IDnowSDK.updateResultCode(IDnowSDK.RESULT_CODE_FAILED);
                                    IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                                    ((Activity) context).setResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);

                                }
                                ((Activity) context).finish();
                            }
                        }
                    }
                });

        if (retryAllowed) {
            alertDialogBuilder.setNeutralButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN, LOCAL_KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN), new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {

                    dialog.cancel();
                    if (runnable != null) {
                        runnable.run();
                    }
                }
            });
        }
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showDeviceRootedDialog(final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_DIALOG_JAILBREAK_TITLE, LOCAL_KEY_VIDEO_IDENT_DIALOG_JAILBREAK_TITLE))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_DIALOG_JAILBREAK_MESSAGE, LOCAL_KEY_VIDEO_IDENT_DIALOG_JAILBREAK_MESSAGE))
                //.setIcon(context.getResources().getDrawable(de.idnow.sdk.R.drawable.ic_launcher))
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        Intent restCallErrorIntent = new Intent();
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorRootedPhoneNotSupported);
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, errorDialogMessage);
                        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).setResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).finish();
                    }

                });

        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showRESTCallPhotoErrorDialog(final Context context, int responseCode, final Runnable runnable, String id, boolean retryAllowed) {
        errorDialogMessage = "";

        if (responseCode == 401) {
            errorDialogMessage = Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_401, LOCAL_KEY_VIDEO_IDENT_ERROR_401);
            retryAllowed = false;
        } else if (responseCode == 410) {
            errorDialogMessage = Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_410, LOCAL_KEY_VIDEO_IDENT_ERROR_410);
            retryAllowed = false;
        }

        // if server returns error code 500, don't allow retry
        else if (responseCode == 500) {
            errorDialogMessage = Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_500, LOCAL_KEY_VIDEO_IDENT_ERROR_500);
            retryAllowed = false;
        } else if (responseCode == 503) {
            errorDialogMessage = Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_503, LOCAL_KEY_VIDEO_IDENT_ERROR_503);
            retryAllowed = false;
        } else {
            errorDialogMessage = Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_DIALOG_ERROR, LOCAL_KEY_VIDEO_IDENT_DIALOG_ERROR);
        }

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setMessage(errorDialogMessage)
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_CANCEL, LOCAL_KEY_VIDEO_IDENT_COMMON_CANCEL), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        Intent restCallErrorIntent = new Intent();
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, errorDialogMessage);
                        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).setResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).finish();
                    }

                });

        if (retryAllowed) {
            alertDialogBuilder.setNeutralButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN, LOCAL_KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN), new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                    runnable.run();
                }
            });
        }

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.setCanceledOnTouchOutside(false);

        if (context instanceof Activity && !((Activity) context).isFinishing()) {
            Util_UtilUI.showBrandedDialog(alertDialog);
        }
    }

    private static void linkToPlayStore(Context context) {
        final String appPackageName = context.getPackageName();
        try {
            // directly open app with Play Store app
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
        } catch (ActivityNotFoundException e) {
            // if Play Store app is not installed, trigger Play Store URL (user can choose an app to open it with)
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + appPackageName)));
        }
    }

    /**
     * gets called during the video session by the reconnect runnable when reconnecting is not possible
     *
     * @param context
     * @param retryAvailable
     * @param runnable       to call, when retry is triggered
     */
    public static void showVideoErrorDialog(final Context context, boolean retryAvailable, final Runnable runnable) {
        String message = "";
        String positiveButtonText = "";


        if (Config.SOCKET_ENABLED) {
            message = Util_Strings.getStringWithDefault(context, KEY_VI_WEBSCOCKET_ERROR_MESSAGE, LOCAL_KEY_VI_WEBSCOCKET_ERROR_MESSAGE);
            positiveButtonText = Util_Strings.getStringWithDefault(context, KEY_VI_WEBSCOCKET_ERROR_ACTION_TRY_LATER, LOCAL_KEY_VI_WEBSCOCKET_ERROR_ACTION_TRY_LATER);

        } else {
            message = Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_DIALOG_VIDEO_ERROR, LOCAL_KEY_VIDEO_IDENT_DIALOG_VIDEO_ERROR);
            positiveButtonText = Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK);

        }

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_RESULT_FAILED_TITLE, LOCAL_KEY_VIDEO_IDENT_RESULT_FAILED_TITLE))
                .setMessage(message)
                .setPositiveButton(positiveButtonText, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                        ((Interface_VideoLiveStream) context).identificationFailedRESTCall();
                    }

                });

        if (retryAvailable || Config.SOCKET_ENABLED) {
            alertDialogBuilder.setNeutralButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN, LOCAL_KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN), new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {

                    dialog.cancel();
                    runnable.run();
                }
            });
        }

        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showCameraAvailableDialog(final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()));
        alertDialogBuilder.setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_DIALOG_NO_CAMERA, LOCAL_KEY_VIDEO_IDENT_DIALOG_NO_CAMERA))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.cancel();
                        Intent noConnectionIntent = new Intent();
                        noConnectionIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, context.getResources().getString(R.string.dialog_error_camera_content));
                        noConnectionIntent.putExtra(RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorCameraAccessNotGranted);
                        noConnectionIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, noConnectionIntent);
                        ((Activity) context).setResult(IDnowSDK.RESULT_CODE_FAILED, noConnectionIntent);
                        ((Activity) context).finish();
                    }
                });

        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());

    }

    /**
     * is called during the video session when the user enters the phone number, email address or the ident-code
     *
     * @param context
     * @param responseCode
     * @param sendCode     if true, then user entered the phone number/email address, if false then user entered the ident-code
     * @param errorId
     */
    public static void showSendingTanErrorDialog(final Context context, int responseCode, boolean sendCode, String errorId, String errorCause, boolean sendTanBySMS) {
        String message;

        if (responseCode == 500) {
            message = Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_500, LOCAL_KEY_VIDEO_IDENT_ERROR_500);
        }
        //TODO replace hardcoded strings with constants / translations
        else if (sendCode && errorCause.equals(IDnowSDK.CONFIRMATION_TOKEN_LIMIT_EXCEEDED)) {
            message = IDnowSDK.getInstance().getStringWithDefault(context, KEY_CONFIRMATION_ATTEMPTS_EXCEEDED, LOCAL_KEY_CONFIRMATION_ATTEMPTS_EXCEEDED);
        } else if (sendCode) {
            message = Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_DIALOG_ERROR_TAN, LOCAL_KEY_VIDEO_IDENT_DIALOG_ERROR_TAN);
        } else if (sendTanBySMS) {
            message = Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_MOBILE_NO, LOCAL_KEY_VIDEO_IDENT_ERROR_MOBILE_NO);
        } else {
            message = Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_EMAIL, LOCAL_KEY_VIDEO_IDENT_ERROR_EMAIL);
        }

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setMessage(message)
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.cancel();
                    }

                });

        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    /**
     * is called during the video session when user clicks the onBackButton
     *
     * @param context
     */
    public static void showCancelIdentificationDialog(final Context context, final boolean openLiveswitchConnectionLossDialog) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CANCEL_ALERT_TITLE, LOCAL_KEY_VIDEO_IDENT_CANCEL_ALERT_TITLE))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CANCEL_ALERT_MSG, LOCAL_KEY_VIDEO_IDENT_CANCEL_ALERT_MSG))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_YES, LOCAL_KEY_VIDEO_IDENT_COMMON_YES), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        IDnowSDK.getInstance().setStartCallIssued(false);
                        if (context instanceof Interface_VideoLiveStream) {
                            ((Interface_VideoLiveStream) context).identificationCanceled();
                        }
                    }

                })
                .setNegativeButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_NO, LOCAL_KEY_VIDEO_IDENT_COMMON_NO), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        // if user first wants to abort the reconnection bug afterwards doesn't want to abort the whole process, show the connectionLossDialog again
                        if (openLiveswitchConnectionLossDialog && context instanceof Activities_VideoLiveStreamActivity_LIVESWITCH) {
                            ((Activities_VideoLiveStreamActivity_LIVESWITCH) context).showConnectionLossDialog();
                        }
                    }
                });

        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showCancelVerificationIdentification(final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VERIFICATION_ALERT_TITLE, LOCAL_KEY_VERIFICATION_ALERT_TITLE))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_VERIFICATION_ALERT_MESSSAGE, LOCAL_KEY_VERIFICATION_ALERT_MESSSAGE))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VERIFICATION_ALERT_QUIT, LOCAL_KEY_VERIFICATION_ALERT_QUIT), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        Intent restCallErrorIntent = new Intent();
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, errorDialogMessage);
                        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_CANCEL, restCallErrorIntent);
                        ((Activity) context).setResult(IDnowSDK.RESULT_CODE_CANCEL, restCallErrorIntent);
                        ((Activity) context).finish();
                        dialog.cancel();
                    }

                })
                .setNegativeButton(Util_Strings.getStringWithDefault(context, KEY_VERIFICATION_ALERT_DISMISS, LOCAL_KEY_VERIFICATION_ALERT_DISMISS), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        // if user first wants to abort the reconnection bug afterwards doesn't want to abort the whole process, show the connectionLossDialog again
                    }
                });

        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showCancelNativeESigningDialog(final Context context, final boolean openLiveswitchConnectionLossDialog) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ESIGN_DIALOG_TITLE, LOCAL_KEY_VIDEO_IDENT_ESIGN_DIALOG_TITLE))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ESIGN_DIALOG_DESC, LOCAL_KEY_VIDEO_IDENT_ESIGN_DIALOG_DESC))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_YES, LOCAL_KEY_VIDEO_IDENT_COMMON_YES), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (Config.INSTANT_SIGN) {
                            ((Interface_VideoLiveStream) context).identificationCanceled();

                        } else {
                            ((Interface_VideoLiveStream) context).signingCanceledRESTCall();
                        }
                    }

                })
                .setNegativeButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_NO, LOCAL_KEY_VIDEO_IDENT_COMMON_NO), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                        ((Activities_VideoLiveStreamActivity_Super) context).closeSocket();

                        dialog.cancel();
                    }
                });

        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showOfficeHoursUnsupportedProductDialog(final Context context, String message) {
        errorDialogMessage = message;
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()));
        alertDialogBuilder.setMessage(message)
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                        Intent restCallErrorIntent = new Intent();
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, errorDialogMessage);
                        restCallErrorIntent.putExtra(RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorOfficeClosed);
                        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).setResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).finish();
                        dialog.cancel();
                    }
                });

        alertDialogBuilder.setCancelable(false);
        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showClassificationFailed(final Context context) {

        errorDialogMessage = "We are not able to classify your document";
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setMessage(errorDialogMessage)
                .setPositiveButton(("Yes"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        ((Activities_VideoLiveStreamActivity_Super) context).video_ident_plus_layout.setVisibility(View.GONE);
                        ((Activities_VideoLiveStreamActivity_Super) context).video_select_document_layout.setVisibility(View.VISIBLE);
                        ((Activities_VideoLiveStreamActivity_Super) context).selectdocumentLayout.setVisibility(View.GONE);
                        ((Activities_VideoLiveStreamActivity_Super) context).document_not_supported_layout.setVisibility(View.VISIBLE);

                        ((Activities_VideoLiveStreamActivity_Super) context).imageViewPhoto.setImageBitmap(null);
                        ((Activities_VideoLiveStreamActivity_Super) context).camera.close();


                        dialog.cancel();

                    }
                })
                .setNegativeButton("Try again", new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ((Activities_VideoLiveStreamActivity_Super) context).video_ident_plus_layout.setVisibility(View.VISIBLE);
                        ((Activities_VideoLiveStreamActivity_Super) context).video_select_document_layout.setVisibility(View.GONE);

                        ((Activities_VideoLiveStreamActivity_Super) context).imageViewPhoto.setImageBitmap(null);
                        ((Activities_VideoLiveStreamActivity_Super) context).camera.open();
                        ((Activities_VideoLiveStreamActivity_Super) context).setRightScreen(Util_PhotoDataHolder.DocumentImages.idfrontside, false);
                        dialog.cancel();
                    }
                });

        alertDialogBuilder.setCancelable(false);
        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());

    }

    public static void showRetryFailed(final Context context, int statusCode) {

        errorDialogMessage = "We are not able to get your images";
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setMessage(errorDialogMessage)
                .setPositiveButton(("Yes"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        Intent restCallErrorIntent = new Intent();
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, errorDialogMessage);
                        restCallErrorIntent.putExtra(RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorServer);
                        restCallErrorIntent.putExtra(RESULT_SERVER_STATUS_CODE, statusCode);
                        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).setResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).finish();
                        dialog.cancel();

                    }
                })
                .setNegativeButton("Try again", new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        alertDialogBuilder.setCancelable(false);
        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());

    }

    public static void showRetryRequest(final Context context) {

        errorDialogMessage = "Now you will proceed to take the pictures that are missing";
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle("Picture Needed")
                .setMessage(errorDialogMessage)
                .setPositiveButton(("Ok"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.cancel();
                        ((Activities_VideoLiveStreamActivity_Super) context).reuseflowAction();

                    }
                });
        alertDialogBuilder.setCancelable(false);
        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());


    }

    public static void showEIDDialog(final Context context, String message) {
        errorDialogMessage = message;
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()));
        alertDialogBuilder.setMessage(message)
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        Intent restCallErrorIntent = new Intent();
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                        restCallErrorIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, errorDialogMessage);
                        restCallErrorIntent.putExtra(RESULT_ERROR_CODE, IDnowErrorCode.IDnowErrorUnsupportedProduct);
                        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).setResult(IDnowSDK.RESULT_CODE_FAILED, restCallErrorIntent);
                        ((Activity) context).finish();
                        dialog.cancel();
                    }
                });

        alertDialogBuilder.setCancelable(false);
        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showWalletAccountExpired(
            final Context context,
            View.OnClickListener onContinueListener) {
        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.alert_idnow_account_expired);

        TextView account_expired_title = dialog.findViewById(R.id.account_expired_title);
        account_expired_title.setText(
                Util_Strings.getStringWithDefault(
                        Util_Strings.KEY_ACCOUNT_EXPIRED_TITLE,
                        Util_Strings.LOCAL_KEY_ACCOUNT_EXPIRED_TITLE
                )
        );

        TextView account_expired_desc = dialog.findViewById(R.id.account_expired_desc);
        account_expired_desc.setText(
                Util_Strings.getStringWithDefault(
                        Util_Strings.KEY_ACCOUNT_EXPIRED_DESC,
                        Util_Strings.LOCAL_KEY_ACCOUNT_EXPIRED_DESC
                )
        );

        TextView account_expired_continue = dialog.findViewById(R.id.account_expired_continue);
        account_expired_continue.setText(
                Util_Strings.getStringWithDefault(
                        Util_Strings.KEY_ACCOUNT_EXPIRED_CONTINUE,
                        Util_Strings.LOCAL_KEY_ACCOUNT_EXPIRED_CONTINUE
                )
        );
        account_expired_continue.setBackgroundResource(R.drawable.rounded_background_orange);

        LottieAnimationView account_expired_animation = dialog.findViewById(R.id.account_expired_animation);
        account_expired_animation.setAnimation("static_time_out.json");
        account_expired_animation.playAnimation();

        account_expired_continue.setOnClickListener(onContinueListener);
        int width = ViewGroup.LayoutParams.WRAP_CONTENT;
        int height = ViewGroup.LayoutParams.WRAP_CONTENT;
        dialog.getWindow().setLayout(width, height);
        dialog.setCancelable(false);
        dialog.show();
    }

    public static boolean isEditTextEmpty(EditText editText, boolean required, String requiredMessage) {
        if (editText.getText().toString().length() == 0) {
            if (required) {
                int ecolor = Color.RED;
                ForegroundColorSpan fgcspan = new ForegroundColorSpan(ecolor);
                SpannableStringBuilder ssbuilder = new SpannableStringBuilder(requiredMessage);
                ssbuilder.setSpan(fgcspan, 0, requiredMessage.length(), 0);
                editText.setError(ssbuilder);
            }
            return true;
        }
        return false;
    }

    /**
     * Overwrite alpha value of a color.
     *
     * @param color original color (format as retrieved with getResources().getColor(int resId)
     * @param alpha new value for opacity, old one is ignored/overwritten
     * @return new color composed of original color and new alpha value.
     */
    public static int getTransparentColor(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    /**
     * Sets the background color selector, where color is determined dynamically from primary color by changing opacity.
     *
     * @param view the view to set the background for
     */
    public static void setListBackgroundSelector(View view) {
        StateListDrawable stateListDrawable = new StateListDrawable();
        final int secondaryColor = view.getResources().getColor(R.color.primary);
        int pressedStateBackgroundColor = getTransparentColor(secondaryColor, 38);
        stateListDrawable.addState(new int[]{android.R.attr.state_pressed}, new ColorDrawable(pressedStateBackgroundColor));
        view.setBackground(stateListDrawable);
    }

    public static void setProceedButtonBackgroundSelector(Button view) {
        Drawable buttonDrawable_activate = null;
        Drawable buDrawable_desactivated = null;
        if (Config.VIDEO_IDENT_PLUS) {
            buttonDrawable_activate = view.getResources().getDrawable(R.drawable.rounded_background_orange);
            buDrawable_desactivated = view.getResources().getDrawable(R.drawable.rounded_background_orange_disable);
            StateListDrawable stateListDrawable = new StateListDrawable();
            stateListDrawable.addState(new int[]{android.R.attr.state_pressed}, buttonDrawable_activate);
            stateListDrawable.addState(new int[]{android.R.attr.state_enabled}, buttonDrawable_activate);
            stateListDrawable.addState(new int[]{}, buDrawable_desactivated);
            view.setBackgroundDrawable(stateListDrawable);
        } else {
            Drawable buttonDrawable_activate_brand = view.getResources().getDrawable(R.drawable.rounded_background_orange);
            Drawable buDrawable_desactivated_brand = view.getResources().getDrawable(R.drawable.rounded_background_orange_disable);
            StateListDrawable stateListDrawable = new StateListDrawable();
            stateListDrawable.addState(new int[]{android.R.attr.state_pressed}, buttonDrawable_activate_brand);
            stateListDrawable.addState(new int[]{android.R.attr.state_enabled}, buttonDrawable_activate_brand);
            stateListDrawable.addState(new int[]{}, buDrawable_desactivated_brand);
            view.setBackgroundDrawable(stateListDrawable);
        }
    }

    private static int getPressedButtonStateColor(int buttonColor) {
        float[] hsv = new float[3];
        Color.colorToHSV(buttonColor, hsv);

        // reduce brightness by 12%
        hsv[2] -= 0.12;
        if (hsv[2] < 0) {
            hsv[2] = 0f;
        }

        return Color.HSVToColor(Color.alpha(buttonColor), hsv);
    }

    public static void setESignatureTextColorSelector(TextView textView) {
        int textDefaultColor = textView.getTextColors().getDefaultColor();
        // int textDefaultColor = textView.getResources().getColor( R.color.text_default );
        int passiveColor = getTransparentColor(textDefaultColor, 224);
        // int activeColor = getPressedButtonStateColor( passiveColor );
        int activeColor = getTransparentColor(textDefaultColor, 141);

        // define states
        int[][] states = new int[][]{new int[]{android.R.attr.state_selected}, // active state
                new int[]{android.R.attr.state_focused}, // active state
                new int[]{android.R.attr.state_pressed}, // active state
                new int[]{}  // passive state
        };

        // map colors to above states
        int[] colors = new int[]{activeColor, activeColor, activeColor, passiveColor};

        // create selector and apply it to textView
        textView.setTextColor(new ColorStateList(states, colors));
    }

    /**
     * Set drawable on an image view. However tint the icon (where it is not transparent) with the color given by @param colorResource.
     *
     * @param imageView     the target view for the drawable
     * @param iconResource  the resource of the drawable
     * @param colorResource the color the drawalbe shall be tinted
     */
    public static void setTintedIcon(ImageView imageView, int iconResource, int colorResource) {
        Context context = imageView.getContext();
        Drawable checkedIcon = context.getResources().getDrawable(iconResource);
        checkedIcon.setColorFilter(context.getResources().getColor(colorResource), Mode.SRC_IN);
        imageView.setImageDrawable(checkedIcon);
    }

    public static void setCheckMark(ImageView imageView, boolean isChecked) {
        Util_UtilUI.setTintedIcon(imageView, isChecked ? Config.CHECKBOX_FORM.checked() : Config.CHECKBOX_FORM.unchecked(), R.color.check_icon);
    }

    /**
     * Convenience method for {@link #showBrandedDialog(AlertDialog, Drawable)}.
     * <p/>
     * This method can only be used from within the SDK since only then the IDnowSDK is guaranteed to be initiliazed and configured properly.
     */
    public static AlertDialog showBrandedDialog(AlertDialog dialog) {
        Context context = dialog.getContext();
        Drawable dialogIconDrawable = null;
        if (IDnowSDK.showDialogsWithIcon()) {
            dialogIconDrawable = context.getResources().getDrawable(R.drawable.ic_launcher);
        }
        return showBrandedDialog(dialog, dialogIconDrawable);
    }

    /**
     * Styling a dialog's title icon, title color, and divider color.
     * <p/>
     * Styling the title color can be activated by overwriting SKD's bool resource "customize_dialog_title_color" to value true.
     * The title color itself is set with color resource "dialog_title".
     * Therefore, use "customize_dialog_title_color" and "dialog_title" in combination.
     * <p/>
     * "Dialog divider" addresses the horizontal line between a dialog's title header and its body.
     * Styling the divider color can be activated by overwriting SKD's bool resource "customize_dialog_divider_color" to value true.
     * The title color itself is set with color resource "dialog_divider".
     * Therefore, use "customize_dialog_divider_color" and "dialog_divider" in combination.
     *
     * @param dialog             the alert dialog to which the branding is applied to.
     * @param dialogIconDrawable Drawable resource id for the icon to be displayed left to the dialog title. If null, no icon is set.
     */
    public static AlertDialog showBrandedDialog(AlertDialog dialog, Drawable dialogIconDrawable) {
        if (dialog == null) {
            return null;
        }

        Context context = dialog.getContext();
        Resources resources = context.getResources();

        if (dialogIconDrawable != null) {
            //	dialog.setIcon(dialogIconDrawable);
        }

        // there are things that must be applied before show() method: e.g. setting icon;
        // and there are things that must be applied afterwards: e.g. color styling

        if (context instanceof Activity) {
            if (!((Activity) context).isFinishing()) {
                dialog.show();
            }
        } else {
            try {
                dialog.show();
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Show dialog failed", e);
                if (e instanceof WindowManager.BadTokenException) {
                    logExternally(context, "BadTokenException @ showBrandedDialog : " + e, LogEventTypeEnum.ERROR.get());
                } else {
                    logExternally(context, "showBrandedDialog : " + e, LogEventTypeEnum.ERROR.get());
                }
            }
        }

        if (resources.getBoolean(R.bool.customize_dialog_title_color)) {
            try {
                // change title text color
                int titleTextColor = resources.getColor(R.color.dialog_title);
                int alertTitleId = resources.getIdentifier("alertTitle", "id", "android");
                TextView alertTitle = dialog.getWindow().getDecorView().findViewById(alertTitleId);
                alertTitle.setTextColor(titleTextColor);
            } catch (Exception ex) {
                Util_Log.e(LOGTAG, "Show branded dialog failed. Could not change title text color", ex);
            }
        }

        if (resources.getBoolean(R.bool.customize_dialog_divider_color)) {
            try {
                int dividerColor = resources.getColor(R.color.dialog_divider);
                int titleDividerId = resources.getIdentifier("titleDivider", "id", "android");
                View titleDivider = dialog.getWindow().getDecorView().findViewById(titleDividerId);
                titleDivider.setBackgroundColor(dividerColor);
            } catch (Exception ex) {
                Util_Log.e(LOGTAG, "Show branded dialog failed. Could not change divider color", ex);
            }
        }
        return dialog;
    }

    public static void overrideBrandingColor(View view, String background, String text) {
        try {
            if (!background.isEmpty()) {
                int backgroundColor = Color.parseColor(background);
                view.setBackgroundColor(backgroundColor);
            }

            if (!text.isEmpty()) {
                int textColor = Color.parseColor(text);
                if (view instanceof TextView) {
                    ((TextView) view).setTextColor(textColor);
                }
            }
        } catch (IllegalArgumentException e) {
            Util_Log.e(LOGTAG, "Override branding color failed", e);
        }
    }

    public static void showDeclineeSigning(final Context context, Dialog dialogWallet) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_ACCOUNT_TITLE_SIGNING, LOCAL_KEY_ACCOUNT_TITLE_SIGNING))
                .setMessage(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_ACCOUNT_DECLINE_SIGNING, LOCAL_KEY_ACCOUNT_DECLINE_SIGNING))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_VIDEO_IDENT_COMMON_YES, LOCAL_KEY_VIDEO_IDENT_COMMON_YES), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                        if (Config.CALL_ABORT_REASON_SCREEN && Config.AGENT_CONNECTED) {
                            dialogWallet.dismiss();
                            ((Activities_VideoLiveStreamActivity_Super) context).user_abort_feedback_view.setVisibility(View.VISIBLE);
                            ((Activities_VideoLiveStreamActivity_Super) context).displayAbortUser();
                        } else {
                            IDnowSDK.getInstance().setStartCallIssued(false);
                            if (context instanceof Interface_VideoLiveStream) {
                                ((Interface_VideoLiveStream) context).identificationCanceled();
                            }
                        }
                    }
                })
                .setNegativeButton(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_VIDEO_IDENT_COMMON_NO, LOCAL_KEY_VIDEO_IDENT_COMMON_NO), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        alertDialogBuilder.setCancelable(false);
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    public static void showEsignDialog(final Context context, String kind, Dialog dialog, WebView webView) {

        Activities_VideoLiveStreamActivity_Super activities_videoLiveStreamActivity_super = new Activities_VideoLiveStreamActivity_LIVESWITCH();

        Dialog myDialog = new Dialog(context);
        myDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (kind.equals(Util_Strings.KEY_ACCOUNT_REGISTER)) {

            myDialog.setContentView(R.layout.activity_activities_registration);

            activities_videoLiveStreamActivity_super.loadCreateAccountLayout(myDialog, context, webView);

        } else if (kind.equals(Util_Strings.KEY_ACCOUNT_LOGIN)) {

            myDialog.setContentView(R.layout.activity_account_login);

            activities_videoLiveStreamActivity_super.loadLoginAccountLayout(myDialog, context, webView);

        } else if (kind.equals(Util_Strings.KEY_ACCOUNT_PASSWORD)) {
            myDialog.setContentView(R.layout.activity_select_password);

            activities_videoLiveStreamActivity_super.loadSavePasswordLayout(myDialog, context, webView);

        } else if (kind.equals(Util_Strings.KEY_ACCOUNT_UPDATE)) {
            myDialog.setContentView(R.layout.activity_account_update);

            activities_videoLiveStreamActivity_super.loadContinueSignLayout(myDialog, context, dialog, webView);

        } else if (kind.equals(Util_Strings.KEY_ACCOUNT_NOT_REM_PASSWORD)) {
            myDialog.setContentView(R.layout.activity_forgot_password);

            activities_videoLiveStreamActivity_super.loadAccountForgotPassword(myDialog, context);
        }

        int width = ViewGroup.LayoutParams.WRAP_CONTENT;
        int height = ViewGroup.LayoutParams.WRAP_CONTENT;
        myDialog.getWindow().setLayout(width, height);
        myDialog.setCancelable(false);
        if (!((Activities_VideoLiveStreamActivity_Super) context).isFinishing()) {
            myDialog.show();
        }
        ViewHelper.INSTANCE.applySafePadding(myDialog.findViewById(android.R.id.content));
    }

    public static void showErrorFieldEsignAuth(final Context context, String KEY) {

        String key_message = "";

        if (KEY.equals(Util_Strings.KEY_ERROR_EMAIL_PRESENCE)) {

            key_message = Util_Strings.KEY_ERROR_EMAIL_PRESENCE;

        } else if (KEY.equals(Util_Strings.KEY_ERROR_MOBILENUMBER_PRESENCE)) {

            key_message = Util_Strings.KEY_ERROR_MOBILENUMBER_PRESENCE;

        } else if (KEY.equals(Util_Strings.KEY_ERROR_MOBILENUMBER_FORMAT)) {

            key_message = Util_Strings.KEY_ERROR_MOBILENUMBER_FORMAT;

        } else if (KEY.equals(Util_Strings.KEY_ERROR_EMAIL_FORMAT)) {

            key_message = Util_Strings.KEY_ERROR_EMAIL_FORMAT;

        } else if (KEY.equals(Util_Strings.KEY_ERROR_PASSWORD_PRESENCE)) {

            key_message = Util_Strings.KEY_ERROR_PASSWORD_PRESENCE;

        } else if (KEY.equals(Util_Strings.KEY_ERROR_PASSWORD_VALIDATION)) {

            key_message = Util_Strings.KEY_ERROR_PASSWORD_VALIDATION;

        } else if (KEY.equals(Util_Strings.KEY_ERROR_CONFIRMED_PASSWORD)) {

            key_message = Util_Strings.KEY_ERROR_CONFIRMED_PASSWORD;

        } else if (KEY.equals(Util_Strings.KEY_ERROR_ACCOUNT_REGISTER_FAILED)) {

            key_message = Util_Strings.KEY_ERROR_ACCOUNT_REGISTER_FAILED;

        } else if (KEY.equals(Util_Strings.KEY_ERROR_ACCOUNT_LOGIN_FAILED)) {

            key_message = Util_Strings.KEY_ERROR_ACCOUNT_LOGIN_FAILED;

        }

        AlertDialog alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_AUTH_WARNING, LOCAL_KEY_VIDEO_IDENT_AUTH_WARNING))
                .setMessage(Util_Strings.getStringWithDefault(context, key_message, null))
                //	.setIcon(context.getResources().getDrawable(R.drawable.ic_launcher))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        Config.ERROR_LOGIN = false;
                    }
                }).create();
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.show();
    }

    public static void setColorLottieAnimation(int colorLottieAnimation, LottieAnimationView viewLottieAnimation, String keyPath) {
        viewLottieAnimation.addValueCallback(
                new KeyPath("**", keyPath),
                LottieProperty.COLOR_FILTER,
                new SimpleLottieValueCallback<ColorFilter>() {
                    @SuppressLint("ResourceAsColor")
                    @Override
                    public ColorFilter getValue(LottieFrameInfo<ColorFilter> frameInfo) {
                        return new PorterDuffColorFilter(colorLottieAnimation, PorterDuff.Mode.SRC_ATOP);
                    }
                }
        );


        viewLottieAnimation.playAnimation();
    }


    public static void dialog_nfc(Context context) {

        Dialog dialog = new Dialog(context);
        dialog.setTitle(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_NFC_REQUIRED_TITLE, LOCAL_EID_NFC_REQUIRED_TITLE));
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, getStyle()));
        alertDialogBuilder.setTitle(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_NFC_REQUIRED_TITLE, LOCAL_EID_NFC_REQUIRED_TITLE));
        alertDialogBuilder.setMessage(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_NFC_REQUIRED_MESSAGE, Util_Strings.LOCAL_EID_NFC_REQUIRED_MESSAGE));
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_NFC_REQUIRED_BUTTON_NEXT, Util_Strings.LOCAL_EID_NFC_REQUIRED_BUTTON_NEXT)
                , new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openNfcSettings((Activities_EntryActivity) context);
                    }
                }).create().show();
    }

    /**
     * On some devices, camera index might differ.
     * This method ensured the correct index is being used.
     *
     * @return index of BACK camera as int
     */

    public static int findBackCamera() {
        int cameraCount = 0;
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        cameraCount = Camera.getNumberOfCameras();
        for (int i = 0; i < cameraCount; i++) {
            Camera.getCameraInfo(i, cameraInfo);
            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
                return i;
            }
        }
        return -1;
    }

    public static void openNfcSettings(Activity activity) {
        Intent intent = new Intent(Settings.ACTION_NFC_SETTINGS);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
    }

    /**
     * On some devices, camera index might differ.
     * This method ensured the correct index is being used.
     *
     * @return index of FRONT FACING camera as int
     */

    public static int findFrontCamera() {
        int cameraCount = 0;
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        cameraCount = Camera.getNumberOfCameras();
        for (int i = 0; i < cameraCount; i++) {
            Camera.getCameraInfo(i, cameraInfo);
            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                return i;
            }
        }
        return -1;
    }
}
