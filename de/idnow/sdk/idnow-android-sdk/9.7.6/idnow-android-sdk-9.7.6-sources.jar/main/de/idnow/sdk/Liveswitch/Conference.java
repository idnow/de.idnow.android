package de.idnow.sdk.Liveswitch;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;

import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.pkcs.RSAPrivateKey;

import java.io.ByteArrayInputStream;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;

import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_CallQualityCheck;
import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_LIVESWITCH;
import de.idnow.sdk.CertificateProvider;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.util.CertificateHelper;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.camera.CameraType;
import de.idnow.sdk.util.helper.ImageHelper;
import fm.liveswitch.AudioStream;
import fm.liveswitch.BandwidthAdaptationPolicy;
import fm.liveswitch.Candidate;
import fm.liveswitch.Connection;
import fm.liveswitch.ConnectionState;
import fm.liveswitch.DataChannel;
import fm.liveswitch.DataStream;
import fm.liveswitch.DtlsCertificate;
import fm.liveswitch.Future;
import fm.liveswitch.IAction1;
import fm.liveswitch.IAction2;
import fm.liveswitch.IFunction0;
import fm.liveswitch.IFunction1;
import fm.liveswitch.IceServer;
import fm.liveswitch.LayoutMode;
import fm.liveswitch.LogLevel;
import fm.liveswitch.MediaSourceState;
import fm.liveswitch.Promise;
import fm.liveswitch.RsaKey;
import fm.liveswitch.SessionDescription;
import fm.liveswitch.Stream;
import fm.liveswitch.StreamStats;
import fm.liveswitch.TransportStats;
import fm.liveswitch.TrickleIcePolicy;
import fm.liveswitch.VideoSource;
import fm.liveswitch.VideoStream;
import fm.liveswitch.android.LayoutManager;

public abstract class Conference {

    static {
        fm.liveswitch.Log.setLogLevel(LogLevel.Warn);
        fm.liveswitch.Log.setProvider(new fm.liveswitch.android.LogProvider(LogLevel.Warn));
    }

    public interface OnScreenshotCapturedCallback {
        void onScreenshotCaptured(@NonNull Bitmap bitmap);

        void onError(Exception e);
    }

    private final String LOGTAG = "IDNOW_Conference";
    private Connection connection;
    private final LocalMedia localMedia;
    private RemoteMedia remoteMedia;
    private final Context appContext;
    private final AecContext aecContext;
    private final boolean trickleIceEnabled;
    private final Mode mode;

    private final Activity activity;
    private RelativeLayout localContainer;
    private RelativeLayout remoteContainer;
    private ProgressBar subscriberProgressBar;
    private LayoutManager localLayoutManager;
    private LayoutManager remoteLayoutManager;

    private boolean agentConnected = false;
    private int reconnectCount = 0;
    private Object dataChannelLock = new Object();
    ArrayList<DataChannel> dataChannels = new ArrayList<DataChannel>();

    public Conference(Activity activity, boolean trickleIceEnabled, Mode mode) {
        this.mode = mode;
        this.activity = activity;
        this.trickleIceEnabled = trickleIceEnabled;

        this.appContext = activity.getApplicationContext();
        this.aecContext = new AecContext();
        this.localMedia = new LocalMedia(appContext, false, false, false, aecContext);
        localMedia.addStateLogging();

        createConnection();
    }

    public int getReconnectCount() {
        return reconnectCount;
    }

    public void setReconnectCount(int reconnectCount) {
        this.reconnectCount = reconnectCount;
    }

    public void setSubscriberProgressBar(ProgressBar subscriberProgressBar) {
        this.subscriberProgressBar = subscriberProgressBar;
    }

    public LocalMedia getLocalMedia() {
        return localMedia;
    }

    public void setProgressBar(ProgressBar progressBar) {
    }

    private IAction1<Connection> getConnectionOnStateChangeHandler(final RemoteMedia remoteMedia) {
        return c -> {
            Util_Log.i(LOGTAG, "Connection state: " + c.getState().name());

            switch (c.getState()) {
                case Closed:
                case New:
                    break;
                case Connected:
                    renderRemoteVideo(remoteMedia, remoteLayoutManager);
                    c.getStats().then(stats -> {
                        StreamStats[] streamStats = stats.getVideoStreams();
                        for (StreamStats stream : streamStats) {
                            TransportStats transport = stream.getTransport();
                            CertificateProvider udpCertProvider = Config.DTLS_CERTIFICATE_OVER_UDP;
                            if (udpCertProvider != null) {
                                try {
                                    String transportCertB64 = transport.getRemoteCertificate().getCertificateBase64();
                                    X509Certificate transportCert = CertificateHelper.Companion.readFromBase64(transportCertB64);
                                    X509Certificate udpCert = CertificateHelper.Companion.readFromBytes(udpCertProvider.provideCertificateBytestream());
                                    if (!CertificateHelper.Companion.checkValidity(transportCert) ||
                                            !CertificateHelper.Companion.checkValidity(udpCert) ||
                                            !CertificateHelper.Companion.compare(transportCert, udpCert)) {
                                        c.close();
                                        activity.runOnUiThread(() -> Util_UtilUI.showMatchingValidationError(activity));
                                        break;
                                    }
                                } catch (Exception ex) {
                                    Util_Log.e(LOGTAG, "DTLS certificates pinning for UDP failed", ex);
                                    throw new RuntimeException(ex);
                                }
                            }
                        }
                    });

                    if (agentConnected) {
                        hideSubscriberProgressBar();
                    } else {
                        showSubscriberProgressBar();
                    }

                    if (activity instanceof Activities_VideoLiveStreamActivity_LIVESWITCH) {
                        activity.runOnUiThread(() -> {
                            if (((Activities_VideoLiveStreamActivity_LIVESWITCH) activity).connectionLossAlertDialog != null) {
                                ((Activities_VideoLiveStreamActivity_LIVESWITCH) activity).connectionLossAlertDialog.dismiss();
                                Util_UtilUI.showBrandedDialog(((Activities_VideoLiveStreamActivity_LIVESWITCH) activity).connectionLossAlertDialog).dismiss();
                            }
                        });
                    }
                    break;

                case Closing:
                case Failing:

                    if (remoteLayoutManager != null) {
                        remoteLayoutManager.removeRemoteViews();
                    }

                    remoteMedia.destroy();

                    break;

                case Failed:

                    if (activity instanceof Activities_VideoLiveStreamActivity_CallQualityCheck) {
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (Config.CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                                    ((Activities_VideoLiveStreamActivity_CallQualityCheck) activity).showCheckResultScreenCustomise(Activities_VideoLiveStreamActivity_CallQualityCheck.CallQualityResult.UNKNOWN.getInt());
                                } else {
                                    if (Config.VIDEO_IDENT_PLUS) {
                                        ((Activities_VideoLiveStreamActivity_CallQualityCheck) activity).showCheckResultScreen_vip(Activities_VideoLiveStreamActivity_CallQualityCheck.CallQualityResult.UNKNOWN.getInt());
                                    } else {
                                        ((Activities_VideoLiveStreamActivity_CallQualityCheck) activity).showCheckResultScreen(Activities_VideoLiveStreamActivity_CallQualityCheck.CallQualityResult.UNKNOWN.getInt());
                                    }
                                }
                            }
                        });
                    }
                    if (agentConnected) {
                        reconnect();
                    }
                    break;
            }
        };
    }

    public abstract Promise<SessionDescription> sendSdpOffer(SessionDescription sd);

    public abstract void sendCandidate(Candidate candidate);

    public Connection getConnection() {
        return connection;
    }

    private Connection createConnection() {

        if (connection != null) {
            connection.close();
        }

        if (remoteMedia != null) {
            remoteMedia.destroy();
        }

        remoteMedia = new RemoteMedia(appContext, false, false, false, aecContext);

        final AudioStream audioStream = new AudioStream(localMedia, remoteMedia);
        audioStream.setLocalSend(true);
        audioStream.setLocalReceive(true);

        audioStream.setMuted(Config.TEST_ROBOT_TYPE != null);

        final VideoStream videoStream = new VideoStream(localMedia, remoteMedia);
        videoStream.setLocalSend(true);
        videoStream.setLocalReceive(true);
        videoStream.setBandwidthAdaptationPolicy(BandwidthAdaptationPolicy.Enabled);

        DataChannel dataChannel = new DataChannel("data");

        DataStream dataStream = new DataStream(dataChannel);


        synchronized (dataChannelLock) {
            dataChannels.add(dataChannel);
        }

        Stream[] streams = new Stream[]{audioStream, videoStream};

//        if (Config.CALL_QUALITY_CHECK_ENABLED && !Config.CALL_QUALITY_CHECK_PASSED) {
//            streams = new Stream[]{audioStream, videoStream, dataStream};
//        }

        if (mode == Mode.CQC && Config.CALL_QUALITY_CHECK_ENABLED) {
            streams = new Stream[]{audioStream, videoStream, dataStream};
        } else {
            streams = new Stream[]{audioStream, videoStream};
        }

        connection = new Connection(dataChannelLock, streams);

        IceServer[] iceServers = {
                new IceServer("stun:" + Config.CURRENT_SERVER.getStunHost(IDnowSDK.getTransactionToken()) + ":" + Config.CURRENT_SERVER.getStunPort()),
                new IceServer("turn:" + Config.CURRENT_SERVER.getStunHost(IDnowSDK.getTransactionToken()) + ":" + Config.CURRENT_SERVER.getStunPort(), "idnow", "1VbrjNLEo9b5N9729HFbQWtw1LrKc9xIaUGSotLm65r0xuaH")
        };
        connection.setIceServers(iceServers);
        connection.setTrickleIcePolicy(trickleIceEnabled ? TrickleIcePolicy.FullTrickle : TrickleIcePolicy.NotSupported);
        connection.addOnStateChange(getConnectionOnStateChangeHandler(remoteMedia));
        connection.setDeadStreamTimeout(5000);
        connection.setLocalDtlsCertificate(createCertificate());

        return connection;
    }

    private void reconnect() {

        Util_Log.i(LOGTAG, "RECONNECTING, conference mode=" + mode + " activity=" + activity.getClass().getSimpleName());

        showSubscriberProgressBar();
        connect(localContainer, remoteContainer);
    }

    private void hideSubscriberProgressBar() {
        if (subscriberProgressBar == null) {
            return;
        }
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                subscriberProgressBar.setVisibility(View.INVISIBLE);
            }
        });
    }

    private void showSubscriberProgressBar() {
        if (subscriberProgressBar == null) {
            return;
        }

        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                subscriberProgressBar.setVisibility(View.VISIBLE);
                subscriberProgressBar.bringToFront();
            }
        });
    }

    public void disconnect() {
        connection.close();
    }

    public Future<fm.liveswitch.LocalMedia> connectToAgent(final RelativeLayout localContainer, final RelativeLayout remoteContainer) {
        this.agentConnected = true;
        return connect(localContainer, remoteContainer);
    }

    public Future<fm.liveswitch.LocalMedia> connect(final RelativeLayout localContainer, final RelativeLayout remoteContainer) {

        if (connection.getState().getAssignedValue() > ConnectionState.New.getAssignedValue() && connection.getState().getAssignedValue() <= ConnectionState.Connected.getAssignedValue()) {
            Util_Log.i(LOGTAG, "conference is in state " + connection.getState());
            if (agentConnected) {
                hideSubscriberProgressBar();
            }
            return Promise.resolveNow(localMedia);
        } else if (connection.getState().getAssignedValue() > ConnectionState.Connected.getAssignedValue()) {
            Util_Log.i(LOGTAG, "conference is in state " + connection.getState() + " needs to be replaced");
            createConnection();
        }

        this.reconnectCount++;
        Util_Log.i(LOGTAG, "Connecting to videoserver " + connection.getState());
        this.localContainer = localContainer;
        this.remoteContainer = remoteContainer;

        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                localLayoutManager = new LayoutManager(localContainer);
                remoteLayoutManager = new LayoutManager(remoteContainer);

                final View localView = localMedia.getView();

                if (localView != null && localLayoutManager.getLocalView() != null) {
                    localView.setContentDescription("localView");
                    localLayoutManager.setLocalView(localView);
                } else {
                    Util_Log.w(LOGTAG, "LocalMedia's View is null!");
                }
            }
        });

        // Start the local media.
        return localMedia.start().
                then(new IAction1<fm.liveswitch.LocalMedia>() {
                    @Override
                    public void invoke(final fm.liveswitch.LocalMedia localMedia) {
                        connection.addOnLocalCandidate(new IAction2<Connection, Candidate>() {
                            @Override
                            public void invoke(Connection connection, Candidate candidate) {
                                sendCandidate(candidate);
                            }
                        });
                        connection.createOffer()
                                .then(new IFunction1<SessionDescription, Future<SessionDescription>>() {
                                    @Override
                                    public Future<SessionDescription> invoke(SessionDescription offer) {
                                        Util_Log.i(LOGTAG, "SDP Offer created");
                                        return connection.setLocalDescription(offer);
                                    }
                                })
                                .then(new IFunction1<SessionDescription, Future<SessionDescription>>() {
                                    @Override
                                    public Future<SessionDescription> invoke(SessionDescription sessionDescription) {
                                        Util_Log.i(LOGTAG, "Sending SDP offer");
                                        return sendSdpOffer(sessionDescription);
                                    }
                                }).then(new IAction1<SessionDescription>() {
                                    @Override
                                    public void invoke(SessionDescription sessionDescription) {
                                        Util_Log.i(LOGTAG, "Setting SDP answer");
                                        connection.setRemoteDescription(sessionDescription);
                                    }
                                });
                    }
                });
    }

    public Future<fm.liveswitch.LocalMedia> setupConference(RelativeLayout localContainer, RelativeLayout remoteContainer) {
        Util_Log.i(LOGTAG, "Setting up conference");
        renderLocalRemoteVideo(localContainer, remoteContainer);
        return localMedia.start();
    }

    public Future<fm.liveswitch.LocalMedia> stopConference() {

        Util_Log.i(LOGTAG, "Stopping conference=" + this);

        connection.close();

        return Promise.wrapPromise(new IFunction0<Future<fm.liveswitch.LocalMedia>>() {
            public Future<fm.liveswitch.LocalMedia> invoke() {
                if (localMedia == null) {
                    throw new RuntimeException("Local media has already been stopped.");
                }

                // Stop the local media.
                return localMedia.stop().then(new IAction1<fm.liveswitch.LocalMedia>() {
                    public void invoke(fm.liveswitch.LocalMedia o) {
                        // Tear down the layout manager.
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (localLayoutManager != null) {
                                    localLayoutManager.removeRemoteViews();
                                    localLayoutManager.unsetLocalView();
                                    localLayoutManager = null;
                                }

                                // Tear down the layout manager.
                                if (remoteLayoutManager != null) {
                                    remoteLayoutManager.removeRemoteViews();
                                    remoteLayoutManager.unsetLocalView();
                                    remoteLayoutManager = null;
                                }

                                // Tear down the local media.

                                try {
                                    localMedia.destroy(); // localMedia.destroy() will also destroy AecContext
                                } catch (Exception e) {
                                    Util_Log.e(LOGTAG, "Stop conference failed. LocalMedia cannot be destroyed", e);
                                }
                            }
                        });

                    }
                });
            }
        });
    }

    public Future<Object> pauseLocalVideo() {
        if (localMedia != null) {
            VideoSource videoSource = localMedia.getVideoSource();
            if (videoSource != null) {
                if (videoSource.getState() == MediaSourceState.Started) {
                    Util_Log.i(LOGTAG, "pauseLocalVideo");
                    return videoSource.stop();
                }
            }
        } else {
            Util_Log.e(LOGTAG, "Pause local video failed. LocalMedia is null");
        }

        return Promise.resolveNow();
    }

    public Future<Object> resumeLocalVideo() {
        if (localMedia != null) {
            VideoSource videoSource = localMedia.getVideoSource();
            if (videoSource != null) {
                if (videoSource.getState() == MediaSourceState.Started) {
                    videoSource.stop().waitForResult();
                }
                if (videoSource.getState() == MediaSourceState.Stopped) {
                    Util_Log.i(LOGTAG, "resumeLocalVideo");
                    return videoSource.start().then(o -> {
                        if (connection.getState() == ConnectionState.Connected && agentConnected) {
                            hideSubscriberProgressBar();
                        }
                    });
                }
            }
        } else {
            Util_Log.w(LOGTAG, "In resumeLocalVideo, but localMedia is null!");
        }

        return Promise.resolveNow();
    }

    public void openCamera(CameraType type) {
        try {
            if (localMedia != null) {
                localMedia.openCamera(type);
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Open camera " + type.name() + " failed", e);
        }
    }

    public void requestCameraFocusCenter() {
        try {
            if (localMedia != null) {
                localMedia.requestCameraFocusCenter();
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Request camera focus center failed", e);
        }
    }

    public void setCameraTorchEnabled(boolean enabled) {
        try {
            if (localMedia != null) {
                localMedia.setCameraTorchEnabled(enabled);
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Set camera torch to " + enabled + " failed", e);
        }
    }

    public void takeScreenshot(int requiredWidth,
                               int requiredHeight,
                               OnScreenshotCapturedCallback callback) {
        try {
            if (localMedia == null) {
                throw new IllegalStateException("Local media is null");
            }

            localMedia.grabVideoFrame().then(vb -> {
                Bitmap bitmap = ImageHelper.INSTANCE.extractBitmapFromVideoBuffer(vb, requiredWidth, requiredHeight);
                callback.onScreenshotCaptured(bitmap);
            });
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Take screenshot failed", e);
            callback.onError(e);
        }
    }

    public boolean connectionHasDataStream() {
        Stream stream = getConnection().getDataStream();
        return stream instanceof DataStream;
    }

    public DataChannel getDataChannel() {

        DataStream stream = getConnection().getDataStream();

        return stream.getChannels()[0];
    }

    protected enum Mode {
        CQC, AGENT_CONFERENCE
    }

    @NonNull
    @Override
    public String toString() {
        return "Conference{" +
                "mode=" + mode +
                ", activity=" + activity.getClass().getSimpleName() +
                '}';
    }

    private void renderLocalRemoteVideo(final RelativeLayout localContainer, final RelativeLayout remoteContainer) {
        Util_Log.i(LOGTAG, "START !");

        this.localContainer = localContainer;
        this.remoteContainer = remoteContainer;

        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                localLayoutManager = new LayoutManager(localContainer);
                remoteLayoutManager = new LayoutManager(remoteContainer);
                View localView = localMedia.getView();

                localView.setContentDescription("localView_" + localMedia.getId());

                if (!(Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED && !Config.AGENT_CONNECTED)) {
                    localLayoutManager.setLocalView(localView);
                    localLayoutManager.setMode(LayoutMode.FloatRemote);
                }

            }
        });

    }

    private void renderRemoteVideo(final RemoteMedia remoteMedia, final LayoutManager remoteLayoutManager) {

        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                View remoteView = remoteMedia.getView();

                if (remoteView != null) {
                    remoteView.setContentDescription("remoteView_" + remoteMedia.getId());
                    remoteLayoutManager.addRemoteView(remoteMedia.getId(), remoteView);

                }
            }
        });

    }

    public DtlsCertificate createCertificate() {
        if (Config.DTLS_CERTIFICATE != null && Config.DTLS_CERTIFICATE.featureCertificate()) {
            try {
                byte[] privateKeyBytes = Config.DTLS_CERTIFICATE.providePrivateKeyBytestream();
                byte[] certificateBytes = Config.DTLS_CERTIFICATE.provideCertificateBytestream();
                if (privateKeyBytes != null && certificateBytes != null) {
                    RSAPrivateKey privateKey = readRSAPrivateKey(privateKeyBytes);
                    if (privateKey == null) {
                        throw new Exception("Failed to read private key from byte stream");
                    }
                    RsaKey rsaKey = generateRsaKey(privateKey);
                    if (rsaKey == null) {
                        throw new Exception("Can't generate RsaKey from RSAPrivateKey");
                    }
                    X509Certificate x509Certificate = readX509Certificate(certificateBytes);
                    if (x509Certificate == null) {
                        throw new Exception("Can't read X509Certificate");
                    }
                    DtlsCertificate certificate = DtlsCertificate.generateCertificate(x509Certificate.getIssuerX500Principal().getName(), null, x509Certificate.getNotAfter(), rsaKey);
                    certificate.setAutoRegenerate(false);

                    return certificate;
                } else {
                    throw new NullPointerException("No valid by streams for key and/or certificate to create DTLS certificate");
                }
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Failed to create DTLS certificate. Default generated LiveSwitch certificate will be used", e);
                return DtlsCertificate.generateCertificate();
            }
        } else {
            Util_Log.i(LOGTAG, "No custom certificate/key provided. Default generated LiveSwitch certificate will be used");
            return DtlsCertificate.generateCertificate();
        }
    }

    private RSAPrivateKey readRSAPrivateKey(byte[] bytes) {
        RSAPrivateKey key = readRSAPrivateKeyPKCS1(bytes);
        if (key != null)
            return key;

        return readRSAPrivateKeyPKCS8(bytes);
    }

    private RSAPrivateKey readRSAPrivateKeyPKCS1(byte[] bytes){
        try{
            return RSAPrivateKey.getInstance(ASN1Primitive.fromByteArray(bytes));
        }catch (Exception e){
            Util_Log.e(LOGTAG, "Failed to read RSA private key: Invalid PKCS#1 format", e);
            return null;
        }
    }

    private RSAPrivateKey readRSAPrivateKeyPKCS8(byte[] bytes) {
        try {
            ASN1Primitive asn1 = ASN1Primitive.fromByteArray(bytes);
            PrivateKeyInfo pki = PrivateKeyInfo.getInstance(asn1);
            ASN1Sequence rsaSeq = (ASN1Sequence) pki.parsePrivateKey();

            return RSAPrivateKey.getInstance(rsaSeq);
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Failed to read RSA private key: Invalid PKCS#8 format", e);
            return null;
        }
    }

    private RsaKey generateRsaKey(RSAPrivateKey privateKey) {
        try {
            RsaKey rsaKey = new RsaKey();
            rsaKey.setModulus(privateKey.getModulus().toByteArray());
            rsaKey.setCoefficient(privateKey.getCoefficient().toByteArray());
            rsaKey.setExponent1(privateKey.getExponent1().toByteArray());
            rsaKey.setExponent2(privateKey.getExponent2().toByteArray());
            rsaKey.setPrime1(privateKey.getPrime1().toByteArray());
            rsaKey.setPrime2(privateKey.getPrime2().toByteArray());
            rsaKey.setPrivateExponent(privateKey.getPrivateExponent().toByteArray());
            rsaKey.setPublicExponent(privateKey.getPublicExponent().toByteArray());

            return rsaKey;
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Generate RsaKey from RSAPrivateKey failed", e);
            return null;
        }
    }

    public X509Certificate readX509Certificate(byte[] bytes) {
        try {
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            ByteArrayInputStream inputStream = new ByteArrayInputStream(bytes);

            return (X509Certificate) certFactory.generateCertificate(inputStream);
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Read X509Certificate from byte array failed", e);
            return null;
        }
    }
}
