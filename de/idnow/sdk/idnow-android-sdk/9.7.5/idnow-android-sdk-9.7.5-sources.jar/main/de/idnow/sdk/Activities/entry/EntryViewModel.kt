package de.idnow.sdk.Activities.entry

import android.content.Intent
import android.os.Bundle
import androidx.activity.result.ActivityResult
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import de.idnow.android.eid.eIDSdk
import de.idnow.sdk.Activities.Model_eIDData
import de.idnow.sdk.Activities.agentlanguage.ActivityAgentLanguage
import de.idnow.sdk.Activities.instasign.VerifyIdActivity
import de.idnow.sdk.AssetsLoader
import de.idnow.sdk.Config
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.models.Model_InstantSignStart
import de.idnow.sdk.models.Models_Customer
import de.idnow.sdk.models.Models_MobileNumber
import de.idnow.sdk.models.Models_OfficeHours
import de.idnow.sdk.models.Models_PDFDocument
import de.idnow.sdk.models.Models_StartObject
import de.idnow.sdk.models.Models_StartObjectResult
import de.idnow.sdk.models.Models_authenticationPossible
import de.idnow.sdk.network.IDnowRestClient
import de.idnow.sdk.network.Network_RESTCallsKt
import de.idnow.sdk.network.RetrofitError
import de.idnow.sdk.network.connectivityService.ConnectivityService
import de.idnow.sdk.util.Util_CustomLogData
import de.idnow.sdk.util.Util_CustomLogData.EVENT_IDENTIFICATION_METHOD_SHOWN
import de.idnow.sdk.util.Util_CustomLogData.EVENT_IDENTIFICATION_METHOD_TIME_SPENT
import de.idnow.sdk.util.Util_Log
import de.idnow.sdk.util.Util_PhotoDataHolder
import de.idnow.sdk.util.Util_Strings
import de.idnow.sdk.util.Util_Strings.KEY_DOC_NOT_UPLOADED
import de.idnow.sdk.util.Util_Strings.LOCAL_KEY_DOC_NOT_UPLOADED
import de.idnow.sdk.util.Util_Util
import de.idnow.sdk.util.Util_UtilRetrofit
import de.idnow.sdk.util.Util_VideoSessionConfig
import de.idnow.sdk.util.Util_VideoStreamService
import de.idnow.sdk.util.camera.CameraType
import de.idnow.sdk.util.helper.CameraHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

private const val LOGTAG = "IDNOW_EntryViewModel"

class EntryViewModel : ViewModel() {
    private val viewState: MutableStateFlow<EntryViewState> = MutableStateFlow(EntryViewState())
    private val events: MutableSharedFlow<EntryEvent> = MutableSharedFlow()

    private var officeHours: Models_OfficeHours? = null
    private var isDarkUiMode = false

    fun getViewState(): StateFlow<EntryViewState> =
        viewState.asStateFlow()

    fun getEvents(): SharedFlow<EntryEvent> =
        events.asSharedFlow()

    fun init(isDarkUiMode: Boolean) = viewModelScope.launch {
        this@EntryViewModel.isDarkUiMode = isDarkUiMode
        if (Config.DARK_MODE &&
            Config.DARK_MODE_ENABLED_CUSTOMER.not() &&
            IDnowSDK.isIsDarkModeFlagInitialized()
        ) {
            Config.DARK_MODE = false
        }

        toggleDarkMode(Config.DARK_MODE)

        Util_Util.handleServerSelection(IDnowSDK.getTransactionToken())
        if (CameraHelper.hasCamera(CameraType.FRONT)) {
            Util_Log.i(LOGTAG, "Front Camera and Back camera are available")
            if (ConnectivityService.isOnline())
                fetchOfficeHours()
            else
                showNoConnectionDialog(true)
        } else {
            events.emit(EntryEvent.ShowCameraAvailableDialog)
        }
    }

    /**
     * get data like failureUrl,fallbackUrl, successUrl, terms, processtype ("Video", "Photo"), eSignature yes or no
     */
    private suspend fun fetchOfficeHours() {
        toggleLoadingSpinnerVisibility(true)
        try {
            val apiService = provideRestApiService()
            val companyShort = IDnowSDK.getCompanyId()?.takeIf { it.isNotBlank() }
                ?: IDnowSDK.getTransactionToken()
            val response = apiService.getCompanyShortname(companyShort)
            if (response.isSuccessful)
                onFetchOfficeHoursSuccess(response.body()!!)
            else
                onFetchOfficeHoursFailure(RetrofitError.from(response))
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Error fetching office hours", e)
            toggleLoadingSpinnerVisibility(false)
            handleRestCallFailure(RetrofitError.from(e))
        }
    }

    private suspend fun onFetchOfficeHoursSuccess(resultObject: Models_OfficeHours) {
        this.officeHours = resultObject
        resultObject.shortname?.takeIf { it.isNotBlank() }?.let { IDnowSDK.setCompanyId(it) }

        AssetsLoader.loadMessages(true)
        AssetsLoader.loadLottieAnimations()

        Util_Log.i(LOGTAG, "office hours call was successful")
        Util_Log.i(LOGTAG, "office open: ${resultObject.isOfficeOpen}")

        val settings = resultObject.settings
        with(settings) {
            Config.SHOW_GTC = showGTC()
            Config.SHOW_RECORDING_AGREEMENT = showRecordingAgreement()
            Config.IS_Auto_Ident = isAutoIdent
            Config.VIDEO_IDENT_PLUS = isVideoIdentPlusEnabled
            Config.EID_CONFIG = isElectronicId
            eidtsp?.let { Config.EIDTSP = it }

            model_customLogData?.let {
                Config.CUSTOM_LOG_URL = it.serverURL
                Config.CUSTOM_LOG_APPKEY = it.appKey
                events.emit(EntryEvent.InitCustomLog(it))
            }

            authadaConfig?.let {
                Config.AUTHADA_STAGING_URL = it.stagingUrl
                Config.AUTHADA_PRODUCTION_URL = it.productionUrl
            }
        }

        if (Config.IS_Auto_Ident) {
            toggleLoadingSpinnerVisibility(false)
            events.emit(
                EntryEvent.ShowLinkAutoIdent(
                    mobileStoreLinks = settings.mobileStoreLinks,
                    message = Util_Strings.getStringWithDefault(
                        Util_Strings.KEY_PLATFORM_WRONG_SDK,
                        null
                    )
                )
            )
        } else {
            if (resultObject.applyVISettingsToConfig().not()) {
                return
            }

            if (Config.ID_MODE == Config.IDENTIFICATION_MODE.VIDEO) {
                if (Config.VIDEO_IDENT_PLUS)
                    Util_PhotoDataHolder.initPhotoData(resultObject.settings.processsteps)
                if (!Config.OFFICE_HOUR && !Config.EID_CONFIG) {
                    toggleLoadingSpinnerVisibility(false)
                    events.emit(
                        EntryEvent.ShowOfficeHoursUnsupportedProductDialog(
                            message = Util_Util.generateOfficeHoursMessage(resultObject)
                        )
                    )
                } else {
                    fetchCustomer()
                }
            } else {
                toggleLoadingSpinnerVisibility(false)
                events.emit(
                    EntryEvent.ShowOfficeHoursUnsupportedProductDialog(
                        message = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_COMMON_UNSUPPORT_PRODUCT,
                            Util_Strings.LOCAL_KEY_COMMON_UNSUPPORT_PRODUCT
                        )
                    )
                )
            }
        }
    }

    private suspend fun onFetchOfficeHoursFailure(error: RetrofitError?) {
        toggleLoadingSpinnerVisibility(false)

        if (!IDnowSDK.getShowErrorSuccessScreen(IDnowSDK.getInstance().appContext)) {
            val hasErrorResponse = error?.response != null
            events.emit(
                EntryEvent.ShowRESTCallErrorDialog(
                    responseCode = if (hasErrorResponse) error!!.response.getStatus() else 0,
                    retryAllowed = hasErrorResponse.not(),
                    result = "",
                    onConfirmAction = {
                        viewModelScope.launch { proceedToIdent() }
                    },
                    finishActivityAfterDialog = hasErrorResponse,
                    activeVideoCall = false,
                    resultError = Util_UtilRetrofit.printRetrofitError(error)
                )
            )
        } else {
            handleRestCallFailure(error)
        }
    }

    private fun Models_OfficeHours.applyVISettingsToConfig(): Boolean {
        Config.OFFICE_HOUR = isOfficeOpen
        highCallVolumeMessage
            ?.trim()
            ?.takeIf { it.isNotBlank() }
            ?.let { Config.HIGH_VOLUME_MESSAGE_FROM_SERVER = it }
        Config.VIDEOSERVER_DISABLED = settings.videoserver.equals("IDNOW", true).not()

        settings.waitingList?.let {
            Config.WAITING_LIST_NOTIFICATIONS_ENABLED = it.android.isEnabled
            Config.WAITING_LIST_NOTIFICATIONS_CHANNEL = it.android.channel
            Config.WAITING_LIST_NOTIFICATIONS_TRESHOLD = it.waitingQueueTreshold
            Config.WAITING_LIST_NOTIFICATIONS_TIMEOUT = it.waitingListTimeOut
            Config.WAITING_LIST_NOTIFICATIONS_ENFORCED_TRESHOLD = it.waitingQueueForcedTreshold
        }

        Config.REVIEW_TIME_LIMIT = settings.reviewTimelimit
        IDnowSDK.enableChat = settings.allowTextChat
        Util_Log.i(LOGTAG, "textChat enabled: $settings.allowTextChat")

        with(settings.android) {
            Config.SUCCESS_URL = successURL.orEmpty()
            Config.FAILURE_URL = failureURL.orEmpty()
            Config.FALLBACK_URL = fallbackURL.orEmpty()
            Config.SUCCESS_MESSAGE = successMessage.orEmpty()
            Config.FAILURE_MESSAGE = failureMessage.orEmpty()
            Config.TERMS_TEXT = terms.orEmpty()

            Util_Log.i(LOGTAG, "Suc Url: ${Config.SUCCESS_URL}")
            Util_Log.i(LOGTAG, "fail Url: ${Config.FAILURE_URL}")
            Util_Log.i(LOGTAG, "message: ${Config.SUCCESS_MESSAGE}")
        }

        Config.VERIFY_PHONE_NO = settings.isVerifyMobileNumber
        Config.IDENT_CODE_AUTO_FILL = settings.isEnableIdentCodeAutoFill
        Config.CALL_QUALITY_CHECK_ENABLED = settings.isCallQualityCheck
        settings.processsteps?.esigning?.let {
            Config.E_SIGNING = true
            Config.E_SIGNING_HAND_WRITING = it.handwritten
            Config.E_SIGNING_ASK_FOR_USER_CONSENT = settings.isShowDocusignPrivacyNotice
        }

        if (settings.processtype.equals("VIDEO", true))
            Config.ID_MODE = Config.IDENTIFICATION_MODE.VIDEO //default is PHOTO

        // SIGNATURE SETUP
        settings.usersteps?.signature?.let {
            Config.SIGNATURE_CAMERA_TO_USE = it.camera
            Config.SIGNATURE_TYPE = it.type
        }
        Config.IDENT_CODE_REQUIRED = settings.isIdentCodeRequired

        Config.CHECK_SCREEN_EXPIRY_DATE_REQUIRED = settings.isExpiryDateRequired

        settings.identCodeChannels?.forEach {
            Util_Log.i(LOGTAG, "identCodeChannels: $it")
            if (it.equals("EMAIL", true))
                Config.IDENT_CODE_BY_EMAIL = true
            if (it.equals("SMS", true))
                Config.IDENT_CODE_BY_SMS = true
        } ?: run {
            Config.IDENT_CODE_BY_SMS = false
            Config.IDENT_CODE_BY_EMAIL = false
        }

        with(settings) {
            Config.MOBILE_NUMBER_CHANGE_DISABLED = isDisabledMobileNumberChange
            Config.SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE = screenshotUploadLongestEdgeSize
            Config.VIDEO_MAX_DIMENSION_EDGE = videoMaxDimensionEdge
            Config.SHOW_POWERED_BY_KEY = showPoweredBy
            Config.SHOW_IDNOW_LOGO = isShowIDnowLogo
            Config.SHOW_HIGH_CALL_VOLUME = showHighCallVolume
            Config.SHOW_REVIEW_GOOGLE_RATING = isEnableGoogleRating
            Config.SHOW_REVIEW_GOOGLE_APPS_RATING = isEnableAppRating
            Config.AUTHENTICATED_SIGNED = isAuthenticatedSigning
            Config.HASH_SIGNING = isHashSigning
            Config.DTMAndPSM = isDTMAndPSM
            Config.ENABLE_AGENT_FEEDBACK = isEnableAgentFeedback
            Config.GOOGLE_RATING_LINK = googleRatingLink
            Config.CREATE_IDENT_RECORD_ATRUST = createIdentRecordinAtrust
            Config.SHOULD_DISPLAY_WAITING_SCREEN = isEnableWaitingScreen
            Config.DISPLAY_WAITING_SCREEN_CUSTOMISED_TIMER =
                enableWaitingScreenCustomisedTimer * 1000L
            Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED = isEnableWaitingScreenCustomisedAndroid
            Config.ENABLE_BLUETOOTH_AUDIO = isEnableBluetoothAudioAndroid
            if (Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED || Config.VIDEO_IDENT_PLUS)
                Config.SHOULD_DISPLAY_WAITING_SCREEN = false

            Config.SHOW_NAME_VERIFICATION_SCREEN = settings.isShowNameVerificationScreen
            Config.AUTHENTICATED_SIGNING_HIDE_OPTION_TO_CONTINUE_WITHOUT_WALLET =
                isAuthenticatedSigningHideOptionToContinueWithoutWallet
            Config.ENABLE_ID_CAPTURE_EID = isEnableIDCaptureEID
            Config.ENABLE_PIN_CHANGE = isEnablePINChange
            Config.ENABLE_EID_STANDALONE = isEnabledEIDStandaloneAndroid
            Config.EID_REROUTING = isEnableEIDRerouting
            Config.ENABLE_QES_EID = isEnableEIDQES
            Config.ENABLE_CHOOSE_EID_TYPE = isChooseEIDType
            Config.SHOW_PREPARE_SCREEN = settings.isShowPrepareScreen == true
            if (settings.isEnablePiPAndroid) {
                Config.ENABLE_PIP_ANDROID = true
            }
        }

        settings.socket?.let {
            Config.SOCKET_ENABLED = it.android.isEnabled
            Config.SOCKET_RECONNECT_INTERVAL = it.android.socketReconnectInterval
            Config.SOCKET_RECONNECT_ATTEMPTS = it.android.socketReconnectAttempts
        }

        settings.userCancellation?.let {
            Config.CALL_ABORT_REASON_SCREEN = it.isEnabled
            Config.USER_CANCELLATION_ENUM = it.getReasons()
        }

        settings.mobile?.let {
            val darkModeEnabledCustomer = it.enableDarkModeAndroid ?: true
            if (Config.DARK_MODE_ENABLED_CUSTOMER != darkModeEnabledCustomer) {
                Config.DARK_MODE_ENABLED_CUSTOMER = darkModeEnabledCustomer
                if (Config.DARK_MODE && Config.DARK_MODE_ENABLED_CUSTOMER.not()) {
                    Config.DARK_MODE = false
                }
                toggleDarkMode(Config.DARK_MODE)
                if (darkModeEnabledCustomer.not() && isDarkUiMode) {
                    return false
                }
            }
            Config.CHECKBOX_INSTRUCTIONS_SCREEN = it.isCheckBoxInstructionsScreen ?: true
        }

        if (Config.VIDEO_IDENT_PLUS) {
            Config.STORED_IDENTITY_SCREEN = settings.isEnableIdentForReuse
            Config.AGREEMENTS = settings.stored_identity?.android?.agreements.orEmpty()
            settings.videoIdentPlus?.let {
                Config.VIDEO_IDENT_PLUS_IDImage = it.isIdImage
                Config.VIDEO_IDENT_PLUS_DOCUMENT_CHECKING = it.isDocumentChecking
                Config.VIDEO_IDENT_PLUS_SEGMENTATIONANDCLASSIFICATION =
                    it.isSegmentationAndClassification
                Config.VIDEO_IDENT_PLUS_SELFIE_IMAGE = it.isSelfieImage
                Config.VIDEO_IDENT_PLUS_REUSE_IMAGES = it.isReuseImages
                if (!Config.VIDEO_IDENT_PLUS_IDImage &&
                    !Config.VIDEO_IDENT_PLUS_DOCUMENT_CHECKING &&
                    !Config.VIDEO_IDENT_PLUS_SEGMENTATIONANDCLASSIFICATION &&
                    !Config.VIDEO_IDENT_PLUS_SELFIE_IMAGE &&
                    !Config.VIDEO_IDENT_PLUS_REUSE_IMAGES
                ) {
                    Config.VIDEO_IDENT_PLUS_UI = true
                }
            } ?: run {
                Config.VIDEO_IDENT_PLUS_UI = true
            }
        }

        settings.model_videoConfig?.let {
            Config.VIDEO_CONFIG_FRAME_RATE = it.video_frame_rate
            Config.VIDEO_CONFIG_HEIGHT = it.video_height
            Config.VIDEO_CONFIG_WIDTH = it.video_width
            Config.VIDEO_CONFIG_SCREENSHOT_WIDTH = it.video_screenshot_width
            Config.VIDEO_CONFIG_SCREENSHOT_HEIGHT = it.video_screenshot_height
            Config.VIDEO_CONFIG_PRE_ESTABLISH_RETRY_COUNT = it.preEstablishRetryCount
            Config.VIDEO_CONFIG_PVID_ENABLED = it.isPvid_enabled
            Config.SUPPORTED_RESOLUTION =
                (Config.VIDEO_CONFIG_HEIGHT * Config.VIDEO_CONFIG_WIDTH) / (1024000.0f)
        }

        return true
    }

    private fun toggleLoadingSpinnerVisibility(visible: Boolean) =
        viewState.update { it.copy(isLoading = visible) }

    private fun toggleDarkMode(isDarkMode: Boolean) =
        viewState.update { it.copy(isDarkModeAllowed = isDarkMode) }

    private fun toggleIdMethodsVisibility(visible: Boolean) =
        viewState.update { it.copy(showIdMethod = visible) }

    private suspend fun handleRestCallFailure(error: RetrofitError?) {
        var result = Util_UtilRetrofit.printRetrofitError(error)
        if (result.isNotBlank())
            result = Util_UtilRetrofit.getErrorIdRetrofit(result)

        val hasErrorResponse = error?.response != null
        events.emit(
            EntryEvent.ShowRESTCallErrorDialog(
                responseCode = if (hasErrorResponse) error!!.response.getStatus() else 0,
                retryAllowed = hasErrorResponse.not(),
                onConfirmAction = {
                    viewModelScope.launch(Dispatchers.IO) { fetchOfficeHours() }
                },
                result = result,
                finishActivityAfterDialog = hasErrorResponse,
                activeVideoCall = false,
                resultError = ""
            )
        )
    }

    /**
     * get the phone number of the customer and try to retrieve the documents (for esigning)
     */
    private suspend fun fetchCustomer() {
        toggleLoadingSpinnerVisibility(true)
        try {
            val response = provideRestApiService().getCustomer(
                transactionToken = IDnowSDK.getTransactionToken(),
                companyShort = IDnowSDK.getCompanyId()
            )
            if (response.isSuccessful)
                onGetCustomerRESTCallSuccess(response.body()!!)
            else
                onGetCustomerRESTCallFailure(RetrofitError.from(response))
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Error fetching customer", e)
            toggleLoadingSpinnerVisibility(false)
            handleRestCallFailure(RetrofitError.from(e))
        }
    }

    private suspend fun onGetCustomerRESTCallSuccess(resultObject: Models_Customer) {
        IDnowSDK.setTransactionToken(resultObject.internalToken)

        val useInstantSign = resultObject.processType.orEmpty()
            .equals("INSTANT_SIGN", true)
        Config.INSTANT_SIGN = useInstantSign
        Config.USE_NATIVE_ESIGNING = useInstantSign

        resultObject.mobile?.takeIf { it.isNotBlank() }
            ?.let {
                if (Config.USER_PHONE_NO.isBlank())
                    Config.USER_PHONE_NO = it
            } ?: run { Util_Log.i(LOGTAG, "mobile nr is null") }

        resultObject.email?.let { Config.EMAIL_ADDRESS = it }

        if (Config.EMAIL_ADDRESS.contains("***") || Config.USER_PHONE_NO.contains("***")) {
            Config.HIDE_USERS_PII_DATA = true
            Config.MASKED_USER_PHONE_NO = Config.USER_PHONE_NO
            Config.MASKED_EMAIL_ADDRESS = Config.EMAIL_ADDRESS
        }

        Config.FIRST_NAME = resultObject.firstName.orEmpty()
        Config.LAST_NAME = resultObject.lastName.orEmpty()

        resultObject.testRobotType?.takeIf { it.isNotBlank() }
            ?.let { Config.TEST_ROBOT_TYPE = it }

        Config.PREFERRED_LANG = resultObject.preferredLang.orEmpty()

        Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE = resultObject.isWaitingListNotified
        Config.WAITING_LIST_NOTIFICATIONS_ENROLLED = resultObject.isWaitingListEnrolled

        if (resultObject.status.equals("FINISHED", true)) {
            toggleLoadingSpinnerVisibility(false)
            events.emit(
                EntryEvent.ShowRESTCallErrorDialog(
                    responseCode = 412,
                    retryAllowed = true,
                    onConfirmAction = {
                        viewModelScope.launch { proceedToIdent() }
                    },
                    result = "",
                    finishActivityAfterDialog = true,
                    activeVideoCall = false,
                    resultError = ""
                )
            )
        } else {
            // setting success and failure urls if available
            resultObject.settings?.sucessUrl?.let { Config.SUCCESS_URL = it }
            resultObject.settings?.failureUrl?.let { Config.FAILURE_URL = it }
            resultObject.request?.let {
                Config.IDENT_ESTIMATED_WAITING_TIME = it.estimatedWaitingTime
                Config.IDENT_POSITION_IN_QUEUE = it.positionInQueue
            }

            if (Config.SHOW_NAME_VERIFICATION_SCREEN) {
                toggleLoadingSpinnerVisibility(false)
                viewState.update {
                    it.copy(
                        showNameCheck = true,
                        nameCheckTitleLabel = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_VERIFICATION_TITLTE,
                            Util_Strings.LOCAL_KEY_VERIFICATION_TITLTE
                        ),
                        nameCheckDescriptionLabel = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_VERIFICATION_DESCRIPTION,
                            Util_Strings.LOCAL_KEY_VERIFICATION_DESCRIPTION
                        ),
                        nameCheckNameLabel = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_VERIFICATION_NAME,
                            Util_Strings.LOCAL_KEY_VERIFICATION_NAME
                        ),
                        nameCheckNameValue = "${Config.FIRST_NAME} ${Config.LAST_NAME}",
                        nameCheckContinueLabel = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_VERIFICATION_CONTINUE,
                            Util_Strings.LOCAL_KEY_VERIFICATION_CONTINUE
                        ),
                        nameCheckQuitLabel = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_VERIFICATION_INCORRECT,
                            Util_Strings.LOCAL_KEY_VERIFICATION_INCORRECT
                        )
                    )
                }
            } else {
                forwardToFlow()
            }
        }
    }

    private suspend fun onGetCustomerRESTCallFailure(error: RetrofitError) {
        toggleLoadingSpinnerVisibility(false)
        handleRestCallFailure(error)
    }

    private suspend fun forwardToFlow() {
        viewState.update {
            it.copy(
                showNameCheck = false,
                isLoading = true
            )
        }

        if (Config.EID_CONFIG && !Config.INSTANT_SIGN) {
            if (Config.BACK_TO_VID) {
                toggleIdMethodsVisibility(false)
                if (Config.E_SIGNING) {
                    // fetch documents if esigning needs to be performed
                    fetchPdfDocuments()
                } else {
                    toggleLoadingSpinnerVisibility(false)
                    navigateToChosenModeActivity()
                }
            } else if (Config.ENABLE_EID_STANDALONE) {
                if (ConnectivityService.isOnline()) {
                    setupEID()
                } else {
                    toggleLoadingSpinnerVisibility(false)
                    showNoConnectionDialog(false)
                }
            } else {
                viewState.update {
                    it.copy(
                        isLoading = false,
                        showIdMethod = true,
                        showEidLogo = IDnowSDK.getShowIDnowLogo(),
                        pageTitle = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_EID_CHOOSER_PAGE_TITLE,
                            Util_Strings.LOCAL_EID_CHOOSER_PAGE_TITLE
                        ),
                        vidTitle = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_EID_CHOOSER_PAGE_VID_TITLE,
                            Util_Strings.LOCAL_EID_CHOOSER_PAGE_VID_TITLE
                        ),
                        vidDescription = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_EID_CHOOSER_PAGE_VID_DESC,
                            Util_Strings.LOCAL_EID_CHOOSER_PAGE_VID_DESC
                        ),
                        vidTime = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_VI_WAITING_TIME,
                            Util_Strings.LOCAL_KEY_VI_WAITING_TIME
                        ),
                        eidTitle = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_EID_CHOOSER_PAGE_EID_TITLE,
                            Util_Strings.LOCAL_EID_CHOOSER_PAGE_EID_TITLE
                        ),
                        eidDescription = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_EID_CHOOSER_PAGE_EID_DESC,
                            Util_Strings.LOCAL_EID_CHOOSER_PAGE_EID_DESC
                        ),
                        eidTime = Util_Strings.getStringWithDefault(
                            Util_Strings.KEY_EID_WAITING_TIME,
                            Util_Strings.LOCAL_KEY_EID_WAITING_TIME
                        )
                    )
                }

                Util_CustomLogData.setEventData(
                    EVENT_IDENTIFICATION_METHOD_SHOWN,
                    "EVENT_IDENTIFICATION_METHOD_SHOWN",
                    "Identification Method",
                    "Screen",
                    EVENT_IDENTIFICATION_METHOD_TIME_SPENT
                )
            }
        } else {
            if (Config.E_SIGNING) {
                // fetch documents if esigning needs to be performed
                fetchPdfDocuments()
            } else {
                toggleLoadingSpinnerVisibility(false)
                navigateToChosenModeActivity()
            }
        }
    }

    private suspend fun setupEID() {
        if (Util_Util.checkNFCenabled(IDnowSDK.getInstance().appContext))
            initializeEID()
        else
            events.emit(EntryEvent.ShowNfcDialog)
    }

    private suspend fun initializeEID() {
        eIDSdk.setLogging(IDnowSDK.isLoggingEnabled())
        events.emit(EntryEvent.InitializeEidSdk)
    }

    fun onEidSdkInitialized() = viewModelScope.launch {
        val eIDData = Model_eIDData().apply {
            endPoint =
                Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken())
            companyID = IDnowSDK.getCompanyId()
            transactionToken = IDnowSDK.getTransactionToken()
        }

        try {
            eIDSdk.setDarkModeEnabled(Config.DARK_MODE_ENABLED_CUSTOMER)
            eIDSdk.setIDnowSDKEndpoint(eIDData.getEndPoint())
            eIDSdk.setCompanyId(eIDData.getCompanyID())
            eIDSdk.setTransactionToken(eIDData.getTransactionToken())
            eIDSdk.setAppkey(Config.CUSTOM_LOG_APPKEY)
            eIDSdk.setAppURL(Config.CUSTOM_LOG_URL)
            eIDSdk.setEnableEIDQES(Config.ENABLE_QES_EID)
            eIDSdk.setPhoneNumber(Config.USER_PHONE_NO)
            eIDSdk.setModels_clientInfoLanguage(Util_Util.getClientInfoLanguage())
            eIDSdk.setShowTermsConditionsEID(
                IDnowSDK.isShowTermsConditionsEID(),
                IDnowSDK.getInstance().appContext
            )
            eIDSdk.setShowPoweredBy(Config.SHOW_POWERED_BY_KEY)
            eIDSdk.setShowIDnowLogo(Config.SHOW_IDNOW_LOGO)
            eIDSdk.setAuthadaStagingUrl(Config.AUTHADA_STAGING_URL)
            eIDSdk.setAuthadaProductionUrl(Config.AUTHADA_PRODUCTION_URL)
            eIDSdk.setShowDialogsWithIcon(IDnowSDK.showDialogsWithIcon())
            eIDSdk.setConnectionType(ConnectivityService.getConnectionType())
            eIDSdk.setEIDTSP(Config.EIDTSP)
            if (Config.EIDTSP.equals("Governikus", ignoreCase = true)) {
                eIDSdk.setEnableChooseEIDType(Config.ENABLE_CHOOSE_EID_TYPE)
            }

            if (Config.ENABLE_ID_CAPTURE_EID)
                eIDSdk.setEnableIDCaptureEID(true)
            if (Config.ENABLE_PIN_CHANGE)
                eIDSdk.setChangePinEID(true)

            eIDSdk.setStandaloneEID(Config.ENABLE_EID_STANDALONE)

            if (IDnowSDK.getNewBrand())
                eIDSdk.setNewBrand(true)
            eIDSdk.setMessagesfromBackend(Config.MESSAGES)
        } catch (error: NoClassDefFoundError) {
            Util_Log.e(LOGTAG, "Init eID failed", error)
            events.emit(
                EntryEvent.ShowEIDDialog(
                    message = "You are trying to perform an identification using the Electronic ID option please contact our support under support@mail.idnow.de"
                )
            )
        }
    }

    private suspend fun navigateToChosenModeActivity() {
        toggleLoadingSpinnerVisibility(false)
        AssetsLoader.loadMessages(true)
        AssetsLoader.loadLottieAnimations()
        if (Config.OFFICE_HOUR.not()) {
            events.emit(
                EntryEvent.ShowOfficeHoursUnsupportedProductDialog(
                    message = Util_Util.generateOfficeHoursMessage(officeHours!!)
                )
            )
        } else {
            if (Config.ID_MODE == Config.IDENTIFICATION_MODE.VIDEO) {
                // call the second step activity
                // either go to streaming or show checkboxes for user first
                val destinationActivity: Class<*>
                var extras: Bundle? = null
                if (shouldGoToAvailableLanguages() && !Config.INSTANT_SIGN) {
                    val bundle = Bundle().apply {
                        putStringArrayList(
                            ActivityAgentLanguage.AVAILABLE_LANGUAGES_KEY,
                            ArrayList(officeHours!!.getAvailableLanguages())
                        )
                    }
                    destinationActivity = ActivityAgentLanguage::class.java
                    extras = bundle
                } else if (IDnowSDK.isShowVideoOverviewCheck(IDnowSDK.getInstance().appContext)) {
                    destinationActivity = IDnowSDK.getCheckScreenActivity()
                } else {
                    events.emit(EntryEvent.CheckForRuntimePermissions)
                    return
                }

                events.emit(
                    EntryEvent.NavigateToActivity(
                        classz = destinationActivity,
                        extras = extras,
                        requestResult = true,
                        disableTransitions = true
                    )
                )
            } else {
                events.emit(
                    EntryEvent.ShowRESTCallErrorDialog(
                        responseCode = 404,
                        retryAllowed = false,
                        onConfirmAction = {
                            viewModelScope.launch { proceedToIdent() }
                        },
                        result = "",
                        finishActivityAfterDialog = true,
                        activeVideoCall = false,
                        resultError = ""
                    )
                )
            }
        }
    }

    private fun shouldGoToAvailableLanguages(): Boolean {
        val isLanguageSelector = officeHours!!.settings.isLanguageSelectorAndroid
        if (isLanguageSelector.not())
            return false

        val availableLanguages = officeHours!!.getAvailableLanguages()
        if (availableLanguages.count() == 1)
            Config.PREFERRED_LANG = availableLanguages[0]

        return availableLanguages.isNotEmpty()
    }

    private fun provideRestApiService(): Network_RESTCallsKt {
        val endpoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken())
        return IDnowRestClient.getRestClient().getCallsForEndpointKt(
            endpoint,
            IDnowSDK.getInstance().appContext
        )
    }

    fun onActivityResult(result: ActivityResult) = viewModelScope.launch {
        Util_CustomLogData.endSession()
        val resultCode = result.resultCode
        val intent = result.data
        Util_Log.i(LOGTAG, "onActivityResult called : ${IDnowSDK.RESULT_CODE}  $resultCode")

        if (resultCode in 1..7) {
            IDnowSDK.RESULT_CODE = resultCode
            IDnowSDK.setCallFromHighCallVolumeActivity(
                false,
                IDnowSDK.getInstance().appContext
            )
        }

        var intentToSet = Intent()

        when (IDnowSDK.RESULT_CODE) {
            IDnowSDK.RESULT_CODE_FALLBACK_VID -> {
                Config.BACK_TO_VID = true
                try {
                    IDnowSDK.getInstance().start(IDnowSDK.getTransactionToken())
                } catch (e: Exception) {
                    Util_Log.e(LOGTAG, "Error starting ident video ident", e)
                }
            }

            IDnowSDK.RESULT_CODE_FAILED -> {
                if (intent?.hasExtra(IDnowSDK.RESULT_ERROR_CODE) == true) {
                    intentToSet = intent
                } else {
                    intentToSet.putExtra(
                        IDnowSDK.RESULT_DATA_ERROR,
                        IDnowSDK.getInstance().appContext.getString(IDnowSDK.MESSAGE_ID_FAILED)
                    )
                }
            }

            IDnowSDK.RESULT_CODE_SUCCESS -> {
                intentToSet.putExtra(
                    IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN,
                    IDnowSDK.getTransactionToken()
                )
            }

            IDnowSDK.RESULT_CODE_CANCEL -> {
                intentToSet.putExtra(
                    IDnowSDK.RESULT_DATA_ERROR,
                    IDnowSDK.getInstance().appContext.getString(IDnowSDK.MESSAGE_USER_CANCELED)
                )
                intentToSet.putExtra(
                    IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN,
                    IDnowSDK.getTransactionToken()
                )
            }

            IDnowSDK.RESULT_CODE_WRONG_IDENT -> {
                intentToSet.putExtra(
                    IDnowSDK.RESULT_DATA_ERROR,
                    IDnowSDK.getInstance().appContext.getString(IDnowSDK.MESSAGE_WRONG_TOKEN)
                )
                intentToSet.putExtra(
                    IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN,
                    IDnowSDK.getTransactionToken()
                )
            }
        }

        if (IDnowSDK.RESULT_CODE == IDnowSDK.CHOOSER_SCREEN) {
            if (Config.ENABLE_EID_STANDALONE) {
                setupEID()
            } else {
                toggleIdMethodsVisibility(true)
            }
        } else {
            val resultCodeToSet = if (resultCode == 0) IDnowSDK.RESULT_CODE else resultCode
            IDnowSDK.getInstance().deliverResult(resultCodeToSet, intentToSet)
            Util_Util.clearApplicationData(IDnowSDK.getInstance().appContext)

            events.emit(
                EntryEvent.NavigateBack(
                    intent = intentToSet,
                    resultCode = resultCodeToSet
                )
            )

            if (!Config.SHOW_HIGH_CALL_VOLUME) {
                IDnowSDK.getInstance().setCallingActivity(null)
            }
        }
        IDnowSDK.RESULT_INTENT = intentToSet
    }

    fun onPermissionsGranted() = viewModelScope.launch {
        proceedToIdent()
    }

    private suspend fun navigateToScreen(
        classz: Class<*>,
        requestResult: Boolean = false,
        disableTransitions: Boolean = false
    ) {
        events.emit(
            EntryEvent.NavigateToActivity(
                classz = classz,
                requestResult = requestResult,
                disableTransitions = disableTransitions
            )
        )
    }

    private suspend fun proceedToIdent() {
        val startCQC = Config.CALL_QUALITY_CHECK_ENABLED && !Config.CALL_QUALITY_CHECK_PASSED
        val allowRestartVideoIdent = Config.AUTHENTICATED_POSSIBLE && !Config.RESTART_VIDEO_IDENT
        when {
            IDnowSDK.isShowVideoOverviewCheck(IDnowSDK.getInstance().appContext) ->
                navigateToScreen(
                    classz = Util_VideoStreamService.getClassForOverviewCheck(),
                    requestResult = true
                )

            Config.INSTANT_SIGN ->
                updatePhoneNumber(Config.USER_PHONE_NO)

            Config.VIDEO_IDENT_PLUS && Config.SHOW_PREPARE_SCREEN ->
                navigateToScreen(
                    classz = Util_VideoStreamService.getClassForBeforeStartingActivity(),
                    requestResult = true
                )

            allowRestartVideoIdent.not() && startCQC ->
                navigateToScreen(
                    classz = Util_VideoStreamService.getClassForCallQualityCheck(),
                    requestResult = true
                )

            allowRestartVideoIdent.not() &&
                    Config.VIDEO_CONFIG_PVID_ENABLED &&
                    !CameraHelper.checkResolutionSupport(Config.SUPPORTED_RESOLUTION.toLong()) ->
                navigateToScreen(
                    classz = Util_VideoStreamService.getClassDeviceSupportActivity(),
                    requestResult = true
                )

            else -> makeStartRESTCall()
        }
    }

    fun onVideoIdentSelected() = viewModelScope.launch {
        if (ConnectivityService.isOnline()) {
            Config.BACK_TO_VID = true
            toggleIdMethodsVisibility(false)
            if (Config.E_SIGNING) {
                // fetch documents if esigning needs to be performed
                fetchPdfDocuments()
            } else {
                toggleLoadingSpinnerVisibility(false)
                navigateToChosenModeActivity()
            }
        } else {
            showNoConnectionDialog(false)
        }
    }

    fun onEidIdentSelected() = viewModelScope.launch {
        if (ConnectivityService.isOnline())
            setupEID()
        else
            showNoConnectionDialog(false)
    }

    /**
     * only called when esignature has to be performed. Fetch all the documents connected to the current customer and store the urls in the config.
     */
    private suspend fun fetchPdfDocuments() {
        try {
            toggleLoadingSpinnerVisibility(true)
            val response = provideRestApiService().getDocuments(
                companyShort = IDnowSDK.getCompanyId(),
                transactionToken = IDnowSDK.getTransactionToken()
            )
            if (response.isSuccessful)
                onFetchPdfDocumentsSuccess(response.body()!!)
            else
                onFetchPdfDocumentsFailure(RetrofitError.from(response))
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Error fetching pdf documents", e)
            toggleLoadingSpinnerVisibility(false)
            handleRestCallFailure(RetrofitError.from(e))
        }
    }

    private suspend fun onFetchPdfDocumentsFailure(error: RetrofitError) {
        toggleLoadingSpinnerVisibility(false)
        handleRestCallFailure(error)
    }

    private suspend fun onFetchPdfDocumentsSuccess(resultObject: Array<Models_PDFDocument>) {
        Util_Log.i(LOGTAG, "SIZE OF DOCUMENTS: ${resultObject.count()}")
        Config.PDF_DOCUMENTS = resultObject

        if (Config.INSTANT_SIGN) {
            if (resultObject.any { it.status.equals("NEED_UPLOAD", ignoreCase = true) }) {
                toggleLoadingSpinnerVisibility(false)
                events.emit(
                    EntryEvent.ShowDocumentNotUploadedDialog(
                        message = Util_Strings.getStringWithDefault(
                            KEY_DOC_NOT_UPLOADED,
                            LOCAL_KEY_DOC_NOT_UPLOADED
                        )
                    )
                )
            } else {
                makeStartInstantSignRESTCall()
            }
        } else {
            if (Config.AUTHENTICATED_SIGNED) {
                authenticationPossibleRESTCall()
            } else {
                toggleLoadingSpinnerVisibility(false)
                navigateToChosenModeActivity()
            }
        }
    }

    private suspend fun makeStartInstantSignRESTCall() {
        toggleLoadingSpinnerVisibility(true)
        try {
            val phoneNo = Config.USER_PHONE_NO.takeUnless { it.contains("***") }
            val email = Config.EMAIL_ADDRESS.takeUnless { it.contains("***") }

            val startObject = Models_StartObject(
                IDnowSDK.getTransactionToken(),
                phoneNo,
                null,
                email,
                Config.PREFERRED_LANG,
                Util_Util.getClientInfo(),
                null
            )

            val response = provideRestApiService().startInstantSign(
                startObject = startObject,
                companyShort = IDnowSDK.getCompanyId(),
                transactionToken = IDnowSDK.getTransactionToken()
            )

            if (response.isSuccessful)
                onMakeStartInstantSignRESTCallSuccess(response.body())
            else
                onMakeStartInstantSignRESTCallFailure(RetrofitError.from(response))
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Error calling start instant sign", e)
            toggleLoadingSpinnerVisibility(false)
            handleRestCallFailure(RetrofitError.from(e))
        }
    }

    private suspend fun onMakeStartInstantSignRESTCallFailure(error: RetrofitError) {
        toggleLoadingSpinnerVisibility(false)
        if (error.response.getStatus() == 412) {
            val resultError = Util_UtilRetrofit.printRetrofitError(error)
            val errorType = Util_UtilRetrofit.getErrorTypeRetrofit(resultError)
            if (errorType == IDnowSDK.INSTANTSIGN_ERROR_ID) {
                Config.INSTANTERROR_TYPE = IDnowSDK.INSTANTSIGN_ERROR_ID
            }

            events.emit(
                EntryEvent.NavigateToActivity(
                    classz = VerifyIdActivity::class.java,
                    requestResult = true
                )
            )
        } else {
            val hasResponseError = error.response != null
            events.emit(
                EntryEvent.ShowRESTCallErrorDialog(
                    responseCode = if (hasResponseError) error.response.status else 0,
                    retryAllowed = false,
                    onConfirmAction = {
                        viewModelScope.launch { proceedToIdent() }
                    },
                    result = "",
                    finishActivityAfterDialog = hasResponseError,
                    activeVideoCall = false,
                    resultError = ""
                )
            )
        }
    }

    private suspend fun onMakeStartInstantSignRESTCallSuccess(resultObject: Model_InstantSignStart?) {
        toggleLoadingSpinnerVisibility(false)
        if (resultObject != null) {
            Config.IDENTIFICATION_SIGNATURE = resultObject.identification_Signature
            Config.E_SIGNING_SECRET = resultObject.clientSecret
            Config.USER_SESSION_TOKEN = resultObject.sessionToken
            if (resultObject.enableOTP != null) {
                Config.OTP_DISPLAY_SIGNING = resultObject.enableOTP.isSigning
                Config.OTP_DISPLAY_IDENT = resultObject.enableOTP.isIdent
            }
        }
        navigateToChosenModeActivity()
    }

    private suspend fun updatePhoneNumber(phoneNumber: String) {
        try {
            toggleLoadingSpinnerVisibility(true)
            val response = provideRestApiService().updateMobileNumber(
                number = Models_MobileNumber(phoneNumber),
                companyShort = IDnowSDK.getCompanyId(),
                transactionToken = IDnowSDK.getTransactionToken()
            )
            toggleLoadingSpinnerVisibility(false)
            if (response.isSuccessful)
                forwardResultAndFinish()
            else {
                val error = RetrofitError.from(response)
                val hasErrorResponse = error.response != null
                events.emit(
                    EntryEvent.ShowRESTCallErrorDialog(
                        responseCode = if (hasErrorResponse) error.response.getStatus() else 0,
                        retryAllowed = false,
                        onConfirmAction = { viewModelScope.launch { updatePhoneNumber(phoneNumber) } },
                        result = "",
                        finishActivityAfterDialog = hasErrorResponse,
                        activeVideoCall = false,
                        resultError = Util_UtilRetrofit.printRetrofitError(error)
                    )
                )
            }
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Error calling update phone number", e)
            toggleLoadingSpinnerVisibility(false)
            handleRestCallFailure(RetrofitError.from(e))
        }
    }

    private suspend fun authenticationPossibleRESTCall() {
        toggleLoadingSpinnerVisibility(true)
        try {
            val response = provideRestApiService().authenticationPossible(
                companyShort = IDnowSDK.getCompanyId(),
                transactionToken = IDnowSDK.getTransactionToken()
            )
            if (response.isSuccessful)
                onAuthenticationPossibleRESTCallSuccess(response.body()!!)
            else
                onAuthenticationPossibleRESTCallFailure()
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Error calling start instant sign", e)
            toggleLoadingSpinnerVisibility(false)
            handleRestCallFailure(RetrofitError.from(e))
        }
    }

    private suspend fun onAuthenticationPossibleRESTCallFailure() {
        Util_Log.i(LOGTAG, "authenticationPossible REST Call failed")
        toggleLoadingSpinnerVisibility(false)
        navigateToChosenModeActivity()
    }

    private suspend fun onAuthenticationPossibleRESTCallSuccess(resultObject: Models_authenticationPossible) {
        Util_Log.i(LOGTAG, "authenticationPossible REST Call was successful")
        Config.AUTHENTICATED_POSSIBLE = resultObject.isAuthenticatedRequest
        Config.EXPIRED_WALLET_EXISTS = resultObject.isExpiredWalletExists
        toggleLoadingSpinnerVisibility(false)
        if (Config.EXPIRED_WALLET_EXISTS) {
            events.emit(
                EntryEvent.ShowWalletAccountExpiredDialog(
                    onContinue = { viewModelScope.launch { navigateToChosenModeActivity() } })
            )
            viewState.update { it.copy(showPoweredByLogo = true) }
        } else
            navigateToChosenModeActivity()
    }

    private suspend fun fetchMaskedData() {
        try {
            toggleLoadingSpinnerVisibility(true)
            val response = provideRestApiService().getCustomer(
                transactionToken = IDnowSDK.getTransactionToken(),
                companyShort = IDnowSDK.getCompanyId()
            )

            toggleLoadingSpinnerVisibility(false)

            if (response.isSuccessful) {
                val customer = response.body()
                customer?.mobile?.takeIf { it.contains("***") }
                    ?.let { Config.MASKED_USER_PHONE_NO = it }
                customer?.email?.takeIf { it.contains("***") }
                    ?.let { Config.MASKED_EMAIL_ADDRESS = it }

                navigateToScreen(
                    classz = Util_VideoStreamService.getClassForVideoLiveStreaming(),
                    requestResult = true
                )
            }
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Error fetching masked data", e)
            toggleLoadingSpinnerVisibility(false)
        }
    }

    private suspend fun forwardResultAndFinish() {
        navigateToScreen(
            classz = Util_VideoStreamService.getClassForVideoLiveStreaming(),
            requestResult = true,
            disableTransitions = true
        )
    }

    /**
     * has to be called only when the VideoOverviewCheckActivity hasn't been shown before.
     */
    private suspend fun makeStartRESTCall() {
        if (IDnowSDK.getInstance().isStartCallIssued && !Config.RESTART_VIDEO_IDENT) {
            Util_Log.i(LOGTAG, "start-Call already done, not reissuing it.")
            if (Config.HIDE_USERS_PII_DATA) {
                fetchMaskedData()
            } else {
                forwardResultAndFinish()
            }

            return
        }

        try {
            toggleLoadingSpinnerVisibility(true)

            val transactionToken = IDnowSDK.getTransactionToken()
            val phone = Config.USER_PHONE_NO.takeUnless { it.contains("***") }
            val email = Config.EMAIL_ADDRESS.takeUnless { it.contains("***") }

            val objData =
                if (Config.AUTHENTICATED_POSSIBLE && !Config.RESTART_VIDEO_IDENT)
                    Models_StartObject(
                        transactionToken,
                        phone,
                        null,
                        email,
                        Config.PREFERRED_LANG,
                        Util_Util.getClientInfo(),
                        true
                    )
                else
                    Models_StartObject(
                        transactionToken,
                        phone,
                        email,
                        Config.PREFERRED_LANG,
                        Util_Util.getClientInfo(),
                        null
                    )

            val response = provideRestApiService().start(
                startObject = objData,
                companyShort = IDnowSDK.getCompanyId(),
                transactionToken = transactionToken
            )
            if (response.isSuccessful)
                onStartRestCallSuccess(response.body()!!)
            else
                onStartRestCallFailure(RetrofitError.from(response))
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Error calling start endpoint", e)
            toggleLoadingSpinnerVisibility(false)
            handleRestCallFailure(RetrofitError.from(e))
        }
    }

    private suspend fun onStartRestCallSuccess(resultObject: Models_StartObjectResult) {
        toggleLoadingSpinnerVisibility(false)

        if (resultObject.getEnableOTPForWallet() != null && Config.AUTHENTICATED_POSSIBLE || Config.AUTHENTICATED_SIGNED) {
            Config.OTP_DISPLAY_SIGNING = resultObject.enableOTPForWallet.isSigning
            Config.OTP_DISPLAY_IDENT = resultObject.enableOTPForWallet.isIdent
        } else {
            if (resultObject.getEnableOTP() != null) {
                Config.OTP_DISPLAY_SIGNING = resultObject.enableOTP.isSigning
                Config.OTP_DISPLAY_IDENT = resultObject.enableOTP.isIdent
            }
        }
        resultObject.mobile?.let { Config.USER_PHONE_NO = it }
        resultObject.email?.let { Config.EMAIL_ADDRESS = it }

        Config.IDENTIFICATION_SIGNATURE = resultObject.getRequest().identification_Signature

        Util_Log.d(LOGTAG, "success : ")

        val remainingInternalTokenRetries = resultObject.getRemainingInternalTokenRetries()
        Util_Log.d(LOGTAG, "remainingInternalTokenRetries = $remainingInternalTokenRetries")

        // set the openTok configs
        Util_VideoSessionConfig.setSessionIdAndToken(resultObject)

        resultObject.request?.let {
            Config.E_SIGNING_SECRET = it.clientSecret
            Config.USER_SESSION_TOKEN = it.sessionToken
        }

        IDnowSDK.getInstance().isStartCallIssued = true
        forwardResultAndFinish()
    }

    private suspend fun onStartRestCallFailure(error: RetrofitError) {
        toggleLoadingSpinnerVisibility(false)
        IDnowSDK.getInstance().isStartCallIssued = false

        val hasErrorResponse = error.response != null
        events.emit(
            EntryEvent.ShowRESTCallErrorDialog(
                responseCode = if (hasErrorResponse) error.response.getStatus() else 0,
                retryAllowed = true,
                onConfirmAction = { viewModelScope.launch { proceedToIdent() } },
                result = "",
                finishActivityAfterDialog = hasErrorResponse,
                activeVideoCall = false,
                resultError = Util_UtilRetrofit.printRetrofitError(error)
            )
        )
    }

    private suspend fun showNoConnectionDialog(dismissScreen: Boolean) {
        events.emit(
            EntryEvent.ShowNoConnectionDialog(dismissScreen)
        )
    }

    fun continueNameVerification() = viewModelScope.launch {
        forwardToFlow()
    }

    fun cancelNameVerification() = viewModelScope.launch {
        events.emit(
            EntryEvent.ShowCancelVerificationIdentificationDialog
        )
    }
}