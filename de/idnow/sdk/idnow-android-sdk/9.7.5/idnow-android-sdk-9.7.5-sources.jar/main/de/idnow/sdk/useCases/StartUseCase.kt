package de.idnow.sdk.useCases

import android.content.Intent
import de.idnow.sdk.Activities.Activities_DeviceSupportActivity
import de.idnow.sdk.Activities.BaseActivity
import de.idnow.sdk.Config
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.models.Models_Customer
import de.idnow.sdk.models.Models_OfficeHours
import de.idnow.sdk.models.Models_StartObject
import de.idnow.sdk.models.Models_StartObjectResult
import de.idnow.sdk.network.Callback
import de.idnow.sdk.network.IDnowRestClient
import de.idnow.sdk.network.RetrofitError
import de.idnow.sdk.network.connectivityService.ConnectivityService
import de.idnow.sdk.util.Util_Log
import de.idnow.sdk.util.Util_Util
import de.idnow.sdk.util.Util_UtilRetrofit
import de.idnow.sdk.util.Util_UtilUI
import de.idnow.sdk.util.Util_VideoSessionConfig
import de.idnow.sdk.util.helper.CameraHelper
import retrofit2.Call
import retrofit2.Response

private const val LOGTAG = "IDNOW_StartUseCase"

internal class StartUseCase(
    private val resultCallback: ResultCallback,
    private val activityContext: BaseActivity
) {
    sealed interface Result {
        sealed interface Success : Result {
            data object NavigateToOverviewCheckScreen: Success
            data object NavigateToCqcScreen : Success
            data object NavigateToBeforeStartScreen : Success
            data object NavigateToLiveStreamScreen : Success
            data object NavigateToDeviceSupportScreen : Success
        }

        sealed interface Failure : Result {
            data object NoInternet : Failure
            data class ShowRemainingInternalTokenRetries(val count: Int) : Failure
            data class RestApiCall(
                val response: RetrofitError.Response?,
                val result: String?
            ) : Failure
        }
    }

    interface ResultCallback {
        fun onLoadingStarted()

        fun onResult(result: Result)
    }

    private var remainingInternalTokenRetries = -1

    fun proceed() {
        if (IDnowSDK.isShowVideoOverviewCheck(activityContext)){
            resultCallback.onResult(Result.Success.NavigateToOverviewCheckScreen)
        }else{
            if (activityContext.checkPermissionsGranted()) {
                onPermissionsAlreadyGranted()
            } else {
                activityContext.runWithPermissions(::onPermissionsGranted)
            }
        }
    }

    private fun onPermissionsAlreadyGranted() {
        if (ConnectivityService.isOnline()) {
            resultCallback.onLoadingStarted()
            fetchWaitingData()
            if (Config.SHOW_PREPARE_SCREEN) {
                resultCallback.onResult(Result.Success.NavigateToBeforeStartScreen)
            } else {
                if (shouldStartCQC()) {
                    resultCallback.onResult(Result.Success.NavigateToCqcScreen)
                } else {
                    fetchStartData(false)
                }
            }
        } else {
            resultCallback.onResult(Result.Failure.NoInternet)
        }
    }

    private fun onPermissionsGranted() {
        if (ConnectivityService.isOnline()) {
            if (Config.AUTHENTICATED_POSSIBLE && !Config.RESTART_VIDEO_IDENT) {
                fetchStartData(true)
            } else {
                if (Config.VIDEO_CONFIG_PVID_ENABLED &&
                    !CameraHelper.checkResolutionSupport(Config.SUPPORTED_RESOLUTION.toLong())
                ) {
                    val intent =
                        Intent(activityContext, Activities_DeviceSupportActivity::class.java)
                    activityContext.startActivity(intent)
                } else {
                    if (Config.SHOW_PREPARE_SCREEN) {
                        resultCallback.onResult(Result.Success.NavigateToBeforeStartScreen)
                    } else {
                        if (shouldStartCQC()) {
                            resultCallback.onResult(Result.Success.NavigateToCqcScreen)
                        } else {
                            fetchWaitingData()
                            fetchStartData(true)
                        }
                    }
                }
            }
        } else {
            resultCallback.onResult(Result.Failure.NoInternet)
        }
    }

    private fun shouldStartCQC(): Boolean =
        Config.CALL_QUALITY_CHECK_ENABLED && !Config.CALL_QUALITY_CHECK_PASSED

    private fun fetchWaitingData() {
        val endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken())
        val service = IDnowRestClient.getRestClient()
            .getCallsForEndpoint(endPoint, IDnowSDK.getInstance().appContext)

        val callback: Callback<Models_OfficeHours?> = object : Callback<Models_OfficeHours?>() {
            override fun failure(error: RetrofitError) {}

            override fun success(resultObject: Models_OfficeHours?, response: Response<*>?) {
                Util_Log.d(
                    LOGTAG,
                    "retrieving initial information about estimated waiting position/duration"
                )

                if (resultObject != null) {
                    Config.IDENT_ESTIMATED_WAITING_TIME = resultObject.estimatedWaitingTime
                    // we guesstimate that the position in the queue will be the number of waiting_chats + 1 (as there are X ppl in front of us, we will be at X+1)
                    Config.IDENT_POSITION_IN_QUEUE = resultObject.numberOfWaitingChatRequests + 1
                    Util_Log.d(
                        LOGTAG,
                        String.format(
                            "initial information about waiting duration: %d and numberOfWaitingChatReq: %d",
                            resultObject.estimatedWaitingTime,
                            resultObject.numberOfWaitingChatRequests
                        )
                    )
                } else {
                    Util_Log.d(LOGTAG, "initial information about waiting pos and duration is null")
                }
            }
        }

        val result = service.getCompanyShortname(IDnowSDK.getTransactionToken())
        result.enqueue(callback)
    }

    private fun handleRestCallFailure(error: RetrofitError?) {
        var result = Util_UtilRetrofit.printRetrofitError(error)
        if (result != "") {
            result = Util_UtilRetrofit.getErrorIdRetrofit(result)
        }

        resultCallback.onResult(
            Result.Failure.RestApiCall(
                response = error?.response,
                result = result
            )
        )
    }

    private fun fetchStartData(ignoreRetries: Boolean) {
        if (IDnowSDK.getInstance().isStartCallIssued && !Config.RESTART_VIDEO_IDENT) {
            Util_Log.i(LOGTAG, "start-Call already done, not reissuing it.")
            loadLiveVideo(false)

            return
        }

        val endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken())
        val service = IDnowRestClient.getRestClient()
            .getCallsForEndpoint(endPoint, IDnowSDK.getInstance().appContext)

        val callback: Callback<Models_StartObjectResult> =
            object : Callback<Models_StartObjectResult>() {
                override fun failure(error: RetrofitError) {
                    val errorType: String?
                    val errorID: String

                    val resultError = Util_UtilRetrofit.printRetrofitError(error)
                    errorType = Util_UtilRetrofit.getErrorTypeRetrofit(resultError)
                    errorID = Util_UtilRetrofit.getErrorIdRetrofit(resultError)


                    if (error.response != null && error.response.getStatus() == 412) {
                        if (errorType != null && errorType == IDnowSDK.DOCUSIGN_TOKEN_EXPIRING_SOON) {
                            val startRESTCallRunnable = Runnable {
                                fetchStartData(ignoreRetries)
                            }
                            Util_UtilUI.showRESTCallErrorDialog(
                                activityContext,
                                error.response.getStatus(),
                                false,
                                startRESTCallRunnable,
                                errorID,
                                true,
                                false,
                                resultError
                            )
                        } else {
                            remainingInternalTokenRetries = 0
                            resultCallback.onResult(
                                Result.Failure.ShowRemainingInternalTokenRetries(
                                    remainingInternalTokenRetries
                                )
                            )
                        }
                        return
                    }


                    if (error.response != null && error.response.getStatus() == 429) {
                        Util_Log.d(LOGTAG, "Forced waiting list active.")
                        loadLiveVideo(true)
                        return
                    }

                    IDnowSDK.getInstance().isStartCallIssued = false
                    handleRestCallFailure(error)
                }

                override fun success(
                    resultObject: Models_StartObjectResult,
                    response: Response<*>?
                ) {
                    if (resultObject.getEnableOTPForWallet() != null && Config.AUTHENTICATED_POSSIBLE || Config.AUTHENTICATED_SIGNED) {
                        Config.OTP_DISPLAY_SIGNING =
                            resultObject.getEnableOTPForWallet()!!.isSigning
                        Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTPForWallet()!!.isIdent
                    } else if (resultObject.getEnableOTP() != null) {
                        Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTP().isSigning
                        Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTP().isIdent
                    }

                    Config.IDENTIFICATION_SIGNATURE =
                        resultObject.getRequest()?.identification_Signature

                    if (resultObject.mobile != null) {
                        Config.USER_PHONE_NO = resultObject.mobile
                    }

                    if (resultObject.email != null) {
                        Config.EMAIL_ADDRESS = resultObject.email
                    }

                    Util_Log.d(LOGTAG, "success")
                    IDnowSDK.setForcedWaitingList(false)

                    remainingInternalTokenRetries = resultObject.getRemainingInternalTokenRetries()
                    Util_Log.d(
                        LOGTAG,
                        "remainingInternalTokenRetries = $remainingInternalTokenRetries"
                    )

                    // check if the configured video server is TokBox, which is not supported anymore
                    if (resultObject.getRequest() != null) {
                        Config.E_SIGNING_SECRET = resultObject.getRequest().clientSecret
                        Config.USER_SESSION_TOKEN = resultObject.getRequest().sessionToken
                    }

                    Util_VideoSessionConfig.setSessionIdAndToken(resultObject)

                    if (remainingInternalTokenRetries == 1 && !ignoreRetries) {
                        resultCallback.onResult(
                            Result.Failure.ShowRemainingInternalTokenRetries(
                                remainingInternalTokenRetries
                            )
                        )
                    } else {
                        IDnowSDK.getInstance().isStartCallIssued = true
                        loadLiveVideo(false)
                    }
                }
            }

        val token = IDnowSDK.getTransactionToken()
        val clientInfo = Util_Util.getClientInfo()


        val companyID = IDnowSDK.getCompanyId()

        val localPhoneNumber = if (!Config.USER_PHONE_NO.contains("***")) {
            Config.USER_PHONE_NO
        } else {
            null
        }

        val localEmail = if (!Config.EMAIL_ADDRESS.contains("***")) {
            Config.EMAIL_ADDRESS
        } else {
            null
        }
        val result: Call<Models_StartObjectResult> =
            if (Config.AUTHENTICATED_POSSIBLE && !Config.RESTART_VIDEO_IDENT) {
                service.start(
                    Models_StartObject(
                        token,
                        localPhoneNumber,
                        null,
                        localEmail,
                        Config.PREFERRED_LANG,
                        clientInfo,
                        true
                    ),
                    companyID,
                    token
                )
            } else {
                service.start(
                    Models_StartObject(
                        token,
                        localPhoneNumber,
                        localEmail,
                        Config.PREFERRED_LANG,
                        clientInfo, null
                    ),
                    companyID,
                    token
                )
            }
        result.enqueue(callback)
    }

    private fun fetchMaskedData() {
        val endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken())
        val service = IDnowRestClient.getRestClient()
            .getCallsForEndpoint(endPoint, IDnowSDK.getInstance().appContext)

        val callback: Callback<Models_Customer> = object : Callback<Models_Customer>() {
            override fun success(resultObject: Models_Customer, response: Response<*>?) {
                if (resultObject.mobile != null && resultObject.mobile.contains("***")) {
                    Config.MASKED_USER_PHONE_NO = resultObject.mobile
                }

                if (resultObject.email != null && resultObject.email.contains("***")) {
                    Config.MASKED_EMAIL_ADDRESS = resultObject.email
                }
                resultCallback.onResult(Result.Success.NavigateToLiveStreamScreen)
            }

            override fun failure(error: RetrofitError) {
                handleRestCallFailure(error)
            }
        }

        val result = service.getCustomer(IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId())
        result.enqueue(callback)
    }

    private fun loadLiveVideo(forcedWaitingList: Boolean) {
        if (forcedWaitingList) {
            IDnowSDK.setForcedWaitingList(true)
        }
        if (Config.HIDE_USERS_PII_DATA) {
            fetchMaskedData()
        } else {
            resultCallback.onResult(Result.Success.NavigateToLiveStreamScreen)
        }
    }
}