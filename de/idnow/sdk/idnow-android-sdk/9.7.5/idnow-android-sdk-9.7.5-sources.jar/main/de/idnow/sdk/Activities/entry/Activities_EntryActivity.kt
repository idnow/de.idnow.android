@file:Suppress("PackageName")

package de.idnow.sdk.Activities.entry

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import androidx.activity.addCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import de.idnow.android.eid.eIDSdk
import de.idnow.insights.Insights
import de.idnow.sdk.Activities.BaseActivity
import de.idnow.sdk.Config
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.R
import de.idnow.sdk.databinding.ActivityEntryBinding
import de.idnow.sdk.util.Util_CustomLogData
import de.idnow.sdk.util.Util_Log
import de.idnow.sdk.util.Util_UtilUI
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

private const val LOGTAG = "IDNOW_Activities_EntryActivity"

@Suppress("ClassName")
class Activities_EntryActivity : BaseActivity() {

    private val viewModel: EntryViewModel by viewModels()

    private var _binding: ActivityEntryBinding? = null
    private val binding: ActivityEntryBinding get() = _binding!!

    private var viewState: EntryViewState? = null

    private val activityLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.onActivityResult(it)
    }

    private fun AppCompatActivity.launchOnCreated(
        block: suspend CoroutineScope.() -> Unit
    ) {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.CREATED) {
                block()
            }
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val result = ActivityResult(resultCode, data)
        viewModel.onActivityResult(result)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Util_Log.i(LOGTAG, "onCreate called")
        if (IDnowSDK.preventScreenshot) {
            // secures against manual screenshots and automatic screenshots
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        }

        _binding = ActivityEntryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupUI()
        collectViewState()
        collectEvents()
        viewModel.init(isDarkUiMode())
    }

    override fun onStart() {
        Util_CustomLogData.onStart(this)
        super.onStart()
    }

    override fun onStop() {
        Util_CustomLogData.onStop()
        super.onStop()
    }

    override fun onDestroy() {
        _binding = null
        super.onDestroy()
        Util_CustomLogData.endSession()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        Insights.sharedInstance().onConfigurationChanged(newConfig)
    }

    private fun collectViewState() = launchOnCreated {
        viewModel.getViewState().collect(::onViewStateChanged)
    }

    private fun collectEvents() = launchOnCreated {
        viewModel.getEvents().collect(::onEvent)
    }

    private fun onViewStateChanged(state: EntryViewState) = with(state) {
        if (isLoading != viewState?.isLoading)
            setupLoadingSpinner(isLoading)

        if (isDarkModeAllowed != viewState?.isDarkModeAllowed)
            setupDarkMode(isDarkModeAllowed)

        binding.idmethodLayout.isVisible = showIdMethod
        binding.apply {
            usedLogoEid.isVisible = showEidLogo
            chooserPageTitle.text = pageTitle

            chooserPageVidTitle.text = vidTitle
            chooserPageVidDesc.text = vidDescription
            chooserPageVidTime.text = vidTime

            chooserPageEidTitle.text = eidTitle
            chooserPageEidDesc.text = eidDescription
            chooserPageEidTime.text = eidTime
        }

        binding.nameVerificationLayout.apply {
            verifyTitle.text = nameCheckTitleLabel
            verifyDesc.text = nameCheckDescriptionLabel
            verifyName.text = nameCheckNameLabel
            verifyNameValue.text = nameCheckNameValue
            nameVerificationContinue.text = nameCheckContinueLabel
            nameVerificationQuit.text = nameCheckQuitLabel

            root.isVisible = showNameCheck
        }

        binding.poweredByIdnow.isVisible = state.showPoweredByLogo

        viewState = this
    }

    private fun onEvent(event: EntryEvent) {
        when (event) {
            is EntryEvent.ShowNoConnectionDialog ->
                Util_UtilUI.showNoConnectionDialog(this, event.dismissScreen)

            EntryEvent.ShowCameraAvailableDialog ->
                Util_UtilUI.showCameraAvailableDialog(this)


            is EntryEvent.ShowRESTCallErrorDialog ->
                Util_UtilUI.showRESTCallErrorDialog(
                    this,
                    event.responseCode,
                    event.retryAllowed,
                    event.onConfirmAction,
                    event.result,
                    event.finishActivityAfterDialog,
                    event.activeVideoCall,
                    event.resultError
                )

            is EntryEvent.ShowLinkAutoIdent ->
                Util_UtilUI.showLinkAutoIdent(event.mobileStoreLinks, event.message, this)

            is EntryEvent.ShowOfficeHoursUnsupportedProductDialog ->
                Util_UtilUI.showOfficeHoursUnsupportedProductDialog(this, event.message)

            is EntryEvent.NavigateToActivity ->
                startActivityForResult(event)

            EntryEvent.CheckForRuntimePermissions ->
                runWithPermissions(viewModel::onPermissionsGranted)

            is EntryEvent.NavigateBack -> {
                setResult(event.resultCode, event.intent)
                finish()
            }

            is EntryEvent.ShowMessageOKCancelDialog ->
                Util_UtilUI.showMessageOKCancel(
                    this,
                    event.message
                ) { _, _ -> event.onConfirm() }

            is EntryEvent.ShowEIDDialog ->
                Util_UtilUI.showEIDDialog(this, event.message)

            EntryEvent.ShowNfcDialog ->
                Util_UtilUI.dialog_nfc(this)

            is EntryEvent.ShowDocumentNotUploadedDialog ->
                Util_UtilUI.showDocumentNotUploaded(this, event.message)

            is EntryEvent.ShowWalletAccountExpiredDialog ->
                Util_UtilUI.showWalletAccountExpired(this) { event.onContinue() }

            EntryEvent.InitializeEidSdk -> {
                eIDSdk.getInstance().initialize(this)
                viewModel.onEidSdkInitialized()
            }

            EntryEvent.ShowCancelVerificationIdentificationDialog ->
                Util_UtilUI.showCancelVerificationIdentification(this)

            is EntryEvent.InitCustomLog -> {
                Util_CustomLogData.initLog(this, event.data)
                Util_CustomLogData.onCreate(this)
            }
        }
    }

    private fun startActivityForResult(event: EntryEvent.NavigateToActivity) {
        val intent = Intent(this, event.classz)
        event.extras?.let { intent.putExtras(it) }
        activityLauncher.launch(intent)
        if (event.disableTransitions) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, 0, 0)
                overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0)
            } else {
                @Suppress("DEPRECATION")
                overridePendingTransition(0, 0)
            }
        }
    }

    private fun setupLoadingSpinner(visible: Boolean) = with(binding) {
        if (visible) {
            progressGif.apply {
                setAnimation("loading.json")
                repeatCount = -1
                playAnimation()
            }
        } else {
            progressGif.pauseAnimation()
        }

        progressGif.isVisible = visible
        idnowProgressBar.isVisible = visible
    }

    private fun setupDarkMode(state: Boolean) {
        if (state.not()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            val bgColor = Color.parseColor("#F8F8F8")
            binding.apply {
                main.setBackgroundColor(bgColor)
                idnowProgressBar.setBackgroundColor(bgColor)
                progressGif.setBackgroundColor(bgColor)
            }
        }

        Util_UtilUI.setColorLottieAnimation(
            if (state) Color.WHITE else R.color.logo_fill,
            binding.usedLogoEid,
            "SecondaryVariant"
        )

        val chooserBgRes =
            if (state)
                R.drawable.chooser_background_dark
            else
                R.drawable.background_try

        binding.apply {
            chooserBackgroundEid.setBackgroundResource(chooserBgRes)
            chooserBackgroundVi.setBackgroundResource(chooserBgRes)
        }

        binding.poweredByIdnow.apply {
            if (state) {
                setAnimation("static_powered_by_idnow.json")
                playAnimation()
            } else {
                setBackgroundResource(R.drawable.powered_by)
            }
        }
    }

    @SuppressLint("ResourceType")
    private fun setupUI() = binding.apply {
        usedLogoEid.setAnimation("static_logo.json")

        videoidentAnimation.setAnimation("static_agent_headset.json")
        Util_UtilUI.setColorLottieAnimation(
            Color.parseColor(getResources().getString(R.color.primaryColor)),
            videoidentAnimation,
            "Primary"
        )

        eidAnimation.setAnimation("static_eid_hand.json")
        Util_UtilUI.setColorLottieAnimation(
            Color.parseColor(getResources().getString(R.color.primaryColor)),
            eidAnimation,
            "Primary"
        )

        arrowChooserEid.setAnimation("static_right_arrow_small.json")
        Util_UtilUI.setColorLottieAnimation(
            Color.parseColor(getResources().getString(R.color.primaryColor)),
            arrowChooserEid,
            "Fill 1"
        )

        arrowChooserVip.setAnimation("static_right_arrow_small.json")
        Util_UtilUI.setColorLottieAnimation(
            Color.parseColor(getResources().getString(R.color.primaryColor)),
            arrowChooserVip,
            "Fill 1"
        )

        videoIdentLayout.setOnClickListener { viewModel.onVideoIdentSelected() }
        eidIdentLayout.setOnClickListener { viewModel.onEidIdentSelected() }

        onBackPressedDispatcher.addCallback {
            if (Config.VERIFY_IDENTITY) {
                val intent = Intent(this@Activities_EntryActivity, Config.HOST_APP_START_ACTIVITY)
                startActivity(intent)
            } else {
                val intent = Intent()
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                IDnowSDK.updateResultCode(IDnowSDK.RESULT_CODE_CANCEL)
                IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_CANCEL, intent)
                setResult(IDnowSDK.RESULT_CODE_CANCEL, getIntent())
                finish()
            }
        }

        //name check layout
        binding.nameVerificationLayout.apply {
            nameVerificationContinue.setOnClickListener {
                viewModel.continueNameVerification()
            }
            nameVerificationQuit.setOnClickListener {
                viewModel.cancelNameVerification()
            }
        }
    }
}