package de.idnow.sdk.Activities;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

import de.idnow.sdk.Activities.entry.Activities_EntryActivity;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_UtilUI;

public class Activities_HighCallVolumeActivity extends BaseActivity {
    private final String LOGTAG = "IDNOW_Activities_HighCallVolumeActivity";

    LottieAnimationView idnow_logo;
    TextView high_call_volume_image_desc,high_call_volume_title,high_call_volume_message,try_later_button,continue_button;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high_call_volume);

        idnow_logo = findViewById(R.id.idnow_logo);
        high_call_volume_image_desc = findViewById(R.id.high_call_volume_image_desc);
        high_call_volume_title = findViewById(R.id.high_call_volume_title);
        high_call_volume_message = findViewById(R.id.high_call_volume_message);
        try_later_button = findViewById(R.id.try_later_button);
        continue_button = findViewById(R.id.continue_button);
        idnow_logo.setAnimation("static_logo.json");

        if(IDnowSDK.getShowIDnowLogo()){
            idnow_logo.setVisibility(View.VISIBLE);
        }
        else {
            idnow_logo.setVisibility(View.GONE);
        }

        context = this;

        setTexts();

        if(Config.DARK_MODE){
            Util_UtilUI.setColorLottieAnimation(Color.WHITE,idnow_logo,"SecondaryVariant");

        }
        else {
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill,idnow_logo,"SecondaryVariant");
        }

        try_later_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IDnowSDK.setCallFromHighCallVolumeActivity(false, context);
                quitSdk();
            }
        });

        continue_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IDnowSDK.setCallFromHighCallVolumeActivity(true, context);
                try {
                    IDnowSDK.getInstance().start(IDnowSDK.getTransactionToken());
                } catch (Exception e) {
                    Util_Log.e(LOGTAG, "Start identification failed", e);
                }
            }
        });
    }


    private void quitSdk() {
        if (!IDnowSDK.getOverrideEntryActivity()) {
            Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity.class;
        }
        Intent intent = new Intent(this, Config.HOST_APP_START_ACTIVITY);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        finish();
        if (!Config.BACK_TO_VID || IDnowSDK.getOverrideEntryActivity()) {
            startActivity(intent);
        }
    }

    private void setTexts() {
        continue_button.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_HIGHVOLUME_CONTINUE, Util_Strings.LOCAL_KEY_HIGHVOLUME_CONTINUE));
        try_later_button.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_HIGHVOLUME_TRYLATER, Util_Strings.LOCAL_KEY_HIGHVOLUME_TRYLATER));
        high_call_volume_image_desc.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_HIGHVOLUME_IMAGE_DESC, Util_Strings.LOCAL_KEY_HIGHVOLUME_IMAGE_DESC));
        high_call_volume_title.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_HIGHVOLUME_TITLE, Util_Strings.LOCAL_KEY_HIGHVOLUME_TITLE));
        high_call_volume_message.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_HIGHVOLUME_MESSAGE_, Util_Strings.LOCAL_KEY_HIGHVOLUME_MESSAGE));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        quitSdk();
        IDnowSDK.setCallFromHighCallVolumeActivity(false, this);
    }
}