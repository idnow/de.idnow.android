package de.idnow.sdk.Activities.instasign

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.airbnb.lottie.LottieAnimationView
import de.idnow.sdk.Activities.BaseActivity
import de.idnow.sdk.Config
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.R
import de.idnow.sdk.util.Util_Log
import de.idnow.sdk.util.Util_Strings

private const val LOGTAG = "IDNOW_VerifyIdActivity"

class VerifyIdActivity: BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verify_id)
        setTheme(androidx.appcompat.R.style.Theme_AppCompat_Light_NoActionBar)

        val idnowLogo = findViewById<LottieAnimationView>(R.id.idnow_logo)
        val verifyTitle = findViewById<TextView>(R.id.verifyTitle)
        val verifyDesc = findViewById<TextView>(R.id.verifyDesc)
        val continueInstantButton = findViewById<TextView>(R.id.continueInstantButton)
        val verifyQuit = findViewById<TextView>(R.id.quitInstantButton)

        if(Config.INSTANTERROR_TYPE.equals(IDnowSDK.INSTANTSIGN_ERROR_ID)){
            verifyTitle.text = Util_Strings.getStringWithDefault(this, Util_Strings.KEY_INSTANTSIGN_ERROR_ID_TITLE, Util_Strings.LOCAL_KEY_INSTANT_ERROR_TITLE)
            verifyDesc.text = Util_Strings.getStringWithDefault(this, Util_Strings.KEY_INSTANTSIGN_ERROR_ID_DESCRIPTION, Util_Strings.LOCAL_KEY_INSTANT_ERROR_DESC)
            continueInstantButton.visibility=View.GONE
        }
        else{
            verifyTitle.text = Util_Strings.getStringWithDefault(this, Util_Strings.KEY_INSTANTSIGN_VERIFY_ID_TITLE, Util_Strings.LOCAL_KEY_INSTANT_VERIFY_TITLE)
            verifyDesc.text = Util_Strings.getStringWithDefault(this, Util_Strings.KEY_INSTANTSIGN_VERIFY_ID_DESCRIPTION, Util_Strings.LOCAL_KEY_INSTANT_VERIFY_DESC)
            continueInstantButton.visibility=View.VISIBLE
        }

   continueInstantButton.text = Util_Strings.getStringWithDefault(this, Util_Strings.KEY_INSTANTSIGN_VERIFY_ID_CONTINUE_IDENTIFICATION, Util_Strings.LOCAL_KEY_INSTANT_VERIFY_CONTINUE_IDENTIFICATION)
        verifyQuit.text = Util_Strings.getStringWithDefault(this, Util_Strings.KEY_INSTANT_VERIFY_QUIT, Util_Strings.LOCAL_KEY_INSTANT_VERIFY_QUIT)

        idnowLogo.setAnimation("static_logo.json")
        idnowLogo.isVisible = Config.SHOW_IDNOW_LOGO

        continueInstantButton.setOnClickListener(View.OnClickListener {
            Config.VERIFY_IDENTITY = true
            try {
                IDnowSDK.getInstance().start(IDnowSDK.getTransactionToken())
            } catch (e: Exception) {
                Util_Log.e(LOGTAG, "Start identification failed", e)
            }
            setResult(IDnowSDK.RESULT_CODE_FALLBACK_VID)
            IDnowSDK.updateResultCode(IDnowSDK.RESULT_CODE_FALLBACK_VID)
            IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FALLBACK_VID, intent)
            finish()
        })

        verifyQuit.setOnClickListener(View.OnClickListener {
            onBackPressed()
        })

    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent()
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        IDnowSDK.updateResultCode(IDnowSDK.RESULT_CODE_CANCEL)
        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_CANCEL, getIntent())
        setResult(IDnowSDK.RESULT_CODE_CANCEL, getIntent())
        finish()
        return
    }

}