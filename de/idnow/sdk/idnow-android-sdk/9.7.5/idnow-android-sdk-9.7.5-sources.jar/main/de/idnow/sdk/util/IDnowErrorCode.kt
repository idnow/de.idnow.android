package de.idnow.sdk.util

enum class IDnowErrorCode(val code: Int) {
    /**
     *  Can occur during initialization (e.g. triggered by [IDnowController initialize]).
     *  Occurs when the IDnowSettings instance does not contain a transactionToken.
     */
    IDnowErrorMissingTransactionToken(1000),

    /**
     *  Can occur during initialization (e.g. triggered by [IDnowController initialize]).
     *  Occurs when the IDnowSettings instance does not contain a companyID.
     */
    IDnowErrorMissingCompanyID(1001),

    /**
     *  Can occur during initialization (e.g. triggered by [IDnowController initialize]).
     *  Occurs when an identification cannot be initialized because the time is outside business hours.
     */
    IDnowErrorOfficeClosed(1003),

    /**
     *  Can occur during initialization (e.g. triggered by [IDnowController initialize]).
     *  Occurs when the device does either have no front camera or no back camera.
     */
    IDnowErrorMissingCamera(1004),

    /**
     *  Can occur during initialization (e.g. triggered by [IDnowController initialize]).
     *  Occurs when a video ident was request, but the camera access was not granted by the user.
     */
    IDnowErrorCameraAccessNotGranted(1005),

    /**
     *  Can occur during initialization (e.g. triggered by [IDnowController initialize]).
     *  Occurs when a video ident was requested, but the microphone access was not granted by the user.
     */
    IDnowErrorMicrophoneAccessNotGranted(1006),

    /**
     *  Can occur during initialization (e.g. triggered by [IDnowController initialize]).
     *  Occurs when a video ident was requested, but the device does not provide a microphone.
     */
    IDnowErrorMissingMicrophone(1007),

    /**
     *  Can occur during initialization (e.g. triggered by [IDnowController initialize]).
     *  Occurs when a video ident was requested, but no internet connection is present.
     */
    IDnowErrorNoInternetConnection(1008),

    /**
     *  Can occur during initialization (e.g. triggered by [IDnowController initialize])
     *  and identification process (e.g. triggered by [IDnowController startIdentificationFromViewController:]).
     *  The error object will also contain the status code returned by the server.
     */
    IDnowErrorServer(1009),

    /**
     *  Can occur during an identification process (e.g. WebRTC service could not establish a video connection).
     */
    IDnowErrorWebRTC(1010),

    /**
     *  The token for Auto Ident
     */
    IDnowErrorTokenNotSupported(1013),

    /**
     *  Unable to perform an identification on a rooted device.
     *
     */
    IDnowErrorRootedPhoneNotSupported(1014),

    /**
     *  Using LiveSwitch with invalid key
     *
     */
    IDnowErrorInvalidWebRTCToken(1015),

    /**
     *  Server trust certificate is not valid
     */
    IDnowErrorInvalidServerCertificate(1021),

    /**
     *  Unsupported products
     */
    IDnowErrorUnsupportedProduct(1022),

    /**
     *  Client certificate is not valid
     */
    IDnowErrorInvalidClientCertificate(1025),

    /**
     *    UDP frontend certificate validation failed
     */
    IDnowUDPCertificateValidationFailed(1026),

    /**
     * eID module failed to initialize
     */
    IDnowEidInitializeFailed(1028),

    /**
     * The identification can't be performed because the device is not compatible
     */
    IDnowUnsupportedDevice(1033);
}