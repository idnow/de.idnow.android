package de.idnow.sdk.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Model_Country;
import de.idnow.sdk.util.Util_Log;

public class CustomAdapter extends BaseAdapter {
    private final String LOGTAG = "CustomAdapter";

    Context context;
    List<Model_Country> items;
    LayoutInflater inflter;

    public CustomAdapter(Context applicationContext, List<Model_Country> items) {
        this.context = applicationContext;
        this.items = items;
        inflter = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        //return flags.length;
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.item_country, null);
        ImageView icon = view.findViewById(R.id.imageView);
        TextView names = view.findViewById(R.id.textView);
        LinearLayout spinnerBackground = view.findViewById(R.id.spinnerBackground);

        if (IDnowSDK.getNewBrand()) {
            spinnerBackground.setBackgroundResource(R.drawable.rounded_background_grey);
        } else {
            spinnerBackground.setBackgroundResource(R.drawable.background_rounded_overview_screen);
        }

        if (!Config.DARK_MODE && !Config.DARK_MODE_ENABLED_CUSTOMER) {
            spinnerBackground.setBackgroundColor(Color.parseColor("#EEEEEE"));
        }

        int drawableID = 0;
        drawableID = context.getResources().getIdentifier("flag_" + items.get(i).getCode().toLowerCase(), "drawable", context.getPackageName());
        names.setText(items.get(i).getName() + " " + items.get(i).getDial_code());
        icon.setImageResource(drawableID);


        return view;
    }

}