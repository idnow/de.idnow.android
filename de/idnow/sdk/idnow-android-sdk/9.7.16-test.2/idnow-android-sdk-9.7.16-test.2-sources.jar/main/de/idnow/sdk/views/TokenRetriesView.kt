package de.idnow.sdk.views

import android.app.Activity
import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.R
import de.idnow.sdk.databinding.TokenRetriesViewBinding
import de.idnow.sdk.util.Util_Strings

internal class TokenRetriesView : LinearLayout {
    constructor(context: Context?) : super(context) {
        initialize()
    }

    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {
        initialize()
    }

    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        initialize()
    }

    private val binding: TokenRetriesViewBinding = TokenRetriesViewBinding.inflate(
        LayoutInflater.from(context),
        this,
        true
    )

    private var orchestratedView: View? = null
    private var onRetryAction: (() -> Unit)? = null
    private var progressBar: ProgressBar? = null

    fun setUpWithView(
        view: View,
        progressBar: ProgressBar,
        onRetry: () -> Unit
    ) {
        orchestratedView = view
        onRetryAction = onRetry
        this.progressBar = progressBar
    }

    private fun initialize() {
        binding.mainButton.setBackgroundResource(R.drawable.rounded_background_orange)
    }

    fun resolve(remainingInternalTokenRetries: Int) {
        when (remainingInternalTokenRetries) {
            0 -> {
                resolveUI(remainingInternalTokenRetries)
                cancelAttemptUsing(binding.mainButton)
            }

            1 -> {
                resolveUI(remainingInternalTokenRetries)
                proceedWithAttempt(remainingInternalTokenRetries)
                cancelAttemptUsing(binding.secondaryButton)
            }

            else -> {}
        }
    }

    private fun resolveUI(remainingInternalTokenRetries: Int) {
        orchestratedView?.visibility = GONE
        this.visibility = VISIBLE

        when (remainingInternalTokenRetries) {
            0 -> {
                binding.tokenRetriesTitle.text = IDnowSDK.getInstance().getStringWithDefault(
                    context,
                    Util_Strings.KEY_USER_FEEDBACK_BLOCKED_TITLE,
                    Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_TITLE
                )
                binding.tokenRetriesMessage.text = IDnowSDK.getInstance().getStringWithDefault(
                    context,
                    Util_Strings.KEY_USER_FEEDBACK_BLOCKED_MESSAGE,
                    Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_MESSAGE
                )
                binding.mainButton.text = IDnowSDK.getInstance().getStringWithDefault(
                    context,
                    Util_Strings.KEY_USER_FEEDBACK_BLOCKED_FINISH,
                    Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_FINISH
                )
                binding.secondaryButton.visibility = GONE
                progressBar?.visibility = GONE
            }

            1 -> {
                binding.tokenRetriesTitle.text = IDnowSDK.getInstance().getStringWithDefault(
                    context,
                    Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TITLE,
                    Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TITLE
                )
                binding.tokenRetriesMessage.text = IDnowSDK.getInstance().getStringWithDefault(
                    context,
                    Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE,
                    Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE
                )
                binding.mainButton.text = IDnowSDK.getInstance().getStringWithDefault(
                    context,
                    Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN,
                    Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN
                )
                binding.secondaryButton.visibility = VISIBLE
                binding.secondaryButton.text = IDnowSDK.getInstance().getStringWithDefault(
                    context,
                    Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER,
                    Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER
                )
                progressBar?.visibility = GONE
            }

            else -> {}
        }
    }

    private fun cancelAttemptUsing(button: View) {
        button.setOnClickListener {
            orchestratedView?.visibility = VISIBLE
            this.visibility = GONE
            (context as Activity).finish()
        }
    }

    private fun proceedWithAttempt(remainingRetries: Int) {
        when (remainingRetries) {
            0 -> cancelAttemptUsing(binding.mainButton)
            1 -> binding.mainButton.setOnClickListener {
                this.visibility = GONE
                orchestratedView?.visibility = VISIBLE
                onRetryAction?.invoke()
            }

            else -> {}
        }
    }
}