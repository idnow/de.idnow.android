package de.idnow.sdk.Activities.cqc

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import de.idnow.sdk.Config
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.models.Models_CallQualityTest
import de.idnow.sdk.models.Models_NewMirrorConference
import de.idnow.sdk.models.Models_SdpOffer
import de.idnow.sdk.models.Models_StartObject
import de.idnow.sdk.models.Models_StartObjectResult
import de.idnow.sdk.models.toSessionDescription
import de.idnow.sdk.network.IDnowRestClient
import de.idnow.sdk.network.logError
import de.idnow.sdk.util.Util_Log
import de.idnow.sdk.util.Util_Util
import de.idnow.sdk.util.Util_UtilRetrofit
import de.idnow.sdk.util.Util_VideoSessionConfig
import fm.liveswitch.Candidate
import fm.liveswitch.Promise
import fm.liveswitch.SessionDescription
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.concurrent.Volatile


class CallQualityCheckViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "CallQualityCheckViewModel"
    }

    @Volatile
    private var callQualityTest: Models_CallQualityTest? = null
    var remainingInternalTokenRetries = 0
        private set
    private val _startCallResult = MutableLiveData<StartCallResult>(StartCallResult.NotDoneYet)
    val startCallResult: LiveData<StartCallResult> = _startCallResult

    private val _startTestState = MutableLiveData<StartTestState>(StartTestState.Idle)
    val startTestState: LiveData<StartTestState> = _startTestState

    private val _stopTestState = MutableLiveData<StopTestState>(StopTestState.Idle)
    val stopTestState: LiveData<StopTestState> = _stopTestState

    private val _callQualityConferenceState =
        MutableLiveData<CallQualityConferenceState>(CallQualityConferenceState.Idle)
    val callQualityConferenceState: LiveData<CallQualityConferenceState> = _callQualityConferenceState

    private fun getApiService() = IDnowRestClient.getRestClient()
        .getCallsForEndpointKt(
            Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken()),
            IDnowSDK.getInstance().appContext,
            5,
            5,
            5
        )

    private fun getVideoService() = IDnowRestClient.getRestClient()
        .getCallsForEndpointKt(
            Config.CURRENT_SERVER.getVideoHost(IDnowSDK.getTransactionToken()),
            IDnowSDK.getInstance().appContext,
            5,
            5,
            5
        )

    fun startTest() {
        Util_Log.i(TAG, "StartTest")
        _startTestState.postValue(StartTestState.Loading)
        viewModelScope.launch(Dispatchers.IO) {
            val mirrorConference = Models_NewMirrorConference(Util_Util.getClientInfo(IDnowSDK.getInstance().appContext))

            runCatching {
                getApiService().startCallQualityTest(
                    mirrorConference,
                    IDnowSDK.getCompanyId(),
                    IDnowSDK.getTransactionToken()
                )
            }.onSuccess { response ->
                if (response.isSuccessful) {
                    Util_Log.i(TAG, "Success creating test connection, sending SDP offer.")
                    callQualityTest = response.body()
                    _startTestState.postValue(StartTestState.Success)
                } else {
                    val rawError = response.errorBody()?.string().orEmpty()
                    response.logError(TAG, "SDP Error", rawError)
                    val errorType = Util_UtilRetrofit.getErrorTypeRetrofit(rawError)
                    if (response.code() == 412 && errorType == IDnowSDK.DOCUSIGN_TOKEN_EXPIRING_SOON) {
                        val errorId = Util_UtilRetrofit.getErrorIdRetrofit(rawError)
                        _startTestState.postValue(
                            StartTestState.ShowErrorDialog(StartCallError(rawError, errorId, response.code()))
                        )
                    } else {
                        _startTestState.postValue(StartTestState.Failure)
                    }
                }
            }.onFailure { e ->
                e.logError(TAG, "SDP Error")
                _startTestState.postValue(StartTestState.Failure)
            }
        }
    }

    fun stopTest() {
        Util_Log.i(TAG, "StopTest")
        viewModelScope.launch(Dispatchers.IO) {
            val mirrorConference = Models_NewMirrorConference(Util_Util.getClientInfo(IDnowSDK.getInstance().appContext))

            runCatching {
                getApiService().stopCallQualityTest(
                    mirrorConference,
                    IDnowSDK.getCompanyId(),
                    IDnowSDK.getTransactionToken()
                )
            }.onSuccess { response ->
                if (response.isSuccessful) {
                    Util_Log.i(TAG, "Success destroying mirror connection.")
                } else {
                    response.logError(TAG, "Failed to destroy video session")
                    _stopTestState.postValue(StopTestState.Failure)
                }
            }.onFailure { e ->
                e.logError(TAG, "Failed to destroy video session")
                _stopTestState.postValue(StopTestState.Failure)
            }
        }
    }


    fun makeSendSdpOffer(sessionDescription: SessionDescription): Promise<SessionDescription> {
        Util_Log.i(TAG, "---> SENDING SDP TO SERVER")
        _callQualityConferenceState.postValue(CallQualityConferenceState.Idle)
        val sessionDescriptionPromise = Promise<SessionDescription>()

        viewModelScope.launch(Dispatchers.IO) {
            val test = callQualityTest ?: run {
                sessionDescriptionPromise.reject(RuntimeException("callQualityTest is null"))
                _callQualityConferenceState.postValue(CallQualityConferenceState.Failure)
                return@launch
            }

            val sdpOffer = Models_SdpOffer(
                sessionDescription.sdpMessage.toString(),
                sessionDescription.isOffer,
                sessionDescription.tieBreaker
            )

            runCatching {
                getVideoService().sendSdpOffer(sdpOffer, test.sessionId, test.userVideoSessionToken)
            }.onSuccess { response ->
                if (response.isSuccessful) {
                    val answer = response.body().toSessionDescription()
                    Util_Log.i(TAG, "<---RECEIVING SDP FROM SERVER")
                    Util_Log.i(TAG, "Sent SDP: success")
                    Util_Log.i(TAG, "RECEIVED SDP: ${answer.toJson()}")
                    sessionDescriptionPromise.resolve(answer)
                } else {
                    response.logError(TAG, "SDP Error")
                    _callQualityConferenceState.postValue(CallQualityConferenceState.Failure)
                    sessionDescriptionPromise.reject(RuntimeException("Could not receive SDP answer — HTTP ${response.code()}"))
                }
            }.onFailure { e ->
                e.logError(TAG, "SDP Error")
                _callQualityConferenceState.postValue(CallQualityConferenceState.Failure)
                sessionDescriptionPromise.reject(RuntimeException("Could not receive SDP answer"))
            }
        }
        return sessionDescriptionPromise
    }

    fun postCandidate(candidate: Candidate) {
        Util_Log.i(TAG, "post Candidate")
        _callQualityConferenceState.postValue(CallQualityConferenceState.Idle)
        Util_Log.i(TAG, "----> SENDING LOCAL CANDIDATE!")

        viewModelScope.launch(Dispatchers.IO) {
            val test = callQualityTest ?: run {
                _callQualityConferenceState.postValue(CallQualityConferenceState.Failure)
                return@launch
            }
            runCatching {
                getVideoService().sendCandidate(
                    candidate, test.sessionId, "USER", test.userVideoSessionToken
                )
            }.onSuccess { response ->
                if (response.isSuccessful) {
                    Util_Log.i(TAG, "<---- RECEIVING LOCAL CANDIDATE!")
                    Util_Log.i(TAG, "Sent candidate ${candidate.toJson()}")
                    Util_Log.i(TAG, "Sent candidate response status: ${response.message()}")
                } else {
                    response.logError(TAG, "Error sending candidate")
                    _callQualityConferenceState.postValue(CallQualityConferenceState.Failure)
                }
            }.onFailure { e ->
                e.logError(TAG, "Error sending candidate")
                _callQualityConferenceState.postValue(CallQualityConferenceState.Failure)
            }
        }
    }

    fun makeStartRESTCall() {
        Util_Log.i(TAG, "makeStartRestCall")
        if (IDnowSDK.getInstance().isStartCallIssued && !Config.RESTART_VIDEO_IDENT) {
            Util_Log.i(TAG, "start-Call already done, not reissuing it.")
            _startCallResult.postValue(StartCallResult.StartCallDone)
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                getApiService().start(
                    buildStartObject(),
                    IDnowSDK.getCompanyId(),
                    IDnowSDK.getTransactionToken()
                )
            }.onSuccess { response ->
                if (response.isSuccessful) {
                    handleStartCallSuccess(response.body())
                } else {
                    val rawError = response.errorBody()?.string()
                    response.logError(TAG, "makeStartRESTCall HTTP error", rawError.orEmpty())
                    handleStartCallHttpFailure(response.code(), rawError)
                }
            }.onFailure { e ->
                e.logError(TAG, "makeStartRESTCall network error")
                handleStartCallNetworkFailure(e)
            }
        }
    }

    private fun buildStartObject(): Models_StartObject {
        val localPhoneNumber = Config.USER_PHONE_NO.takeUnless { it.contains("***") }
        val localEmail = Config.EMAIL_ADDRESS.takeUnless { it.contains("***") }

        return if (Config.AUTHENTICATED_POSSIBLE && !Config.RESTART_VIDEO_IDENT)
            Models_StartObject(
                IDnowSDK.getTransactionToken(),
                localPhoneNumber,
                null,
                localEmail,
                Config.PREFERRED_LANG,
                Util_Util.getClientInfo(IDnowSDK.getInstance().appContext),
                true
            )
        else
            Models_StartObject(
                IDnowSDK.getTransactionToken(),
                localPhoneNumber,
                localEmail,
                Config.PREFERRED_LANG,
                Util_Util.getClientInfo(IDnowSDK.getInstance().appContext),
                null
            )
    }

    private fun handleStartCallSuccess(resultObject: Models_StartObjectResult?) {
        when {
            resultObject?.getEnableOTPForWallet() != null &&
                    (Config.AUTHENTICATED_POSSIBLE || Config.AUTHENTICATED_SIGNED) -> {
                Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTPForWallet().isSigning
                Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTPForWallet().isIdent
            }

            resultObject?.getEnableOTP() != null -> {
                Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTP().isSigning
                Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTP().isIdent
            }
        }

        resultObject?.mobile?.let { Config.USER_PHONE_NO = it }
        resultObject?.email?.let { Config.EMAIL_ADDRESS = it }

        Config.IDENTIFICATION_SIGNATURE = resultObject?.getRequest()?.identification_Signature
        Util_VideoSessionConfig.setSessionIdAndToken(resultObject)

        resultObject?.getRequest()?.let {
            Config.E_SIGNING_SECRET = it.getClientSecret()
            Config.USER_SESSION_TOKEN = it.getSessionToken()
        }

        remainingInternalTokenRetries = resultObject?.getRemainingInternalTokenRetries() ?: 0
        Util_Log.d(TAG, "success — remainingInternalTokenRetries = $remainingInternalTokenRetries")
        IDnowSDK.getInstance().isStartCallIssued = true
        if (remainingInternalTokenRetries == 1) {
            _startCallResult.postValue(StartCallResult.GiveUserFeedback)
        } else {
            _startCallResult.postValue(StartCallResult.StartCallDone)
        }

    }


    private fun handleStartCallHttpFailure(code: Int, rawError: String?) {
        val errorType = Util_UtilRetrofit.getErrorTypeRetrofit(rawError)
        val errorId = Util_UtilRetrofit.getErrorIdRetrofit(rawError)
        val startCallError = StartCallError(rawError ?: "", errorId, code)

        when {
            code == 412 && errorType == IDnowSDK.DOCUSIGN_TOKEN_EXPIRING_SOON -> {
                _startCallResult.postValue(StartCallResult.ShowErrorDialog(startCallError))
            }

            code == 412 -> {
                remainingInternalTokenRetries = 0
                _startCallResult.postValue(StartCallResult.GiveUserFeedback)
            }

            Config.WAITING_LIST_NOTIFICATIONS_ENABLED -> {
                _startCallResult.postValue(StartCallResult.LoadWaitingScreen)
            }

            Config.CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED -> {
                _startCallResult.postValue(StartCallResult.ShowCheckResultScreenCustomise)
            }

            else -> {
                _startCallResult.postValue(StartCallResult.ShowErrorDialog(startCallError))
            }
        }

        IDnowSDK.getInstance().isStartCallIssued = false
    }


    private fun handleStartCallNetworkFailure(e: Throwable) {
        val startCallError = StartCallError(e.message ?: "", "", -1)

        val result = if (Config.CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
            StartCallResult.ShowCheckResultScreenCustomise
        } else {
            StartCallResult.ShowErrorDialog(startCallError)
        }

        IDnowSDK.getInstance().isStartCallIssued = false
        _startCallResult.postValue(result)
    }


    sealed class StartTestState {
        object Idle : StartTestState()
        object Loading : StartTestState()
        object Success : StartTestState()
        object Failure : StartTestState()
        data class ShowErrorDialog(val error: StartCallError) : StartTestState()

        override fun toString(): String {
            return if (this is ShowErrorDialog) {
                "${this.javaClass.simpleName}: ${this.error}"
            } else this.javaClass.simpleName
        }
    }

    sealed class StopTestState {
        object Idle : StopTestState()
        object Failure : StopTestState()

        override fun toString(): String {
            return this.javaClass.simpleName
        }
    }

    sealed class CallQualityConferenceState {
        object Idle : CallQualityConferenceState()
        object Failure : CallQualityConferenceState()

        override fun toString(): String {
            return this.javaClass.simpleName
        }
    }

    sealed class StartCallResult {
        object NotDoneYet : StartCallResult()
        object GiveUserFeedback : StartCallResult()
        object LoadWaitingScreen : StartCallResult()
        object ShowCheckResultScreenCustomise : StartCallResult()
        object StartCallDone : StartCallResult()
        data class ShowErrorDialog(val error: StartCallError) : StartCallResult()

        override fun toString(): String {
            return if (this is ShowErrorDialog) {
                "${this.javaClass.simpleName}: ${this.error}"
            } else this.javaClass.simpleName
        }
    }

    data class StartCallError(
        val error: String = "",
        val errorId: String = "",
        val errorStatus: Int = -1,
    )

    override fun onCleared() {
        super.onCleared()
        cancelPendingApiCalls()
    }

    fun cancelPendingApiCalls() {
        Util_Log.i(TAG, "cancelPendingApiCalls ${viewModelScope.isActive}")
        if (viewModelScope.isActive) {
            viewModelScope.cancel()
        }
    }
}