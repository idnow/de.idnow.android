package de.idnow.sdk.util;

import android.content.Context;
import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/**
 * Created by Mathias Grasy on 15.06.2016.
 * <p>
 * Best-effort root detection. Combines several independent heuristics ({@code su} binary paths,
 * {@code which su}, known root-management/cloaking packages, dangerous system props and
 * read-write system mounts). If at least one check matches, the device is treated as
 * rooted. No on-device check is guaranteed (e.g. Magisk DenyList can hide root) — this is an
 * indication of root, not a proof.
 */
public class Util_Jailbreaking
{

	/**
	 * Common locations where a {@code su} binary may live. Also used as the search paths for
	 * {@link #findBinary(String)}. Every entry ends with a path separator.
	 */
	private static final String[] SU_PATHS = {
			"/data/local/",
			"/data/local/bin/",
			"/data/local/xbin/",
			"/sbin/",
			"/su/bin/",
			"/system/bin/",
			"/system/bin/.ext/",
			"/system/bin/failsafe/",
			"/system/sd/xbin/",
			"/system/usr/we-need-root/",
			"/system/xbin/",
			"/system_ext/bin/",
			"/cache/",
			"/data/",
			"/dev/" };

	/** Known root-management and root-cloaking app packages (subset of RootBeer's lists). */
	private static final String[] ROOT_APP_PACKAGES = {
			"com.topjohnwu.magisk",
			"eu.chainfire.supersu",
			"com.noshufou.android.su",
			"com.noshufou.android.su.elite",
			"com.koushikdutta.superuser",
			"com.thirdparty.superuser",
			"com.yellowes.su",
			"com.kingroot.kinguser",
			"com.kingo.root",
			"com.zachspong.temprootremovejb",
			"com.ramdroid.appquarantine" };

	/** System paths that should never be mounted read-write on a stock device. */
	private static final String[] RW_SYSTEM_PATHS = {
			"/system",
			"/system/bin",
			"/system/xbin",
			"/vendor/bin",
			"/sbin",
			"/etc" };

	/**
	 * checks if the device is rooted. if at least one of the checks is valid -> device is rooted
	 * <p>
	 * Kept for backward compatibility; prefer {@link #isDeviceRooted(Context)} which additionally
	 * checks for installed root apps.
	 *
	 * @return
	 */
	public static boolean isDeviceRooted()
	{
		return checkRootMethod2() || checkRootMethod3() || checkRootMethod4()
				|| checkForDangerousProps() || checkForRWSystemPaths();
	}

	/**
	 * Context-aware root check. Runs the same heuristics as {@link #isDeviceRooted()} plus a
	 * lookup for known root-management / root-cloaking apps via the {@link PackageManager}.
	 *
	 * @param context used to query installed packages; if null, package detection is skipped.
	 * @return true if any heuristic indicates the device is rooted.
	 */
	public static boolean isDeviceRooted( Context context )
	{
		return isDeviceRooted() || checkRootPackages( context );
	}

	private static boolean checkRootMethod2()
	{
		// The su-binary path scan lives in findBinary()/checkRootMethod4(); this only checks the
		// Superuser.apk marker to avoid iterating SU_PATHS twice per isDeviceRooted() call.
		try
		{
			return new File( "/system/app/Superuser.apk" ).exists();
		}
		catch ( Throwable t )
		{
			return false;
		}
	}

	private static boolean checkRootMethod3()
	{
		Process process = null;
		try
		{
			process = Runtime.getRuntime().exec( new String[]{ "/system/xbin/which", "su" } );
			BufferedReader in = new BufferedReader( new InputStreamReader( process.getInputStream() ) );
            return in.readLine() != null;
        }
		catch ( Throwable t )
		{
			return false;
		}
		finally
		{
			if ( process != null )
			{
				process.destroy();
			}
		}
	}


	private static boolean findBinary( String binaryName )
	{
		try
		{
			for ( String where : SU_PATHS )
			{
				if ( new File( where + binaryName ).exists() )
				{
					return true;
				}
			}
		}
		catch ( Throwable t )
		{
			return false;
		}
		return false;
	}

	/**
	 * checks if the device is rooted
	 *
	 * @return
	 */
	private static boolean checkRootMethod4()
	{
		return findBinary( "su" );
	}

	/**
	 * Detects installed root-management / root-cloaking apps (e.g. Magisk, SuperSU).
	 */
	private static boolean checkRootPackages( Context context )
	{
		if ( context == null )
		{
			return false;
		}
		PackageManager packageManager = context.getPackageManager();
		if ( packageManager == null )
		{
			return false;
		}
		for ( String packageName : ROOT_APP_PACKAGES )
		{
			try
			{
				packageManager.getPackageInfo( packageName, 0 );
				return true;
			}
			catch ( PackageManager.NameNotFoundException e )
			{
				// package not installed, keep checking
			}
			catch ( Throwable t )
			{
				// transient PackageManager failure for this package; keep checking the rest
			}
		}
		return false;
	}

	/**
	 * Flags dangerous system props: only when {@code ro.debuggable=1} AND {@code ro.secure=0}
	 * together. Requiring both avoids false positives on legitimate {@code userdebug}/OEM builds
	 * that ship {@code ro.debuggable=1} without being rooted.
	 */
	private static boolean checkForDangerousProps()
	{
		Process process = null;
		try
		{
			process = Runtime.getRuntime().exec( "getprop" );
			BufferedReader in = new BufferedReader( new InputStreamReader( process.getInputStream() ) );
			boolean debuggable = false;
			boolean insecure = false;
			String line;
			while ( ( line = in.readLine() ) != null )
			{
				if ( line.contains( "[ro.debuggable]" ) && line.contains( "[1]" ) )
				{
					debuggable = true;
				}
				if ( line.contains( "[ro.secure]" ) && line.contains( "[0]" ) )
				{
					insecure = true;
				}
			}
			return debuggable && insecure;
		}
		catch ( Throwable t )
		{
			return false;
		}
		finally
		{
			if ( process != null )
			{
				process.destroy();
			}
		}
	}

	/**
	 * Flags any of the protected system paths mounted read-write.
	 */
	private static boolean checkForRWSystemPaths()
	{
		try ( BufferedReader reader = new BufferedReader( new InputStreamReader(
				new FileInputStream( "/proc/mounts" ) ) ) )
		{
			String line;
			while ( ( line = reader.readLine() ) != null )
			{
				// /proc/mounts format: <device> <mountPoint> <fsType> <options> ...
				String[] parts = line.split( " " );
				if ( parts.length < 4 )
				{
					continue;
				}
				String mountPoint = parts[1];
				String options = parts[3];
				for ( String path : RW_SYSTEM_PATHS )
				{
					if ( mountPoint.equals( path ) )
					{
						for ( String option : options.split( "," ) )
						{
							if ( option.equals( "rw" ) )
							{
								return true;
							}
						}
					}
				}
			}
		}
		catch ( Throwable t )
		{
			return false;
		}
		return false;
	}
}
