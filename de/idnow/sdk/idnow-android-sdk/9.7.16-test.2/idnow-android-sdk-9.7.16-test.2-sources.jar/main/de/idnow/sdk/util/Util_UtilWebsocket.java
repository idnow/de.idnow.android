package de.idnow.sdk.util;

import static de.idnow.sdk.util.Util_CustomLogData.EVENT_AGENT_CONNECTED_SCREEN_SHOWN;
import static de.idnow.sdk.util.Util_CustomLogData.EVENT_IDENTIFICATION_COMPLETE_SCREEN_SHOWN;
import static de.idnow.sdk.util.Util_CustomLogData.EVENT_SECURITY_STEPS_SCREEN_SHOWN;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_ERROR_FLASH;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_IDENT_COMPLETED;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_IDENT_COMPLETED_DESC;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_ERROR_FLASH;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_IDENT_COMPLETED;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_IDENT_COMPLETED_DESC;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.io.ByteArrayOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_Super;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.Interface_VideoLiveStream;
import de.idnow.sdk.models.Models_ChatMessage;
import de.idnow.sdk.models.Models_WebSocketResponse;
import de.idnow.sdk.util.camera.CameraType;
import de.idnow.sdk.util.helper.CameraHelper;
import de.idnow.sdk.util.helper.ImageHelper;

public class Util_UtilWebsocket {
    public static final String LOGTAG = "IDNOW_Util_UtilWebsocket";
    public static int CURRENT_STEP = 1;
    public static long IDENT_START_TIME = -1;

    /**
     * handles all incoming messages of the socket
     * <p/>
     * 1. 	setupComplete
     * 2. 	takeScreenshot
     * 3. 	finishedFace
     * 4. 	takeScreenshot
     * 5. 	finishedIdFrontside
     * 6. 	wiggleDone
     * 7. 	takeScreenshot
     * 8. 	finishedIdBackside
     * 9. 	idNumberDone (insert-phone-number-overlay is now displayed)
     * 10.	tanDone (when agent has finished his checkview and the user has successfully inserted his tan
     * 11.	finished
     * <p/>
     * <p/>
     * canceled can be called all the time
     * toggle flashlight can be called most of the time
     * <p/>
     * E-Signing:
     * instead of 9. -> startESigning
     * checking the contract is available (not yet specified )
     * at the end of esigning finished is called
     *
     * @param response
     * @param context
     */
    public static void handleSocketMessage(final Models_WebSocketResponse response, final Context context, @NonNull Interface_VideoLiveStream sink) {
        Util_Log.i(LOGTAG, "response: " + response.getCommand());

        // For testing purposes - please do not remove
//		if (true) {
//			((Interface_VideoLiveStream) context).startESigning();
//
//			return;
//		}

        if (!response.getCommand().equals("ping")) {

            if (response.getCommand().equals(Config.COMMAND_INITIAL_COMPARISON_DONE)) {
                setNewStep(sink, 1);
                updateExplanationView(sink, Config.COMMAND_INITIAL_COMPARISON_DONE);
                tryOpenCamera(CameraType.FRONT, sink);
            } else if (response.getCommand().equals(Config.COMMAND_FINISHED_FACE)) {
                setNewStep(sink, 2);
                updateExplanationView(sink, Config.COMMAND_FINISHED_FACE);
                tryOpenCamera(CameraType.BACK, sink);
            } else if (response.getCommand().equals(Config.COMMAND_FINISHED_ID_TYPE)) {
                setNewStep(sink, 2);
                updateExplanationView(sink, Config.COMMAND_FINISHED_ID_TYPE);
                tryOpenCamera(CameraType.BACK, sink);
            } else if (response.getCommand().equals(Config.COMMAND_FINISHED_ID_FRONTSIDE)) {
                setNewStep(sink, 3);
                updateExplanationView(sink, Config.COMMAND_FINISHED_ID_FRONTSIDE);
                tryOpenCamera(CameraType.BACK, sink);
                if (CameraHelper.INSTANCE.hasTorch()) {
                    sink.setCameraTorchEnabled(true);
                } else {
                    ((Activity) context).runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(context.getApplicationContext(), Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_FLASH, LOCAL_KEY_VIDEO_IDENT_ERROR_FLASH), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            } else if (response.getCommand().equals(Config.COMMAND_WIGGLE_DONE)) {
                setNewStep(sink, 3);
                updateExplanationView(sink, Config.COMMAND_WIGGLE_DONE);
                tryOpenCamera(CameraType.BACK, sink);
            } else if (response.getCommand().equals(Config.COMMAND_FINISHED_ID_BACKSIDE)) {
                Config.SCREEN = "SECURITY FEATURE";

                Util_CustomLogData.setEventData(EVENT_SECURITY_STEPS_SCREEN_SHOWN, "EVENT_SECURITY_STEPS_SCREEN_SHOWN", "Security steps screen", "Screen", null);
                Util_Log.d("COUNTLY LOG", "EVENT_SECURITY_STEPS_SCREEN_SHOWN");

                setNewStep(sink, 3);
                updateExplanationView(sink, Config.COMMAND_FINISHED_ID_BACKSIDE);
                tryOpenCamera(CameraType.FRONT, sink);
            } else if (response.getCommand().equals(Config.COMMAND_ID_NUMBER_DONE) || response.getCommand().equals(Config.COMMAND_FINISHED_CENSORING_BACK) || response.getCommand().equals(Config.COMMAND_FINISHED_CENSORING_FRONT) || response.getCommand().equals(Config.COMMAND_FINISHED_INTEGRITY_MRZ)) {
                setNewStep(sink, 4);
                updateExplanationView(sink, Config.COMMAND_ID_NUMBER_DONE);
                tryOpenCamera(CameraType.FRONT, sink);
            } else if (response.getCommand().equals(Config.COMMAND_TAN_DONE)) {
                setNewStep(sink, 5);
                updateExplanationView(sink, Config.COMMAND_TAN_DONE);
                tryOpenCamera(CameraType.FRONT, sink);
            } else if (response.getCommand().equals(Config.COMMAND_FINISHED)) {

                Config.SCREEN = "COMPLETE";

                String name = "name";
                String event_name = "event_name";
                String category = "category";
                String type = "type";

                String segName = "Identification complete screen - shown";
                String segEventName = "EVENT_IDENTIFICATION_COMPLETE_SCREEN_SHOWN";
                String segCategory = "Identification complete screen";
                String segType = "screen";

                Map<String, Object> segMap = new HashMap<>();
                segMap.put(name, segName);
                segMap.put(event_name, segEventName);
                segMap.put(category, segCategory);
                segMap.put(type, segType);


                Util_CustomLogData.setEventData(EVENT_IDENTIFICATION_COMPLETE_SCREEN_SHOWN, "EVENT_IDENTIFICATION_COMPLETE_SCREEN_SHOWN", "Identification complete screen", "Screen", null);
                Util_Log.d("COUNTLY LOG", "EVENT_IDENTIFICATION_COMPLETE_SCREEN_SHOWN");

                if (Config.E_SIGNING) {

                    (((Activities_VideoLiveStreamActivity_Super) context)).runOnUiThread(new Runnable() {

                        @Override
                        public void run() {
                            ((Activities_VideoLiveStreamActivity_Super) context).setExplanationTitleText(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_IDENT_COMPLETED, LOCAL_KEY_VIDEO_IDENT_IDENT_COMPLETED));
                            ((Activities_VideoLiveStreamActivity_Super) context).setExplanationContentText((Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_IDENT_COMPLETED_DESC, LOCAL_KEY_VIDEO_IDENT_IDENT_COMPLETED_DESC)));
                            Util_Util.clearApplicationData(context);
                        }
                    });

                }


                ((Activities_VideoLiveStreamActivity_Super) context).fetchWaitingInformation(sink, context, true);
            } else if (response.getCommand().equals(Config.COMMAND_WAITING_FOR_REVIEW)) {
                openReportActivity(sink, context, true);
            } else if (response.getCommand().equals(Config.COMMAND_FAILED)) {
                if (!Config.ABORT_IDENT) {
                    openReportActivity(sink, context, false);
                }
            }

            // flashlight toggle
            else if (response.getCommand().equals(Config.COMMAND_FLASHLIGHT)) {
                sink.setCameraTorchEnabled(response.getData().getType().equalsIgnoreCase("turnFlashlightOn"));
            }
            // focus
            else if (response.getCommand().equals(Config.COMMAND_FOCUS)) {
                sink.requestCameraFocusCenter();
            } else if (response.getCommand().equals(Config.COMMAND_SCREENSHOT)) {
                sink.takeScreenshot(response.getData().getType());
            } else if (response.getCommand().equals(Config.COMMAND_AGENT_CONNECTED)) {
                if (!Config.AGENT_CONNECTED) {
                    Config.AGENT_CONNECTED = true;
                    sink.agentConnected();
                    Util_CustomLogData.setEventData(EVENT_AGENT_CONNECTED_SCREEN_SHOWN, "EVENT_AGENT_CONNECTED_SCREEN_SHOWN", "Agent Connected Screen", "Screen", null);
                    Util_Log.d("COUNTLY LOG", "EVENT_AGENT_CONNECTED_SCREEN_SHOWN");
                }
            } else if (response.getCommand().equals(Config.COMMAND_SWITCH_CAMERA)) {
                if (response.getData() == null || TextUtils.isEmpty(response.getData().getType())) {
                    return;
                }

                CameraType cameraRequired = response.getData().getType().equalsIgnoreCase("BACK")
                        ? CameraType.BACK
                        : CameraType.FRONT;
                sink.openCamera(cameraRequired);
            }


            // =========================
            // E-SIGNATURE SOCKET CALLS
            // =========================

            // COMMAND_FAILED is triggered, when user clicks the "decline the contract" - button, it's already handled above

            else if (response.getCommand().equals(Config.COMMAND_START_ESIGNING)) {
                String consentProtocolStr = response.getData().getConsentProtocolVersion();
                Config.USE_NATIVE_ESIGNING = consentProtocolStr != null && !consentProtocolStr.equals("docusign-2017-08-29");
                // rbarbu: problem here with URL being null and crashing. TODO: See cause
                Config.OPENTRUST_URL = response.getData().getUrl() == null ? "" : response.getData().getUrl();
                Config.START_ESIGNING = true;
                if (!Config.IDENTIFICATION_SIGNATURE.equals("") && Config.USE_NATIVE_ESIGNING
                        || !Config.OTP_DISPLAY_SIGNING) {
                    ((Activities_VideoLiveStreamActivity_Super) context).loadNamirialSigning();
                } else if (!Config.AUTHENTICATED_SIGNED) {
                    sink.startESigning();
                } else {
                    if (Config.LOAD_URL && Config.OPENTRUST_URL != null) {
                        ((Activities_VideoLiveStreamActivity_Super) context).loadWebView(((Activities_VideoLiveStreamActivity_Super) context).openTrustWebView, (Activities_VideoLiveStreamActivity_Super) context);
                        Config.LOAD_URL = false;
                    } else {
                        Config.ERROR_LOGIN = true;
                    }
                }

            } else if (response.getCommand().equals(Config.COMMAND_FINISHED_INTEGRITY_ID_DATA)) {
                if (Config.AUTHENTICATED_SIGNED) {
                    sink.startESigning();
                }
            } else if (response.getCommand().equals(Config.COMMAND_DO_USER_STEP)) {
                if (response.getNextStep() != null) {
                    Config.DO_USER_STEP_EXPLANATION_TITLE = response.getNextStep().getTitle();
                    Config.DO_USER_STEP_EXPLANATION_CONTENT = response.getNextStep().getEmployeeMessage();
                    Config.DO_USER_STEP_CAMERA_TO_USE = response.getNextStep().getCameraToUse();
                    updateExplanationView(sink, Config.COMMAND_DO_USER_STEP);
                }

                if (Config.DO_USER_STEP_CAMERA_TO_USE != null && !Config.DO_USER_STEP_CAMERA_TO_USE.isEmpty()) {
                    CameraType cameraType = Config.DO_USER_STEP_CAMERA_TO_USE.equalsIgnoreCase("BACK")
                            ? CameraType.BACK : CameraType.FRONT;
                    tryOpenCamera(cameraType, sink);
                }
            }

            // Text Chat
            // example: {"command":"chatMessage","data":{"originator":"AGENT","timestamp":"2016-10-06T13:35:34","content":"test msg from agent Thu Oct 06 2016 13:35:33 GMT+0200 (W. Europe Daylight Time)"},"employee":{"firstname":"IDnow","lastname":"Team"},"requestId":113281}
            else if (response.getCommand().equals(Config.COMMAND_CHAT_MESSAGE)) {
                // check if chat is enabled or not
                if (IDnowSDK.enableChat && response.getData() != null) {
                    final String message = response.getData().getContent();
                    final String timestamp = response.getData().getTimestamp();
                    final String originator = response.getData().getOriginator();
                    final String agentName = response.getEmployee().getFirstname() + " " + response.getEmployee().getLastname();

                    ((Activity) context).runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZZ", Locale.getDefault()).parse(timestamp);

                                ((Activities_VideoLiveStreamActivity_Super) context).
                                        showNewAgentMessage(new Models_ChatMessage(message, date, originator, agentName));

                            } catch (ParseException e) {
                                Util_Log.e(LOGTAG, "Parse ts failed", e);
                            }
                        }
                    });
                }
            }
        }
    }

    private static void tryOpenCamera(CameraType mainCameraType, Interface_VideoLiveStream sink) {
        if (CameraHelper.INSTANCE.hasCamera(mainCameraType)) {
            sink.openCamera(mainCameraType);
            sink.setCameraTorchEnabled(false);
        }
    }

    public static void sendImageToServer(String type, Bitmap bitmap, @NonNull Interface_VideoLiveStream sink) {
        if (Config.SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE != 0) {
            bitmap = ImageHelper.INSTANCE.scaleBitmap(bitmap, Config.SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE);
        }

        Util_Log.i(LOGTAG, "Converted bitmap");
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream);
        Util_Log.i(LOGTAG, "picture saved");

        sink.setupImageStreamPush(stream.toByteArray(), type);
    }

    public static void sendImageToServer(String type, byte[] data, @NonNull Interface_VideoLiveStream sink) {
        if (Config.SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE != 0) {
            Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
            bitmap = ImageHelper.INSTANCE.scaleBitmap(bitmap, Config.SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE);
            ByteArrayOutputStream os2 = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, os2);
            data = os2.toByteArray();
        }
        sink.setupImageStreamPush(data, type);
    }

    /**
     * closes the liveStreamActivity and opens the reportActivity with a flag if the identification has been successful or not.
     * if its triggered by the idnow host app, check if there are fallback urls, then link to them. if none is available use the normal sdk behavior
     *
     * @param context
     * @param successful
     */
    public static void openReportActivity(@NonNull Interface_VideoLiveStream sink, final Context context, boolean successful) {
        openResultActivity(sink, context, successful);
    }

    private static void openResultActivity(@NonNull Interface_VideoLiveStream sink, Context context, boolean successful) {

        Config.IDENT_STATUS = successful;

        if (Config.IDENT_STATUS) {
            Util_Util.deleteCache(context);
        }

        int resultCode = successful ? IDnowSDK.RESULT_CODE_SUCCESS : IDnowSDK.RESULT_CODE_FAILED;
        IDnowSDK.getInstance().setStartCallIssued(false);

        ((Activities_VideoLiveStreamActivity_Super) context).setcompleteScreenVisible();

        sink.onEndCall(resultCode);
        if (context instanceof Activities_VideoLiveStreamActivity_Super) {
            ((Activities_VideoLiveStreamActivity_Super) context).activityIsFinishing = true;
        }
        // Only show success screen if user configured it to be shown.

        // the process has been successful and an alternative success url is set. -> link to this url instead of linking to the result screen
        if (successful && Config.SUCCESS_URL != null) {
            openUrlInNewBrowserTask(context, Config.SUCCESS_URL);
        } else if (successful && Config.CREATE_IDENT_RECORD_ATRUST && Config.REDIRECT_URL != null && !Config.REDIRECT_URL.isEmpty()) {
            openUrlInNewBrowserTask(context, Config.REDIRECT_URL);
        }
        // the process failed and an alternative failure url is set, then link to this url instead of linking to the result screen
        else if (!successful && Config.FAILURE_URL != null) {
            linkToFailure(sink, context);
        } else {
            handleReportActivityLinking(sink, context, successful);
        }

    }

    public static void openUrlInNewBrowserTask(@NonNull Context context, @NonNull String url) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);

        // Verify that the intent will resolve to an activity
        try {
            context.startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, "Your browser cannot open the URL!\nInstall another browser and try again.", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * check if the showErrorSuccessScreen is set to true by the host app, then show the result screen. if the showErrorSuccessScreen is set to false, return to the host app
     *
     * @param context
     * @param successful
     */
    //
    public static void handleReportActivityLinking(@NonNull Interface_VideoLiveStream sink, Context context, boolean successful) {
        Util_Log.i(LOGTAG, "handleReportActivityLinking: successful=" + successful);
    }

    public static void updateExplanationView(@NonNull Interface_VideoLiveStream sink, String websocketResponse) {
        sink.updateExplanationView(websocketResponse);
    }

    public static void setNewStep(@NonNull Interface_VideoLiveStream sink, int step) {
        CURRENT_STEP = step;
        sink.setCurrentStep(CURRENT_STEP);
    }

    /**
     * if a failure url is given, open the url. if this is not possible, try to open the fallback url or result screen
     *
     * @param context
     */
    public static void linkToFailure(@NonNull Interface_VideoLiveStream sink, Context context) {
        handleReportActivityLinking(sink, context, false);
        if (Config.FAILURE_URL != null) {
            openUrlInNewBrowserTask(context, Config.FAILURE_URL);
        }
    }
}
