package de.idnow.sdk.models;

/**
 * Stable, customer-facing identifiers of the VideoIdent+ step a user was on when
 * they canceled the identification.
 *
 * The {@link #getValue()} string is what is surfaced to integrators (as the
 * {@code RESULT_CANCEL_STEP extra on the result Intent). These strings are a
 * public contract and MUST stay in sync with the iOS SDK's IDnowCancelationStep —
 * do not rename existing values.
 */
public enum IDnowCancelationStep {
    LANGUAGE_SELECTION("LANGUAGE_SELECTION"),
    CONSENT("CONSENT"),
    CALL_QUALITY_CHECK("CALL_QUALITY_CHECK"),
    INSTRUCTIONS("INSTRUCTIONS"),
    HIGH_CALL_VOLUME("HIGH_CALL_VOLUME"),
    WAITING_ROOM("WAITING_ROOM"),
    WAITING_LIST("WAITING_LIST"),
    WAITING_FOR_AGENT("WAITING_FOR_AGENT"),
    AGENT_CONVERSATION("AGENT_CONVERSATION"),
    DOCUMENT_CLASSIFICATION("DOCUMENT_CLASSIFICATION"),
    NAME_VERIFICATION("NAME_VERIFICATION");

    private final String value;

    IDnowCancelationStep(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
