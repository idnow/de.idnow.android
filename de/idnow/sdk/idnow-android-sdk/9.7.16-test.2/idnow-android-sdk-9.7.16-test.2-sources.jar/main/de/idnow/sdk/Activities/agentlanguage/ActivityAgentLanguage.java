package de.idnow.sdk.Activities.agentlanguage;

import static de.idnow.sdk.Config.DARK_MODE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CANCEL_ALERT_MSG;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CANCEL_ALERT_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_COMMON_NO;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_COMMON_YES;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CANCEL_ALERT_MSG;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CANCEL_ALERT_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_COMMON_NO;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_COMMON_YES;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Group;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;

import java.util.ArrayList;
import java.util.List;

import de.idnow.sdk.Activities.Activities_BeforeStartingActivity;
import de.idnow.sdk.Activities.Activities_DeviceSupportActivity;
import de.idnow.sdk.Activities.Activities_HighCallVolumeActivity;
import de.idnow.sdk.Activities.Activities_VideoOverviewCheckActivity;
import de.idnow.sdk.Activities.BaseActivity;
import de.idnow.sdk.Config;
import de.idnow.sdk.models.IDnowCancelationStep;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.network.RetrofitError;
import de.idnow.sdk.useCases.StartUseCase;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.Util_VideoStreamService;
import de.idnow.sdk.views.TokenRetriesView;

public class ActivityAgentLanguage extends BaseActivity {
    public static final String AVAILABLE_LANGUAGES_KEY = "availableLanguagesKey";

    LottieAnimationView logo;
    Group animationUnderListGroup;

    Group listGroup;
    Group selectedItemGroup;
    ImageView actionIcon;
    TextView changeLanguage;

    TextView choosePreferredLangText;

    TextView selectedLanguage;
    View expandingView;

    LottieAnimationView agentAnimationList;
    RecyclerView languageRecyclerView;
    LinearLayout chooseLanguageLayout;
    Button continueButton;
    Button quitButton;

    List<AgentLanguageViewModel.Language> languageSpokenList;

    AgentLanguageViewModel viewModel;

    private ProgressBar progressBar;

    boolean isExpanded = true;

    private ConstraintLayout agentLanguageLayout;
    private TokenRetriesView tokenRetriesView;

    private StartUseCase startUseCaseInstance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_language);
        Config.CANCELATION_STEP = IDnowCancelationStep.LANGUAGE_SELECTION.getValue();

        initViews();

        viewModel = new ViewModelProvider(this).get(AgentLanguageViewModel.class);
        setAnimationUi(viewModel);

        Bundle bundle = getIntent().getExtras();
        List<String> languageCodes = bundle.getStringArrayList(AVAILABLE_LANGUAGES_KEY);

        List<AgentLanguageViewModel.Language> mapperList = new ArrayList<>();
        for (String language : languageCodes) {
            mapperList.add(new AgentLanguageViewModel.Language(language, AgentLanguageUtils.Companion.getDisplayLanguage(this, language)));
        }
        viewModel.setup(mapperList);

        LanguagesAdapter adapter = new LanguagesAdapter();
        languageRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        languageRecyclerView.setAdapter(adapter);
        viewModel.getLanguages().observe(this, languages -> {
            languageSpokenList = languages;
            adapter.addAll(languages);
        });

        chooseLanguageLayout.setOnClickListener(l -> {
            if (isExpanded) {
                expandingView.setVisibility(View.GONE);
                collapseList(adapter);
            } else {
                expandingView.setVisibility(View.VISIBLE);
                selectedLanguage.setVisibility(View.GONE);
                choosePreferredLangText.setVisibility(View.VISIBLE);
                animationUnderListGroup.setVisibility(View.GONE);
                isExpanded = true;
                adapter.addAll(languageSpokenList);
                actionIcon.setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.action_expand));
            }
        });

        adapter.setListener(language -> {
            onLanguageSelected(viewModel, adapter, language);
            return null;
        });

        continueButton.setOnClickListener(l -> {
            String languageCode = viewModel.getLanguageSpoken().getValue();
            if (languageCode != null) {
                Config.PREFERRED_LANG = languageCode; //this will be sent in the next /start call
            }
            provideStartUseCaseInstance().proceed();
        });

        quitButton.setOnClickListener(l -> {
//            retrofit2.Call<Object> result = service.identificationCanceled(reason_cancellation, IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
            showCancelIdentificationDialog(this);
        });
    }

    private void onLanguageSelected(AgentLanguageViewModel viewModel, LanguagesAdapter adapter, AgentLanguageViewModel.Language language) {
        if (viewModel.setLanguageSpoken(language)) {
            collapseList(adapter);
            expandingView.setVisibility(View.GONE);
            selectedLanguage.setVisibility(View.VISIBLE);
            selectedItemGroup.setVisibility(View.VISIBLE);
            choosePreferredLangText.setVisibility(View.GONE);
            continueButton.setEnabled(true);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        setResult(resultCode, data);
        finish();
    }

    @Override
    public void onBackPressed() {
        showCancelIdentificationDialog(this);
    }

    private void collapseList(LanguagesAdapter adapter) {
        String languageSelected = viewModel.getLanguageSpokenName().getValue();
        if (languageSelected == null) {
            selectedLanguage.setText("");
            selectedLanguage.setVisibility(View.GONE);
            choosePreferredLangText.setVisibility(View.VISIBLE);
        } else {
            selectedLanguage.setText(languageSelected);
            selectedLanguage.setVisibility(View.VISIBLE);
            choosePreferredLangText.setVisibility(View.GONE);

        }
        isExpanded = false;
        actionIcon.setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.action_collapse));
        adapter.removeAll();
        animationUnderListGroup.setVisibility(View.VISIBLE);
    }

    private void initViews() {
        String continueIdentificationRes = Util_Strings.getStringWithDefault(this,
                Util_Strings.KEY_AGENT_CONTINUE,
                Util_Strings.LOCAL_KEY_AGENT_CONTINUE
        );

        String changeLanguageRes = Util_Strings.getStringWithDefault(this,
                Util_Strings.KEY_AGENT_CHANGE,
                Util_Strings.LOCAL_KEY_AGENT_CHOOSE
        );

        String choosePreferredLanguageRes = Util_Strings.getStringWithDefault(this,
                Util_Strings.KEY_AGENT_CHOOSE_PREFERRED,
                Util_Strings.LOCAL_KEY_AGENT_CHOOSE_PREFERRED
        );

        String quitIdentificationRes = Util_Strings.getStringWithDefault(this,
                Util_Strings.KEY_AGENT_QUIT,
                Util_Strings.LOCAL_KEY_AGENT_QUIT
        );

        logo = findViewById(R.id.logo);
        agentAnimationList = findViewById(R.id.agentAnimationList);
        changeLanguage = findViewById(R.id.changeLanguage);
        continueButton = findViewById(R.id.continueButton);
        quitButton = findViewById(R.id.quitButton);
        chooseLanguageLayout = findViewById(R.id.chooseLanguageLayout);
        actionIcon = findViewById(R.id.actionIcon);
        listGroup = findViewById(R.id.listGroup);
        animationUnderListGroup = findViewById(R.id.animationUnderListGroup);
        languageRecyclerView = findViewById(R.id.languageList);
        selectedLanguage = findViewById(R.id.selectedLanguage);
        selectedItemGroup = findViewById(R.id.selectedItemGroup);
        expandingView = findViewById(R.id.expandingView);
        choosePreferredLangText = findViewById(R.id.choosePreferredLanguage);
        changeLanguage.setText(changeLanguageRes);
        choosePreferredLangText.setText(choosePreferredLanguageRes);
        continueButton.setText(continueIdentificationRes);
        quitButton.setText(quitIdentificationRes);
        progressBar = findViewById(android.R.id.progress);
        progressBar.getIndeterminateDrawable().setColorFilter(getResources().getColor(Config.VIDEO_IDENT_PLUS ? R.color.primaryColor : R.color.primary), PorterDuff.Mode.MULTIPLY);

        if (Config.DARK_MODE) {
            Util_UtilUI.setColorLottieAnimation(Color.WHITE, logo, "SecondaryVariant");
        } else {
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, logo, "SecondaryVariant");
        }

        logo.setVisibility(IDnowSDK.getShowIDnowLogo() ? View.VISIBLE : View.GONE);

        LottieAnimationView poweredByView = findViewById(R.id.poweredByView);
        poweredByView.setVisibility(Config.SHOW_POWERED_BY_KEY ? View.VISIBLE : View.GONE);

        if (DARK_MODE) {
            poweredByView.setAnimation("static_powered_by_idnow.json");
        } else {
            poweredByView.setAnimation("static_powered_by_idnow_dark.json");
        }
        poweredByView.playAnimation();

        agentLanguageLayout = findViewById(R.id.agentLanguageLayout);
        tokenRetriesView = findViewById(R.id.tokenRetriesView);
        tokenRetriesView.setUpWithView(
                agentLanguageLayout,
                progressBar,
                () -> {
                    provideStartUseCaseInstance().proceed();
                    return null;
                }
        );
    }

    @SuppressLint("SetTextI18n")
    private void setupAgentLanguageTextView(String languageText) {
        String specialistLanguageRes = Util_Strings.getStringWithDefault(this,
                Util_Strings.KEY_AGENT_SPECIALIST_SPEAKING,
                Util_Strings.LOCAL_KEY_AGENT_SPECIALIST_SPEAKING
        );

        TextView agentLanguageTextList = findViewById(R.id.agentLanguageTextList);
        agentLanguageTextList.setText(specialistLanguageRes + " " + languageText);
        selectedLanguage.setText(languageText);
    }

    private void setAnimationUi(AgentLanguageViewModel viewModel) {
        agentAnimationList.setAnimation("agent_language_selector.json");
        viewModel.getLanguageSpokenName().observe(this, displayLanguage -> {
            String languageToSet = displayLanguage.toLowerCase();
            setupAgentLanguageTextView(capitalize(languageToSet));
        });
        viewModel.getLanguageSpoken().observe(this, languageSpoken -> {
            agentAnimationList.setRepeatCount(LottieDrawable.INFINITE);
            agentAnimationList.playAnimation();
        });
    }

    private String capitalize(String value) {
        StringBuilder sb = new StringBuilder(value);
        sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
        return sb.toString();
    }

    public void showCancelIdentificationDialog(final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CANCEL_ALERT_TITLE, LOCAL_KEY_VIDEO_IDENT_CANCEL_ALERT_TITLE))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CANCEL_ALERT_MSG, LOCAL_KEY_VIDEO_IDENT_CANCEL_ALERT_MSG))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_YES, LOCAL_KEY_VIDEO_IDENT_COMMON_YES), (dialog, id) -> {
                    dialog.cancel();
                    setResult(IDnowSDK.RESULT_CODE_CANCEL);
                    finish();
                })
                .setNegativeButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_NO, LOCAL_KEY_VIDEO_IDENT_COMMON_NO), (dialog, id) -> dialog.cancel());

        alertDialogBuilder.show();
    }

    private void navigateToScreen(Class<?> screenClass) {
        Intent intent = new Intent(this, screenClass);
        startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
    }

    private StartUseCase provideStartUseCaseInstance() {
        if (startUseCaseInstance == null) {
            StartUseCase.ResultCallback callback = new StartUseCase.ResultCallback() {
                @Override
                public void onLoadingStarted() {
                    progressBar.setVisibility(View.VISIBLE);
                }

                @Override
                public void onResult(@NonNull StartUseCase.Result result) {
                    progressBar.setVisibility(View.GONE);
                    if (result instanceof StartUseCase.Result.Success) {
                        onStartSuccess((StartUseCase.Result.Success) result);
                    } else if (result instanceof StartUseCase.Result.Failure) {
                        onStartFailure((StartUseCase.Result.Failure) result);
                    }
                }
            };
            startUseCaseInstance = new StartUseCase(callback, this);
        }

        return startUseCaseInstance;
    }

    private void onStartSuccess(StartUseCase.Result.Success result) {
        if (result instanceof StartUseCase.Result.Success.NavigateToOverviewCheckScreen) {
            navigateToScreen(Activities_VideoOverviewCheckActivity.class);
        } else if (result instanceof StartUseCase.Result.Success.NavigateToHighCallVolumeScreen) {
            navigateToScreen(Activities_HighCallVolumeActivity.class);
        } else if (result instanceof StartUseCase.Result.Success.NavigateToBeforeStartScreen) {
            navigateToScreen(Activities_BeforeStartingActivity.class);
        } else if (result instanceof StartUseCase.Result.Success.NavigateToCqcScreen) {
            navigateToScreen(Util_VideoStreamService.getClassForCallQualityCheck());
        } else if (result instanceof StartUseCase.Result.Success.NavigateToLiveStreamScreen) {
            navigateToScreen(Util_VideoStreamService.getClassForVideoLiveStreaming());
        } else if (result instanceof StartUseCase.Result.Success.NavigateToDeviceSupportScreen) {
            navigateToScreen(Activities_DeviceSupportActivity.class);
        }
    }

    private void onStartFailure(StartUseCase.Result.Failure result) {
        if (result instanceof StartUseCase.Result.Failure.NoInternet) {
            Util_UtilUI.showNoConnectionDialog(ActivityAgentLanguage.this, false);
        } else if (result instanceof StartUseCase.Result.Failure.RestApiCall) {
            RetrofitError.Response response = ((StartUseCase.Result.Failure.RestApiCall) result).getResponse();
            String resultText = ((StartUseCase.Result.Failure.RestApiCall) result).getResult();
            Runnable runnableT = () -> provideStartUseCaseInstance().proceed();
            if (response != null) {
                Util_UtilUI.showRESTCallErrorDialog(
                        this,
                        response.getStatus(),
                        false,
                        runnableT,
                        resultText,
                        true,
                        false,
                        ""
                );
            } else {
                Util_UtilUI.showRESTCallErrorDialog(
                        this,
                        0,
                        true,
                        runnableT,
                        resultText,
                        false,
                        false,
                        ""
                );
            }
        } else if (result instanceof StartUseCase.Result.Failure.ShowRemainingInternalTokenRetries) {
            int count = ((StartUseCase.Result.Failure.ShowRemainingInternalTokenRetries) result).getCount();
            tokenRetriesView.resolve(count);
        }
    }
}
