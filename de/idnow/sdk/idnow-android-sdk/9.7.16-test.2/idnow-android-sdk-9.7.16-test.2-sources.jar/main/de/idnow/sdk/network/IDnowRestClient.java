package de.idnow.sdk.network;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import de.idnow.sdk.BuildConfig;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.util.Util_Log;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

//TODO: Endpoints list should not be used. We should just replace the provided api service whenever the endpoint changes
public class IDnowRestClient {

    private static IDnowRestClient m_instance;
    private static final String LOGTAG = "IDNOW_IDnowRestClient";
    private static String appPackageName = "unknown";
    private static String appVersionName = "unknown";

    private final Map<String, Network_RESTCalls> m_callsForEndpoint;
    private final Map<String, Network_RESTCallsKt> m_callsForEndpointKt;

    public static IDnowRestClient getRestClient() {
        Util_Log.i(LOGTAG, " getRestClient()");
        if (m_instance == null)
            m_instance = new IDnowRestClient();

        return m_instance;
    }

    public static void clearInstance() {
        m_instance = null;
    }

    public Network_RESTCalls getCallsForEndpoint(String endpoint, Context context) {
        return getCallsForEndpoint(endpoint, context, -1, -1, -1);
    }

    public Network_RESTCalls getCallsForEndpoint(String endpoint, Context context, int readTimeout, int writeTimeout, int connectionTimeout) {
        if (m_callsForEndpoint.containsKey(endpoint)) {
            return m_callsForEndpoint.get(endpoint);
        } else {
            m_callsForEndpoint.put(endpoint, createClientCalls(endpoint, readTimeout, writeTimeout, connectionTimeout, context));
            return m_callsForEndpoint.get(endpoint);
        }
    }

    public Network_RESTCallsKt getCallsForEndpointKt(String endpoint, Context context) {
        return getCallsForEndpointKt(endpoint, context, -1, -1, -1);
    }

    public Network_RESTCallsKt getCallsForEndpointKt(String endpoint, Context context, int readTimeout, int writeTimeout, int connectionTimeout) {
        if (m_callsForEndpointKt.containsKey(endpoint)) {
            return m_callsForEndpointKt.get(endpoint);
        } else {
            m_callsForEndpointKt.put(endpoint, createClientCallsKt(endpoint, readTimeout, writeTimeout, connectionTimeout, context));
            return m_callsForEndpointKt.get(endpoint);
        }
    }

    private IDnowRestClient() {
        m_callsForEndpoint = new HashMap();
        m_callsForEndpointKt = new HashMap<>();
    }

    private Network_RESTCalls createClientCalls(String endPoint, int readTimeout, int writeTimeout, int connectionTimeout, Context context) {
        resolvePackageInfo(context);
        Network_RESTCalls restCalls = null;
        Interceptor requestInterceptor = chain -> {
            Request.Builder request = chain.request().newBuilder();
            request.addHeader("Accept", "application/json");

            request.addHeader("X-Client-Version", String.format("%s.android-%s", appPackageName, appVersionName));
            request.addHeader("X-Client-SDK-Version", String.format("%s.androidsdk-%s", appPackageName, BuildConfig.CURRENT_VERSION));

            if (Config.E_SIGNING_SECRET != null) {
                // Client secret needed to view eSign documents
                request.addHeader("X-Client-Secret", Config.E_SIGNING_SECRET);
            }

            if (Config.USER_SESSION_TOKEN != null && !Config.USER_SESSION_TOKEN.isEmpty()) {
                request.addHeader("X-Idnow-Session-Token", Config.USER_SESSION_TOKEN);
            }

            String currentSystemLanguage = Locale.getDefault().getLanguage();
            Util_Log.i(LOGTAG, "SYSTEM-LANGUAGE: " + currentSystemLanguage);
            request.addHeader("Accept-Language", currentSystemLanguage);
            Response response = chain.proceed(request.build());
            if (response.code() == 401 || response.code() == 403) {
                IDnowSDK.getInstance().setStartCallIssued(false);
                Config.USER_SESSION_TOKEN = "";
            }
            return response;
        };

        try {
            int currentapiVersion = Build.VERSION.SDK_INT;
            if (readTimeout < 0) {
                readTimeout = 60;
            }

            if (writeTimeout < 0) {
                writeTimeout = 10;
            }

            if (connectionTimeout < 0) {
                connectionTimeout = 10;
            }

            if (currentapiVersion < Build.VERSION_CODES.LOLLIPOP) {
                readTimeout = 5;
                writeTimeout = 3;
                connectionTimeout = 3;
            }

            HttpLoggingInterceptor logInterceptor = new HttpLoggingInterceptor();
            logInterceptor.level(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient client = IDNowOkHttpFactory.Companion.createOkHttpClient(
                    readTimeout,
                    connectionTimeout,
                    writeTimeout,
                    requestInterceptor,
                    logInterceptor
            );

            Retrofit adapter = new Retrofit.Builder()
                    .baseUrl(endPoint)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

            restCalls = adapter.create(Network_RESTCalls.class);

        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Create rest api failed", e);
        }

        return restCalls;
    }

    private Network_RESTCallsKt createClientCallsKt(String endPoint, int readTimeout, int writeTimeout, int connectionTimeout, Context context) {
        resolvePackageInfo(context);
        Network_RESTCallsKt restCalls = null;
        Interceptor requestInterceptor = chain -> {
            Request.Builder request = chain.request().newBuilder();
            request.addHeader("Accept", "application/json");

            request.addHeader("X-Client-Version", String.format("%s.android-%s", appPackageName, appVersionName));
            request.addHeader("X-Client-SDK-Version", String.format("%s.androidsdk-%s", appPackageName, BuildConfig.CURRENT_VERSION));

            if (Config.E_SIGNING_SECRET != null) {
                // Client secret needed to view eSign documents
                request.addHeader("X-Client-Secret", Config.E_SIGNING_SECRET);
            }
            if (Config.USER_SESSION_TOKEN != null && !Config.USER_SESSION_TOKEN.isEmpty()) {
                request.addHeader("X-Idnow-Session-Token", Config.USER_SESSION_TOKEN);
            }

            String currentSystemLanguage = Locale.getDefault().getLanguage();
            Util_Log.i(LOGTAG, "SYSTEM-LANGUAGE: " + currentSystemLanguage);
            request.addHeader("Accept-Language", currentSystemLanguage);
            Response response = chain.proceed(request.build());
            if (response.code() == 401 || response.code() == 403) {
                IDnowSDK.getInstance().setStartCallIssued(false);
                Config.USER_SESSION_TOKEN = "";
            }
            return response;
        };

        try {
            int currentapiVersion = Build.VERSION.SDK_INT;
            if (readTimeout < 0) {
                readTimeout = 60;
            }

            if (writeTimeout < 0) {
                writeTimeout = 10;
            }

            if (connectionTimeout < 0) {
                connectionTimeout = 10;
            }

            if (currentapiVersion < Build.VERSION_CODES.LOLLIPOP) {
                readTimeout = 5;
                writeTimeout = 3;
                connectionTimeout = 3;
            }

            HttpLoggingInterceptor logInterceptor = new HttpLoggingInterceptor();
            logInterceptor.level(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient client = IDNowOkHttpFactory.Companion.createOkHttpClient(
                    readTimeout,
                    connectionTimeout,
                    writeTimeout,
                    requestInterceptor,
                    logInterceptor
            );

            Retrofit adapter = new Retrofit.Builder()
                    .baseUrl(endPoint)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

            restCalls = adapter.create(Network_RESTCallsKt.class);

        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Create rest api failed", e);
        }

        return restCalls;
    }

    private void resolvePackageInfo(Context context) {
        if (appPackageName.equals("unknown")) {
            if (context != null) {
                String tmpAppPackageName = context.getPackageName();
                appPackageName = tmpAppPackageName.equals("de.idnow") ? "orangeapp" : tmpAppPackageName;
            }
        }

        if (appVersionName.equals("unknown")) {
            try {
                PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                appVersionName = packageInfo.versionName;
            } catch (PackageManager.NameNotFoundException e) {
                Util_Log.e(LOGTAG, "Failed to read app version", e);
            }
        }
    }
}
