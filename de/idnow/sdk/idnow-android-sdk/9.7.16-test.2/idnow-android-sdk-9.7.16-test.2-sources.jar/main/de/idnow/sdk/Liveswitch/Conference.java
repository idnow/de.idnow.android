package de.idnow.sdk.Liveswitch;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;

import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.pkcs.RSAPrivateKey;

import java.io.ByteArrayInputStream;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;

import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_LIVESWITCH;
import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_Super;
import de.idnow.sdk.Activities.cqc.CallQualityCheckActivity;
import de.idnow.sdk.CertificateProvider;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.util.CertificateHelper;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.camera.CameraType;
import de.idnow.sdk.util.helper.ImageHelper;
import fm.liveswitch.AudioStream;
import fm.liveswitch.BandwidthAdaptationPolicy;
import fm.liveswitch.Candidate;
import fm.liveswitch.Connection;
import fm.liveswitch.ConnectionState;
import fm.liveswitch.DataChannel;
import fm.liveswitch.DataStream;
import fm.liveswitch.DtlsCertificate;
import fm.liveswitch.ErrorCode;
import fm.liveswitch.Future;
import fm.liveswitch.IAction1;
import fm.liveswitch.IceServer;
import fm.liveswitch.LayoutMode;
import fm.liveswitch.LocalMediaState;
import fm.liveswitch.LogLevel;
import fm.liveswitch.Promise;
import fm.liveswitch.RsaKey;
import fm.liveswitch.SessionDescription;
import fm.liveswitch.Stream;
import fm.liveswitch.StreamStats;
import fm.liveswitch.TransportStats;
import fm.liveswitch.TrickleIcePolicy;
import fm.liveswitch.VideoStream;
import fm.liveswitch.android.LayoutManager;

public abstract class Conference {

    static {
        fm.liveswitch.Log.setDefaultLogLevel(LogLevel.Warn);
        fm.liveswitch.Log.setProvider(new fm.liveswitch.android.LogProvider(LogLevel.Warn));
    }

    public interface OnScreenshotCapturedCallback {
        void onScreenshotCaptured(@NonNull Bitmap bitmap);

        void onError(Exception e);
    }

    private final String LOGTAG = "IDNOW_Conference";
    private Connection connection;
    private final LocalMedia localMedia;
    private RemoteMedia remoteMedia;
    private final Context appContext;
    private final AecContext aecContext;
    private final boolean trickleIceEnabled;
    private final Mode mode;

    private final Activity activity;
    private RelativeLayout localContainer;
    private RelativeLayout remoteContainer;
    private ProgressBar subscriberProgressBar;
    private LayoutManager localLayoutManager;
    private LayoutManager remoteLayoutManager;

    private boolean agentConnected = false;
    private int reconnectCount = 0;
    private final Object dataChannelLock = new Object();
    ArrayList<DataChannel> dataChannels = new ArrayList<>();

    /** The last local media start/stop, so the next one can wait for it instead of racing it. */
    private volatile Future<fm.liveswitch.LocalMedia> localMediaTransition;
    private volatile boolean localMediaPaused = false;
    /** Set when the host went fully invisible while capture was still running. */
    private volatile boolean rebuildLocalMediaOnResume = false;

    public Conference(Activity activity, boolean trickleIceEnabled, Mode mode) {
        this.mode = mode;
        this.activity = activity;
        this.trickleIceEnabled = trickleIceEnabled;

        this.appContext = activity.getApplicationContext();
        this.aecContext = new AecContext();
        this.localMedia = new LocalMedia(appContext, false, false, false, aecContext);
        localMedia.addStateLogging();

        Util_Log.i(LOGTAG, "Creating conference mode=" + mode
                + " on " + Build.MANUFACTURER + " " + Build.MODEL + " (" + Build.DEVICE + ")"
                + " API " + Build.VERSION.SDK_INT);

        createConnection();
    }

    public int getReconnectCount() {
        return reconnectCount;
    }

    public void setSubscriberProgressBar(ProgressBar subscriberProgressBar) {
        this.subscriberProgressBar = subscriberProgressBar;
    }

    private IAction1<Connection> getConnectionOnStateChangeHandler(final RemoteMedia remoteMedia) {
        return c -> {
            Util_Log.i(LOGTAG, "Connection state: " + c.getState().name());

            switch (c.getState()) {
                case Closed:
                case New:
                    break;
                case Connected:
                    renderRemoteVideo(remoteMedia, remoteLayoutManager);
                    c.getStats().then(stats -> {
                        StreamStats[] streamStats = stats.getStreams();
                        if (streamStats == null || streamStats.length == 0) {
                            Util_Log.e(LOGTAG, "LiveSwitch connection has zero streams, exiting...");
                            c.close();
                            showResultScreenForFailedDtls();
                            return;
                        }

                        CertificateProvider udpCertProvider = Config.DTLS_CERTIFICATE_OVER_UDP;
                        if (udpCertProvider != null) {
                            for (StreamStats stream : streamStats) {
                                TransportStats transport = stream.getTransport();
                                try {
                                    String transportCertB64 = transport.getRemoteCertificate().getCertificateBase64();
                                    X509Certificate transportCert = CertificateHelper.Companion.readFromBase64(transportCertB64);
                                    X509Certificate udpCert = CertificateHelper.Companion.readFromBytes(udpCertProvider.provideCertificateBytestream());
                                    if (!CertificateHelper.Companion.checkValidity(transportCert) ||
                                            !CertificateHelper.Companion.checkValidity(udpCert) ||
                                            !CertificateHelper.Companion.compare(transportCert, udpCert)) {
                                        Util_Log.e(LOGTAG, "LiveSwitch certificate mismatch");
                                        c.close();
                                        showResultScreenForFailedDtls();
                                        return;
                                    }
                                    Util_Log.i(LOGTAG, "DTLS certificates pinning for UDP succeed ");
                                } catch (Exception ex) {
                                    Util_Log.e(LOGTAG, "DTLS certificates pinning for UDP failed", ex);
                                    throw new RuntimeException(ex);
                                }
                            }
                        }
                    });

                    if (agentConnected) {
                        hideSubscriberProgressBar();
                    } else {
                        showSubscriberProgressBar();
                    }

                    if (activity instanceof Activities_VideoLiveStreamActivity_LIVESWITCH) {
                        activity.runOnUiThread(() -> {
                            if (activity.isFinishing() || activity.isDestroyed()) return;
                            AlertDialog dialog = ((Activities_VideoLiveStreamActivity_LIVESWITCH) activity).connectionLossAlertDialog;
                            if (dialog != null && dialog.isShowing()) {
                                try {
                                    dialog.dismiss();
                                } catch (IllegalArgumentException ignored) {}
                            }
                        });
                    }
                    break;

                case Closing:
                case Failing:

                    if (remoteLayoutManager != null) {
                        remoteLayoutManager.removeRemoteViews();
                    }

                    remoteMedia.destroy();

                    break;

                case Failed:

                    // A failure caused by not being able to establish ICE/TURN connectivity
                    // (e.g. the TURN server is unreachable) is an infrastructure problem, not a
                    // poor user network. Surface it as an internal error instead of the
                    // misleading "poor network quality" result.
                    final boolean internalConnectivityFailure = isIceConnectivityFailure(c.getError());

                    if (activity instanceof CallQualityCheckActivity) {
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (internalConnectivityFailure) {
                                    ((CallQualityCheckActivity) activity).showWebRtcConnectivityError();
                                } else if (Config.CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                                    ((CallQualityCheckActivity) activity).showCheckResultScreenCustomise(CallQualityCheckActivity.CallQualityResult.UNKNOWN.getInt());
                                } else {
                                    if (Config.VIDEO_IDENT_PLUS) {
                                        ((CallQualityCheckActivity) activity).showCheckResultScreen_vip(CallQualityCheckActivity.CallQualityResult.UNKNOWN.getInt());
                                    } else {
                                        ((CallQualityCheckActivity) activity).showCheckResultScreen(CallQualityCheckActivity.CallQualityResult.UNKNOWN.getInt());
                                    }
                                }
                            }
                        });
                    } else if (internalConnectivityFailure && activity instanceof Activities_VideoLiveStreamActivity_LIVESWITCH) {
                        activity.runOnUiThread(() ->
                                ((Activities_VideoLiveStreamActivity_LIVESWITCH) activity).showWebRtcConnectivityError());
                        break;
                    }

                    if (agentConnected) {
                        reconnectIfForeground();
                    }
                    break;
            }
        };
    }

    /**
     * Returns true when the connection could not be established at all because ICE/TURN
     * connectivity could not be set up (e.g. the TURN server is unreachable).
     *
     * Only the "never established" codes are matched here. Transient mid-call failures
     * (e.g. {@code IceRefreshTimeout}, {@code IceCreatePermissionTimeout},
     * {@code IceConnectivityCheckFailed}) are deliberately excluded so the live-ident path
     * keeps auto-reconnecting and recovering from them instead of ending the session.
     */
    private static boolean isIceConnectivityFailure(fm.liveswitch.Error error) {
        if (error == null) {
            return false;
        }
        ErrorCode code = error.getCode();
        if (code == null) {
            return false;
        }
        return code == ErrorCode.ConnectionNotEstablished
                || code == ErrorCode.IceLocalRelayedStreamCandidateError
                || code == ErrorCode.IceLocalRelayedDatagramCandidateError;
    }

    private void showResultScreenForFailedDtls() {
        activity.runOnUiThread(() -> {
            if (activity instanceof Activities_VideoLiveStreamActivity_LIVESWITCH) {
                ((Activities_VideoLiveStreamActivity_LIVESWITCH) activity).identificationFailedRESTCall();
            } else {
                Util_UtilUI.showMatchingValidationError(activity);
            }
        });
    }

    public abstract Promise<SessionDescription> sendSdpOffer(SessionDescription sd);

    public abstract void sendCandidate(Candidate candidate);

    public Connection getConnection() {
        return connection;
    }

    private void createConnection() {

        if (connection != null) {
            connection.close();
        }

        if (remoteMedia != null) {
            remoteMedia.destroy();
        }

        remoteMedia = new RemoteMedia(appContext, false, false, false, aecContext);

        final AudioStream audioStream = new AudioStream(localMedia, remoteMedia);
        audioStream.setLocalSend(true);
        audioStream.setLocalReceive(true);

        audioStream.setMuted(Config.TEST_ROBOT_TYPE != null);

        final VideoStream videoStream = new VideoStream(localMedia, remoteMedia);
        videoStream.setLocalSend(true);
        videoStream.setLocalReceive(true);
        videoStream.setBandwidthAdaptationPolicy(BandwidthAdaptationPolicy.Enabled);

        DataChannel dataChannel = new DataChannel("data");

        DataStream dataStream = new DataStream(dataChannel);


        synchronized (dataChannelLock) {
            dataChannels.add(dataChannel);
        }

        Stream[] streams;

        if (mode == Mode.CQC && Config.CALL_QUALITY_CHECK_ENABLED) {
            streams = new Stream[]{audioStream, videoStream, dataStream};
        } else {
            streams = new Stream[]{audioStream, videoStream};
        }

        connection = new Connection(dataChannelLock, streams);

        IceServer[] iceServers = {
                new IceServer("stun:" + Config.CURRENT_SERVER.getStunHost(IDnowSDK.getTransactionToken()) + ":" + Config.CURRENT_SERVER.getStunPort()),
                new IceServer("turn:" + Config.CURRENT_SERVER.getStunHost(IDnowSDK.getTransactionToken()) + ":" + Config.CURRENT_SERVER.getStunPort(), "idnow", "1VbrjNLEo9b5N9729HFbQWtw1LrKc9xIaUGSotLm65r0xuaH")
        };
        connection.setIceServers(iceServers);
        connection.setTrickleIcePolicy(trickleIceEnabled ? TrickleIcePolicy.FullTrickle : TrickleIcePolicy.NotSupported);
        connection.addOnStateChange(getConnectionOnStateChangeHandler(remoteMedia));
        connection.setDeadStreamTimeout(5000);
        connection.setLocalDtlsCertificate(createCertificate());
    }

    /**
     * Reconnects, but never from the background.
     *
     * A backgrounded process cannot resolve DNS, so the re-offer fails with
     * {@code UnknownHostException}, the new connection never gets a remote description, and 30s
     * later it reports {@code ConnectionNotEstablished} — which ends the identification. The same
     * background reconnect also restarts capture, and with no foreground service covering it the
     * framework takes the camera away for good. Recovery is deferred to
     * {@link #onLocalMediaSettled()}, which runs once the host is visible again.
     */
    private void reconnectIfForeground() {
        if (isHostBackgrounded()) {
            Util_Log.i(LOGTAG, "Reconnect skipped: host is backgrounded, will recover on resume");
            return;
        }
        reconnect();
    }

    /**
     * Whether the host activity is currently backgrounded.
     *
     * Reads {@code isActivityRunning} rather than tracking pause/resume here: the host skips
     * {@link #pauseLocalMedia()} entirely on its picture-in-picture path, but
     * {@code Super.onPause()} always runs and always clears that flag.
     */
    private boolean isHostBackgrounded() {
        // Picture-in-picture is not the background: the window is visible, the process keeps
        // foreground importance, so DNS resolves and the camera stays ours. The call is meant to
        // carry on there, and it must still be able to recover. isActivityRunning is false in PiP
        // (the activity stays paused), so it has to be checked first.
        if (activity.isInPictureInPictureMode()) {
            return false;
        }

        return activity instanceof Activities_VideoLiveStreamActivity_Super
                && !((Activities_VideoLiveStreamActivity_Super) activity).isActivityRunning;
    }

    private void reconnect() {

        Util_Log.i(LOGTAG, "RECONNECTING, conference mode=" + mode + " activity=" + activity.getClass().getSimpleName());

        showSubscriberProgressBar();
        connect(localContainer, remoteContainer);
    }

    private void hideSubscriberProgressBar() {
        if (subscriberProgressBar == null) {
            return;
        }
        activity.runOnUiThread(() -> subscriberProgressBar.setVisibility(View.INVISIBLE));
    }

    private void showSubscriberProgressBar() {
        if (subscriberProgressBar == null) {
            return;
        }

        activity.runOnUiThread(() -> {
            subscriberProgressBar.setVisibility(View.VISIBLE);
            subscriberProgressBar.bringToFront();
        });
    }

    public void disconnect() {
        connection.close();
    }

    public Future<fm.liveswitch.LocalMedia> connectToAgent(final RelativeLayout localContainer, final RelativeLayout remoteContainer) {
        this.agentConnected = true;
        return connect(localContainer, remoteContainer);
    }

    public Future<fm.liveswitch.LocalMedia> connect(final RelativeLayout localContainer, final RelativeLayout remoteContainer) {

        if (connection.getState().getAssignedValue() > ConnectionState.New.getAssignedValue() && connection.getState().getAssignedValue() <= ConnectionState.Connected.getAssignedValue()) {
            Util_Log.i(LOGTAG, "conference is in state " + connection.getState());
            if (agentConnected) {
                hideSubscriberProgressBar();
            }
            return Promise.resolveNow(localMedia);
        } else if (connection.getState().getAssignedValue() > ConnectionState.Connected.getAssignedValue()) {
            Util_Log.i(LOGTAG, "conference is in state " + connection.getState() + " needs to be replaced");
            createConnection();
        }

        this.reconnectCount++;
        Util_Log.i(LOGTAG, "Connecting to videoserver " + connection.getState());
        this.localContainer = localContainer;
        this.remoteContainer = remoteContainer;

        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                localLayoutManager = new LayoutManager(localContainer);
                remoteLayoutManager = new LayoutManager(remoteContainer);

                final View localView = localMedia.getView();

                if (localView != null && localLayoutManager.getLocalView() != null) {
                    localView.setContentDescription("localView");
                    localLayoutManager.setLocalView(localView);
                } else {
                    Util_Log.w(LOGTAG, "LocalMedia's View is null!");
                }
            }
        });

        // Start the local media.
        return localMedia.start().
                then(localMedia -> {
                    connection.addOnLocalCandidate((connection, candidate) -> sendCandidate(candidate));
                    connection.createOffer()
                            .then(offer -> {
                                Util_Log.i(LOGTAG, "SDP Offer created");
                                return connection.setLocalDescription(offer);
                            })
                            .then(sessionDescription -> {
                                Util_Log.i(LOGTAG, "Sending SDP offer");
                                return sendSdpOffer(sessionDescription);
                            }).then(sessionDescription -> {
                                Util_Log.i(LOGTAG, "Setting SDP answer");
                                connection.setRemoteDescription(sessionDescription);
                            });
                });
    }

    public Future<fm.liveswitch.LocalMedia> setupConference(RelativeLayout localContainer, RelativeLayout remoteContainer) {
        Util_Log.i(LOGTAG, "Setting up conference");
        renderLocalRemoteVideo(localContainer, remoteContainer);
        return localMedia.start();
    }

    public Future<fm.liveswitch.LocalMedia> stopConference() {
        Util_Log.i(LOGTAG, "Stopping conference=" + this);
        connection.close();

        return Promise.wrapPromise(() -> {
            if (localMedia == null) {
                throw new RuntimeException("Local media has already been stopped.");
            }

            // Stop the local media.
            return localMedia.stop().then(o -> {
                activity.runOnUiThread(() -> {
                    if (localLayoutManager != null) {
                        localLayoutManager.removeRemoteViews();
                        localLayoutManager.unsetLocalView();
                        localLayoutManager = null;
                    }

                    if (remoteLayoutManager != null) {
                        remoteLayoutManager.removeRemoteViews();
                        remoteLayoutManager.unsetLocalView();
                        remoteLayoutManager = null;
                    }

                    try {
                        localMedia.destroy(); // localMedia.destroy() will also destroy AecContext
                    } catch (Exception e) {
                        Util_Log.e(LOGTAG, "Stop conference failed. LocalMedia cannot be destroyed", e);
                    }
                });
            });
        });
    }

    /**
     * Stops capturing — camera <em>and</em> microphone, since both live on the same
     * {@link LocalMedia}. Called when the host activity is backgrounded.
     */
    public void pauseLocalMedia() {
        if (localMedia == null) {
            Util_Log.e(LOGTAG, "Pause local media failed. LocalMedia is null");
            return;
        }

        localMediaPaused = true;
        Util_Log.i(LOGTAG, "Stopping local media, state=" + localMedia.getState().name());
        localMediaTransition = localMedia.stop();
    }

    /**
     * The host activity is no longer visible. Capture still running at this point means the
     * framework can revoke the camera while we are away, so note that the sources need rebuilding
     * on the way back. Picture-in-picture does not come through here — the window stays visible,
     * the camera stays ours, and cycling it there would break a working stream.
     */
    public void onHostStopped() {
        if (localMedia == null) {
            return;
        }

        // Starting counts as capturing: a stop issued against it is rejected outright, so capture
        // carries on into the background just the same.
        LocalMediaState state = localMedia.getState();
        rebuildLocalMediaOnResume = state == LocalMediaState.Started || state == LocalMediaState.Starting;

        if (rebuildLocalMediaOnResume) {
            Util_Log.i(LOGTAG, "Host stopped while still capturing (state=" + state.name()
                    + "), local media will be rebuilt on resume");
        }
    }

    /**
     * Restarts capturing after {@link #pauseLocalMedia()}.
     *
     * The restart waits for the pending stop instead of inspecting {@code getState()}: the stop
     * issued on background is asynchronous, so on a quick background/foreground bounce the state
     * is still {@code Stopping} here, and the old state-based check silently restarted nothing —
     * leaving the microphone dead for the rest of the session.
     */
    public void resumeLocalMedia() {
        if (localMedia == null) {
            Util_Log.w(LOGTAG, "Resume local media failed. LocalMedia is null");
            return;
        }

        localMediaPaused = false;

        if (rebuildLocalMediaOnResume && localMedia.getState() == LocalMediaState.Started) {
            // We went out of sight still capturing, so the sources may be dead even though the
            // state says otherwise: the framework revokes the camera and Camera2Source reports
            // CAMERA_ERROR without ever recovering. start() is a no-op while the state is Started,
            // so cycle local media to rebuild the sources.
            Util_Log.i(LOGTAG, "Local media still started on resume, cycling to rebuild sources");
            localMediaTransition = localMedia.stop();
        }
        rebuildLocalMediaOnResume = false;

        Future<fm.liveswitch.LocalMedia> pending = localMediaTransition;
        if (pending == null) {
            startLocalMedia();
        } else {
            pending.then(result -> {
                startLocalMedia();
            }, ex -> {
                Util_Log.e(LOGTAG, "Pending local media stop failed, starting anyway", ex);
                startLocalMedia();
            });
        }
    }

    private void startLocalMedia() {
        if (localMediaPaused) {
            Util_Log.i(LOGTAG, "Local media start skipped, paused again in the meantime");
            return;
        }

        Util_Log.i(LOGTAG, "Starting local media, state=" + localMedia.getState().name());
        localMediaTransition = localMedia.start();
        localMediaTransition.then(
                result -> {
                    Util_Log.i(LOGTAG, "Local media started");
                    onLocalMediaSettled();
                },
                ex -> {
                    Util_Log.e(LOGTAG, "Start local media failed, state=" + localMedia.getState().name(), ex);
                    onLocalMediaSettled();
                });
    }

    /**
     * The restart has finished, successfully or not — the connection still needs checking either
     * way. A camera that refuses to start must not also cost us the connection: the skipped
     * background reconnect is only retried from here, and no further {@code Failed} event is
     * coming to trigger it.
     */
    private void onLocalMediaSettled() {
        ConnectionState state = connection.getState();

        if (state == ConnectionState.Connected) {
            if (agentConnected) {
                hideSubscriberProgressBar();
            }
        } else if (agentConnected && state.getAssignedValue() > ConnectionState.Connected.getAssignedValue()) {
            // Either a reconnect was skipped while backgrounded, or the connection died while we
            // were away. Now that the host is visible again, the re-offer can actually reach DNS.
            Util_Log.i(LOGTAG, "Connection is " + state.name() + " after resume, recovering");
            reconnectIfForeground();
        }
    }

    public void openCamera(CameraType type) {
        try {
            if (localMedia != null) {
                localMedia.openCamera(type);
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Open camera " + type.name() + " failed", e);
        }
    }

    public void requestCameraFocusCenter() {
        try {
            if (localMedia != null) {
                localMedia.requestCameraFocusCenter();
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Request camera focus center failed", e);
        }
    }

    public void setCameraTorchEnabled(boolean enabled) {
        try {
            if (localMedia != null) {
                localMedia.setCameraTorchEnabled(enabled);
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Set camera torch to " + enabled + " failed", e);
        }
    }

    public void takeScreenshot(int requiredWidth,
                               int requiredHeight,
                               OnScreenshotCapturedCallback callback) {
        try {
            if (localMedia == null) {
                throw new IllegalStateException("Local media is null");
            }

            localMedia.grabVideoFrame().then(vb -> {
                Bitmap bitmap = ImageHelper.INSTANCE.extractBitmapFromVideoBuffer(vb, requiredWidth, requiredHeight);
                callback.onScreenshotCaptured(bitmap);
            });
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Take screenshot failed", e);
            callback.onError(e);
        }
    }

    public boolean connectionHasDataStream() {
        Stream stream = getConnection().getDataStream();
        return stream != null;
    }

    public DataChannel getDataChannel() {

        DataStream stream = getConnection().getDataStream();

        return stream.getChannels()[0];
    }

    public enum Mode {
        CQC, AGENT_CONFERENCE
    }

    @NonNull
    @Override
    public String toString() {
        return "Conference{" +
                "mode=" + mode +
                ", activity=" + activity.getClass().getSimpleName() +
                '}';
    }

    private void renderLocalRemoteVideo(final RelativeLayout localContainer, final RelativeLayout remoteContainer) {
        Util_Log.i(LOGTAG, "START !");

        this.localContainer = localContainer;
        this.remoteContainer = remoteContainer;

        activity.runOnUiThread(() -> {
            localLayoutManager = new LayoutManager(localContainer);
            remoteLayoutManager = new LayoutManager(remoteContainer);
            View localView = localMedia.getView();

            localView.setContentDescription("localView_" + localMedia.getId());

            if (!(Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED && !Config.AGENT_CONNECTED)) {
                localLayoutManager.setLocalView(localView);
                localLayoutManager.setMode(LayoutMode.FloatRemote);
            }
        });
    }

    private void renderRemoteVideo(final RemoteMedia remoteMedia, final LayoutManager remoteLayoutManager) {
        activity.runOnUiThread(() -> {
            View remoteView = remoteMedia.getView();

            if (remoteView != null) {
                remoteView.setContentDescription("remoteView_" + remoteMedia.getId());
                remoteLayoutManager.addRemoteView(remoteMedia.getId(), remoteView);
            }
        });
    }

    public DtlsCertificate createCertificate() {
        if (Config.DTLS_CERTIFICATE != null && Config.DTLS_CERTIFICATE.featureCertificate()) {
            try {
                byte[] privateKeyBytes = Config.DTLS_CERTIFICATE.providePrivateKeyBytestream();
                byte[] certificateBytes = Config.DTLS_CERTIFICATE.provideCertificateBytestream();
                if (privateKeyBytes != null && certificateBytes != null) {
                    RSAPrivateKey privateKey = readRSAPrivateKey(privateKeyBytes);
                    if (privateKey == null) {
                        throw new Exception("Failed to read private key from byte stream");
                    }
                    RsaKey rsaKey = generateRsaKey(privateKey);
                    if (rsaKey == null) {
                        throw new Exception("Can't generate RsaKey from RSAPrivateKey");
                    }
                    X509Certificate x509Certificate = readX509Certificate(certificateBytes);
                    if (x509Certificate == null) {
                        throw new Exception("Can't read X509Certificate");
                    }
                    DtlsCertificate certificate = DtlsCertificate.generateCertificate(x509Certificate.getIssuerX500Principal().getName(), null, x509Certificate.getNotAfter(), rsaKey);
                    certificate.setAutoRegenerate(false);

                    return certificate;
                } else {
                    throw new NullPointerException("No valid by streams for key and/or certificate to create DTLS certificate");
                }
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Failed to create DTLS certificate. Default generated LiveSwitch certificate will be used", e);
                return DtlsCertificate.generateCertificate();
            }
        } else {
            Util_Log.i(LOGTAG, "No custom certificate/key provided. Default generated LiveSwitch certificate will be used");
            return DtlsCertificate.generateCertificate();
        }
    }

    private RSAPrivateKey readRSAPrivateKey(byte[] bytes) {
        RSAPrivateKey key = readRSAPrivateKeyPKCS1(bytes);
        if (key != null)
            return key;

        return readRSAPrivateKeyPKCS8(bytes);
    }

    private RSAPrivateKey readRSAPrivateKeyPKCS1(byte[] bytes){
        try{
            return RSAPrivateKey.getInstance(ASN1Primitive.fromByteArray(bytes));
        }catch (Exception e){
            Util_Log.e(LOGTAG, "Failed to read RSA private key: Invalid PKCS#1 format", e);
            return null;
        }
    }

    private RSAPrivateKey readRSAPrivateKeyPKCS8(byte[] bytes) {
        try {
            ASN1Primitive asn1 = ASN1Primitive.fromByteArray(bytes);
            PrivateKeyInfo pki = PrivateKeyInfo.getInstance(asn1);
            ASN1Sequence rsaSeq = (ASN1Sequence) pki.parsePrivateKey();

            return RSAPrivateKey.getInstance(rsaSeq);
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Failed to read RSA private key: Invalid PKCS#8 format", e);
            return null;
        }
    }

    private RsaKey generateRsaKey(RSAPrivateKey privateKey) {
        try {
            RsaKey rsaKey = new RsaKey();
            rsaKey.setModulus(privateKey.getModulus().toByteArray());
            rsaKey.setCoefficient(privateKey.getCoefficient().toByteArray());
            rsaKey.setExponent1(privateKey.getExponent1().toByteArray());
            rsaKey.setExponent2(privateKey.getExponent2().toByteArray());
            rsaKey.setPrime1(privateKey.getPrime1().toByteArray());
            rsaKey.setPrime2(privateKey.getPrime2().toByteArray());
            rsaKey.setPrivateExponent(privateKey.getPrivateExponent().toByteArray());
            rsaKey.setPublicExponent(privateKey.getPublicExponent().toByteArray());

            return rsaKey;
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Generate RsaKey from RSAPrivateKey failed", e);
            return null;
        }
    }

    public X509Certificate readX509Certificate(byte[] bytes) {
        try {
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            ByteArrayInputStream inputStream = new ByteArrayInputStream(bytes);

            return (X509Certificate) certFactory.generateCertificate(inputStream);
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Read X509Certificate from byte array failed", e);
            return null;
        }
    }
}
