package de.idnow.sdk.util;

import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CONNECTING_DESC;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CONNECTING_POS1;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CONNECTING_POSX;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_LONGER;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_MINUTE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_MINUTES;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_SECONDS;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CONNECTING_DESC;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CONNECTING_POS1;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CONNECTING_POSX;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_LONGER;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_MINUTE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_MINUTES;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_SECONDS;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.graphics.Rect;
import android.nfc.NfcAdapter;
import android.nfc.NfcManager;
import android.os.Build;
import android.os.Build.VERSION_CODES;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UnknownFormatConversionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.idnow.sdk.Activities.Activities_VideoLiveStreamActivity_Super;
import de.idnow.sdk.BuildConfig;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.IDnowSDK.Server;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Models_ClientInfo;
import de.idnow.sdk.models.Models_Customer;
import de.idnow.sdk.models.Models_OfficeHour;
import de.idnow.sdk.models.Models_OfficeHours;
import de.idnow.sdk.network.Callback;
import de.idnow.sdk.network.IDnowRestClient;
import de.idnow.sdk.network.Network_RESTCalls;
import de.idnow.sdk.network.RetrofitError;
import de.idnow.sdk.network.connectivityService.ConnectivityService;
import de.idnow.sdk.util.camera.CameraType;
import de.idnow.sdk.util.helper.CameraHelper;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import retrofit2.Response;

public class Util_Util {
    private final static String LOGTAG = "IDNOW_Util_Util";
    public static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    public static String getClientInfoLanguage() {

        String language = "en";
        try {
            language = IDnowSDK.language.isEmpty() ?
                    IDnowSDK.getInstance()
                            .getAppContext()
                            .getResources()
                            .getConfiguration()
                            .locale.getLanguage() :
                    IDnowSDK.language;
        } catch (NullPointerException e) {
            Util_Log.e(LOGTAG, "Get client language failed", e);
        }

        return language;
    }

    /**
     * generates a new ClientInfo Object to provide user information for the start REST call
     *
     * @param visualContext a visual (Activity) context used to resolve the display size. On
     *                      targetSdk >= 30 the WindowManager can only be accessed from a visual
     *                      context; a non-visual context falls back to display metrics safely.
     */
    public static Models_ClientInfo getClientInfo(Context visualContext) {
        String language = "en";
        Context context = IDnowSDK.getInstance().getAppContext();
        try {
            language = IDnowSDK.language.isEmpty() ?
                    context.getResources()
                            .getConfiguration()
                            .locale.getLanguage() :
                    IDnowSDK.language;
        } catch (NullPointerException e) {
            Util_Log.e(LOGTAG, "Get client info language failed", e);
        }
        String locale = context.getResources().getConfiguration().locale.toString();

        Point size = getDisplaySize(visualContext != null ? visualContext : context);
        String screenWidth = String.valueOf(size.x);
        String screenHeight = String.valueOf(size.y);


        boolean frontCameraAvailable = CameraHelper.INSTANCE.hasCamera(CameraType.FRONT);
        boolean backCameraAvailable = CameraHelper.INSTANCE.hasCamera(CameraType.BACK);
        String frontCameraWidth = frontCameraAvailable ? "640" : null;
        String frontCameraHeight = frontCameraAvailable ? "480" : null;
        String backCameraWidth =  backCameraAvailable ? "640" : null;
        String backCameraHeight =  backCameraAvailable ? "480" : null;
        boolean flashLight = CameraHelper.INSTANCE.hasTorch();

        String connectionType = ConnectivityService.INSTANCE.getConnectionType();

        String osVersion = String.valueOf(android.os.Build.VERSION.SDK_INT);

        String deviceInfo = android.os.Build.DEVICE;

        String timezone = TimeZone.getDefault().getID();

        String os = "Android";
        String sdkVersion = BuildConfig.CURRENT_VERSION;
        String customerApp = Config.APP_ID.equals("de.idnow") ? "IDnow" : IDnowSDK.getCompanyId();
        String mobileAppVersion = resolveMobileAppVersion(context);
        String clientVersion = resolveClientVersion(context);

        return new Models_ClientInfo(language, locale, screenWidth, screenHeight, clientVersion, frontCameraWidth, frontCameraHeight, backCameraWidth, backCameraHeight, flashLight, connectionType, osVersion, deviceInfo, timezone, os, sdkVersion, customerApp, mobileAppVersion);
    }

    /**
     * Resolves the display size. On targetSdk >= 30 the WindowManager is a visual service and can
     * only be accessed from a visual (Activity) context - accessing it from the Application context
     * throws. This method prefers the visual WindowManager and always falls back to the display
     * metrics so it can never propagate an exception, even if a non-visual context is passed.
     */
    private static Point getDisplaySize(Context context) {
        Context ctx = context != null ? context : IDnowSDK.getInstance().getAppContext();
        try {
            WindowManager windowManager = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            if (windowManager != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Rect bounds = windowManager.getCurrentWindowMetrics().getBounds();
                    return new Point(bounds.width(), bounds.height());
                } else {
                    Display display = windowManager.getDefaultDisplay();
                    Point size = new Point();
                    display.getSize(size);
                    return size;
                }
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Get display size from WindowManager failed, falling back to display metrics", e);
        }

        DisplayMetrics metrics = ctx.getResources().getDisplayMetrics();
        return new Point(metrics.widthPixels, metrics.heightPixels);
    }

    private static String resolveMobileAppVersion(Context context) {
        String tmpAppPackageName = context.getPackageName();
        String appPackageName =  tmpAppPackageName.equals("de.idnow") ? "orangeapp" : tmpAppPackageName;

        String appVersionName = "";
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            appVersionName = packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            Util_Log.e(LOGTAG, "Failed to read app version", e);
        }

        return String.format("%s.android-%s", appPackageName, appVersionName);
    }

    private static String resolveClientVersion(Context context) {
        String tmpAppPackageName = context.getPackageName();
        String appPackageName =  tmpAppPackageName.equals("de.idnow") ? "orangeapp" : tmpAppPackageName;

        return String.format("%s.androidsdk-%s", appPackageName, BuildConfig.CURRENT_VERSION);
    }

    /**
     * Cancel a running or queued Call with OkHttp3
     *
     * @param client
     * @param tag
     */
    public static void cancelCallWithTag(OkHttpClient client, String tag) {
        for (Call call : client.dispatcher().queuedCalls()) {
            if (call.request().tag().equals(tag)) {
                call.cancel();
            }
        }
        for (Call call : client.dispatcher().runningCalls()) {
            if (call.request().tag().equals(tag)) {
                call.cancel();
            }
        }
    }

    public static String getCountrynameToISOCode(String iso) {
        Locale loc = new Locale("", iso);
        return loc.getDisplayCountry();
    }

    /**
     * selects message shown to the user according to the current position in the waiting queue.
     *
     * @param context
     * @param positionInQueue
     * @return
     */
    protected static String getHumanReadableWaitingPosition(Context context, int positionInQueue) {
        // next person
        if (positionInQueue == 0) {
            return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTING_DESC, LOCAL_KEY_VIDEO_IDENT_CONNECTING_DESC);
        }

        // one person in front of the user
        else if (positionInQueue == 1) {
            return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTING_POS1, LOCAL_KEY_VIDEO_IDENT_CONNECTING_POS1);
        }

        // multiple persons in front of the user.
        try {
            return String.format(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTING_POSX, LOCAL_KEY_VIDEO_IDENT_CONNECTING_POSX), positionInQueue);
        } catch (UnknownFormatConversionException e) {
            Util_Log.e(LOGTAG, "Get human readable waiting position failed", e);
            return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTING_POSX, LOCAL_KEY_VIDEO_IDENT_CONNECTING_POSX);
        }
    }

    /**
     * chooses the format the remaining waiting time has to be shown to the user.
     *
     * @param context
     * @param waitingTime
     * @return
     */
    protected static String getHumanReadableWaitingDuration(Context context, int waitingTime) {
        try {
            // it seems that the server could send negative values -> use 60 seconds in this case.
            if (waitingTime <= 0) {
                waitingTime = 60;
            }

            // if the waitingTime from the server is less than 60 seconds, show the user the waiting time in seconds.
            if (waitingTime < 60) {
                return String.format(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_SECONDS, LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_SECONDS), waitingTime);
            }

            int minutes = (int) Math.floor(waitingTime / 60);

            if (minutes > 30) {
                return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_LONGER, LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_LONGER);
            }

            // if the waiting time is exactly one minute, show the user "1 minute"
            if (minutes == 1) {
                return String.format(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_MINUTE, LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_MINUTE), 1);
            }

            // if the waiting time is more than 1 minute, but less than 10 minutes, show the user the waiting time "X minutes".
            return String.format(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_MINUTES, LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_MINUTES), minutes);

        } catch (UnknownFormatConversionException e) {
            return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_MINUTES, LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_MINUTES);
        }

    }

    public static String getHumanReadableWaitingInformation(Context context, int positionInQueue, int waitingTime) {
        Util_Log.d(LOGTAG, String.format("WaitingPos positionInQueue %s, waitingTime: %d", positionInQueue, waitingTime));
        return Util_Util.getHumanReadableWaitingPosition(context, positionInQueue) + " " +
                Util_Util.getHumanReadableWaitingDuration(context, waitingTime);
    }


    public static String convertDateToFormattedDateString(Date date, SimpleDateFormat simpleDateFormat) {
        String formattedDate = simpleDateFormat.format(date);
        return formattedDate;
    }

    public static int getStatusBarHeight(Context context) {
        int result = 0;
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = context.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    public static String generateOfficeHoursMessage(Models_OfficeHours resultObject) {
        String s;
        Context context = IDnowSDK.getInstance().getAppContext();
        s = Util_Strings.getStringWithDefault(context, "js.mobile.service-hours-1", R.string.dialog_office_hours_content_1);

        for (Models_OfficeHour h : resultObject.getOfficeHours()) {
            s = s.concat(h.getDays() + " : " + h.getHours() + "\n");
        }

        s = s.concat(Util_Strings.getStringWithDefault(context, "js.mobile.service-hours-2", R.string.dialog_office_hours_content_2));
        return s;
    }

    public static String hidePhoneNum(String input) {
        String strPattern = "\\d(?=\\d{3})";

        if (!input.equals("")) {
            return input.replaceAll(strPattern, "*");
        }
        return null;
    }

    public static String hideEmail(String input) {
        if (!input.equals("")) {
            return input.replaceAll("(^[^@]{3}|(?!^)\\G)[^@]", "$1*");
        }
        return null;
    }

    /**
     * handles the server selection according to the following guidelines:
     * <p/>
     * If the HostApp has set an environment to work against, choose it.
     * Otherwise dependent on the transaction token inserted:
     * If a normal transaction token is entered -> connect to production environment (e.g. CFG-H5DAF)
     * If a transactiontoken is entered which starts with "TST" -> connect to test environment (e.g. TST-J6DHS)
     * If a transactiontoken is entered which starts with "DEV" -> connect to dev environment (e.g. DEV-J6DHS)
     *
     * @param token
     */
    public static void handleServerSelection(String token) {
        if (IDnowSDK.getEnvironment() != null) {
            Config.CURRENT_SERVER = IDnowSDK.getEnvironment();
        } else {
            // The Environment wasn't set by the host app. Use token to determine.
            if (token.toUpperCase().startsWith("DEV")) {
                Config.CURRENT_SERVER = Server.DEV;
                Util_Log.i(LOGTAG, "select dev server");
            } else if (token.toUpperCase().startsWith("DV2")) {
                Config.CURRENT_SERVER = Server.DEV2;
                Util_Log.i(LOGTAG, "select dev2 server");
            } else if (token.toUpperCase().startsWith("DV3")) {
                Config.CURRENT_SERVER = Server.DV3;
                Util_Log.i(LOGTAG, "select dev3 server");
            } else if (token.toUpperCase().startsWith("DV4")) {
                Config.CURRENT_SERVER = Server.DV4;
                Util_Log.i(LOGTAG, "select dev4 server");
            } else if (token.toUpperCase().startsWith("DV5")) {
                Config.CURRENT_SERVER = Server.DV5;
                Util_Log.i(LOGTAG, "select dev5 server");
            } else if (token.toUpperCase().startsWith("DV7")) {
                Config.CURRENT_SERVER = Server.DV7;
                Util_Log.i(LOGTAG, "select dev7 server");
            } else if (token.toUpperCase().startsWith("DV8")) {
                Config.CURRENT_SERVER = Server.DV8;
                Util_Log.i(LOGTAG, "select dev8 server");
            } else if (token.toUpperCase().startsWith("DV9")) {
                Config.CURRENT_SERVER = Server.DV9;
                Util_Log.i(LOGTAG, "select dev9 server");
            } else if (token.toUpperCase().startsWith("DV0")) {
                Config.CURRENT_SERVER = Server.DV0;
                Util_Log.i(LOGTAG, "select dev0 server");
            } else if (token.toUpperCase().startsWith("DV1")) {
                Config.CURRENT_SERVER = Server.DV1;
                Util_Log.i(LOGTAG, "select dev1 server");
            } else if (token.toUpperCase().startsWith("DV10")) {
                Config.CURRENT_SERVER = Server.DV10;
                Util_Log.i(LOGTAG, "select dev10 server");
            } else if (token.toUpperCase().startsWith("DV11")) {
                Config.CURRENT_SERVER = Server.DV11;
                Util_Log.i(LOGTAG, "select dev11 server");
            } else if (token.toUpperCase().startsWith("DV12")) {
                Config.CURRENT_SERVER = Server.DV12;
                Util_Log.i(LOGTAG, "select dev12 server");
            } else if (token.toUpperCase().startsWith("DV13")) {
                Config.CURRENT_SERVER = Server.DV13;
                Util_Log.i(LOGTAG, "select dev13 server");
            } else if (token.toUpperCase().startsWith("DV14")) {
                Config.CURRENT_SERVER = Server.DV14;
                Util_Log.i(LOGTAG, "select dev14 server");
            } else if (token.toUpperCase().startsWith("DV15")) {
                Config.CURRENT_SERVER = Server.DV15;
                Util_Log.i(LOGTAG, "select dev15 server");
            } else if (token.toUpperCase().startsWith("DV16")) {
                Config.CURRENT_SERVER = Server.DV16;
                Util_Log.i(LOGTAG, "select dev16 server");
            } else if (token.toUpperCase().startsWith("DV17")) {
                Config.CURRENT_SERVER = Server.DV17;
                Util_Log.i(LOGTAG, "select dev17 server");
            } else if (token.toUpperCase().startsWith("DV18")) {
                Config.CURRENT_SERVER = Server.DV18;
                Util_Log.i(LOGTAG, "select dev18 server");
            } else if (token.toUpperCase().startsWith("DV19")) {
                Config.CURRENT_SERVER = Server.DV19;
                Util_Log.i(LOGTAG, "select dev19 server");
            } else if (token.toUpperCase().startsWith("DV20")) {
                Config.CURRENT_SERVER = Server.DV20;
                Util_Log.i(LOGTAG, "select dev20 server");
            } else if (token.toUpperCase().startsWith("TST")) {
                Config.CURRENT_SERVER = Server.TEST;
                Util_Log.i(LOGTAG, "select test server");
            } else if (token.toUpperCase().startsWith("TS1")) {
                Config.CURRENT_SERVER = Server.TEST1;
                Util_Log.i(LOGTAG, "select test1 server");
            } else if (token.toUpperCase().startsWith("TS2")) {
                Config.CURRENT_SERVER = Server.TEST2;
                Util_Log.i(LOGTAG, "select test2 server");
            } else if (token.toUpperCase().startsWith("TS3")) {
                Config.CURRENT_SERVER = Server.TEST3;
                Util_Log.i(LOGTAG, "select test3 server");
            } else if (token.toUpperCase().startsWith("SG1")) {
                Config.CURRENT_SERVER = Server.SG1;
                Util_Log.i(LOGTAG, "select staging1 server");
            } else if (token.toUpperCase().startsWith("INT")) {
                Config.CURRENT_SERVER = Server.INT;
                Util_Log.i(LOGTAG, "select intrum server");
            } else {
                Config.CURRENT_SERVER = Server.LIVE;
                Util_Log.i(LOGTAG, "select live server");
            }
        }
    }

    public static boolean isValidEmail(CharSequence target) {
        if (TextUtils.isEmpty(target)) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }

    public static int getPhoneCountryCode(String phoneNo) {
        String country = Locale.getDefault().getCountry();
        int countrycode = 0;
        PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
        try {
            Phonenumber.PhoneNumber phonenumber = phoneNumberUtil.parse(phoneNo, country);
            countrycode = phonenumber.getCountryCode();
        } catch (NumberParseException e) {
            Util_Log.e(LOGTAG, "Parse phone number failed", e);
        }

        return countrycode;
    }

    public static String getPhoneRegionCode(String phoneNo) {
        String country = Locale.getDefault().getCountry();
        String regionCode = "";
        PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
        try {
            if (phoneNo.equals("+") || phoneNo.isEmpty()) {
                return "";
            }
            if (phoneNo.length() > 5) {
                Phonenumber.PhoneNumber phonenumber = phoneNumberUtil.parse(phoneNo, country);
                regionCode = phoneNumberUtil.getRegionCodeForNumber(phonenumber);
            } else {
                int countryCode = Integer.parseInt(phoneNo.replace("+", "").replace("\\s+", ""));
                regionCode = phoneNumberUtil.getRegionCodeForCountryCode(countryCode);
            }
        } catch (NumberParseException | NumberFormatException e) {
            Util_Log.e(LOGTAG, "Parse phone number or country code failed", e);
        }

        return regionCode;
    }

    public static boolean isPhoneValid(String phoneNo) {
        String country = Locale.getDefault().getCountry();
        if (Config.VERIFY_PHONE_NO) {
            PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
            try {
                Phonenumber.PhoneNumber phonenumber = phoneNumberUtil.parse(phoneNo, country);

                phonenumber.getCountryCode();
                return phoneNumberUtil.isValidNumber(phonenumber);
            } catch (NumberParseException e) {
                Util_Log.e(LOGTAG, "Parse phone number failed", e);
                return false;
            }
        } else {
            // remove whitespaces and special characters
            phoneNo = phoneNo.replace(" ", "");

            String expression = "^[0-9-+]{9,15}$";
            CharSequence inputStr = phoneNo;
            Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(inputStr);
            return (matcher.matches());
        }
    }

    public static String formatValidE164(String number, Locale locale) {
        PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
        String e164 = null;

        try {
            e164 = phoneNumberUtil.format(phoneNumberUtil.parse(number, Locale.getDefault().getCountry()), PhoneNumberUtil.PhoneNumberFormat.E164);
        } catch (NumberParseException e) {
            Util_Log.e(LOGTAG, "Parse phone number failed", e);
        }

        return e164;
    }

    public static Phonenumber.PhoneNumber parseValidPhoneNumber(String number, Locale locale) {
        PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
        Phonenumber.PhoneNumber phoneNumber = null;
        try {
            phoneNumber = phoneNumberUtil.parse(number, locale.getCountry());
            return phoneNumber;
        } catch (NumberParseException e) {
            Util_Log.e(LOGTAG, "Parse phone number failed", e);
            return null;
        }
    }

    /**
     * closes the keyboard, when user touches anywhere but the edittext
     *
     * @param activity
     */
    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (activity.getCurrentFocus() != null) {
            inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        }
    }

    /**
     * bug fix for notification (Android Version 4.4)
     *
     * @param context
     * @return
     */
    @TargetApi(VERSION_CODES.JELLY_BEAN)
    public static PendingIntent getNotificationPendingIntent(Context context) {
        // Creates an explicit intent for an Activity in your app
        Intent resultIntent = new Intent(context, Util_VideoStreamService.getClassForVideoLiveStreaming());

        // The stack builder object will contain an artificial back stack for the
        // started Activity.
        // This ensures that navigating backward from the Activity leads out of
        // your application to the Home screen.
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);

        // Adds the back stack for the Intent (but not the Intent itself)
        stackBuilder.addParentStack(Util_VideoStreamService.getClassForVideoLiveStreaming());

        // Adds the Intent that starts the Activity to the top of the stack
        stackBuilder.addNextIntent(resultIntent);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            return stackBuilder.getPendingIntent(0, PendingIntent.FLAG_MUTABLE);
        } else {
            return stackBuilder.getPendingIntent(0, PendingIntent.FLAG_ONE_SHOT);
        }

    }

    public static void deleteCache(Context context) {
        try {
            File dir = null;

            if (Config.VIDEO_IDENT_PLUS_REUSE_IMAGES) {
                dir = context.getFilesDir();
            } else {
                dir = context.getCacheDir();
            }


            if (dir != null && dir.isDirectory()) {
                deleteDir(dir);
            }
        } catch (Exception e) {
        }
    }

    private static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        return dir.delete();
    }

    public static void setActivityTitle(Context context) {
        // Setup the title
        if (!IDnowSDK.getNameForActionBar(context).equals("")) {
            ((Activity) context).setTitle(IDnowSDK.getNameForActionBar(context));
        }
    }

    public static void showKeyBoard(Context context, View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
    }

    public static void hideKeyBoard(Context context, View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        view.clearFocus();
        if (view.getWindowToken() != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        if (view.getRootView() != null && view.getRootView().getWindowToken() != null) {
            imm.hideSoftInputFromWindow(view.getRootView().getWindowToken(), 0);
        }
    }

    public static boolean checkNFCenabled(Context context) {
        NfcManager manager = (NfcManager) context.getSystemService(Context.NFC_SERVICE);
        NfcAdapter adapter = manager.getDefaultAdapter();
        return adapter != null && adapter.isEnabled();
    }

    public static boolean isEmptyString(String string) {
        return string == null || string.isEmpty();
    }

    public static void clearApplicationData(Context context) {
        if (context == null) {
            return;
        }
        File cacheDirectory = context.getCacheDir();
        File filesDirectory = context.getFilesDir();
        String idNowPath = "/IDnow";

        if (cacheDirectory != null) {
            File idNowCacheDirectory = new File(cacheDirectory, idNowPath);
            if (idNowCacheDirectory.exists()) {
                String[] fileNames = idNowCacheDirectory.list();
                if (fileNames != null) {
                    for (String fileName : fileNames) {
                        deleteFile(new File(idNowCacheDirectory, fileName));
                    }
                }
            }
//			File applicationCacheDirectory = new File(cacheDirectory.getParent());
//			if (applicationCacheDirectory.exists()) {
//				String[] fileNames = applicationCacheDirectory.list();
//				if(fileNames != null) {
//					for (String fileName : fileNames) {
//						if (!fileName.equals("databases") && !fileName.equals("no_backup")) {
//							deleteFile(new File(applicationCacheDirectory, fileName));
//						}
//					}
//				}
//			}
        }

        if (filesDirectory != null) {
            File idNowFilesDirectory = new File(filesDirectory, idNowPath);
            if (idNowFilesDirectory.exists()) {
                String[] fileNames = idNowFilesDirectory.list();
                if (fileNames != null) {
                    for (String fileName : fileNames) {
                        deleteFile(new File(idNowFilesDirectory, fileName));
                    }
                }
            }
//			File applicationFilesDirectory = new File(filesDirectory.getParent());
//			if (applicationFilesDirectory.exists()) {
//				String[] fileNames = applicationFilesDirectory.list();
//				if(fileNames != null) {
//					for (String fileName : fileNames) {
//						if (!fileName.equals("databases") && !fileName.equals("no_backup")) {
//							deleteFile(new File(applicationFilesDirectory, fileName));
//						}
//					}
//				}
//			}
        }
    }

    public static boolean deleteFile(File file) {
        boolean deletedAll = true;
        if (file != null) {
            if (file.isDirectory()) {
                String[] children = file.list();
                if (children != null) {
                    for (String child : children) {
                        deletedAll = deleteFile(new File(file, child)) && deletedAll;
                    }
                }
            } else {
                deletedAll = file.delete();
            }
        }
        return deletedAll;
    }

    public static void getMaskedData(Activity activity) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Models_Customer> callback = new Callback<Models_Customer>() {
            @Override
            public void success(Models_Customer resultObject, Response response) {

                if (resultObject.getMobile() != null && resultObject.getMobile().contains("***")) {
                    Config.MASKED_USER_PHONE_NO = resultObject.getMobile();
                }

                if (resultObject.getEmail() != null && resultObject.getEmail().contains("***")) {
                    Config.MASKED_EMAIL_ADDRESS = resultObject.getEmail();
                }
                if (!(activity instanceof Activities_VideoLiveStreamActivity_Super)) {
                    Intent intent = new Intent(activity, Util_VideoStreamService.getClassForVideoLiveStreaming());
                    activity.startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
                }


            }

            @Override
            public void failure(RetrofitError error) {

            }
        };

        retrofit2.Call<Models_Customer> result = service
                .getCustomer(IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        result.enqueue(callback);

    }

    public static void updateMaskedData(Callback<Object> objectCallback) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Models_Customer> callback = new Callback<Models_Customer>() {
            @Override
            public void success(Models_Customer resultObject, Response response) {
                if (resultObject.getMobile() != null && resultObject.getMobile().contains("***")) {
                    Config.MASKED_USER_PHONE_NO = resultObject.getMobile();
                }

                if (resultObject.getEmail() != null && resultObject.getEmail().contains("***")) {
                    Config.MASKED_EMAIL_ADDRESS = resultObject.getEmail();
                }
            }

            @Override
            public void failure(RetrofitError error) {

            }
        };

        retrofit2.Call<Models_Customer> result = service
                .getCustomer(IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        result.enqueue(callback);
    }
}
