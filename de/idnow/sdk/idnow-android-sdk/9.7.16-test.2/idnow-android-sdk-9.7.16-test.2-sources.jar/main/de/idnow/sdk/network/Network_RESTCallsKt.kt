package de.idnow.sdk.network

import de.idnow.sdk.models.Model_InstantSignStart
import de.idnow.sdk.models.Models_CallQualityTest
import de.idnow.sdk.models.Models_Customer
import de.idnow.sdk.models.Models_MobileNumber
import de.idnow.sdk.models.Models_NewMirrorConference
import de.idnow.sdk.models.Models_OfficeHours
import de.idnow.sdk.models.Models_PDFDocument
import de.idnow.sdk.models.Models_SdpOffer
import de.idnow.sdk.models.Models_StartObject
import de.idnow.sdk.models.Models_StartObjectResult
import de.idnow.sdk.models.Models_authenticationPossible
import de.idnow.sdk.util.RemoteAnimationsCollection
import fm.liveswitch.Candidate
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

internal interface Network_RESTCallsKt {
    @GET("/assets/messages.json")
    suspend fun getMessages(
        @Query("shortName") companyShort: String,
        @Query("prefLang") language: String
    ): Response<Map<String, String>>

    @GET("/api/v1/{transactionToken}/animations")
    suspend fun getLottieAnimations(
        @Path("transactionToken") companyShort: String
    ): Response<RemoteAnimationsCollection>

    @GET("/api/v1/{transactionToken}")
    suspend fun getCompanyShortname(
        @Path("transactionToken") companyShort: String
    ): Response<Models_OfficeHours>

    @GET("/api/v1/{companyShort}/identifications/{transactionToken}")
    suspend fun getCustomer(
        @Path("transactionToken") transactionToken: String,
        @Path("companyShort") companyShort: String
    ): Response<Models_Customer>

    // Live version:
    @GET("/api/v1/{companyShort}/identifications/{transactionToken}/documents")
    suspend fun getDocuments(
        @Path("companyShort") companyShort: String,
        @Path("transactionToken") transactionToken: String
    ): Response<Array<Models_PDFDocument>>

    @POST("/api/v1/{companyShort}/identifications/{transactionToken}/start")
    suspend fun start(
        @Body startObject: Models_StartObject,
        @Path("companyShort") companyShort: String,
        @Path("transactionToken") transactionToken: String
    ): Response<Models_StartObjectResult>

    @POST("/api/v1/{companyShort}/trustedOriginalData/{transactionToken}/start")
    suspend fun startInstantSign(
        @Body startObject: Models_StartObject,
        @Path("companyShort") companyShort: String,
        @Path("transactionToken") transactionToken: String
    ): Response<Model_InstantSignStart>

    @GET("/api/v1/{companyShort}/identifications/{transactionToken}/authenticationPossible")
    suspend fun authenticationPossible(
        @Path("companyShort") companyShort: String,
        @Path("transactionToken") transactionToken: String
    ): Response<Models_authenticationPossible>

    @POST("/api/v1/{companyShort}/identifications/{transactionToken}/updateMobileNumber")
    suspend fun updateMobileNumber(
        @Body number: Models_MobileNumber,
        @Path("companyShort") companyShort: String,
        @Path("transactionToken") transactionToken: String
    ): Response<Models_MobileNumber>

    @POST("/api/v1/{companyToken}/identifications/{transactionToken}/startCallQualityTest")
    suspend fun startCallQualityTest(
        @Body mirrorConference: Models_NewMirrorConference,
        @Path("companyToken") companyToken: String,
        @Path("transactionToken") transactionToken: String
    ): Response<Models_CallQualityTest>

    @POST("/api/v1/{companyToken}/identifications/{transactionToken}/stopCallQualityTest")
    suspend fun stopCallQualityTest(
        @Body mirrorConference: Models_NewMirrorConference,
        @Path("companyToken") shortname: String,
        @Path("transactionToken") token: String
    ): Response<Boolean>

    @POST("/api/v1/conferences/{sessionId}/USER/{agentToken}/sendSdpOffer")
    suspend fun sendSdpOffer(
        @Body sdpOffer: Models_SdpOffer,
        @Path("sessionId") sessionId: String,
        @Path("agentToken") agentToken: String
    ): Response<Models_SdpOffer>

    @POST("/api/v1/conferences/{conferenceID}/{peerType}/{peerID}/sendCandidate")
    suspend fun sendCandidate(
        @Body candidate: Candidate,
        @Path("conferenceID") conferenceID: String,
        @Path("peerType") peerType: String,
        @Path("peerID") peerID: String
    ): Response<String>
}