package de.idnow.sdk.models

import fm.liveswitch.SessionDescription
import fm.liveswitch.SessionDescriptionType
import fm.liveswitch.sdp.Message


data class Models_SdpOffer(
    val sdpMessage: String,
    val isOffer: Boolean,
    val tieBreaker: String
)

fun Models_SdpOffer?.toSessionDescription(): SessionDescription {
    return SessionDescription().apply {
        type = if (this@toSessionDescription?.isOffer == true) {
            SessionDescriptionType.Offer
        } else {
            SessionDescriptionType.Answer
        }
        sdpMessage = Message.parse(this@toSessionDescription?.sdpMessage)
        tieBreaker = this@toSessionDescription?.tieBreaker
    }
}