package de.idnow.sdk.network

import de.idnow.sdk.util.Util_Log
import de.idnow.sdk.util.Util_UtilRetrofit
import retrofit2.Response


fun <T> Response<T>.logError(tag: String, context: String) {
    val retrofitError = RetrofitError.from(this)
    var result = Util_UtilRetrofit.printRetrofitError(retrofitError)
    Util_Log.i(tag, "$context: HTTP ${code()} — $result")
    if (result.isNotEmpty()) {
        result = Util_UtilRetrofit.getErrorIdRetrofit(result)
        Util_Log.i(tag, result)
    }
}

fun Response<*>.logError(tag: String, context: String, body: String) {
    Util_Log.i(tag, "$context: HTTP ${code()} — $body")
    val errorId = Util_UtilRetrofit.getErrorIdRetrofit(body)
    if (errorId.isNotEmpty()) {
        Util_Log.i(tag, errorId)
    }
}

fun Throwable.logError(tag: String, context: String) {
    val retrofitError = RetrofitError.from(this)
    var result = Util_UtilRetrofit.printRetrofitError(retrofitError)
    Util_Log.i(tag, "$context: ${retrofitError.message}")
    Util_Log.i(tag, "Result: $result")
    if (result.isNotEmpty()) {
        result = Util_UtilRetrofit.getErrorIdRetrofit(result)
        Util_Log.i(tag, result)
    }
}
