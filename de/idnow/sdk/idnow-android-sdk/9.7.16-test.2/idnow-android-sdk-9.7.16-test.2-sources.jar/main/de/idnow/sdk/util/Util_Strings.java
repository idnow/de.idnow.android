package de.idnow.sdk.util;


import android.content.Context;
import android.text.TextUtils;
import android.util.SparseArray;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;

@SuppressWarnings("WeakerAccess")
public class Util_Strings {

    public static final String KEY_EID_CHOOSER_PAGE_TITLE = "js.mobile.eid.chooser.page.title";
    public static final String KEY_EID_CHOOSER_PAGE_VID_TITLE = "js.mobile.eid.chooser.page.vid.title";
    public static final String KEY_EID_CHOOSER_PAGE_VID_DESC = "js.mobile.eid.chooser.page.vid.description";
    public static final String KEY_EID_CHOOSER_PAGE_EID_TITLE = "js.mobile.eid.chooser.page.eid.title";
    public static final String KEY_EID_CHOOSER_PAGE_EID_DESC = "js.mobile.eid.chooser.page.eid.description";

    public static final @StringRes int LOCAL_EID_CHOOSER_PAGE_TITLE = R.string.title_text_chooser_page;
    public static final @StringRes int LOCAL_EID_CHOOSER_PAGE_VID_TITLE = R.string.vi_title_text_chooser_page;
    public static final @StringRes int LOCAL_EID_CHOOSER_PAGE_VID_DESC = R.string.vi_desc_text_chooser_page;
    public static final @StringRes int LOCAL_EID_CHOOSER_PAGE_EID_TITLE = R.string.eid_title_text_chooser_page;
    public static final @StringRes int LOCAL_EID_CHOOSER_PAGE_EID_DESC = R.string.eid_desc_text_chooser_page;

    public static final String KEY_EID_NFC_REQUIRED_TITLE = "js.mobile.eid.nfc.required.title";
    public static final String KEY_EID_NFC_REQUIRED_MESSAGE = "js.mobile.eid.nfc.required.message";
    public static final String KEY_EID_NFC_REQUIRED_BUTTON_NEXT = "js.mobile.eid.nfc.required.button.text";
    public static final @StringRes int LOCAL_EID_NFC_REQUIRED_TITLE = R.string.nfc_required_title;
    public static final @StringRes int LOCAL_EID_NFC_REQUIRED_MESSAGE = R.string.nfc_required_message;
    public static final @StringRes int LOCAL_EID_NFC_REQUIRED_BUTTON_NEXT = R.string.nfc_required_button_text;


    static final String KEY_IDENTCODE_RECEIVED_DESCRIPTION = "js.mobile.identcode.received.description";
    public static final String KEY_ESIGN_FORWARDING_CONTINUE = "js.mobile.esign.forwarding.continue";
    public static final String KEY_ESIGN_FORWARDING_HEADLINE = "js.mobile.esign.forwarding.headline";
    public static final String KEY_ESIGN_FORWARDING_BODY = "js.mobile.esign.forwarding.body";
    public static final String KEY_DOCUSIGN_TOKEN_EXPIRING_SOON = "";
    public static final String KEY_LINK_PRIVACY_POLICY = "js.link.privacy.mobile";
    public static final String KEY_LABEL_PRIVACY_POLICY = "js.link.privacy.label.mobile";
    public static final String KEY_LINK_TERMS_OF_USE = "js.link.terms.mobile";
    public static final String KEY_LABEL_TERMS_OF_USE = "js.link.terms.label.mobile";
    public static final String KEY_LABEL_TERMS = "js.mobile.checkscreen.termsText";
    public static final String KEY_LABEL_PHONE_VALIDATION_CORRECTED = "js.mobile.phone.validation.corrected";
    public static final String KEY_LABEL_PHONE_VALIDATION_ERROR = "js.mobile.phone.validation.error";
    public static final String KEY_LABEL_WAITING_FOR_AGENT = "js.mobile.connecting";
    public static final String KEY_PLATFORM_WRONG_SDK = "js.idnow.platform.wrongSDK.content";

    public static final String KEY_VIDEOIDENT_HELPDATA_TEXT = "js.mobile.videoident.helpdata.text";
    static final String KEY_VIDEOIDENT_STEP_BACK = "js.mobile.videoident.step.back";
    static final String KEY_VIDEOIDENT_STEP_FRONT = "js.mobile.videoident.step.front";
    static final String KEY_VIDEOIDENT_READ_NO = "js.mobile.videoident.step.read.no";
    static final String KEY_VIDEOIDENT_STEP_BACK_TITLE = "js.mobile.videoident.step.back.title";
    static final String KEY_VIDEOIDENT_STEP_FRONT_TITLE = "js.mobile.videoident.step.front.title";

    static final @StringRes int LOCAL_IDENTCODE_RECEIVED_DESCRIPTION = R.string.insert_tan_hint;
    public static final @StringRes int LOCAL_ESIGN_FORWARDING_CONTINUE = R.string.first_step_next;
    public static final @StringRes int LOCAL_ESIGN_FORWARDING_HEADLINE = R.string.first_step_next;
    public static final @StringRes int LOCAL_ESIGN_FORWARDING_BODY = R.string.e_signature_user_consent_body;
    public static final @StringRes int LOCAL_DOCUSIGN_TOKEN_EXPIRING_SOON = R.string.docusign_token_expiring_soon;
    static final @StringRes int LOCAL_ESIGN_DOCUMENT_NOT_DOWNLOADED = R.string.force_document_download;
    public static final @StringRes int LOCAL_LINK_PRIVACY_POLICY = R.string.second_step_privacy_policy_url;
    public static final @StringRes int LOCAL_LABEL_PRIVACY_POLICY = R.string.second_step_privacy_policy;
    public static final @StringRes int LOCAL_LINK_TERMS_OF_USE = R.string.second_step_terms_of_use_url;
    public static final @StringRes int LOCAL_LABEL_TERMS_OF_USE = R.string.second_step_terms_of_use;
    public static final @StringRes int LOCAL_LABEL_TERMS = R.string.second_step_approval_text;
    public static final @StringRes int LOCAL_LABEL_PHONE_VALIDATION_CORRECTED = R.string.phone_no_validation_corrected;
    public static final @StringRes int LOCAL_LABEL_PHONE_VALIDATION_ERROR = R.string.phone_no_validation_error;
    public static final @StringRes int LOCAL_LABEL_WAITING_FOR_AGENT = R.string.step_start;

    public static final @StringRes int LOCAL_VIDEOIDENT_HELPDATA_TEXT = R.string.activity_id_data_text;
    static final @StringRes int LOCAL_VIDEOIDENT_STEP_BACK = R.string.step_id_back;
    static final @StringRes int LOCAL_VIDEOIDENT_STEP_FRONT = R.string.step_id_front;
    static final @StringRes int LOCAL_VIDEOIDENT_READ_NO = R.string.step_id_read_no;
    static final @StringRes int LOCAL_VIDEOIDENT_STEP_BACK_TITLE = R.string.step_title_id_back;
    static final @StringRes int LOCAL_VIDEOIDENT_STEP_FRONT_TITLE = R.string.step_title_id_front;

    public static final String LOGTAG = "IDNOW_Util_Strings";
    public static final String KEY_ERROR = "errorType";
    public static final String TRANSLATION_KEY = "translationKey";
    public static final String ERROR_TYPE_DOCUMENT_NOT_DOWNLOADED = "DOCUMENT_NOT_DOWNLOADED";
    public static final String DOCUSIGN_TOKEN_EXPIRING_SOON = "DOCUSIGN_TOKEN_EXPIRING_SOON";
    public static final String ERRORS_ARRAY = "errors";
    public static final String LOGIN_PASSWORD_JSON_KEY = "password";
    public static final String LOGIN_MOBILE_JSON_KEY = "mobile";
    public static final String LOGIN_PASSWORD = "password";
    public static final String LOGIN_PASSWORD_CONFIRMED_PASSWORD = "confirmedPassword";
    public static final String LOGIN_CONTENT_TYPE = "application/json; charset=utf-8";

    ////Account Registration
    public static final String KEY_ACCOUNTINFO_INSTRCUTION = "js.signing.accountInformation.instruction";
    public static final String KEY_ACCOUNTINFO_HEADLINE = "js.signing.accountInformation.headline";
    public static final String KEY_ACCOUNTINFO_HINT = "js.signing.accountInformation.hint";
    public static final String KEY_ACCOUNTINFO_HELP_EMAIL = "js.signing.accountInformation.help.email";
    public static final String KEY_ACCOUNTINFO_HELP_PHONE = "js.signing.accountInformation.help.phone";
    public static final String KEY_ACCOUNTINFO_NO_REGISTRATION_LINK = "js.signing.accountInformation.noRegistration.link";

    static final String KEY_ACCOUNTINFO_INSTRUTION_NO_ACCOUNT = "js.signing.accountInformation.instruction.noaccount";
    public static final String KEY_ACCOUNTINFO_CREATE_ACCOUNT_LINK = "js.signing.accountInformation.createAccount.link";
    static final String KEY_ACCOUNTINFO_HINT_NO_REGISTRATION_PHONE_NUM = "js.signing.accountInformation.hint.noRegistration.phonenumber";
    static final String KEY_ACCOUNTINFO_INSTRUCTION_HEADLINE_NO_ACCOUNT = "js.signing.accountInformation.instruction.headline.noaccount";
    static final String KEY_ACCOUNTINFO_INSTRUCTION_HEADLINE = "js.signing.accountInformation.instruction.headline";

    // Complete Signing with Phone number
    public static final String KEY_ACCOUNTINFO_HINT_NO_REGISTRATION = "js.signing.accountInformation.hint.noRegistration";
    public static final String KEY_ACCOUNTFORGOT_HEADLINE = "js.signing.accountForgot.headline";
    public static final String KEY_CONFIRMATION_TOKEN_WRONG_OTP_CODE = "js.signing.native.consentProtocol.confirmationToken.wrongOtpCode";

    // Forgot Password
    public static final String KEY_FORGOT_PASSWORD_HEADLINE = "js.signing.accountForgot.headline";
    public static final String KEY_FORGOT_PASSWORD_INSTRUCTION = "js.signing.accountForgot.instruction";
    public static final String KEY_FORGOT_PASSWORD_CONT_IDENT = "js.signing.accountForgot.btn.continueWithIdentification";

    // Save Passowrd
    public static final String KEY_SIGNING_ABORT = "js.signing.abort";
    public static final String KEY_SIGNIN_CONTINUE = "js.signing.continue";
    public static final String KEY_SELECTPASSWORD_HEADLINE = "js.signing.selectPassword.headline";
    public static final String KEY_SELECTPASSWORD_HINT_HTML = "js.signing.selectPassword.hint.html";
    public static final String KEY_SELECTPASSWORD_VALIDATION_SELECT_PASSWORD_INSTRUCTION = "js.signing.selectPassword.instruction";
    public static final String KEY_SELECTPASSWORD_HELP_PASSWORD_CONF = "js.signing.selectPassword.help.passwordConfirmation";
    public static final String KEY_SELECTPASSWORD_HELP_PASSWORD = "js.signing.selectPassword.help.password";

    static final String KEY_SELECTPASSWORD_INSTRUCTION_HEADLINE = "js.signing.selectPassword.instruction.headline";

    ////Account Login
    public static final String KEY_ACCOUNT_LOGIN_HEADLINE = "js.signing.accountLogin.headline";
    public static final String KEY_ACCOUNT_LOGIN_CANTREM_LINK = "js.signing.accountLogin.cantRemember.link";
    public static final String KEY_ACCOUNT_LOGIN_HINT = "js.signing.accountLogin.hint";
    public static final String KEY_ACCOUNT_LOGIN_INSTRUCTION = "js.signing.accountLogin.instruction";
    public static final String KEY_ACCOUNT_LOGIN_HELP_PASSWORD = "js.signing.accountLogin.help.password";
    public static final String KEY_ACCOUNT_LOGIN_HELP_EMAIL = "js.signing.accountLogin.help.email";
    static final String KEY_ACCOUNT_LOGIN_INSTRUCTION_HEADLINE = "js.signing.accountLogin.instruction.headline";
    static final String KEY_ACCOUNT_LOGIN_ACTION_LOGIN = "js.signing.accountLogin.action.login";

    //Update phone number
    static final String KEY_SIGNING_UPDATE_PHONE_NUMBER_HEADLINE = "js.signing.mobilenumber.headline";
    static final String KEY_SIGNING_UPDATE_PHONE_NUMBER_INSTRUCTIONS = "js.signing.mobilenumber.instructions";

    // Decline Signing
    static final String KEY_ACCOUNT_DECLINE_SIGNING = "js.signing.sure-to-decline";
    static final String KEY_ACCOUNT_TITLE_SIGNING = "js.signing.sure-to-decline.title";
    static final @StringRes int LOCAL_KEY_ACCOUNT_TITLE_SIGNING = R.string.are_you_sure;
    static final @StringRes int LOCAL_KEY_ACCOUNT_DECLINE_SIGNING = R.string.are_you_sure_decline;


    /// Keys Account
    public static final String KEY_ACCOUNT_REGISTER = "REGISTER";
    public static final String KEY_ACCOUNT_LOGIN = "LOGIN";
    public static final String KEY_ACCOUNT_PASSWORD = "PASSWORD";
    public static final String KEY_ACCOUNT_UPDATE = "UPDATE";
    public static final String KEY_ACCOUNT_NOT_REM_PASSWORD = "NOT_REM_PASSWORD";
    static final String KEY_UPDATE_PHONE_NUMBER = "UPDATE_PHONE_NUMBER";

    // Error Failed messages

    public static final String KEY_ERROR_ACCOUNT_LOGIN_FAILED = "js.signing.accountLogin.failed";
    public static final String KEY_ERROR_ACCOUNT_REGISTER_FAILED = "js.signing.accountInformation.alreadyExists";
    public static final String KEY_ERROR_EMAIL_FORMAT = "js.signing.email.format";
    public static final String KEY_ERROR_MOBILENUMBER_FORMAT = "js.signing.mobilenumber.format";
    public static final String KEY_ERROR_EMAIL_PRESENCE = "js.signing.email.presence";
    public static final String KEY_ERROR_MOBILENUMBER_PRESENCE = "js.signing.mobilenumber.presence";
    public static final String KEY_ERROR_PASSWORD_PRESENCE = "js.signing.password.presence";
    public static final String KEY_ERROR_PASSWORD_VALIDATION = "js.signing.selectPassword.validation.password";
    public static final String KEY_ERROR_CONFIRMED_PASSWORD = "js.signing.selectPassword.validation.confirmedPassword";

    // preparing signing

    public static final String KEY_SIGNING_PREPARING_HEADLINE = "js.signing.preparing.headline";
    public static final String KEY_SIGNING_PREPARING_DESCRIPTION = "js.signing.preparing.instructions";

    public static final String GOOGLE_RATING_URL = "https://www.google.com/search?q=idnow&oq=idnow#lkt=LocalPoiReviews&lrd=0x479e75ed1eb9554f:0x214d16243cac880,3,,,&trex=m_t:lcl_akp,rc_f:nav,rc_ludocids:149974907584432256,rc_q:IDnow,ru_q:IDnow";

    // Waiting Screen

    public static final String KEY_WAITING_SCREEN_AGENT_CONNECTING = "js.mobile.waitingscreen.title.agent-connecting";
    public static final String KEY_WAITING_SCREEN_IDENT_DOCUMENT_MSG = "js.mobile.waitingscreen.msg.document";
    public static final String KEY_WAITING_SCREEN_VERIFY_MSG = "js.mobile.waitingscreen.msg.verify-info";
    public static final String KEY_WAITING_SCREEN_SELFIE_MSG = "js.mobile.waitingscreen.msg.selfie";
    public static final String KEY_CONFIRMATION_ATTEMPTS_EXCEEDED = "js.ident-code.error.confirmation.attemps.exceeded";
    public static final String KEY_WAITING_SCREEN_AGENT_BUSY = "js.mobile.waitingscreen.title.agent-busy";
    public static final String KEY_WAITING_SCREEN_SMS_TITLE = "js.mobile.waitingscreen.title.waiting-list";
    public static final String KEY_WAITING_SCREEN_WAITING_LIST_CONFIRM = "js.mobile.waitingscreen.title.waiting-list-confirm";
    public static final String KEY_WAITING_SCREEN_MSG_WISH_NOTIFIED = "js.mobile.waitingscreen.msg.wish-notified";
    public static final String KEY_WAITING_SCREEN_WAITING_LIST_DESC = "js.waitingList.success";
    public static final String KEY_WAITING_SCREEN_MSG_WAITING_LIST_PUSH = "js.mobile.waitingscreen.msg.waiting-list-push";
    public static final String KEY_WAITING_SCREEN_MSG_WAITING_LIST_SMS = "js.mobile.waitingscreen.msg.waiting-list-sms";
    public static final String KEY_WAITING_SCREEN_ACTION_NO_WAIT = "js.mobile.waitingscreen.action.no-wait";
    public static final String KEY_WAITING_SCREEN_OK_WAIT = "js.mobile.waitingscreen.action.ok-wait";
    public static final String KEY_WAITNG_SCREEN_ACTION_NOTIFY_SMS = "js.mobile.waitingscreen.action.notify-sms";
    public static final String KEY_WAITING_SCREEN_ACTION_ENROLL = "js.mobile.waitingscreen.action.enroll";

    public static final String KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION = "js.mobile.customised.waiting.screen.instruction";
    public static final String KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION1 = "js.mobile.customised.waiting.screen.instruction1";
    public static final String KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION2 = "js.mobile.customised.waiting.screen.instruction2";
    public static final String KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION3 = "js.mobile.customised.waiting.screen.instruction3";
    public static final String KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION4 = "js.mobile.customised.waiting.screen.instruction4";
    public static final String KEY_CUSTOMISED_WAITING_SCREEN_APOLOGIES = "js.mobile.customised.waiting.screen.apologies";

    public static final String KEY_CUSTOMISED_WAITING_SCREEN_ACTION1 = "js.mobile.customised.waiting.screen.action1";
    public static final String KEY_CUSTOMISED_WAITING_SCREEN_ACTION2 = "js.mobile.customised.waiting.screen.action2";
    public static final String KEY_CUSTOMISED_WAITING_SCREEN_POPUP_TITLE = "js.mobile.customised.waiting.screen.popup.title";
    public static final String KEY_CUSTOMISED_WAITING_SCREEN_POPUP_DESC = "js.mobile.customised.waiting.screen.popup.desc";
    public static final String KEY_CUSTOMISED_WAITING_SCREEN_POPUP_WAIT = "js.mobile.customised.waiting.screen.popup.wait";
    public static final String KEY_CUSTOMISED_WAITING_SCREEN_POPUP_QUIT = "js.mobile.customised.waiting.screen.popup.quit";


    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION = R.string.connecting_with_an_ident_specialist;
    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION1 = R.string.waiting_screen_headline;
    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION2 = R.string.waiting_screen_desc;
    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION3 = R.string.dont_leave;
    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_APOLOGIES = R.string.apologies;
    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION4 = R.string.keep_id;

    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_ACTION1 = R.string.keep_waiting;
    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_ACTION2 = R.string.come_back_later;
    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_POPUP_TITLE = R.string.waiting_screen_popup_title;
    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_POPUP_DESC = R.string.waiting_screen_popup_desc;
    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_POPUP_WAIT = R.string.waiting_screen_popup_yes;
    public static final @StringRes int LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_POPUP_QUIT = R.string.waiting_screen_popup_no;


    // High Volume Calls

    public static final String KEY_HIGHVOLUME_IMAGE_DESC = "js.mobile.highvolume.image.desc";
    public static final String KEY_HIGHVOLUME_TITLE = "js.mobile.highvolume.title";
    public static final String KEY_HIGHVOLUME_MESSAGE_ = "js.mobile.highvolume.message";
    public static final String KEY_HIGHVOLUME_TRYLATER = "js.mobile.highvolume.button.trylater";
    public static final String KEY_HIGHVOLUME_CONTINUE = "js.mobile.highvolume.button.continue";

    public static final @StringRes int LOCAL_KEY_HIGHVOLUME_IMAGE_DESC = R.string.high_call_volume_image_desc;
    public static final @StringRes int LOCAL_KEY_HIGHVOLUME_TITLE = R.string.high_call_volume_title;
    public static final @StringRes int LOCAL_KEY_HIGHVOLUME_MESSAGE = R.string.high_call_volume_message;
    public static final @StringRes int LOCAL_KEY_HIGHVOLUME_TRYLATER = R.string.high_call_volume_trylater;
    public static final @StringRes int LOCAL_KEY_HIGHVOLUME_CONTINUE = R.string.high_call_volume_continue;

    // Waiting Screen local

    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_AGENT_CONNECTING = R.string.waiting_screen_title;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_IDENT_DOCUMENT_MSG = R.string.waiting_screen1_description;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_VERIFY_MSG = R.string.waiting_screen2_description;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_SELFIE_MSG = R.string.waiting_screen3_description;
    public static final @StringRes int LOCAL_KEY_CONFIRMATION_ATTEMPTS_EXCEEDED = R.string.insert_tan_attempts_exceeded;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_AGENT_BUSY = R.string.waiting_screen4_description;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_SMS_TITLE = R.string.waiting_screen_title_waiting_list;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_WAITING_LIST_CONFIRM = R.string.waiting_screen_title_waiting_list_confirm;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_MSG_WISH_NOTIFIED = R.string.waiting_screen_msg_wish_notified;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_WAITING_LIST_DESC = R.string.waiting_list_description;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_MSG_WAITING_LIST_PUSH = R.string.waiting_screen_msg_waiting_list_push;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_MSG_WAITING_LIST_SMS = R.string.waiting_screen_msg_waiting_list_sms;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_ACTION_NO_WAIT = R.string.waiting_screen_action_no_wait;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_OK_WAIT = R.string.waiting_screen_action_ok_wait;
    public static final @StringRes int LOCAL_KEY_WAITNG_SCREEN_ACTION_NOTIFY_SMS = R.string.waiting_screen_action_notify_sms;
    public static final @StringRes int LOCAL_KEY_WAITING_SCREEN_ACTION_ENROLL = R.string.waiting_screen_action_enroll;

    // Remaining attempts for token retry
    public static final String KEY_USER_FEEDBACK_UNBLOCKED_TITLE = "js.mobile.userfeedback.unblocked.title";
    public static final String KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE = "js.mobile.userfeedback.unblocked.message";
    public static final String KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN = "js.mobile.userfeedback.unblocked.try.again";
    public static final String KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER = "js.mobile.userfeedback.unblocked.try.later";
    public static final String KEY_USER_FEEDBACK_BLOCKED_TITLE = "js.mobile.userfeedback.blocked.title";
    public static final String KEY_USER_FEEDBACK_BLOCKED_MESSAGE = "js.mobile.userfeedback.blocked.message";
    public static final String KEY_USER_FEEDBACK_BLOCKED_FINISH = "js.mobile.userfeedback.blocked.finish";
    public static final String KEY_USER_FEEDBACK_BLOCKED_ERROR_MESSAGE = "js.mobile.userfeedback.blocked.error.message";

    // Remaining attempts for token retry local
    public static final @StringRes int LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TITLE = R.string.userfeedback_unblocked_title;
    public static final @StringRes int LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE = R.string.userfeedback_unblocked_message;
    public static final @StringRes int LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN = R.string.userfeedback_unblocked_try_again;
    public static final @StringRes int LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER = R.string.userfeedback_unblocked_try_later;
    public static final @StringRes int LOCAL_KEY_USER_FEEDBACK_BLOCKED_TITLE = R.string.userfeedback_blocked_title;
    public static final @StringRes int LOCAL_KEY_USER_FEEDBACK_BLOCKED_MESSAGE = R.string.userfeedback_blocked_message;
    public static final @StringRes int LOCAL_KEY_USER_FEEDBACK_BLOCKED_FINISH = R.string.userfeedback_blocked_finish;
    public static final @StringRes int LOCAL_KEY_USER_FEEDBACK_BLOCKED_ERROR_MESSAGE = R.string.userfeedback_blocked_error_message;
    public static final @StringRes int LOCAL_KEY_CONFIRMATION_TOKEN_WRONG_OTP_CODE = R.string.confirmation_token_wrong_otp_code;


    // Video Ident Plus
    public static final String KEY_VIDEO_IDENT_PLUS_TERMS = "js.mobile.videoidentplus.terms";
    public static final String KEY_VIDEO_IDENT_PLUS_CONSENT = "js.mobile.videoidentplus.consent";
    public static final String KEY_VIDEO_IDENT_PLUS_CONTINUE = "js.mobile.videoidentplus.continue";
    public static final String KEY_VIDEO_IDENT_PLUS_CQC_DESC = "js.mobile.videoidentplus.cqc.desc";
    public static final String KEY_VIDEO_IDENT_PLUS_CQC_OTHER_STATUS = "js.mobile.videoidentplus.cqc.status";
    public static final String KEY_VIDEO_IDENT_PLUS_CQC_MODERATE = "js.mobile.videoidentplus.cqc.moderate";
    public static final String KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE = "js.mobile.videoidentplus.cqc.bad.title";
    public static final String KEY_VIDEO_IDENT_PLUS_CQC_BAD = "js.mobile.videoidentplus.cqc.bad";
    public static final String KEY_VIDEO_IDENT_CQC_MODERATE_1 = "js.mobile.videoidentplus.cqc.moderate.1";
    public static final String KEY_VIDEO_IDENT_CQC_MODERATE_2 = "js.mobile.videoidentplus.cqc.moderate.2";
    public static final String KEY_VIDEO_IDENT_CQC_MODERATE_3 = "js.mobile.videoidentplus.cqc.moderate.3";
    public static final String KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON = "js.mobile.videoidentplus.cqc.moderate.button";
    public static final String KEY_VIDEO_IDENT_PLUS_CQC_BAD_1 = "js.mobile.videoidentplus.cqc.bad.1";
    public static final String KEY_VIDEO_IDENT_PLUS_CQC_BAD_2 = "js.mobile.videoidentplus.cqc.bad.2";
    public static final String KEY_CQC_ACTIVE_TITLE = "js.precheck.mobile.active.title";
    public static final String KEY_CQC_ACTIVE_NETWORK = "js.precheck.mobile.active.network";
    public static final String KEY_CQC_ACTIVE_AUDIO = "js.precheck.mobile.active.audio";
    public static final String KEY_CQC_ACTIVE_VIDEO = "js.precheck.mobile.active.video";
    public static final String KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON = "js.precheck.web.result.button.retest";
    public static final String KEY_VIDEO_IDENT_PLUS_CQC_BEFORE_STARTING = "js.mobile.videoidentplus.before.starting.title";
    public static final String KEY_VIDEO_IDENT_PLUS_BEFORE_1 = "js.mobile.videoidentplus.before.1";
    public static final String KEY_VIDEO_IDENT_PLUS_BEFORE_2 = "js.mobile.videoidentplus.before.2";
    public static final String KEY_VIDEO_IDENT_PLUS_BEFORE_3 = "js.mobile.videoidentplus.before.3";
    public static final String KEY_VIDEO_IDENT_PLUS_BEFORE_BUTTON = "js.mobile.videoidentplus.before.button";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_TITLE = "js.mobile.videoidentplus.take.front.title";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_BACK_TITLE = "js.mobile.videoidentplus.take.back.title";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_BACK_DESC = "js.mobile.videoidentplus.take.back.desc";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_DESC = "js.mobile.videoidentplus.take.front.desc";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_IMAGE_DESC = "js.mobile.videoidentplus.take.image.desc";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_IMAGE_RETAKE = "js.mobile.videoidentplus.take.image.retake.id";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_IMAGE_CONTINUE = "js.mobile.videoidentplus.take.image.continue";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_TITLE = "js.mobile.videoidentplus.take.selfie.title";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_DESC1 = "js.mobile.videoidentplus.take.selfie.desc.1";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_DESC2 = "js.mobile.videoidentplus.take.selfie.desc.2";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE = "js.mobile.videoidentplus.take.agent.title";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC1 = "js.mobile.videoidentplus.take.agent.desc.1";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC2 = "js.mobile.videoidentplus.take.agent.desc.2";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC3 = "js.mobile.videoidentplus.take.agent.desc.3";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC4 = "js.mobile.videoidentplus.take.agent.desc.4";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC4_EMAIL = "js.mobile.videoidentplus.take.agent.desc.4.email";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC5 = "js.mobile.videoidentplus.take.agent.desc.5";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC5_EMAIL = "js.mobile.videoidentplus.take.agent.desc.5.email";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC6 = "js.mobile.videoidentplus.take.agent.desc.6";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_TITLE = "js.mobile.videoidentplus.take.agent.waiting.title";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC1 = "js.mobile.videoidentplus.take.agent.waiting.desc.1";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC2 = "js.mobile.videoidentplus.take.agent.waiting.desc.2";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC3 = "js.mobile.videoidentplus.take.agent.waiting.desc.3";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC4 = "js.mobile.videoidentplus.take.agent.waiting.desc.4";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_BUTTON = "js.mobile.videoidentplus.take.agent.waiting.button";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_CANCEL = "js.mobile.videoidentplus.take.agent.waiting.cancel";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_NO = "js.mobile.videoidentplus.take.agent.waiting.no";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_BUTTON_RESEND = "js.mobile.videoidentplus.take.agent.button.resend";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_BUTTON_CONFIRM = "js.mobile.videoidentplus.take.agent.button.confirm";
    public static final String KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_BUTTON_REQUEST = "js.mobile.videoidentplus.take.agent.button.request";
    public static final String KEY_VIDEO_IDENT_PLUS_MESSAGE_SUCCESS = "js.mobile.videoidentplus.message.success";
    public static final String KEY_VIDEO_IDENT_PLUS_MESSAGE_FAILURE = "js.mobile.videoidentplus.message.failure";
    public static final String KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_TITLE = "js.mobile.videoidentplus.classification.title";
    public static final String KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_IDSELECTION = "js.mobile.videoidentplus.classification.idselection";
    public static final String KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_SEARCH = "js.mobile.videoidentplus.classification.search";
    public static final String KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_DOCUMENT = "js.mobile.videoidentplus.classification.document";
    public static final String KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_NOT_LISTED = "js.mobile.videoidentplus.not.listed";
    public static final String KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_LISTED_TITLE = "js.mobile.videoidentplus.country.not.listed.title";
    public static final String KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_LISTED_DESC = "js.mobile.videoidentplus.country.not.listed.desc";
    public static final String KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_BUTTON = "js.mobile.videoidentplus.country.not.button";
    public static final String KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_TITLE = "js.mobile.videoidentplus.somehting.wrong.title";
    public static final String KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_DESC = "js.mobile.videoidentplus.somehting.wrong.desc";
    public static final String KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_BUTTON = "js.mobile.videoidentplus.somehting.wrong.button";
    public static final String KEY_VIDEO_IDENT_AGENT_COMPLETE = "js.mobile.eid.complete.title";
    public static final String KEY_VERIFICATION_TITLTE = "js.mobile.name.verification.title";
    public static final String KEY_VERIFICATION_DESCRIPTION = "js.mobile.name.verification.description";
    public static final String KEY_VERIFICATION_NAME = "js.mobile.name.verification.name";
    public static final String KEY_VERIFICATION_CONTINUE = "js.mobile.name.verification.continue.button";
    public static final String KEY_VERIFICATION_INCORRECT = "js.mobile.name.verification.details.incorrect";
    public static final String KEY_VERIFICATION_ALERT_TITLE = "js.mobile.name.verification.alert.title";
    public static final String KEY_VERIFICATION_ALERT_MESSSAGE = "js.mobile.name.verification.alert.message";
    public static final String KEY_VERIFICATION_ALERT_DISMISS = "js.mobile.name.verification.alert.dismiss";
    public static final String KEY_VERIFICATION_ALERT_QUIT = "js.mobile.name.verification.alert.quit";

    public static final @StringRes int LOCAL_KEY_VERIFICATION_TITLTE = R.string.verification_title;
    public static final @StringRes int LOCAL_KEY_VERIFICATION_DESCRIPTION = R.string.verification_description;
    public static final @StringRes int LOCAL_KEY_VERIFICATION_NAME = R.string.verification_name;
    public static final @StringRes int LOCAL_KEY_VERIFICATION_CONTINUE = R.string.verification_continue_button;
    public static final @StringRes int LOCAL_KEY_VERIFICATION_INCORRECT = R.string.verification_details;
    public static final @StringRes int LOCAL_KEY_VERIFICATION_ALERT_TITLE = R.string.verification_alert_title;
    public static final @StringRes int LOCAL_KEY_VERIFICATION_ALERT_MESSSAGE = R.string.verification_alert_message;
    public static final @StringRes int LOCAL_KEY_VERIFICATION_ALERT_DISMISS = R.string.verification_alert_quit;
    public static final @StringRes int LOCAL_KEY_VERIFICATION_ALERT_QUIT = R.string.verification_alert_dismiss;
    public static final String KEY_IDENTITY_LINK = "js.mobile.data.protection.link";
    public static final String KEY_IDENTITY_LABEL = "js.mobile.data.protection.label";
    public static final String KEY_IDENTITY_AGREEMENT = "js.mobile.stored.identity.agreement";
    public static final String KEY_IDENTITY_TITLE = "js.mobile.stored.identity.title";
    public static final String KEY_IDENTITY_DESCRIPTION = "js.mobile.stored.identity.description";
    public static final String KEY_IDENTITY_AGREEMENTS_TITLE = "js.mobile.stored.identity.we.always";

    public static final String KEY_IDENTITY_CONFIRM = "js.mobile.stored.identity.confirm";
    public static final String KEY_IDENTITY_DECLINE = "js.mobile.stored.identity.decline";

    public static final String KEY_IDENTITY_NOTE = "js.mobile.stored.identity.note";
    public static final String KEY_IDENTITY_ENCRYPT = "js.mobile.stored.identity.STORED_IDENTITY_ENCRYP_DATA";
    public static final String KEY_IDENTITY_EUROPEAN_LAWS = "js.mobile.stored.identity.STORED_IDENTITY_EUROPEAN_LAWS";
    public static final String KEY_IDENTITY_FLEXIBLE = "js.mobile.stored.identity.STORED_IDENTITY_FLEXIBLE_ABILITY";

    public static final String KEY_IDENTITY_STORED_TITLE_CONFIRMED = "js.mobile.stored.identity.confirmed";
    public static final String KEY_IDENTITY_STORED_TITLE_NOT_CONFIRMED = "js.mobile.stored.identity.notconfirmed";

    public static final @StringRes int LOCAL_KEY_IDENTITY_LINK = R.string.identity_link;
    public static final @StringRes int LOCAL_KEY_IDENTITY_LABEL = R.string.identity_label;
    public static final @StringRes int LOCAL_KEY_IDENTITY_AGREEMENT = R.string.identity_agreeement;
    public static final @StringRes int LOCAL_KEY_IDENTITY_TITLE = R.string.identity_title;
    public static final @StringRes int LOCAL_KEY_IDENTITY_DESCRIPTION = R.string.identity_description;
    public static final @StringRes int LOCAL_KEY_AGREEMENTS_TITLE = R.string.agreement_title;
    public static final @StringRes int LOCAL_KEY_IDENTITY_CONFIRM = R.string.identity_confirm;
    public static final @StringRes int LOCAL_KEY_IDENTITY_DECLINE = R.string.identity_decline;
    public static final @StringRes int LOCAL_KEY_IDENTITY_NOTE = R.string.identity_note;


    /***** Terms & Conditions********/

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TERMS = R.string.overview_title_vip;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CONSENT = R.string.checkScreenConsentHeader_vip;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CONTINUE = R.string.startident_vip;

    /***** CQC********/

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_DESC = R.string.connection_vip_desc;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_MODERATE = R.string.connection_vip_status;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_1 = R.string.connection_vip_other_desc_1;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_2 = R.string.connection_vip_other_desc_2;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_3 = R.string.connection_vip_other_desc_3;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON = R.string.connection_vip_other_button;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_OTHER_STATUS = R.string.connection_vip_other_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD = R.string.vip_cqc_bad;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_1 = R.string.vip_cqc_bad_1;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_2 = R.string.vip_cqc_bad_2;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON = R.string.vip_cqc_bqd_button; // retest connection


    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE = R.string.vip_cqc_bqd_title; // we need to add the message
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_AGENT_COMPLETE = R.string.vip_agent_complete; // we need to add the message

    /***** Before starting ********/

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BEFORE_STARTING = R.string.before_starting_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_1 = R.string.vip_before_text_1;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_2 = R.string.vip_before_text_2;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_3 = R.string.vip_before_text_3;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_BUTTON = R.string.vip_ready_button;

    /***** FRONT - BACK - SELFIE ********/

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_TITLE = R.string.vip_take_picture_front_side_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_DESC = R.string.mainTextDescription;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_BACK_TITLE = R.string.vip_tak_picture_back_side_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_BACK_DESC = R.string.vip_tak_picture_back_side_desc;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_IMAGE_RETAKE = R.string.retakeAction;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_IMAGE_CONTINUE = R.string.continueButton;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_IMAGE_DESC = R.string.vip_tak_picture_desc;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_TITLE = R.string.vip_tak_picture_selfie_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_DESC1 = R.string.vip_tak_picture_selfie_desc_1;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_DESC2 = R.string.vip_tak_picture_selfie_desc_2;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_BUTTON_REQUEST = R.string.requestIdentCodeButton;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE = R.string.idcard_text_steps;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC1 = R.string.vip_take_agent_desc_1;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC2 = R.string.vip_take_agent_desc_2;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC3 = R.string.vip_take_agent_desc_3;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC4 = R.string.vip_take_agent_desc_4;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC4_EMAIL = R.string.vip_take_agent_desc_4_email;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC5 = R.string.vip_take_agent_desc_5;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC5_EMAIL = R.string.vip_take_agent_desc_5_email;

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC6 = R.string.vip_take_agent_desc_6;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_TITLE = R.string.waiting_list_vip_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC1 = R.string.vip_document_text;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC2 = R.string.vip_well_text;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC3 = R.string.waiting_estimated_text;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC4 = R.string.vip_selfie_text;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_BUTTON = R.string.vip_ok_waiting_list;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_CANCEL = R.string.vip_cancel_waiting_list;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_BUTTON_RESEND = R.string.vip_take_agent_send_again;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_BUTTON_CONFIRM = R.string.insert_tan_accept;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_MESSAGE_SUCCESS = R.string.vip_message_success;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_MESSAGE_FAILURE = R.string.vip_message_failure;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_TITLE = R.string.id_selection_user_feedback;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_IDSELECTION = R.string.id_selection_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_SEARCH = R.string.id_selection_search;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_DOCUMENT = R.string.id_selection_document_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_NOT_LISTED = R.string.id_selection_continue;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_LISTED_TITLE = R.string.title_error_layout;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_LISTED_DESC = R.string.description_error_layout;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_BUTTON = R.string.button_error_layout;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_TITLE = R.string.vip_something_wron_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_DESC = R.string.vip_something_wrong_desc;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_BUTTON = R.string.vip_scan_again;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_NO = R.string.vip_waiting_no;
    public static final @StringRes int LOCAL_KEY_CQC_ACTIVE_TITLE = R.string.connection_vip_title;
    public static final @StringRes int LOCAL_KEY_CQC_ACTIVE_NETWORK = R.string.connection_vip_good_1;
    public static final @StringRes int LOCAL_KEY_CQC_ACTIVE_AUDIO = R.string.connection_vip_good_2;
    public static final @StringRes int LOCAL_KEY_CQC_ACTIVE_VIDEO = R.string.connection_vip_good_3;

    public static final String KEY_VIDEO_IDENT_PLUS_IDENT_COMPELTED = "js.mobile.videoidentplus.take.agent.desc.6";
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_IDENT_COMPELTED = R.string.vip_take_agent_desc_6;

    public static final String KEY_VIDEO_IDENT_PLUS_IDENT_BEING_COMPELTED = "js.mobile.videoident.progress.title";
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_IDENT_BEING_COMPELTED = R.string.complete_identification_title;

    public static final String KEY_VIDEO_IDENT_PLUS_IDENT_BEING_WAIT = "js.mobile.videoident.progress.description"; // Backend check

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_IDENT_BEING_WAIT = R.string.complete_identification_text;

    public static final String KEY_VIDEO_IDENT_PLUS_IDENT_FINISHED = "js.mobile.videoidentplus.message.success";
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_IDENT_FINISEDH = R.string.step_finished;

    public static final String KEY_AGENT_FEEDBACK_TITLE = "js.agent.feedback.title";
    public static final String KEY_AGENT_FEEDBACK_DESC = "js.agent.feedback.desc";
    public static final String KEY_AGENT_FEEDBACK_VERY_BAD = "js.agent.feedback.very.bad";
    public static final String KEY_AGENT_FEEDBACK_VERY_GOOD = "js.agent.feedback.very.good";
    public static final String KEY_AGENT_FEEDBACK_OPTION = "js.agent.feedback.option";
    public static final String KEY_AGENT_FEEDBACK_SEND = "js.agent.feedback.send";
    public static final String KEY_AGENT_FEEDBACK_NOT_NOW = "js.agent.feedback.not.now";
    public static final String KEY_AGENT_FEEDBACK_DIALOG_TITLE = "js.agent.feedback.dialog.title";
    public static final String KEY_AGENT_FEEDBACK_DIALOG_CONTENT = "js.agent.feedback.dialog.content";
    public static final @StringRes int LOCAL_KEY_AGENT_FEEDBACK_TITLE = R.string.agent_feedback_title;
    public static final @StringRes int LOCAL_KEY_AGENT_FEEDBACK_DESC = R.string.agent_feedback_desc;
    public static final @StringRes int LOCAL_KEY_AGENT_FEEDBACK_VERY_BAD = R.string.agent_feedback_very_bad;
    public static final @StringRes int LOCAL_KEY_AGENT_FEEDBACK_VERY_GOOD = R.string.agent_feedback_very_good;
    public static final @StringRes int LOCAL_KEY_AGENT_FEEDBACK_OPTION = R.string.agent_feedback_option;
    public static final @StringRes int LOCAL_KEY_AGENT_FEEDBACK_SEND = R.string.agent_feedback_send;
    public static final @StringRes int LOCAL_KEY_AGENT_FEEDBACK_NOT_NOW = R.string.agent_feedback_not_now;
    public static final @StringRes int LOCAL_KEY_AGENT_FEEDBACK_DIALOG_TITLE = R.string.dialog_agent_feedback_error;
    public static final @StringRes int LOCAL_KEY_AGENT_FEEDBACK_DIALOG_CONTENT = R.string.dialog_agent_feedback_content;

    public static final String KEY_VIDEO_IDENT_PLUS_REUSE_TITLE = "js.mobile.videoidentplus.reuse.title";
    public static final String KEY_VIDEO_IDENT_PLUS_REUSE_DESC = "js.mobile.videoidentplus.reuse.desc";
    public static final String KEY_VIDEO_IDENT_PLUS_REUSE_TAKE_PHOTOS = "js.mobile.videoidentplus.reuse.take.new.photo";
    public static final String KEY_VIDEO_IDENT_PLUS_REUSE_FRONTID = KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_TITLE;
    public static final String KEY_VIDEO_IDENT_PLUS_REUSE_BACKID = KEY_VIDEO_IDENT_PLUS_TAKE_BACK_TITLE;
    public static final String KEY_VIDEO_IDENT_PLUS_REUSE_SELFIE = KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_TITLE;
    public static final String KEY_VIDEO_IDENT_PLUS_REUSE_CHECKING = "js.mobile.videoidentplus.reuse.checking";
    public static final String KEY_VIDEO_IDENT_PLUS_REUSE_DONE = "js.mobile.videoidentplus.reuse.done";
    public static final String KEY_VIDEO_IDENT_PLUS_REUSE_MISSING = "js.mobile.videoidentplus.reuse.missing";
    public static final String KEY_VIDEO_IDENT_PLUS_REUSE_USE_SAVED_IMAGES = "js.mobile.videoidentplus.reuse.use.saved.images";

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_TITLE = R.string.reuse_welcome;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_DESC = R.string.reuse_description;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_TAKE_PHOTOS = R.string.reuse_take_new_photo;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_FRONTID = R.string.reuse_front_id;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_BACKID = R.string.reuse_back_id;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_SELFIE = R.string.reuse_selfie;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_CHECKING = R.string.reuse_checking;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_DONE = R.string.reuse_done;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_MISSING = R.string.reuse_missing;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_USE_SAVED_IMAGES = R.string.reuse_saved_images;

    /*++++++++++ Consent screen ++++++++++ */
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_TITLE = "js.mobile.consent.title";//
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_TITLE = "js.mobile.consent.check.phone.number.title";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_DESC = "js.mobile.consent.check.phone.number.description";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_TITLE = "js.mobile.consent.check.email.title";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_DESC = "js.mobile.consent.check.email.description";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_PLACEHOLDER = "js.mobile.videoident.email.placeholder";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_TITLE = "js.mobile.consent.check.document.expiry.title";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_DESC = "js.mobile.consent.check.document.expiry.description";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_NO_PRESENT = "js.mobile.consent.check.document.expiry.no.present";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_INVALID = "js.mobile.consent.check.document.expiry.invalid";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICENSE_TITLE = "js.mobile.consent.check.license.title";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICNESE_DESC = "js.mobile.consent.check.license.description";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_AGREEMENT_TITLE = "js.mobile.consent.check.agreement.title";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_BUTTON_START_IDENT = "js.mobile.consent.button.start.ident";
    public static final String KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EXPIRTY_DATE_TODAY = "js.mobile.consent.button.start.ident";

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_TITLE = R.string.second_step_intro_text;//
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_TITLE = R.string.second_step_mobile_nr_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_DESC = R.string.second_step_mobile_nr_text;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_TITLE = R.string.second_step_email_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_DESC = R.string.second_step_email_text;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_PLACEHOLDER = R.string.second_step_email_hint;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_TITLE = R.string.second_step_expiry_date;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_DESC = R.string.second_step_id_expiry_date_text;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_NO_PRESENT = R.string.second_step_id_expiry_date_not_present;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_DOCUMENT_EXPIRY_INVALID = R.string.second_step_id_expiry_date_past;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICENSE_TITLE = R.string.second_step_id_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_LICNESE_DESC = R.string.second_step_id_text;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_AGREEMENT_TITLE = R.string.second_step_recording_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_BUTTON_START_IDENT = R.string.second_step_start_ident;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EXPIRTY_DATE_TODAY = R.string.second_step_id_expiry_date_today;

    /*++++++++++ VIDEO CALL ++++++++++ */
    public static final String KEY_VIDEO_IDENT_CANCEL_ALERT_TITLE = "js.mobile.videoident.cancel.alert.title"; // dialog_cancel_identification_title
    public static final String KEY_VIDEO_IDENT_CANCEL_ALERT_MSG = "js.mobile.videoident.cancel.alert.message"; // dialog_cancel_identification
    public static final String KEY_VIDEO_IDENT_WAITING_EXPERT = "js.mobile.videoident.waiting.expert"; //
    public static final String KEY_VIDEO_IDENT_NAME_AND_PHOTO_TITLE = "js.mobile.videoident.name.and.photo.title"; // step_title_say_name
    public static final String KEY_VIDEO_IDENT_NAME_AND_PHOTO = "js.identification.process.facepicture"; // step_say_name
    public static final String KEY_VIDEO_IDENT_CONNECTING_TITLE = "js.mobile.videoident.connecting.title"; // step_title_start
    public static final String KEY_VIDEO_IDENT_CONNECTING_DESC = "js.mobile.videoident.connecting.description"; // identification_wait_next_in_line
    public static final String KEY_VIDEO_IDENT_CONNECTING_POS1 = "js.mobile.videoident.connecting.position1"; // identification_wait_second_in_line
    public static final String KEY_VIDEO_IDENT_CONNECTING_POSX = "js.mobile.videoident.connecting.positionx"; // identification_wait_not_first
    public static final String KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_SECONDS = "js.mobile.videoident.connecting.waitingtimex.seconds"; // identification_wait_seconds
    public static final String KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_MINUTE = "js.mobile.videoident.connecting.waitingtime1.minute"; // identification_wait_minute
    public static final String KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_MINUTES = "js.mobile.videoident.connecting.waitingtimex.minutes"; // identification_wait_minutes
    public static final String KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_LONGER = "js.mobile.videoident.connecting.waitingtime.longer"; // identification_wait_longer
    public static final String KEY_VIDEO_IDENT_TITLE_DOCUMENT_TITL = "js.mobile.videoident.tilt.document.title"; // step_id_wiggle
    public static final String KEY_VIDEO_IDENT_IDENTCODE_REQUEST_MESSAGE = "js.mobile.videoident.identcode.request.message"; // retrieve_tan_content
    public static final String KEY_VIDEO_IDENT_IDENTCODE_PHONE_NUMBER_TITLE = "js.mobile.videoident.identcode.phone.number.title"; // retrieve_tan_content_bis
    public static final String KEY_VIDEO_IDENT_PHONE_NUMBER_PLACEHOLDER = "js.mobile.videoident.phone.number.placeholder"; // second_step_mobile_nr_hint
    public static final String KEY_VIDEO_IDENT_IDENTCODE_REQUEST_EMAIL_TITILE = "js.mobile.videoident.identcode.request.email.title"; // retrieve_tan_email_title
    public static final String KEY_VIDEO_IDENT_IDENT_CODE_ENTER_CODE = "js.mobile.videoident.identcode.enter.code"; // insert_tan_title
    public static final String KEY_VIDEO_IDENT_IDENT_CODE_RECEIVE_TAN_EMAIL_MESSAGE = "js.mobile.videoident.identcode.receive.tan.email.message"; // insert_tan_text_email
    public static final String KEY_VIDEO_IDENT_IDENT_CODE_REQUEST_AGAIN_SMS_MESSAGE = "js.mobile.videoident.identcode.request.again.sms.message"; // insert_tan_forgot_tan
    public static final String KEY_VIDEO_IDENT_IDENT_CODE_REQUEST_AGAIN_EMAIL_MESSAGE = "js.mobile.videoident.identcode.request.again.email.message"; // insert_tan_forgot_tan_email
    public static final String KEY_VIDEO_IDENT_IDENT_COMPLETED = "js.mobile.videoident.ident.completed.title"; // ident_done_successful
    public static final String KEY_VIDEO_IDENT_IDENT_COMPLETED_DESC = "js.mobile.videoident.ident.completed.description"; // step_finished
    public static final String KEY_VIDEO_IDENT_ESIGN_PROGRESS_TITLE = "js.mobile.videoident.esignature.progress.title"; // step_esigning_wait

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CANCEL_ALERT_TITLE = R.string.dialog_cancel_identification_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CANCEL_ALERT_MSG = R.string.dialog_cancel_identification; //
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_NAME_AND_PHOTO_TITLE = R.string.step_title_say_name;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_NAME_AND_PHOTO = R.string.step_say_name;

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CONNECTING_TITLE = R.string.step_title_start;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CONNECTING_DESC = R.string.identification_wait_next_in_line;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CONNECTING_POS1 = R.string.identification_wait_second_in_line;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CONNECTING_POSX = R.string.identification_wait_not_first;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_SECONDS = R.string.identification_wait_seconds;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_MINUTE = R.string.identification_wait_minute;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIMEX_MINUTES = R.string.identification_wait_minutes;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CONNECTING_WAITING_TIME1_LONGER = R.string.identification_wait_longer;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_TITLE_DOCUMENT_TITL = R.string.step_id_wiggle;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_IDENTCODE_REQUEST_MESSAGE = R.string.retrieve_tan_content;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_IDENTCODE_PHONE_NUMBER_TITLE = R.string.retrieve_tan_content_bis;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PHONE_NUMBER_PLACEHOLDER = R.string.second_step_mobile_nr_hint;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_IDENTCODE_REQUEST_EMAIL_TITILE = R.string.retrieve_tan_email_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_IDENT_CODE_ENTER_CODE = R.string.insert_tan_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_IDENT_CODE_RECEIVE_TAN_EMAIL_MESSAGE = R.string.insert_tan_text_email;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_IDENT_CODE_REQUEST_AGAIN_SMS_MESSAGE = R.string.insert_tan_forgot_tan;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_IDENT_CODE_REQUEST_AGAIN_EMAIL_MESSAGE = R.string.insert_tan_forgot_tan_email;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_IDENT_COMPLETED = R.string.ident_done_successful;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_IDENT_COMPLETED_DESC = R.string.step_finished;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ESIGN_PROGRESS_TITLE = R.string.step_esigning_wait;

    /*++++++++++ WAITING LIST ++++++++++ */
    public static final String KEY_VIDEO_IDENT_WAITING_LIST_SMS_REQUEST_TITLE = "js.mobile.waitinglist.sms.request.title"; // sms_requestpushbutton_title
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_WAITING_LIST_SMS_REQUEST_TITLE = R.string.sms_requestpushbutton_title; // sms_requestpushbutton_title
    public static final String KEY_VIDEO_IDENT_CHAT_TEXT_USER = "js.mobile.chat.text.user"; // idnow_chat_sender_user_at

    public static final String KEY_VIDEO_IDENT_ESIGN_CONTRACTID_TITLE = "js.mobile.esign.contractid.title"; // e_signature_hash
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ESIGN_CONTRACTID_TITLE = R.string.e_signature_hash; // e_signature_hash

    public static final String KEY_VIDEO_IDENT_WAITING_LIST_BUTTON_DONE = "js.mobile.waitinglist.button.done"; // result_screen_button_done
    public static final String KEY_VIDEO_IDENT_WAITING_LIST_SUCCESS_PUSH_TITLE = "js.mobile.waitinglist.success.push.title"; // notify_via_push_register sms_stage1_title
    public static final String KEY_VIDEO_IDENT_WAITING_LIST_SUCCESS_SMS_MSG = "js.mobile.waitinglist.success.sms.message"; // result_success_detail_smsnotification

    public static final String KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN = "js.mobile.identresult.button.try.again"; // result_screen_button_retry
    public static final String KEY_VIDEO_IDENT_RESULT_FAILED_TITLE = "js.mobile.identresult.failed.title"; // Identification Failed

    public static final String KEY_VIDEO_IDENT_RESULT_FAILED_MSG = "js.mobile.identresult.failed.message"; // result_screen_info_failure
    public static final String KEY_VIDEO_IDENT_COMMON_NO = "js.mobile.common.no"; // dialog_no
    public static final String KEY_VIDEO_IDENT_COMMON_YES = "js.mobile.common.yes"; // dialog_yes
    public static final String KEY_VIDEO_IDENT_COMMON_CONTINUE = "js.mobile.common.continue"; // dialog_no_wifi_continue
    public static final String KEY_VIDEO_IDENT_COMMON_ERROR = "js.mobile.common.error"; // error_dialog_title
    public static final String KEY_VIDEO_IDENT_COMMON_CANCEL = "js.mobile.common.cancel"; // dialog_no_wifi_cancel
    public static final String KEY_VIDEO_IDENT_COMMON_OK = "js.mobile.common.ok"; // vip_ok_waiting_list


    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_WAITING_LIST_BUTTON_DONE = R.string.result_screen_button_done;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_WAITING_LIST_SUCCESS_PUSH_TITLE = R.string.notify_via_push_register;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_WAITING_LIST_SUCCESS_SMS_MSG = R.string.result_success_detail_smsnotification;

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN = R.string.result_screen_button_retry;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_RESULT_FAILED_TITLE = R.string.result_screen_status_failed;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_RESULT_FAILED_MSG = R.string.result_screen_info_failure;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_NO = R.string.dialog_no;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_YES = R.string.dialog_yes;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_CONTINUE = R.string.dialog_no_wifi_continue;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_ERROR = R.string.error_dialog_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_CANCEL = R.string.dialog_no_wifi_cancel;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_OK = R.string.vip_ok_waiting_list;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMPLETE_ESIGN = R.string.complete_esign_text;
    public static String KEY_VIDEO_IDENT_COMPLETE_ESIGN = "js.mobile.ident.complete.esign";
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ERROR_FLASH = R.string.error_flash;
    public static final String KEY_VIDEO_IDENT_ERROR_FLASH = "js.mobile.camera.flash";
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ESIGN_ACCEPT_BUTTON = R.string.e_signature_accept_contract_button;
    public static final String KEY_VIDEO_IDENT_ESIGN_ACCEPT_BUTTON = "js.mobile.sign.contract";

    public static final String KEY_SIGNING_BUTTON_DUCPLICATED = "js.vi.esign.consent.confirmAndSign";
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ESIGN_BACK_SIGNING = R.string.e_signature_back_to_signing;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ESIGN_CHECK_CONTRACT = R.string.e_signature_check_contract;
    public static final String KEY_VIDEO_IDENT_ESIGN_CHECK_CONTRACT = "js.signature.check.contract";

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ESIGN_CONTRACT_WARNING_CONTENT = R.string.e_signature_warning_content;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ESIGN_CONTRACT_WARNING_TITLE = R.string.e_signature_warning_title;
    public static final String KEY_VIDEO_IDENT_ESIGN_CONTRACT_WARNING_TITLE = "js.mobile.ident.esign.contract.warning.title"; //
    public static final String KEY_VIDEO_IDENT_ESIGN_CONTRACT_WARNING_CONTENT = "js.mobile.ident.esign.contract.warning.content"; //
    public static final String KEY_VIDEO_IDENT_ESIGN_BACK_SIGNING = "js.mobile.ident.esign.back.signing"; //


    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_LIVESWITCH_CONNECTION_ERROR = R.string.liveswitch_network_connection_error;
    public static final String KEY_VIDEO_IDENT_LIVESWITCH_CONNECTION_ERROR = "js.mobile.ident.icelink.connection.error"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_LIVESWITCH_CONNECTION_ERROR_ABORT = R.string.liveswitch_network_connection_error_abort;
    public static final String KEY_VIDEO_IDENT_LIVESWITCH_CONNECTION_ERROR_ABORT = "js.mobile.ident.icelink.error.abort"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CHAT_ENTER_MSG = R.string.idnow_chat_enter_message;

    public static final String KEY_VIDEO_IDENT_CHAT_ENTER_MSG = "js.mobile.ident.chat.enter.msg";

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CHAT_TEXT_USER = R.string.idnow_chat_sender_user_at;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CHAT_SEND_MSG_FAILURE = R.string.idnow_chat_send_message_failure;
    public static final String KEY_VIDEO_IDENT_CHAT_SEND_MSG_FAILURE = "js.mobile.chat.send.msg.failure"; //
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_TAN_HINT_ENTER_CODE = R.string.insert_tan_hint_enter_code;
    public static final String KEY_VIDEO_IDENT_TAN_HINT_ENTER_CODE = "js.mobile.ident.tan.hint.enter.code"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS = R.string.insert_tan_text_sms;
    public static final String KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS = "js.mobile.ident.tan.hint.text.sms"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_NETWORK_CONNECTION_FAILURE = R.string.network_connection_failure;

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_EMAIL = R.string.insert_tan_text_email;
    public static final String KEY_VIDEO_IDENT_TAN_HINT_TEXT_EMAIL = "js.mobile.videoident.identcode.receive.tan.email.message";

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_NOTIF_CONTENT = R.string.notification_content;
    public static final String KEY_VIDEO_IDENT_NOTIF_CONTENT = "js.mobile.ident.notif.content"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE = R.string.notification_dialog_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PER_INTRO_END = R.string.permissions_intro_end;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PER_AUDIO = R.string.permission_audio;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PER_VIDEO = R.string.permissions_intro_video;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PER_CAMERA = R.string.permission_camera;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PER_FAILED_BREAK = R.string.permission_failed_break;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PER_FAILED_CONTINUE = R.string.permission_failed_continue;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD = R.string.required_field;

    public static final String KEY_VIDEO_IDENT_PER_INTRO_END = "js.mobile.ident.per.intro.end"; //
    public static final String KEY_VIDEO_IDENT_PER_AUDIO = "js.mobile.ident.per.audio"; //
    public static final String KEY_VIDEO_IDENT_PER_VIDEO = "js.mobile.ident.per.video"; //

    public static final String KEY_VIDEO_IDENT_PER_CAMERA = "js.mobile.ident.per.camera"; //
    public static final String KEY_VIDEO_IDENT_PER_FAILED_BREAK = "js.mobile.ident.per.failed.break"; //
    public static final String KEY_VIDEO_IDENT_PER_FAILED_CONTINUE = "js.mobile.per.failde.continue";

    public static final String KEY_VIDEO_IDENT_REQUIRED_FIELD = "js.mobile.ident.invalid.phone.number";//
    public static final String KEY_VIDEO_IDENT_NOTIF_TITLE = "js.mobile.ident.notif.title"; //
    public static final String KEY_VIDEO_IDENT_NETWORK_CONNECTION_FAILURE = "js.mobile.ident.network.connection.failure"; //

    public static final String KEY_VIDEO_IDENT_REQUIRED_EMAIL = "js.signing.email.format";

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_RATING_SCREEN = R.string.result_screen_rating_message;
    public static final String KEY_VIDEO_IDENT_RATING_SCREEN = "js.mobile.rating.screen";//
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_RATING_NEGATIVE = R.string.result_screen_rating_negative;
    public static final String KEY_VIDEO_IDENT_RATING_NEGATIVE = "js.mobile.rating.negative"; //
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_RATING_POSITIVE = R.string.result_screen_rating_positive;
    public static final String KEY_VIDEO_IDENT_RATING_POSITIVE = "js.mobile.rating.positive"; //
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_RATING_TITLE = R.string.result_screen_rating_title;
    public static final String KEY_VIDEO_IDENT_RATING_TITLE = "js.mobule.rate.app"; //
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ERROR_400 = R.string.rest_dialog_error_content_400;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ERROR_401 = R.string.rest_dialog_error_content_401;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ERROR_404 = R.string.rest_dialog_error_content_404;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ERROR_410 = R.string.rest_dialog_error_content_410;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ERROR_500 = R.string.rest_dialog_error_content_500;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ERROR_412 = R.string.rest_dialog_error_content_412;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ERROR_503 = R.string.rest_dialog_error_content_503;

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_RATING_MSG_GOOGLE = R.string.result_scrren_rating_message_google;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_SUCCESS_HOME_BUTTON = R.string.result_success_home_button;

    public static final String KEY_VIDEO_IDENT_SUCCESS_HOME_BUTTON = "js.mobile.back.to.start"; //

    public static final String KEY_VIDEO_IDENT_RATING_MSG_GOOGLE = "js.mobile.rating.msg.google"; //

    public static final String KEY_VIDEO_IDENT_ERROR_400 = "js.mobile.error.400"; //
    public static final String KEY_VIDEO_IDENT_ERROR_404 = "js.mobile.error.404"; //
    public static final String KEY_VIDEO_IDENT_ERROR_410 = "js.mobile.error.410"; //
    public static final String KEY_VIDEO_IDENT_ERROR_401 = "js.mobile.error.401"; //
    public static final String KEY_VIDEO_IDENT_ERROR_500 = "js.mobile.error.500"; //
    public static final String KEY_VIDEO_IDENT_ERROR_DOCUSIGN_EXPIRED = "js.errors.docusign.token.expiring.soon"; //
    public static final String KEY_VIDEO_IDENT_ERROR_412 = "js.mobile.error.412"; //
    public static final String KEY_VIDEO_IDENT_ERROR_503 = "js.mobile.error.503"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CONNECTION_ERROR_TITLE = R.string.dialog_error_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CONNECTION_ERROR_DESC = R.string.dialog_error_content;

    public static final String KEY_VIDEO_IDENT_CONNECTION_ERROR_TITLE = "js.mobile.ident.connection.error.title"; //
    public static final String KEY_VIDEO_IDENT_CONNECTION_ERROR_DESC = "js.mobile.ident.connection.error.desc"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_BLUETOOTH_ERROR = R.string.dialog_error_bluetooth;
    public static final String KEY_VIDEO_IDENT_BLUETOOTH_ERROR = "js.mobile.ident.bluetooth.error"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CAMERA_ERROR = R.string.dialog_error_camera_title;
    public static final String KEY_VIDEO_IDENT_CAMERA_ERROR = "js.mobile.ident.camera.error"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CAMERA_ERROR_DESC = R.string.dialog_error_camera_content;
    public static final String KEY_VIDEO_IDENT_CAMERA_ERROR_DESC = "js.mobile.ident.camera.error.desc"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PLAY_STORE = R.string.dialog_play_store;
    public static final String KEY_VIDEO_IDENT_PLAY_STORE = "js.mobile.ident.go.play.store"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_DIALOG_ERROR = R.string.dialog_error;
    public static final String KEY_VIDEO_IDENT_DIALOG_ERROR = "js.mobile.ident.dialog.error"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_DIALOG_VIDEO_ERROR = R.string.dialog_error_video;
    public static final String KEY_VIDEO_IDENT_DIALOG_VIDEO_ERROR = "js.mobile.ident.dialog.video.error"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_DIALOG_NO_CAMERA = R.string.dialog_no_camera;
    public static final String KEY_VIDEO_IDENT_DIALOG_NO_CAMERA = "js.mobile.ident.dialog.no.camera"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_DIALOG_ERROR_TAN = R.string.dialog_error_tan;
    public static final String KEY_VIDEO_IDENT_DIALOG_ERROR_TAN = "js.mobile.ident.dialog.error.tan"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ERROR_MOBILE_NO = R.string.dialog_error_mobile_no;
    public static final String KEY_VIDEO_IDENT_ERROR_MOBILE_NO = "js.mobile.ident.error.mobile.no"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ERROR_EMAIL = R.string.dialog_error_email;
    public static final String KEY_VIDEO_IDENT_ERROR_EMAIL = "js.mobile.ident.error.email"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ESIGN_DIALOG_TITLE = R.string.dialog_cancel_native_esigning_title;
    public static final String KEY_VIDEO_IDENT_ESIGN_DIALOG_TITLE = "js.mobile.ident.esign.dialog.title"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ESIGN_DIALOG_DESC = R.string.dialog_cancel_native_esigning;
    public static final String KEY_VIDEO_IDENT_ESIGN_DIALOG_DESC = "js.mobile.ident.esign.dialog.desc"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_AUTH_WARNING = R.string.auth_val_warning;
    public static final String KEY_VIDEO_IDENT_AUTH_WARNING = "js.mobile.ident.auth.warning"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_IMAGE_PROCESSING = R.string.photo_ident_image_processed;
    public static final String KEY_VIDEO_IDENT_IMAGE_PROCESSING = "js.mobile.ident.iamge.processing"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_SEARCH_TEXT = R.string.search_text;
    public static final String KEY_VIDEO_IDENT_SEARCH_TEXT = "js.mobile.ident.search.text"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_STEP_TITLE_START = R.string.step_title_start;
    public static final String KEY_VIDEO_IDENT_STEP_TITLE_START = "js.mobile.ident.step.title.start"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_STEP_WAIT_LONG = R.string.step_wait_long;
    public static final String KEY_VIDEO_IDENT_STEP_WAIT_LONG = "js.mobile.ident.step.wait.long"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_STEP_IDENT_CODE = R.string.step_title_ident_code;
    public static final String KEY_VIDEO_IDENT_STEP_IDENT_CODE = "js.mobile.ident.step.ident.code"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_STEP_TITLE_PLEASE_WAIT = R.string.step_title_please_wait;
    public static final String KEY_VIDEO_IDENT_STEP_TITLE_PLEASE_WAIT = "js.mobile.ident.step.title.please.wait"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_RETRIEVE_TAN_BUTTON = R.string.retrieve_tan_button;
    public static final String KEY_VIDEO_IDENT_RETRIEVE_TAN_BUTTON = "js.mobile.videoident.identcode.request.title"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_STATUS_SUCCESS = R.string.result_screen_status_success;
    public static final String KEY_VIDEO_IDENT_STATUS_SUCCESS = "js.mobile.videoidentplus.take.agent.done"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_RETRIEVE_TAN_TITLE = R.string.retrieve_tan_title;
    public static final String KEY_VIDEO_IDENT_RETRIEVE_TAN_TITLE = "js.mobile.videoident.identcode.request.title"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_REQUEST_CODE_AGAIN = R.string.insert_tan_button_send_again;
    public static final String KEY_VIDEO_IDENT_REQUEST_CODE_AGAIN = "js.mobile.videoident.identcode.request.code.again";

    public static final @StringRes int LOCAL_KEY_USER_ABORT_FEEDBACK_TITLE = R.string.user_abort_feedback_title;
    public static final String KEY_USER_ABORT_FEEDBACK_TITLE = "js.mobile.videoident.user.abort.feedback.title";

    public static final @StringRes int LOCAL_KEY_USER_ABORT_FEEDBACK_DESC = R.string.user_abort_feedback_desc;
    public static final String KEY_USER_ABORT_FEEDBACK_DESC = "js.mobile.videoident.user.abort.feedback.desc";

    public static final String USER_ABORT_REASON = "js.mobile.videoident.user.abort";

    public static final @StringRes int LOCAL_KEY_USER_ABORT_REASON_1 = R.string.user_abort_reason_1;
    public static final String KEY_USER_ABORT_REASON_1 = "js.mobile.videoident.user.abort.reason.1";

    public static final @StringRes int LOCAL_KEY_USER_ABORT_REASON_2 = R.string.user_abort_reason_2;
    public static final String KEY_USER_ABORT_REASON_2 = "js.mobile.videoident.user.abort.reason.2";

    public static final @StringRes int LOCAL_KEY_USER_ABORT_REASON_3 = R.string.user_abort_reason_3;
    public static final String KEY_USER_ABORT_REASON_3 = "js.mobile.videoident.user.abort.reason.3";

    public static final @StringRes int LOCAL_KEY_USER_ABORT_REASON_4 = R.string.user_abort_reason_4;
    public static final String KEY_USER_ABORT_REASON_4 = "js.mobile.videoident.user.abort.reason.4";

    public static final @StringRes int LOCAL_KEY_USER_ABORT_REASON_5 = R.string.user_abort_reason_5;
    public static final String KEY_USER_ABORT_REASON_5 = "js.mobile.videoident.user.abort.reason.5";

    public static final @StringRes int LOCAL_KEY_USER_ABORT_LEAVE_IDENTIFICATION = R.string.user_abort_leave_identification;
    public static final String KEY_USER_ABORT_LEAVE_IDENTIFICATION = "js.mobile.videoident.user.abort.leave.identification";

    public static final @StringRes int LOCAL_KEY_USER_ABORT_CONTINUE_IDENTIFICATION = R.string.user_abort_continue_identification;
    public static final String KEY_USER_ABORT_CONTINUE_IDENTIFICATION = "js.mobile.videoident.user.abort.continue.identification";

    public static final @StringRes int LOCAL_KEY_USER_ABORT_FEEDBACK_THANKYOU = R.string.user_abort_feedback_thankyou;
    public static final String KEY_USER_ABORT_FEEDBACK_THANKYOU = "js.mobile.videoident.user.abort.feedback.thankyou";
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_REROUTING_TITLE = R.string.german_id_title;
    public static final String KEY_VIDEO_IDENT_REROUTING_TITLE = "js.mobile.videoident.rerouting.title";

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_REROUTING_DESC = R.string.german_id_desc;
    public static final String KEY_VIDEO_IDENT_REROUTING_DESC = "js.mobile.videoident.rerouting.desc";

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_REROUTING_EID = R.string.german_id_button_eid;
    public static final String KEY_VIDEO_IDENT_REROUTING_EID = "js.mobile.videoident.rerouting.eid";

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_REROUTING_CONTINUE = R.string.german_id_button_continue;
    public static final String KEY_VIDEO_IDENT_REROUTING_CONTINUE = "js.mobile.videoident.rerouting.continue";

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ESIGN_BEING_COMPLETED_TITLE = R.string.complete_esign_title;
    public static final String KEY_VIDEO_IDENT_ESIGN_BEING_COMPLETED_TITLE = "js.mobile.videoident.esign.progress.title";

    public static final String KEY_EID_WAITING_TIME = "js.mobile.eid.waiting.time";
    public static final @StringRes int LOCAL_KEY_EID_WAITING_TIME = R.string.time_eid;

    public static final String KEY_VI_WAITING_TIME = "js.mobile.vi.waiting.time";
    public static final @StringRes int LOCAL_KEY_VI_WAITING_TIME = R.string.time_vid;

    public static final String KEY_ACCOUNT_EXPIRED_TITLE = "js.mobile.account.expired.title";
    public static final String KEY_ACCOUNT_EXPIRED_DESC = "js.mobile.account.expired.desc";
    public static final String KEY_ACCOUNT_EXPIRED_CONTINUE = "js.mobile.common.continue";

    public static final @StringRes int LOCAL_KEY_ACCOUNT_EXPIRED_TITLE = R.string.idnow_account_expired_title;
    public static final @StringRes int LOCAL_KEY_ACCOUNT_EXPIRED_DESC = R.string.idnow_account_expired_desc;
    public static final @StringRes int LOCAL_KEY_ACCOUNT_EXPIRED_CONTINUE = R.string.idnow_account_expired_continue;

    public static final String KEY_DEVICE_SUPPORT_TITLE = "js.mobile.device.support.title";
    public static final String KEY_DEVICE_SUPPORT_DESC = "js.mobile.device.support.desc";
    public static final String KEY_DEVICE_SUPPORT_FINISH = "js.mobile.common.continue";

    public static final @StringRes int LOCAL_KEY_DEVICE_SUPPORT_TITLE = R.string.title_requirement;
    public static final @StringRes int LOCAL_KEY_DEVICE_SUPPORT_DESC = R.string.text_reequirement;
    public static final @StringRes int LOCAL_KEY_DEVICE_SUPPORT_FINISH = R.string.button_error_layout;
    public static final String KEY_AGENT_LANGUAGE_YOUR_DEVICE = "js.mobile.agent.language.your.device.language";
    public static final String KEY_AGENT_SPECIALIST_SPEAKING = "js.mobile.agent.language.specialist.language";
    public static final String KEY_AGENT_CONTINUE = "js.mobile.agent.language.continue.identification";
    public static final String KEY_AGENT_CHANGE = "js.mobile.agent.language.select.ident.language";
    public static final String KEY_AGENT_CHOOSE = "js.mobile.agent.language.choose.language.title";
    public static final String KEY_AGENT_CHOOSE_PREFERRED = "js.mobile.agent.language.select.preferred.language";
    public static final String KEY_AGENT_QUIT = "js.mobile.agent.language.quit.identification";

    public static final @StringRes int LOCAL_KEY_AGENT_LANGUAGE_YOUR_DEVICE = R.string.agent_your_device_language;
    public static final @StringRes int LOCAL_KEY_AGENT_SPECIALIST_SPEAKING = R.string.agent_your_specialist_language;
    public static final @StringRes int LOCAL_KEY_AGENT_CONTINUE = R.string.agent_continue_identification;
    public static final @StringRes int LOCAL_KEY_AGENT_CHANGE = R.string.agent_change_language;
    public static final @StringRes int LOCAL_KEY_AGENT_CHOOSE = R.string.agent_choose_language;
    public static final @StringRes int LOCAL_KEY_AGENT_CHOOSE_PREFERRED = R.string.agent_choose_preferred_language;
    public static final @StringRes int LOCAL_KEY_AGENT_QUIT = R.string.agent_quit_identification;

    public static final String KEY_COMMON_UNSUPPORT_PRODUCT = "js.mobile.common.unsupport.product";
    public static final @StringRes int LOCAL_KEY_COMMON_UNSUPPORT_PRODUCT = R.string.common_unsupport_product;

    public static final String KEY_VI_WEBSCOCKET_ERROR_MESSAGE = "js.mobile.ident.websocket.error.message";
    public static final @StringRes int LOCAL_KEY_VI_WEBSCOCKET_ERROR_MESSAGE = R.string.websocket_error_message;

    public static final String KEY_VI_WEBSCOCKET_ERROR_ACTION_TRY_AGAIN = "js.mobile.ident.websocket.error.action.try.again";
    public static final @StringRes int LOCAL_EY_VI_WEBSCOCKET_ERROR_ACTION_TRY_AGAIN = R.string.websocket_error_action_try_again;

    public static final String KEY_VI_WEBSCOCKET_ERROR_ACTION_TRY_LATER = "js.mobile.ident.websocket.error.action.try.later";
    public static final @StringRes int LOCAL_KEY_VI_WEBSCOCKET_ERROR_ACTION_TRY_LATER = R.string.websocket_error_action_try_later;

    public static final String KEY_EMAIL_FORMAT = "js.errors.email.format";
    public static final @StringRes int LOCAL_KEY_EMAIL_FORMAT = R.string.email_format;

    public static final @StringRes int LOCAL_KEY_ESIGN_PREPARATION_TITLE = R.string.verify_title;
    public static final @StringRes int LOCAL_KEY_ESIGN_PREPARATION_DESC = R.string.verify_desc;

    public static final String KEY_ESIGN_PREPARATION_TITLE = "js.mobile.eid.signing.preparing.title";
    public static final String KEY_ESIGN_PREPARATION_DESC = "js.mobile.eid.signing.preparing.desc";


    public static final @StringRes int LOCAL_KEY_DOC_NOT_UPLOADED = R.string.doc_not_uploaded;
    public static final @StringRes int LOCAL_KEY_INSTANT_VERIFY_TITLE = R.string.verify_your_id;
    public static final @StringRes int LOCAL_KEY_INSTANT_VERIFY_DESC = R.string.verify_instant_desc;

    public static final @StringRes int LOCAL_KEY_INSTANT_ERROR_TITLE = R.string.error_your_id;
    public static final @StringRes int LOCAL_KEY_INSTANT_ERROR_DESC = R.string.error_desc;

    public static final @StringRes int LOCAL_KEY_INSTANT_VERIFY_CONTINUE_IDENTIFICATION = R.string.verify_your_id_continue;

    public static final @StringRes int LOCAL_KEY_INSTANT_VERIFY_QUIT = R.string.verify_your_id_quit;

    public static final @StringRes int LOCAL_KEY_INSTASIGN_SUCCESS_TITLE = R.string.instasign_success_title;
    public static final @StringRes int LOCAL_KEY_INSTASIGN_SUCCESS_MESSAGE = R.string.instasign_success_message;
    public static final @StringRes int LOCAL_KEY_INSTASIGN_FAILED_TITLE = R.string.instasing_failed_title;
    public static final @StringRes int LOCAL_KEY_INSTASIGN_FAILED_MESSAGE = R.string.instasing_failed_message;


    public static final String KEY_DOC_NOT_UPLOADED = "js.mobile.instantsign.doc.not.uploaded";
    public static final String KEY_INSTASIGN_SUCCESS_TITLE = "js.mobile.instantsign.singing.success.title";
    public static final String KEY_INSTASIGN_SUCCESS_MESSAGE = "js.mobile.instantsign.singing.success.message";
    public static final String KEY_INSTASIGN_FAILED_TITLE = "js.mobile.instantsign.singing.failed.title";
    public static final String KEY_INSTASIGN_FAILED_MESSAGE = "js.mobile.instantsign.singing.failed.message";

    public static final String KEY_INSTANTSIGN_VERIFY_ID_TITLE = "js.mobile.instantsign.verifyid.title";

    public static final String KEY_INSTANTSIGN_VERIFY_ID_DESCRIPTION = "js.mobile.instantsign.verifyid.description";

    public static final String KEY_INSTANTSIGN_ERROR_ID_TITLE = "js.mobile.instantsign.errorid.title";

    public static final String KEY_INSTANTSIGN_ERROR_ID_DESCRIPTION = "js.mobile.instantsign.errorid.description";

    public static final String KEY_INSTANTSIGN_VERIFY_ID_CONTINUE_IDENTIFICATION = "js.mobile.instantsign.verifyid.continue.identification";

    public static final String KEY_INSTANT_VERIFY_QUIT = "js.mobile.instantsign.verifyid.quit";

    public static final String KEY_VIDEO_IDENT_ERROR_MATCHING_VALIDATION="js.mobile.videoident.unexpected.error.description"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_ERROR_MATCHING_VALIDATION= R.string.error_matching_validation;

    public static @NonNull String getStringWithDefault(@NonNull String serverStringKey, @StringRes Integer fallbackStringResId) {
        return getStringWithDefault(
                IDnowSDK.getInstance().getAppContext(),
                serverStringKey,
                fallbackStringResId
        );
    }

    public static @NonNull
    String getStringWithDefault(@NonNull Context context, @NonNull String serverStringKey, @StringRes Integer fallbackStringResId) {
        Map<String, String> messages = Config.MESSAGES;
        if (messages != null && !TextUtils.isEmpty(serverStringKey) && !TextUtils.isEmpty(messages.get(serverStringKey))) {
            return messages.get(serverStringKey);
        }

        // !!! crash here -> context NULL see contextVIP global variable
        if (fallbackStringResId != null && !TextUtils.isEmpty(context.getString(fallbackStringResId))) {
            Util_Log.i(LOGTAG, "Messages key " + serverStringKey + " not found, falling back to default.");
            return context.getString(fallbackStringResId);
        }

        return "";
    }

    private static class TextEntry {
        public String key;
        public @StringRes int localResId;

        public TextEntry(@Nullable String key, @StringRes int localResId) {
            this.key = key;
            this.localResId = localResId;
        }

        public TextEntry(@StringRes int localResId) {
            this.key = null;
            this.localResId = localResId;
        }
    }


    private static final SparseArray<TextEntry> videoIdentStepTextEntries = new SparseArray<>();

    static {
        videoIdentStepTextEntries.put(0, new TextEntry(KEY_LABEL_WAITING_FOR_AGENT, LOCAL_LABEL_WAITING_FOR_AGENT));
        videoIdentStepTextEntries.put(1, new TextEntry(KEY_VIDEO_IDENT_NAME_AND_PHOTO, LOCAL_KEY_VIDEO_IDENT_NAME_AND_PHOTO));
        videoIdentStepTextEntries.put(2, new TextEntry(KEY_VIDEOIDENT_STEP_FRONT, LOCAL_VIDEOIDENT_STEP_FRONT));
        videoIdentStepTextEntries.put(3, new TextEntry(KEY_VIDEO_IDENT_TITLE_DOCUMENT_TITL, LOCAL_KEY_VIDEO_IDENT_TITLE_DOCUMENT_TITL));
        videoIdentStepTextEntries.put(4, new TextEntry(KEY_VIDEOIDENT_READ_NO, LOCAL_VIDEOIDENT_READ_NO));
        videoIdentStepTextEntries.put(5, new TextEntry(KEY_VIDEOIDENT_STEP_BACK, LOCAL_VIDEOIDENT_STEP_BACK));
        videoIdentStepTextEntries.put(6, new TextEntry(KEY_VIDEO_IDENT_TITLE_DOCUMENT_TITL, LOCAL_KEY_VIDEO_IDENT_TITLE_DOCUMENT_TITL));
        videoIdentStepTextEntries.put(7, new TextEntry(R.string.step_id_empty_string));
        videoIdentStepTextEntries.put(8, new TextEntry(KEY_VIDEO_IDENT_IDENT_COMPLETED_DESC, LOCAL_KEY_VIDEO_IDENT_IDENT_COMPLETED_DESC));
        videoIdentStepTextEntries.put(99, new TextEntry(KEY_VIDEO_IDENT_ESIGN_PROGRESS_TITLE, LOCAL_KEY_VIDEO_IDENT_ESIGN_PROGRESS_TITLE));
        videoIdentStepTextEntries.put(100, new TextEntry(KEY_VIDEO_IDENT_STEP_WAIT_LONG, LOCAL_KEY_VIDEO_IDENT_STEP_WAIT_LONG));
    }


    public static @NonNull String getVideoIdentStepText(@NonNull Context context, int step) {
        if (videoIdentStepTextEntries.get(step) != null) {
            return Util_Strings.getStringWithDefault(context,
                    videoIdentStepTextEntries.get(step).key,
                    videoIdentStepTextEntries.get(step).localResId);
        } else {
            return "";
        }
    }

    private static final SparseArray<TextEntry> videoIdentStepTitleEntries = new SparseArray<>();

    static {
        videoIdentStepTitleEntries.put(0, new TextEntry(KEY_VIDEO_IDENT_CONNECTING_TITLE, LOCAL_KEY_VIDEO_IDENT_CONNECTING_TITLE));
        videoIdentStepTitleEntries.put(1, new TextEntry(KEY_VIDEO_IDENT_NAME_AND_PHOTO_TITLE, LOCAL_KEY_VIDEO_IDENT_NAME_AND_PHOTO_TITLE));
        videoIdentStepTitleEntries.put(2, new TextEntry(KEY_VIDEOIDENT_STEP_FRONT_TITLE, LOCAL_VIDEOIDENT_STEP_FRONT_TITLE));
        videoIdentStepTitleEntries.put(3, new TextEntry(KEY_VIDEOIDENT_STEP_FRONT_TITLE, LOCAL_VIDEOIDENT_STEP_FRONT_TITLE));
        videoIdentStepTitleEntries.put(4, new TextEntry(KEY_VIDEOIDENT_STEP_FRONT_TITLE, LOCAL_VIDEOIDENT_STEP_FRONT_TITLE));
        videoIdentStepTitleEntries.put(5, new TextEntry(KEY_VIDEOIDENT_STEP_BACK_TITLE, LOCAL_VIDEOIDENT_STEP_BACK_TITLE));
        videoIdentStepTitleEntries.put(6, new TextEntry(KEY_VIDEOIDENT_STEP_BACK_TITLE, LOCAL_VIDEOIDENT_STEP_BACK_TITLE));
        videoIdentStepTitleEntries.put(7, new TextEntry(KEY_VIDEO_IDENT_STEP_IDENT_CODE, LOCAL_KEY_VIDEO_IDENT_STEP_IDENT_CODE));
        videoIdentStepTitleEntries.put(8, new TextEntry(KEY_VIDEO_IDENT_IDENT_COMPLETED, LOCAL_KEY_VIDEO_IDENT_IDENT_COMPLETED));
        // E-Signing
        videoIdentStepTitleEntries.put(99, new TextEntry(KEY_VIDEO_IDENT_STEP_TITLE_PLEASE_WAIT, LOCAL_KEY_VIDEO_IDENT_STEP_TITLE_PLEASE_WAIT));

    }

    public static @NonNull String getVideoIdentStepTitle(@NonNull Context context, int step) {
        if (videoIdentStepTitleEntries.get(step) != null) {
            return Util_Strings.getStringWithDefault(context,
                    videoIdentStepTitleEntries.get(step).key,
                    videoIdentStepTitleEntries.get(step).localResId);
        } else {
            return "";
        }
    }

    public static @NonNull String getErrorMessageForResponseCode(@NonNull final Context context, final int responseCode) {
        return Util_Strings.getErrorMessageForResponseCode(context, responseCode, null, null);
    }

    public static @NonNull String getErrorMessageForResponseCode(@NonNull final Context context, final int responseCode, @Nullable String exceptionId, String resultError) {
        switch (responseCode) {

            case 400:
                return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_400, LOCAL_KEY_VIDEO_IDENT_ERROR_400);
            case 401:
                return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_401, LOCAL_KEY_VIDEO_IDENT_ERROR_401);
            case 404:
                return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_404, LOCAL_KEY_VIDEO_IDENT_ERROR_404);
            case 410:
                return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_410, LOCAL_KEY_VIDEO_IDENT_ERROR_410);
            case 412:
                if (!resultError.equals("")) {
                    try {
                        JSONArray jsonArray = new JSONObject(resultError).getJSONArray(ERRORS_ARRAY);
                        JSONObject jsonObject = jsonArray.getJSONObject(0);
                        String errorType = jsonObject.getString(KEY_ERROR);
                        if (errorType.equalsIgnoreCase(ERROR_TYPE_DOCUMENT_NOT_DOWNLOADED)) {
                            return Util_Strings.getStringWithDefault(context, jsonObject.getString(TRANSLATION_KEY), LOCAL_ESIGN_DOCUMENT_NOT_DOWNLOADED);
                        } else if (errorType.equalsIgnoreCase(DOCUSIGN_TOKEN_EXPIRING_SOON)) {
                            return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_DOCUSIGN_EXPIRED, LOCAL_DOCUSIGN_TOKEN_EXPIRING_SOON);
                        } else {
                            return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_412, LOCAL_KEY_VIDEO_IDENT_ERROR_412);
                        }
                    } catch (JSONException e) {
                        Util_Log.e(LOGTAG, "Parse error messages from response code failed", e);
                    }
                } else {
                    return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_412, LOCAL_KEY_VIDEO_IDENT_ERROR_412);
                }
            case 500: {
                return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_500, LOCAL_KEY_VIDEO_IDENT_ERROR_500);
            }
            case 503:
                return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ERROR_503, LOCAL_KEY_VIDEO_IDENT_ERROR_503);
            default:
                return Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_DIALOG_ERROR, LOCAL_KEY_VIDEO_IDENT_DIALOG_ERROR);
        }
    }
}
