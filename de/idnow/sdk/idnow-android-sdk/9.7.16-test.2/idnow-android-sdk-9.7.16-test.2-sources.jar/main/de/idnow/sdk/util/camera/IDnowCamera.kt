package de.idnow.sdk.util.camera

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.Point
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.display.DisplayManager
import android.hardware.display.DisplayManager.DisplayListener
import android.os.Build
import android.util.Range
import android.util.Size
import android.view.MotionEvent
import android.view.WindowManager
import androidx.camera.core.Camera
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.CameraState
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCapture.OnImageCapturedCallback
import androidx.camera.core.MeteringPointFactory
import androidx.camera.core.Preview
import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import de.idnow.sdk.util.Util_Log
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private const val TAG: String = "IDnowCamera"
private const val ASPECT_RATIO_4_3 = 4.0 / 3.0
private const val ASPECT_RATIO_16_9 = 16.0 / 9.0

@SuppressLint("ClickableViewAccessibility")
class IDnowCamera(
    private val lifecycleOwner: LifecycleOwner,
    private val activity: Activity,
    private val previewView: PreviewView
) {
    private val cameraExecutor: Executor = ContextCompat.getMainExecutor(activity)
    private val displayManager: DisplayManager =
        activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val availableCameras = ArrayList<CameraSpec>()
    private var displayId: Int = getDefaultDisplayId()
    private var camera: Camera? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null
    private val cameraData: IDnowCameraData = IDnowCameraData()
    private val isCameraOpened = AtomicBoolean(false)

    private val displayListener: DisplayListener = object : DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}

        override fun onDisplayRemoved(displayId: Int) {}

        override fun onDisplayChanged(displayId: Int) {
            if (displayId == this@IDnowCamera.displayId) {
                if (imageCapture != null) {
                    imageCapture!!.setTargetRotation(getDisplayRotation(displayId))
                }
            }
        }
    }

    init {
        displayManager.registerDisplayListener(displayListener, null)
        previewView.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                requestPointFocus(event.x, event.y)
            }
            true
        }

        loadCameraProvider()
        loadCameras()
    }

    private fun getDefaultDisplayId(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity.display.displayId
        } else {
            val dm = activity.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            dm.defaultDisplay.displayId
        }
    }

    private fun getDisplayRotation(displayId: Int): Int {
        val dm = activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        return dm.getDisplay(displayId)?.rotation ?: run {
            Util_Log.w(TAG, "Display $displayId not found. Defaulting to rotation 0")
            return 0
        }
    }

    private fun getDisplaySize(): Size {
        val wm = activity.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val metrics = wm.currentWindowMetrics.bounds
            Size(metrics.width(), metrics.height())
        } else {
            val outPoint = Point()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getSize(outPoint)
            Size(outPoint.x, outPoint.y)
        }
    }

    private fun loadCameraProvider() {
        try {
            cameraProvider = ProcessCameraProvider.getInstance(activity).get()
        } catch (e: ExecutionException) {
            Util_Log.e(TAG, "Access camera provider failed", e)
            return
        } catch (e: InterruptedException) {
            Util_Log.e(TAG, "Access camera provider failed", e)
            return
        }
    }

    @SuppressLint("RestrictedApi")
    private fun loadCameras() {
        try {
            cameraProvider!!.availableCameraInfos
                .mapNotNull {
                    if (it.cameraIdentifier != null &&
                        it.lensFacing != CameraSelector.LENS_FACING_UNKNOWN
                    ) {
                        Pair(it.cameraIdentifier!!.cameraIds, it.lensFacing)
                    } else {
                        null
                    }
                }
                .forEach { (cameraIds, cameraLensFacing) ->
                    val cameraType =
                        if (cameraLensFacing == CameraSelector.LENS_FACING_BACK) {
                            CameraType.BACK
                        } else {
                            CameraType.FRONT
                        }
                    val spec = CameraSpec(
                        ids = cameraIds,
                        lensFacing = cameraLensFacing,
                        type = cameraType,
                        hasAutofocus = cameraIds.any { checkHasAutofocus(it) }
                    )
                    availableCameras.add(spec)
                }
        } catch (e: Exception) {
            Util_Log.e(TAG, "Load cameras failed", e)
        }
    }

    private fun checkHasAutofocus(cameraId: String): Boolean {
        val manager = activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            if (!manager.cameraIdList.contains(cameraId)) {
                Util_Log.w(TAG, "Camera ID $cameraId not found in manager list")
                return false
            }
            val characteristics = manager.getCameraCharacteristics(cameraId)
            val afModes =
                characteristics.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
            if (afModes != null) {
                for (mode in afModes) {
                    if (mode == CameraMetadata.CONTROL_AF_MODE_AUTO || mode == CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE || mode == CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO || mode == CameraMetadata.CONTROL_AF_MODE_MACRO) {
                        return true
                    }
                }
            }
        } catch (e: CameraAccessException) {
            Util_Log.e(TAG, "Check camera has autofocus failed", e)
        } catch (e: IllegalArgumentException) {
            Util_Log.e(TAG, "Check camera has autofocus failed: unknown camera ID $cameraId", e)
        }
        return false
    }

    @SuppressLint("RestrictedApi")
    private fun startPreview() {
        if (cameraProvider == null) {
            return
        }
        stopPreview()
        val lensFacing = availableCameras.firstOrNull { it.type == cameraData.type }
            ?.lensFacing ?: run {
            Util_Log.e(TAG, "Camera lens facing is null for ${cameraData.type.name}")
            return
        }
        val cameraSelector = CameraSelector.Builder()
            .requireLensFacing(lensFacing)
            .build()
        val displaySize = getDisplaySize()
        val resolutionSelector =
            ResolutionSelector.Builder()
                .setAspectRatioStrategy(
                    resolveAspectRatio(displaySize)
                )
                .build()

        val rotation = getDisplayRotation(displayId)
        cameraData.orientation = rotation
        val preview = Preview.Builder()
            .setResolutionSelector(resolutionSelector)
            .setTargetFrameRate(Range(60, 60))
            .setTargetRotation(rotation)
            .build()
        try {
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setFlashMode(ImageCapture.FLASH_MODE_AUTO)
                .setResolutionSelector(resolutionSelector)
                .setTargetRotation(rotation)
                .setBufferFormat(ImageFormat.JPEG)
                .build()
            camera = cameraProvider!!.bindToLifecycle(
                lifecycleOwner,
                cameraSelector,
                preview,
                imageCapture
            )

            preview.surfaceProvider = previewView.getSurfaceProvider()
            if (camera != null) {
                observeCameraState(camera!!.cameraInfo)
            }
        } catch (e: Exception) {
            Util_Log.e(TAG, "Start preview", e)
        }
    }

    private fun stopPreview() {
        if (cameraProvider == null) {
            return
        }

        cameraProvider!!.unbindAll()
    }

    private fun observeCameraState(cameraInfo: CameraInfo) {
        cameraInfo.cameraState.observe(activity as LifecycleOwner) { cameraState ->
            isCameraOpened.set(cameraState.type == CameraState.Type.OPEN)
        }
    }

    private fun resolveAspectRatio(displaySize: Size): AspectRatioStrategy = with(displaySize) {
        val previewRatio = (max(width, height).toDouble()) / min(width, height)
        return if (abs(previewRatio - ASPECT_RATIO_4_3) <= abs(previewRatio - ASPECT_RATIO_16_9)) {
            AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
        } else {
            AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
        }
    }

    fun takePicture(callback: OnImageCapturedCallback) {
        if (imageCapture != null) {
            imageCapture!!.takePicture(cameraExecutor, callback)
        }
    }

    private fun requestPointFocus(x: Float, y: Float) {
        val cameraControl = camera?.cameraControl ?: run {
            Util_Log.w(TAG, "Focus request not sent because camera is off")
            return
        }
        val factory: MeteringPointFactory =
            SurfaceOrientedMeteringPointFactory(
                previewView.width.toFloat(), previewView.height.toFloat()
            )
        val centerPoint = factory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(centerPoint).build()
        cameraControl.startFocusAndMetering(action)
    }

    fun destroy() {
        displayManager.unregisterDisplayListener(displayListener)
    }

    fun open() {
        open(cameraData.type)
    }

    fun open(type: CameraType) {
        if (cameraProvider == null) {
            Util_Log.w(TAG, "No camera access")
            return
        }

        if (isCameraOpened.get() && cameraData.type == type) {
            Util_Log.w(TAG, "Camera already opened")
            return
        }

        if (availableCameras.none { it.type == type }) {
            Util_Log.e(TAG, type.name + " camera not available")
            return
        }

        stopPreview()
        cameraData.type = type
        startPreview()
    }

    fun close() {
        if (isCameraOpened.get() && cameraProvider != null)
            stopPreview()
    }
}
