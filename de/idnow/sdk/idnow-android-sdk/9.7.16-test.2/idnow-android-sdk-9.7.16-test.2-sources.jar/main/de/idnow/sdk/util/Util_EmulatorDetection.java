package de.idnow.sdk.util;

import android.os.Build;

/**
 * Detects whether the SDK is running on an emulator.
 * <p>
 * Uses a set of {@link android.os.Build} heuristics covering the common emulator vendors
 * (AOSP/AVD, Genymotion/VirtualBox, Nox, Andy, Droid4X, TiantianVM, Bluestacks). This is a
 * best-effort check: emulators can spoof {@code Build.*} values and real devices can lack
 * expected properties, so it is not 100% reliable.
 */
public class Util_EmulatorDetection {

	/**
	 * @return true if the current device is most likely an emulator.
	 */
	public static boolean isProbablyEmulator()
	{
		return checkProduct()
				|| checkManufacturer()
				|| checkBrand()
				|| checkDevice()
				|| checkModel()
				|| checkHardware()
				|| checkFingerprint()
				|| checkBoard();
	}

	private static boolean checkProduct()
	{
		String product = Build.PRODUCT;
		// contains("sdk") already covers google_sdk / sdk_x86 / sdk_google / sdk_gphone.
		return product != null && (product.contains( "sdk" )
				|| product.contains( "vbox86p" )
				|| product.contains( "nox" )
				|| product.contains( "Andy" )
				|| product.contains( "Droid4X" )
				|| product.contains( "ttVM_Hdragon" ));
	}

	private static boolean checkManufacturer()
	{
		String manufacturer = Build.MANUFACTURER;
		return manufacturer != null && (manufacturer.contains( "Genymotion" )
				|| manufacturer.contains( "Andy" )
				|| manufacturer.contains( "nox" )
				|| manufacturer.contains( "TiantianVM" )
				|| manufacturer.contains( "Bluestacks" ));
	}

	private static boolean checkBrand()
	{
		String brand = Build.BRAND;
		return brand != null && (brand.equals( "generic" )
				|| brand.equals( "generic_x86" )
				|| brand.equals( "TTVM" )
				|| brand.contains( "Andy" ));
	}

	private static boolean checkDevice()
	{
		String device = Build.DEVICE;
		// contains("generic") already covers generic_x86 / generic_x86_64.
		return device != null && (device.contains( "generic" )
				|| device.contains( "vbox86p" )
				|| device.contains( "nox" )
				|| device.contains( "Andy" )
				|| device.contains( "Droid4X" )
				|| device.contains( "ttVM_Hdragon" ));
	}

	private static boolean checkModel()
	{
		String model = Build.MODEL;
		return model != null && (model.equals( "sdk" )
				|| model.equals( "google_sdk" )
				|| model.equals( "Android SDK built for x86" )
				|| model.equals( "Android SDK built for x86_64" )
				|| model.contains( "Emulator" )
				|| model.contains( "Droid4X" )
				|| model.contains( "Andy" )
				|| model.contains( "TiantianVM" ));
	}

	private static boolean checkHardware()
	{
		String hardware = Build.HARDWARE;
		return hardware != null && (hardware.equals( "goldfish" )
				|| hardware.equals( "ranchu" )
				|| hardware.equals( "vbox86" )
				|| hardware.contains( "nox" )
				|| hardware.contains( "ttVM_x86" ));
	}

	private static boolean checkFingerprint()
	{
		String fingerprint = Build.FINGERPRINT;
		// startsWith("generic") already covers the "generic/sdk/generic" style fingerprints.
		return fingerprint != null && (fingerprint.startsWith( "generic" )
				|| fingerprint.contains( "generic_x86" )
				|| fingerprint.contains( "vbox86p" )
				|| fingerprint.contains( "google_sdk" )
				|| fingerprint.contains( "emulator" )
				|| fingerprint.contains( "ranchu" ));
	}

	private static boolean checkBoard()
	{
		String board = Build.BOARD;
		return board != null && (board.contains( "nox" )
				|| board.contains( "goldfish" ));
	}
}
