package de.idnow.sdk.Activities;

import static de.idnow.sdk.Config.USER_PHONE_NO;
import static de.idnow.sdk.IDnowSDK.DOCUSIGN_TOKEN_EXPIRING_SOON;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_FINISH;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_IDENTCODE_PHONE_NUMBER_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_MOBILE_CONSENT_BUTTON_START_IDENT;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CONTINUE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_FINISH;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_IDENTCODE_PHONE_NUMBER_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_BUTTON_START_IDENT;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CONTINUE;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff.Mode;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.airbnb.lottie.LottieAnimationView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import de.idnow.sdk.Activities.entry.Activities_EntryActivity;
import de.idnow.sdk.BaseActivities_BaseFragmentActivity;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Models_ClientInfo;
import de.idnow.sdk.models.Models_EmptyJson;
import de.idnow.sdk.models.Models_MobileNumber;
import de.idnow.sdk.models.Models_OfficeHours;
import de.idnow.sdk.models.Models_StartObject;
import de.idnow.sdk.models.Models_StartObjectResult;
import de.idnow.sdk.network.Callback;
import de.idnow.sdk.network.IDnowRestClient;
import de.idnow.sdk.network.Network_RESTCalls;
import de.idnow.sdk.network.RetrofitError;
import de.idnow.sdk.network.connectivityService.ConnectivityService;
import de.idnow.sdk.util.Util_CustomLogData;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_Util;
import de.idnow.sdk.util.Util_UtilRetrofit;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.Util_VideoSessionConfig;
import de.idnow.sdk.util.Util_VideoStreamService;
import de.idnow.sdk.util.helper.CameraHelper;
import retrofit2.Call;
import retrofit2.Response;


/**
 * the class is the super class for the checkScreen. Some customers want to have their own checkScreen layouts, so only the core functionality (api calls) are
 * handled in this super class. All the view specific behavior has to be handled in the subclasses.
 */
public class Activities_VideoOverviewCheckActivity_Super extends BaseActivities_BaseFragmentActivity
{
	public Context     context;
	public ProgressBar progressBar;

	public Button               nextButton, finishButton;
	public ArrayList<ImageView> imagesToCheckList;
	public EditText             editTextMobileNr, editTextEmail;

	private TextView token_retries_title, token_retries_message, secondary_button;
	private Button main_button;

	// Video Ident Plus

	public EditText editTextMobileNr_vip, editTextEmail_vip;

	public Button nextButton_vip;

	public CheckBox checkbox_phone_vip,checkbox_email_vip,checkbox_consent_vip;

	private RelativeLayout layout_overview_video_ident_plus,layout_overview_video_ident;
	private LinearLayout token_retries_layout;

	public LottieAnimationView used_logo,idnow_logo_retries_screen;

	public Spinner sCountry;

	private final String LOGTAG = "IDNOW_Activities_VideoOverviewCheckActivity_Super";

	protected final String STATE1 = "STATE1";
	protected final String STATE2 = "STATE2";
	protected final String STATEA = "STATEA";
	protected final String[] supportedCheckStates = new String[]{STATE1, STATE2, STATEA};
	protected HashMap<String, Boolean> checkStatesStati = new HashMap<>();
	private int remainingInternalTokenRetries = -1;

	private final Runnable startRESTCallRunnable = new Runnable()
	{
		@Override
		public void run()
		{
			fetchWaitingPositionAndDuration();
			makeStartRESTCall(true);
		}
	};

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );

		Config.REMAINING_TRIES =-1;

		if ( IDnowSDK.preventScreenshot )
		{
			// secures against manual screenshots and automatic screenshots
			getWindow().setFlags( LayoutParams.FLAG_SECURE, LayoutParams.FLAG_SECURE );
		}

		Util_CustomLogData.setEventData(Util_CustomLogData.EVENT_TNC_SHOWN,"EVENT_TNC_SHOWN", "TnC", "Screen",null);

			if (savedInstanceState != null){
				for (String checkState: supportedCheckStates){
					checkStatesStati.put(checkState, savedInstanceState.getBoolean(checkState, false));
				}
		}



	}

	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);

		for (String checkState: supportedCheckStates){
			outState.putBoolean(checkState, getCheckState(checkState));
		}

	}

	/**
	 * this method has to be called from the subclasses to set the correct layout file
	 *
	 * @param layoutRes
	 */
	public void overrideContentView(int layoutRes) {
		setContentView(layoutRes);

		layout_overview_video_ident_plus = findViewById(R.id.layout_overview_video_ident_plus);
		layout_overview_video_ident = findViewById(R.id.layout_overview_video_ident);
		token_retries_layout = findViewById(R.id.token_retries_layout);
		token_retries_title = findViewById(R.id.token_retries_title);
		token_retries_message = findViewById(R.id.token_retries_message);
		main_button = findViewById(R.id.main_button);
		secondary_button = findViewById(R.id.secondary_button);



		if (Config.VIDEO_IDENT_PLUS){

			context = this;
			imagesToCheckList = new ArrayList<>();

			used_logo = findViewById(R.id.used_logo);
			used_logo.setAnimation("static_logo.json");
			idnow_logo_retries_screen = findViewById(R.id.idnow_logo_retries_screen);
			idnow_logo_retries_screen.setAnimation("static_logo.json");

			if(IDnowSDK.getShowIDnowLogo()){
				used_logo.setVisibility(View.VISIBLE);
				idnow_logo_retries_screen.setVisibility(View.VISIBLE);
			}
			else {
				used_logo.setVisibility(View.GONE);
				idnow_logo_retries_screen.setVisibility(View.GONE);
			}

			if(Config.DARK_MODE){
				Util_UtilUI.setColorLottieAnimation(Color.WHITE,used_logo,"SecondaryVariant");
				Util_UtilUI.setColorLottieAnimation(Color.WHITE,idnow_logo_retries_screen,"SecondaryVariant");
			}
			else {
				Util_UtilUI.setColorLottieAnimation(R.color.logo_fill,used_logo,"SecondaryVariant");
				Util_UtilUI.setColorLottieAnimation(R.color.logo_fill,idnow_logo_retries_screen,"SecondaryVariant");
			}
			progressBar = findViewById(android.R.id.progress);
			progressBar.getIndeterminateDrawable().setColorFilter(getResources().getColor(R.color.primaryColor), Mode.MULTIPLY);

			layout_overview_video_ident_plus.setVisibility(View.VISIBLE);
			layout_overview_video_ident.setVisibility(View.GONE);

			nextButton_vip = findViewById(R.id.startident_vip);
			Util_UtilUI.setProceedButtonBackgroundSelector(nextButton_vip);
			editTextMobileNr_vip = findViewById(R.id.editTextPhoneNr_vip);
			editTextEmail_vip = findViewById(R.id.editTextemail_vip);

			editTextMobileNr_vip.setEnabled(!Config.MOBILE_NUMBER_CHANGE_DISABLED);
			editTextEmail_vip = findViewById(R.id.editTextemail_vip);

			checkbox_phone_vip = findViewById(R.id.checkbox_phone_vip);
			checkbox_email_vip = findViewById(R.id.checkbox_email_vip);
			checkbox_consent_vip = findViewById(R.id.checkbox_consent_vip);

			checkbox_phone_vip.setOnCheckedChangeListener((compoundButton, b) -> {
				if (editTextMobileNr_vip.getText().toString().isEmpty())
					checkbox_phone_vip.setChecked(false);
				handleIdentificationButtonActivation();
			});

			checkbox_consent_vip.setOnCheckedChangeListener((compoundButton, b) -> {
				handleIdentificationButtonActivation();
			});
			nextButton_vip.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CONTINUE, LOCAL_KEY_VIDEO_IDENT_PLUS_CONTINUE));

			sCountry = findViewById(R.id.sCountry);

			sCountry.setVisibility(View.VISIBLE);

			initVideoIdent();

			// close the keyboard when clicked anywhere else but on the edittext
			super.setupUI(findViewById(R.id.main));
		}
		else {
			context = this;

			if(!Config.CHECK_BOX_ORIENTATION_RIGHT){
				layout_overview_video_ident.setVisibility(View.VISIBLE);
				layout_overview_video_ident_plus.setVisibility(View.GONE);
			}

			imagesToCheckList = new ArrayList<>();

			progressBar = findViewById(android.R.id.progress);
			progressBar.getIndeterminateDrawable().setColorFilter(getResources().getColor(R.color.primary), Mode.MULTIPLY);

			nextButton = findViewById(R.id.buttonNext);
			editTextMobileNr = findViewById(R.id.editTextPhoneNr);
			editTextEmail = findViewById(R.id.editTextEmail);


			nextButton.setText(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_MOBILE_CONSENT_BUTTON_START_IDENT,LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_BUTTON_START_IDENT));

			editTextMobileNr.setHint(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_IDENTCODE_PHONE_NUMBER_TITLE,LOCAL_KEY_VIDEO_IDENT_IDENTCODE_PHONE_NUMBER_TITLE));

			editTextMobileNr.setEnabled(!Config.MOBILE_NUMBER_CHANGE_DISABLED);

			initLayout();

			// close the keyboard when clicked anywhere else but on the edittext
			super.setupUI(findViewById(R.id.main));
		}

	}

	@Override
	public void onResume()
	{
		progressBar.setVisibility( View.GONE );
		super.onResume();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
		super.onActivityResult(requestCode, resultCode, intent);
        Util_Log.w(LOGTAG, "onActivityResult: requestCode=" + requestCode + " resultCode=" + resultCode);
		if (requestCode == IDnowSDK.REQUEST_ID_NOW_SDK) {
			if (resultCode == IDnowSDK.RESULT_CALL_QUALITY_DONE) {
				Util_Log.i(LOGTAG, "Call Quality Check finished");
				handleNextButtonClicked();
			} else if (resultCode != IDnowSDK.RESULT_CODE_INTERNAL) {
				// Means some important callback from the SDK came along. Pass it on and terminate
				IDnowSDK.getInstance().deliverResult(resultCode, intent);
				setResult(resultCode, intent);
				finish();
			} else {
				// Usually just a back button press in the called activity
				// Do nothing.
			}
		}
	}

	@Override
	public void onBackPressed() {
		Config.CALL_QUALITY_CHECK_PASSED = false;
		super.onBackPressed();

	}

	/**
	 * has to be overridden by the subclasses, to define their specific behavior
	 */
	public void initLayout()
	{
	}

	public void initVideoIdent()
	{
	}
	protected Boolean allCheckboxesSelected() {
		boolean isConsentBoxChecked = !Config.SHOW_GTC || checkbox_consent_vip.isChecked();

		if (!isConsentBoxChecked)
			return false;
		if (Config.IDENT_CODE_BY_EMAIL && !checkbox_email_vip.isChecked())
			return false;
		if (Config.IDENT_CODE_BY_SMS && !checkbox_phone_vip.isChecked())
			return false;

		return true;
	}

	// checks if all checkboxes are checked (then activate button) or not (then deactivate button)
	@SuppressWarnings("deprecation")
	public void handleIdentificationButtonActivation() {
		boolean dataValidated;
		Button nextBtn;
		if (Config.VIDEO_IDENT_PLUS) {
			dataValidated = allCheckboxesSelected();

			nextBtn = nextButton_vip;
		} else {
			dataValidated = true;
			if (imagesToCheckList != null) {
				for (int i = 0; i < imagesToCheckList.size(); i++) {
					if (!(Boolean) imagesToCheckList.get(i).getTag()) {
						Util_Log.d(LOGTAG, "tag :" + " " + imagesToCheckList.get(i).getTag());
						dataValidated = false;
						break;
					}
				}
			}
			nextBtn = nextButton;
		}

		boolean finalDataValidated = dataValidated;
		nextBtn.post(() -> {
			nextBtn.setEnabled(finalDataValidated);
		});
	}

	public void handleNextButtonClicked() {
		if (ConnectivityService.INSTANCE.isOnline()) {
			progressBar.setVisibility(View.VISIBLE);
            if (Config.INSTANT_SIGN) {
                updatePhoneNumber(USER_PHONE_NO);
            } else {
                fetchWaitingPositionAndDuration();
                checkForRuntimePermissions();
            }
        } else {
			Util_UtilUI.showNoConnectionDialog(context, false);
		}
	}

	public void handleNextButtonClicked_vip(boolean ignoreRetries) {
		// check for internet connectivity
		if (ConnectivityService.INSTANCE.isOnline()) {
			if ( editTextMobileNr_vip != null )
			{
				Config.USER_PHONE_NO = editTextMobileNr_vip.getText().toString();
			}
			if ( editTextEmail_vip != null )
			{
				if(!Config.AUTHENTICATED_SIGNED){
					Config.EMAIL_ADDRESS = editTextEmail_vip.getText().toString();
				}
			}

			progressBar.setVisibility( View.VISIBLE );

			if(Config.SHOW_PREPARE_SCREEN){
				Intent intent = new Intent(this,Activities_BeforeStartingActivity.class);
				startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
			}
			else {
				if (shouldShowCQC()) {
					doStartCQCActivity();
				}
				else {
					makeStartRESTCall(false);
				}
			}
		}
		else
		{
			Util_UtilUI.showNoConnectionDialog( context, false );
		}
	}

	private void checkForRuntimePermissions() {
		if (checkPermissionsGranted()){
			onPermissionsAlreadyGranted();
		}else{
			runWithPermissions(() -> {
				onPermissionsGranted();
				return null;
			});
		}
	}

	private void onPermissionsAlreadyGranted(){
		if (Config.VIDEO_IDENT_PLUS) {
			if (Config.INSTANT_SIGN) {
				updatePhoneNumber(USER_PHONE_NO);
			} else {
				if (Config.SHOW_PREPARE_SCREEN) {
					Intent intent = new Intent(this, Activities_BeforeStartingActivity.class);
					startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
				} else {
					if (shouldShowCQC()) {
						doStartCQCActivity();
					} else {
						makeStartRESTCall(false);
					}
				}
			}
		} else {
			startCallQualityCheckOrStartRest();
		}
	}

	private void onPermissionsGranted() {
		if (Config.AUTHENTICATED_POSSIBLE && !Config.RESTART_VIDEO_IDENT) {
			if (Config.INSTANT_SIGN) {
				updatePhoneNumber(USER_PHONE_NO);
			} else {
				makeStartRESTCall(true);
			}
		} else {
			if (Config.VIDEO_CONFIG_PVID_ENABLED && !CameraHelper.INSTANCE.checkResolutionSupport((long) Config.SUPPORTED_RESOLUTION)) {
				if (Config.INSTANT_SIGN) {
					updatePhoneNumber(USER_PHONE_NO);
				} else {
					Intent intent = new Intent(Activities_VideoOverviewCheckActivity_Super.this, Activities_DeviceSupportActivity.class);
					startActivity(intent);
				}
			} else {
				if (shouldShowCQC()) {
					if (Config.INSTANT_SIGN) {
						updatePhoneNumber(USER_PHONE_NO);
					} else {
						if (Config.SHOW_PREPARE_SCREEN) {
							Intent intent = new Intent(this, Activities_BeforeStartingActivity.class);
							startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
							return;
						}
						doStartCQCActivity();
					}
				} else {
					if (Config.INSTANT_SIGN) {
						updatePhoneNumber(USER_PHONE_NO);
					} else {
						fetchWaitingPositionAndDuration();
						makeStartRESTCall(true);
					}
				}

			}
		}
	}

	private boolean shouldShowCQC() {
		return Config.CALL_QUALITY_CHECK_ENABLED && !Config.CALL_QUALITY_CHECK_PASSED;
	}

	private void startCallQualityCheckOrStartRest() {
		if (Config.VIDEO_CONFIG_PVID_ENABLED && !CameraHelper.INSTANCE.checkResolutionSupport((long) Config.SUPPORTED_RESOLUTION)) {
			Intent intent = new Intent(Activities_VideoOverviewCheckActivity_Super.this, Activities_DeviceSupportActivity.class);
			startActivity(intent);
		} else {
			if (Config.AUTHENTICATED_POSSIBLE && !Config.RESTART_VIDEO_IDENT) {
				if (Config.INSTANT_SIGN) {
					updatePhoneNumber(USER_PHONE_NO);
				} else {
					makeStartRESTCall(true);
				}
			} else {
				if (Config.INSTANT_SIGN) {
					updatePhoneNumber(USER_PHONE_NO);
				} else {
					if (Config.SHOW_PREPARE_SCREEN) {
						Intent intent = new Intent(this, Activities_BeforeStartingActivity.class);
						startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
					} else {
						if (shouldShowCQC()) {
							doStartCQCActivity();
						} else {
							makeStartRESTCall(true);
						}
					}
				}
			}
		}
	}

	private void doStartCQCActivity() {
		Intent intent = new Intent(this, Util_VideoStreamService.getClassForCallQualityCheck());
		startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
	}

	/**
	 * call the live stream activity
	 */
	private void loadLiveScreen()
	{
		Intent intent = new Intent( context, Util_VideoStreamService.getClassForVideoLiveStreaming() );
		startActivityForResult( intent, IDnowSDK.REQUEST_ID_NOW_SDK );
	}


	// =========================
	// REST Calls
	// =========================


	public void cancelIdentRESTCall(){
		String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
		Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

		Callback<Object> callback = new Callback<Object>(){


			@Override
			public void success(Object resultObject, Response response) {
			}

			@Override
			public void failure(RetrofitError error) {
			}
		};


		Call<Object> result;
		result = service.identificationCanceled(new Models_EmptyJson(),
				IDnowSDK.getCompanyId(),
				IDnowSDK.getTransactionToken());

		result.enqueue(callback);

	}

	public void updatePhoneNumber(String phoneNumber){
		if(Config.OTP_DISPLAY_SIGNING){
            String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
            Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

			Callback<Models_MobileNumber> callback = new Callback<Models_MobileNumber>(){
				@Override
				public void success(Models_MobileNumber resultObject, Response response) {
					hideProgressbarAndLoadVideo();
				}

				@Override
				public void failure(RetrofitError error) {

				}
			};

			retrofit2.Call<Models_MobileNumber> result = service
					.updateMobileNumber(new Models_MobileNumber(phoneNumber),
							IDnowSDK.getCompanyId(),
							IDnowSDK.getTransactionToken()
					);
			result.enqueue(callback);
		}
		else {
			hideProgressbarAndLoadVideo();
		}



	}


	public void makeStartRESTCall(boolean ignoreRetries)
	{
		String localPhoneNumber;
		String localEmail;

		if(IDnowSDK.getInstance().isStartCallIssued()&&!Config.RESTART_VIDEO_IDENT) {

			Util_Log.i(LOGTAG, "start-Call already done, not reissuing it.");
			hideProgressbarAndLoadVideo();

			return;
		}

        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
		Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

		Callback<Models_StartObjectResult> callback = new Callback<Models_StartObjectResult>()
		{
			@Override
			public void failure( RetrofitError error )
			{

				String resultError, errorCause, errorType, errorID;

				resultError = Util_UtilRetrofit.printRetrofitError(error);
				errorCause  = Util_UtilRetrofit.getErrorCauseRetrofit(resultError);
				errorType  = Util_UtilRetrofit.getErrorTypeRetrofit(resultError);
				errorID = Util_UtilRetrofit.getErrorIdRetrofit(resultError);

				if(error != null && error.getResponse() != null && error.getResponse().getStatus() == 412) {
					if(errorType!= null && errorType.equals(DOCUSIGN_TOKEN_EXPIRING_SOON)) {
						Util_UtilUI.showRESTCallErrorDialog( context, error.getResponse().getStatus(), false, startRESTCallRunnable, errorID, true, false, resultError);
					} else {
						remainingInternalTokenRetries = 0;
						giveUserFeedback(remainingInternalTokenRetries);
					}
					return;
				}


				if(error != null && error.getResponse() != null && error.getResponse().getStatus() == 429) {
					Util_Log.d( LOGTAG, "Forced waiting list active." );
					progressBar.setVisibility(View.GONE);
					loadForcedWaitingScreen();
					return;
				}

				IDnowSDK.getInstance().setStartCallIssued(false);
				handleRestCallFailure( error );
			}

			@Override
			public void success(Models_StartObjectResult resultObject, Response response )
			{
				if(resultObject.getEnableOTPForWallet()!=null&&Config.AUTHENTICATED_POSSIBLE||Config.AUTHENTICATED_SIGNED){
					Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTPForWallet().isSigning();
					Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTPForWallet().isIdent();
				}
				else
				if(resultObject.getEnableOTP()!=null){
					Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTP().isSigning();
					Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTP().isIdent();
				}

				Config.IDENTIFICATION_SIGNATURE = resultObject.getRequest().getIdentification_Signature();

				if (resultObject.mobile!=null){
					Config.USER_PHONE_NO =  resultObject.mobile;
				}

				if(resultObject.email!=null){
					Config.EMAIL_ADDRESS =  resultObject.email;
				}

				Util_Log.d( LOGTAG, "success" );
				IDnowSDK.setForcedWaitingList(false);

				remainingInternalTokenRetries = resultObject.getRemainingInternalTokenRetries();
				Util_Log.d( LOGTAG, "remainingInternalTokenRetries = " + remainingInternalTokenRetries );

				// check if the configured video server is TokBox, which is not supported anymore
				String videoserver = resultObject         != null &&
						             resultObject.request != null &&
						             resultObject.request.getVideoserverUsed() != null ? resultObject.request.getVideoserverUsed() : null;

  				if(resultObject != null && resultObject.getRequest() != null) {
					Config.E_SIGNING_SECRET = resultObject.getRequest().getClientSecret();
					Config.USER_SESSION_TOKEN = resultObject.getRequest().getSessionToken();
				}

        		Util_VideoSessionConfig.setSessionIdAndToken(resultObject);

				if(remainingInternalTokenRetries == 1&&!ignoreRetries) {
					giveUserFeedback(remainingInternalTokenRetries);
				} else {
					IDnowSDK.getInstance().setStartCallIssued(true);
					hideProgressbarAndLoadVideo();
				}
			}
		};

		String token = IDnowSDK.getTransactionToken();
		Models_ClientInfo clientInfo = Util_Util.getClientInfo();



		String companyID = IDnowSDK.getCompanyId();

		if(!Config.USER_PHONE_NO.contains("***")){
			localPhoneNumber = Config.USER_PHONE_NO;
		}
		else {
			localPhoneNumber = null;
		}


		if(!Config.EMAIL_ADDRESS.contains("***")){
			localEmail = Config.EMAIL_ADDRESS;
		}
		else
		{
			localEmail = null;

		}

		Call<Models_StartObjectResult> result;
		if(Config.AUTHENTICATED_POSSIBLE&&!Config.RESTART_VIDEO_IDENT){
			result = service.start(new Models_StartObject(token,
										localPhoneNumber,
							null,
							localEmail,
							Config.PREFERRED_LANG,
							clientInfo,
							true),
					companyID,
					token);
		}
		else{
			result = service.start(new Models_StartObject(token,
							localPhoneNumber,
							localEmail,
							Config.PREFERRED_LANG,
							clientInfo, null),
					companyID,
					token);
		}
		result.enqueue(callback);
	}

	private void hideProgressbarAndLoadVideo() {
		progressBar.setVisibility(View.GONE);
		if(Config.HIDE_USERS_PII_DATA){
			Util_Util.getMaskedData(this);
		}else {
			loadLiveScreen();
		}
	}

	private void loadForcedWaitingScreen() {
		IDnowSDK.setForcedWaitingList(true);
		if(Config.HIDE_USERS_PII_DATA){
			Util_Util.getMaskedData(this);
		}else {
			loadLiveScreen();
		}
	}


	public void fetchWaitingPositionAndDuration()
	{
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint( endPoint, IDnowSDK.getInstance().getAppContext() );

		Callback<Models_OfficeHours> callback = new Callback<Models_OfficeHours>()
		{

			@Override
			public void failure( RetrofitError error )
			{
				handleRestCallFailure( error );
			}

			@Override
			public void success(Models_OfficeHours resultObject, Response response )
			{

				Util_Log.d( LOGTAG, "retrieving initial information about estimated waiting position/duration" );

				if ( resultObject != null )
				{
					Config.IDENT_ESTIMATED_WAITING_TIME = resultObject.getEstimatedWaitingTime();
					// we guesstimate that the position in the queue will be the number of waiting_chats + 1 (as there are X ppl in front of us, we will be at X+1)
					Config.IDENT_POSITION_IN_QUEUE = resultObject.getNumberOfWaitingChatRequests() + 1;
					Util_Log.d( LOGTAG, String.format( "initial information about waiting duration: %d and numberOfWaitingChatReq: %d", resultObject.getEstimatedWaitingTime(), resultObject.getNumberOfWaitingChatRequests() ) );
				}
				else
				{
					Util_Log.d( LOGTAG, "initial information about waiting pos and duration is null" );
				}
			}
		};

		Call<Models_OfficeHours> result = service.getCompanyShortname(IDnowSDK.getTransactionToken());
		result.enqueue(callback);
	}

	private void handleRestCallFailure(RetrofitError error) {
		progressBar.setVisibility(View.GONE);
		boolean hasErrorResponse = error.getResponse() != null;
		Util_UtilUI.showRESTCallErrorDialog(
				this,
				hasErrorResponse ? error.getResponse().status : 0,
				!hasErrorResponse,
				startRESTCallRunnable,
				Util_UtilRetrofit.getErrorIdRetrofit(error.getBody().getMessage()),
				hasErrorResponse,
				false,
				error.getBody().getMessage()
		);
	}

	protected @NonNull Boolean getCheckState(@NonNull String name){
		return checkStatesStati.get(name) != null? checkStatesStati.get(name) : false;
	}

	protected void setCheckState(@NonNull String name, @NonNull Boolean value){
		List<String> states = Arrays.asList(supportedCheckStates);
		if (states.contains(name)){
			checkStatesStati.put(name, value);
		}

	}

	private void giveUserFeedback(int remainingInternalTokenRetries) {

		switch (remainingInternalTokenRetries) {
			case 0:
				loadSpecificUI(remainingInternalTokenRetries);
				cancelAttemptUsing(main_button);
				break;
			case 1:
				loadSpecificUI(remainingInternalTokenRetries);
				proceedWithAttempt(remainingInternalTokenRetries);
				cancelAttemptUsing(secondary_button);
				break;
			default:
				break;
		}
	}

	private void cancelAttemptUsing(View button) {
		button.setOnClickListener(v -> {
			layout_overview_video_ident.setVisibility(View.VISIBLE);
			layout_overview_video_ident_plus.setVisibility(View.VISIBLE);
			token_retries_layout.setVisibility(View.GONE);
			if (!IDnowSDK.getOverrideEntryActivity()) {
				Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity.class;
			}
			Intent intent = new Intent(this, Config.HOST_APP_START_ACTIVITY);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
			this.finish();
			if((!Config.BACK_TO_VID)||IDnowSDK.getOverrideEntryActivity()){
				startActivity(intent);
			}
		});
	}

	private void proceedWithAttempt(int remainingInternalTokenRetries) {
		switch (remainingInternalTokenRetries) {
			case 0:
				cancelAttemptUsing(main_button);
				break;
			case 1:
				main_button.setOnClickListener(v -> {
					if (Config.VIDEO_IDENT_PLUS) {
						token_retries_layout.setVisibility(View.GONE);
						layout_overview_video_ident.setVisibility(View.GONE);
						layout_overview_video_ident_plus.setVisibility(View.VISIBLE);
					} else {
						token_retries_layout.setVisibility(View.GONE);
						layout_overview_video_ident.setVisibility(View.VISIBLE);
						layout_overview_video_ident_plus.setVisibility(View.GONE);
					}

					if (Config.VIDEO_IDENT_PLUS) {
						runWithPermissions(() -> {
							handleNextButtonClicked_vip(false);
							return null;
						});
					} else {
						// check for internet connectivity
						if (ConnectivityService.INSTANCE.isOnline()) {
							if (editTextMobileNr != null) {
								if (!editTextMobileNr.getText().toString().contains("***")) {
									Config.USER_PHONE_NO = editTextMobileNr.getText().toString();
								}
							}

							if (editTextEmail != null) {
								if (!Config.AUTHENTICATED_SIGNED) {
									if (!editTextEmail.getText().toString().contains("***")) {
										Config.EMAIL_ADDRESS = editTextEmail.getText().toString();
									}
								}
							}

							progressBar.setVisibility(View.VISIBLE);

                            fetchWaitingPositionAndDuration();
                            checkForRuntimePermissions();
                        } else {
							Util_UtilUI.showNoConnectionDialog(context, false);
						}
					}
				});
				break;
			default:
				break;
		}
	}

	private void loadSpecificUI(int remainingInternalTokenRetries) {

		layout_overview_video_ident.setVisibility(View.GONE);
		layout_overview_video_ident_plus.setVisibility(View.GONE);
		token_retries_layout.setVisibility(View.VISIBLE);

		switch (remainingInternalTokenRetries) {
			case 0:
				token_retries_title.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_TITLE, LOCAL_KEY_USER_FEEDBACK_BLOCKED_TITLE));
				token_retries_message.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_MESSAGE, LOCAL_KEY_USER_FEEDBACK_BLOCKED_MESSAGE));
				main_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_FINISH, LOCAL_KEY_USER_FEEDBACK_BLOCKED_FINISH));
				secondary_button.setVisibility(View.GONE);
				progressBar.setVisibility(View.GONE);
				break;
			case 1:
				token_retries_title.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TITLE, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TITLE));
				token_retries_message.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE));
				main_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN));
				secondary_button.setVisibility(View.VISIBLE);
				secondary_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER));
				progressBar.setVisibility(View.GONE);
				break;
			default:
				break;
		}
	}

	@Override
	protected void onStop() {

		Util_CustomLogData.onStop();

		super.onStop();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	@Override
	protected void onStart() {
		Util_CustomLogData.onStart(this);
		super.onStart();
	}

}
