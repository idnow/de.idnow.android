package de.idnow.sdk.Activities;

import static de.idnow.sdk.Config.VIDEO_IDENT_AGENT_FLOW;
import static de.idnow.sdk.util.Util_CustomLogData.EVENT_IDENTIFICATION_STATUS_SCREEN_SHOWN;
import static de.idnow.sdk.util.Util_Strings.KEY_INSTASIGN_FAILED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.KEY_INSTASIGN_FAILED_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_INSTASIGN_SUCCESS_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.KEY_INSTASIGN_SUCCESS_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_ABORT_FEEDBACK_THANKYOU;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_MESSAGE_FAILURE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_MESSAGE_SUCCESS;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_RESULT_FAILED_MSG;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_RESULT_FAILED_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_STATUS_SUCCESS;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_WAITING_LIST_BUTTON_DONE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_INSTASIGN_FAILED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_INSTASIGN_FAILED_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_INSTASIGN_SUCCESS_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_INSTASIGN_SUCCESS_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_ABORT_FEEDBACK_THANKYOU;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_MESSAGE_FAILURE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_MESSAGE_SUCCESS;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_RESULT_FAILED_MSG;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_RESULT_FAILED_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_STATUS_SUCCESS;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_WAITING_LIST_BUTTON_DONE;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

import de.idnow.sdk.Activities.entry.Activities_EntryActivity;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Models_StartObject;
import de.idnow.sdk.models.Models_StartObjectResult;
import de.idnow.sdk.network.Callback;
import de.idnow.sdk.network.IDnowRestClient;
import de.idnow.sdk.network.Network_RESTCalls;
import de.idnow.sdk.network.RetrofitError;
import de.idnow.sdk.util.IDnowErrorCode;
import de.idnow.sdk.util.Util_CustomLogData;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_Util;
import de.idnow.sdk.util.Util_UtilRetrofit;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.Util_UtilWebsocket;
import de.idnow.sdk.util.Util_VideoSessionConfig;
import de.idnow.sdk.util.Util_VideoStreamService;
import retrofit2.Call;
import retrofit2.Response;
/**
 * @author Mathias Grasy
 * @version 1.0
 * @brief this activity gets called from the liveStreamActivity in 2 different ways (successful or not successful).
 * The customer has different options: finish the process (Stack gets cleared and user is linked to StartScreen) or reconnect to session (only available if the
 * process hasn't been successful before).
 */
public class Activities_ResultActivity extends BaseActivity {
    private Context context;
    private LottieAnimationView resultImage;
    private TextView statusTextView;
    private TextView informationTextView;
    private boolean identificationSuccessful = false;
    private String identType = IDnowSDK.SessionType.VIDEO_IDENT.toString();
    private int resultCode;
    private IDnowErrorCode errorCode;

    private final static String LOGTAG = "IDNOW_Activities_ResultActivity";
    private TextView user_abort_feedback_thankyou;
    private LottieAnimationView result_logo;
    String instantSignFailedTitle = "";
    String instantSignFailedMessage = "";
    String failedTitle = "";
    String failedMessage = "";

    String successTitle = "";
    String instaSignSuccessTitle = "";
    String successMessage = "";
    String instantSignSuccessMessage = "";

    // ============================
    // LIFECYCLE
    // ============================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Config.REMAINING_TRIES=-1;

        if (IDnowSDK.preventScreenshot) {
            // secures against manual screenshots and automatic screenshots
            getWindow().setFlags(LayoutParams.FLAG_SECURE, LayoutParams.FLAG_SECURE);
        }

        setContentView(R.layout.activity_result);
        context = this;

        instantSignFailedTitle = Util_Strings.getStringWithDefault(context,KEY_INSTASIGN_FAILED_TITLE,LOCAL_KEY_INSTASIGN_FAILED_TITLE);
        instantSignFailedMessage = Util_Strings.getStringWithDefault(getApplicationContext(), KEY_INSTASIGN_FAILED_MESSAGE, LOCAL_KEY_INSTASIGN_FAILED_MESSAGE);
        failedTitle = Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_RESULT_FAILED_TITLE,LOCAL_KEY_VIDEO_IDENT_RESULT_FAILED_TITLE);
        failedMessage = Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_MESSAGE_FAILURE, LOCAL_KEY_VIDEO_IDENT_PLUS_MESSAGE_FAILURE).toUpperCase();
        successTitle = Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_STATUS_SUCCESS,LOCAL_KEY_VIDEO_IDENT_STATUS_SUCCESS);
        instaSignSuccessTitle = Util_Strings.getStringWithDefault(context,KEY_INSTASIGN_SUCCESS_TITLE,LOCAL_KEY_INSTASIGN_SUCCESS_TITLE);
        successMessage = Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_MESSAGE_SUCCESS, LOCAL_KEY_VIDEO_IDENT_PLUS_MESSAGE_SUCCESS);
        instantSignSuccessMessage = Util_Strings.getStringWithDefault(getApplicationContext(), KEY_INSTASIGN_SUCCESS_MESSAGE, LOCAL_KEY_INSTASIGN_SUCCESS_MESSAGE);

        user_abort_feedback_thankyou = findViewById(R.id.user_abort_feedback_thankyou);
        user_abort_feedback_thankyou.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_ABORT_FEEDBACK_THANKYOU, LOCAL_KEY_USER_ABORT_FEEDBACK_THANKYOU));

        if(Config.CALL_ABORT_REASON_SCREEN){
            user_abort_feedback_thankyou.setVisibility(View.VISIBLE);
        }
        result_logo = findViewById(R.id.result_logo);
        result_logo.setAnimation("static_logo.json");
        result_logo.playAnimation();
        if(Config.VIDEO_IDENT_PLUS){
            result_logo.setVisibility(View.VISIBLE);
            user_abort_feedback_thankyou.setVisibility(View.VISIBLE);
        }

        result_logo.setVisibility(IDnowSDK.getShowIDnowLogo() ? View.VISIBLE : View.GONE);

        if(Config.DARK_MODE){
            Util_UtilUI.setColorLottieAnimation(Color.WHITE,result_logo,"SecondaryVariant");

        }
        else{
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill,result_logo,"SecondaryVariant");
        }

        identificationSuccessful = getIntent().getBooleanExtra(Config.EXTRA_IDENTIFICATION_SUCCESSFUL, true);
        resultCode = getIntent().getIntExtra(Config.EXTRA_RESPONSE_CODE, -1);
        errorCode = (IDnowErrorCode) getIntent().getSerializableExtra(IDnowSDK.RESULT_ERROR_CODE);
        boolean userCanceled = getIntent().getBooleanExtra("userCanceled", false);

        if (getIntent().getStringExtra(Config.EXTRA_IDENT_TYPE) != null) {
            identType = getIntent().getStringExtra(Config.EXTRA_IDENT_TYPE);
        }

        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_NORMAL);
        initLayout();
        updateContent();

        if(Config.ENABLE_AGENT_FEEDBACK && !userCanceled && Config.AGENT_CONNECTED) {
            Intent agentFeedback = new Intent(context, Activities_AgentFeedbackActivity.class);
            startActivity(agentFeedback);
        }
    }

    // =====================
    // ACTIVITY METHODS
    // =====================

    private void setLastResultCodeAndFinish() {
        IDnowSDK.getInstance().setCallingActivity(null);

        if (!IDnowSDK.getOverrideEntryActivity()) {
            Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity.class;
        }
        Intent intent = new Intent(this, Config.HOST_APP_START_ACTIVITY);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int resultCode = identificationSuccessful ? IDnowSDK.RESULT_CODE_SUCCESS : this.resultCode;
        Intent resultIntent = getIntent();
        if (errorCode != null && this.resultCode == IDnowSDK.RESULT_CODE_FAILED) {
            resultIntent.putExtra(IDnowSDK.RESULT_ERROR_CODE, errorCode);
        }
        IDnowSDK.updateResultCode(resultCode);
        IDnowSDK.getInstance().deliverResult(resultCode, resultIntent);
        setResult(resultCode, resultIntent);
        finish();
        if(!Config.BACK_TO_VID || IDnowSDK.getOverrideEntryActivity()){
            startActivity(intent);
        }
        Config.BACK_TO_VID = false;
        return;
    }

    private void forwardResultAndFinish() {
        Intent intent = new Intent(this, Util_VideoStreamService.getClassForVideoLiveStreaming());
        startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);

        // no animation between activities
        overridePendingTransition(0, 0);
    }

    private final Runnable startRESTCallRunnable = new Runnable() {
        @Override
        public void run() {
            restartIdent();
        }
    };

    private void makeStartRESTCall() {

        String localPhoneNumber;
        String localEmail;

        if (IDnowSDK.getInstance().isStartCallIssued()) {
            Util_Log.i(LOGTAG, "start-Call already done, not reissuing it.");
            if(Config.HIDE_USERS_PII_DATA){
                Util_Util.getMaskedData(this);
            }
            else {
                forwardResultAndFinish();
            }
            return;
        }

        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());
        Callback<Models_StartObjectResult> callback = new Callback<Models_StartObjectResult>() {

            @Override
            public void failure(RetrofitError error) {
                String result = "";
                result = Util_UtilRetrofit.printRetrofitError(error);


                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                }

                if (error != null && error.getResponse() != null) {
                    Util_UtilUI.showRESTCallErrorDialog(context, error.getResponse().getStatus(), true, startRESTCallRunnable, result, true, false,"" );
                } else {
                    Util_UtilUI.showRESTCallErrorDialog(context, 0, true, startRESTCallRunnable, result, false, false,"" );
                }

                IDnowSDK.getInstance().setStartCallIssued(false);
            }

            @Override
            public void success(Models_StartObjectResult resultObject, Response response) {
                Config.IDENTIFICATION_SIGNATURE = resultObject.getRequest().getIdentification_Signature();

                if(resultObject.getEnableOTPForWallet()!=null&&Config.AUTHENTICATED_POSSIBLE||Config.AUTHENTICATED_SIGNED){
                    Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTPForWallet().isSigning();
                    Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTPForWallet().isIdent();
                }
                else
                if(resultObject.getEnableOTP()!=null){
                    Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTP().isSigning();
                    Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTP().isIdent();
                }

                if (resultObject.mobile!=null){
                    Config.USER_PHONE_NO =  resultObject.mobile;
                }

                if(resultObject.email!=null){
                    Config.EMAIL_ADDRESS =  resultObject.email;
                }

                Util_Log.d(LOGTAG, "success");

                int remainingInternalTokenRetries = resultObject.getRemainingInternalTokenRetries();
                Util_Log.d( LOGTAG, "remainingInternalTokenRetries = " + remainingInternalTokenRetries );

                // set the openTok configs
                Util_VideoSessionConfig.setSessionIdAndToken(resultObject);

                if (resultObject.getRequest() != null) {
                    Config.E_SIGNING_SECRET = resultObject.getRequest().getClientSecret();
                    Config.USER_SESSION_TOKEN = resultObject.getRequest().getSessionToken();
                }

                IDnowSDK.getInstance().setStartCallIssued(true);
                forwardResultAndFinish();

            }

        };

        String transactionToken = IDnowSDK.getTransactionToken();

        if(!Config.USER_PHONE_NO.contains("***")){
            localPhoneNumber = Config.USER_PHONE_NO;
        }
        else {
            localPhoneNumber = null;
        }

        if(!Config.EMAIL_ADDRESS.contains("***")){
            localEmail = Config.EMAIL_ADDRESS;
        }
        else
        {
            localEmail = null;

        }

        Models_StartObject startObject = new Models_StartObject(transactionToken, localPhoneNumber, localEmail, Config.PREFERRED_LANG, Util_Util.getClientInfo(), null);

        Util_Log.d(LOGTAG, "Start Called!");
        Call<Models_StartObjectResult> result = service.start(startObject, IDnowSDK.getCompanyId(), transactionToken);
        result.enqueue(callback);
    }

    public void restartIdent() {

        boolean startCQC = Config.CALL_QUALITY_CHECK_ENABLED && !Config.CALL_QUALITY_CHECK_PASSED;

        if (startCQC) {

            Intent intent = new Intent(this, Util_VideoStreamService.getClassForCallQualityCheck());
            startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);

        } else {

            makeStartRESTCall();

        }
    }

    private void initLayout() {
        Util_Util.setActivityTitle(context);

        Util_CustomLogData.setEventData(EVENT_IDENTIFICATION_STATUS_SCREEN_SHOWN,"EVENT_IDENTIFICATION_STATUS_SCREEN_SHOWN", "Identification Status Screen", "Screen",null);

        resultImage = findViewById(R.id.imageViewStatus);
        statusTextView = findViewById(R.id.textViewStatus);
        TextView transactionNrContentTextView = findViewById(R.id.textViewTransactionNrContent);
        transactionNrContentTextView.setText(IDnowSDK.getTransactionToken());
        informationTextView = findViewById(R.id.textViewInformation);

        Button doneButton = findViewById(R.id.buttonDone);
        doneButton.setText(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_WAITING_LIST_BUTTON_DONE,LOCAL_KEY_VIDEO_IDENT_WAITING_LIST_BUTTON_DONE));
        Util_UtilUI.setProceedButtonBackgroundSelector(doneButton);
        doneButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                IDnowSDK.setCallFromHighCallVolumeActivity(false, context);
                VIDEO_IDENT_AGENT_FLOW = false;
                Config.WALLET_LOGIN=false;
                onDoneButtonClick();
            }
        });

        if (IDnowSDK.SessionType.UNKNOWN.toString().equals(identType)) {
            doneButton.setVisibility(View.GONE);
        }

        Button retryButton = findViewById(R.id.buttonRetry);
        retryButton.setText(Util_Strings.getStringWithDefault(getApplicationContext(),KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN,LOCAL_KEY_VIDEO_IDENT_RESULT_BUTTON_TRY_AGAIN));
        Util_UtilUI.setProceedButtonBackgroundSelector(retryButton);
        retryButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                IDnowSDK.resetStativFieldsTryAgain();
                IDnowSDK.getInstance().setStartCallIssued(false);
                if(retryButton != null) {
                    retryButton.setEnabled(false);
                }

                if(doneButton != null) {
                    doneButton.setEnabled(false);
                }
                handleRetryButtonClicked();
            }
        });

        // hide retry button if identification was successful OR in case of foto ident
        if (identificationSuccessful ||
                IDnowSDK.SessionType.PHOTO_IDENT.toString().equals(identType) ||
                IDnowSDK.SessionType.UNKNOWN.toString().equals(identType)) {
            retryButton.setVisibility(View.GONE);
        }
    }

    private void onDoneButtonClick() {
        long idenDuration = SystemClock.uptimeMillis() - Util_UtilWebsocket.IDENT_START_TIME;
        boolean showRatingDialog = identificationSuccessful && (Config.REVIEW_TIME_LIMIT > -1) && (idenDuration / 1000) <= Config.REVIEW_TIME_LIMIT;

        if (!identificationSuccessful) {
            if (!IDnowSDK.getOverrideEntryActivity()) {
                Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity.class;
            }
            Intent intent = new Intent(this, Config.HOST_APP_START_ACTIVITY);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

            if (errorCode != null && this.resultCode == IDnowSDK.RESULT_CODE_FAILED) {
                intent.putExtra(IDnowSDK.RESULT_ERROR_CODE, errorCode);
            }
            IDnowSDK.updateResultCode(resultCode);
            IDnowSDK.getInstance().deliverResult(resultCode, intent);
            setResult(resultCode, intent);
            IDnowSDK.getInstance().setStartCallIssued(false);
            finish();
            return;
        }

        if (showRatingDialog) {
            IDnowSDK.showRatingDialog(context, new Runnable() {
                @Override
                public void run() {
                    setLastResultCodeAndFinish();
                }
            });
        } else {
            setLastResultCodeAndFinish();
        }
    }

    @SuppressLint("ResourceAsColor")
    private void updateContent() {
        if (identificationSuccessful) {
            String successTitle = Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_STATUS_SUCCESS,LOCAL_KEY_VIDEO_IDENT_STATUS_SUCCESS);
            String instaSignSuccessTitle = Util_Strings.getStringWithDefault(context,KEY_INSTASIGN_SUCCESS_TITLE,LOCAL_KEY_INSTASIGN_SUCCESS_TITLE);
            String successMessage = Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_MESSAGE_SUCCESS, LOCAL_KEY_VIDEO_IDENT_PLUS_MESSAGE_SUCCESS);
            String instantSignSuccessMessage = Util_Strings.getStringWithDefault(getApplicationContext(), KEY_INSTASIGN_SUCCESS_MESSAGE, LOCAL_KEY_INSTASIGN_SUCCESS_MESSAGE);

            if(Config.VIDEO_IDENT_PLUS){
                resultImage.setAnimation("static_step_id_scan_no_background.json");
                resultImage.playAnimation();
                if(Config.INSTANT_SIGN) {
                    statusTextView.setText(instaSignSuccessTitle);
                    informationTextView.setText(instantSignSuccessMessage);
                } else {
                    statusTextView.setText(successTitle);
                    informationTextView.setText(successMessage);
                }
            }
            else {
                resultImage.setImageDrawable(getResources().getDrawable(R.drawable.ic_result_success));
                statusTextView.setText(Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_STATUS_SUCCESS,LOCAL_KEY_VIDEO_IDENT_STATUS_SUCCESS));
                statusTextView.setTextColor(getResources().getColor(R.color.success));
            }
        } else {
            if(Config.VIDEO_IDENT_PLUS){
                resultImage.setAnimation("static_agent_id_fail.json");
                resultImage.playAnimation();
                if(Config.INSTANT_SIGN) {
                    statusTextView.setText(instantSignFailedTitle);
                    informationTextView.setText(instantSignFailedMessage);
                } else {
                    statusTextView.setText(failedTitle);
                    informationTextView.setText(failedMessage);
                }
            }
            else {
                resultImage.setImageDrawable(getResources().getDrawable(R.drawable.ic_result_failure));
                statusTextView.setText(Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_RESULT_FAILED_TITLE,LOCAL_KEY_VIDEO_IDENT_RESULT_FAILED_TITLE));
                statusTextView.setTextColor(getResources().getColor(R.color.failure));
            }
        }

        if (identificationSuccessful) {
            if (Config.SUCCESS_MESSAGE != null && !Config.SUCCESS_MESSAGE.isEmpty()) {
                if(Config.VIDEO_IDENT_PLUS){
                    if(Config.INSTANT_SIGN) {
                        informationTextView.setText(instantSignSuccessMessage);
                    } else {
                        informationTextView.setText(successMessage);
                    }
                }
                else {
                    informationTextView.setText(Config.SUCCESS_MESSAGE);
                }

            } else {

                if(Config.VIDEO_IDENT_PLUS){
                    if(Config.INSTANT_SIGN) {
                        informationTextView.setText(instantSignSuccessMessage);
                    } else {
                        informationTextView.setText(successMessage);
                    }
                }
                else {
                    informationTextView.setText(Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_STATUS_SUCCESS,LOCAL_KEY_VIDEO_IDENT_STATUS_SUCCESS));
                }

            }
        } else {
            if (resultCode > 0) {
                if(Config.VIDEO_IDENT_PLUS){
                    if(Config.INSTANT_SIGN) {
                        informationTextView.setText(instantSignFailedMessage);
                    } else {
                        informationTextView.setText(failedMessage);
                    }

                }
                else {
                    informationTextView.setText(Util_Strings.getErrorMessageForResponseCode(context, resultCode));

                }

            } else {
                if (Config.FAILURE_MESSAGE != null && !Config.FAILURE_MESSAGE.isEmpty()) {
                    if(Config.VIDEO_IDENT_PLUS){
                        if(Config.INSTANT_SIGN) {
                            informationTextView.setText(instantSignFailedMessage);
                        } else {
                            informationTextView.setText(failedMessage);
                        }
                    }
                    else {
                        informationTextView.setText(Config.FAILURE_MESSAGE);
                    }

                } else {

                    if(Config.VIDEO_IDENT_PLUS){
                        if(Config.INSTANT_SIGN) {
                            informationTextView.setText(instantSignFailedMessage);
                        } else {
                            informationTextView.setText(failedMessage);
                        }
                    }
                    else {
                        informationTextView.setText(Util_Strings.getStringWithDefault(context,KEY_VIDEO_IDENT_RESULT_FAILED_MSG,LOCAL_KEY_VIDEO_IDENT_RESULT_FAILED_MSG));
                    }
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == IDnowSDK.REQUEST_ID_NOW_SDK) {
            if (resultCode != IDnowSDK.RESULT_CODE_INTERNAL) {
                this.resultCode = resultCode;

                setLastResultCodeAndFinish();
            } else {
                // Usually just a back button press in the called activity
                // Do nothing.
            }
        }
    }

    @Override
    public void onBackPressed() {
        onDoneButtonClick();
    }

    // =========================
    // REST CALLS
    // =========================


    public void handleRetryButtonClicked()
    {
        try {
            IDnowSDK.getInstance().start(IDnowSDK.getTransactionToken());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        setResult(IDnowSDK.RESULT_CODE_FALLBACK_VID);
        IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE_FALLBACK_VID, getIntent());
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Util_CustomLogData.onStart(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        Util_CustomLogData.onStop();
    }
}

