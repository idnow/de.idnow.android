package de.idnow.sdk.Activities;

import static android.graphics.Color.WHITE;
import static de.idnow.sdk.IDnowSDK.RESULT_CODE_CANCEL;
import static de.idnow.sdk.util.Util_CustomLogData.EVENT_INSTRUCTION_SCREEN_SHOWN;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_FINISH;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_BEFORE_1;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_BEFORE_2;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_BEFORE_3;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_BEFORE_BUTTON;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_BEFORE_STARTING;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_FINISH;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_1;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_2;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_3;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_BUTTON;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BEFORE_STARTING;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.airbnb.lottie.LottieAnimationView;

import de.idnow.sdk.Activities.entry.Activities_EntryActivity;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Models_ClientInfo;
import de.idnow.sdk.models.Models_OfficeHours;
import de.idnow.sdk.models.Models_StartObject;
import de.idnow.sdk.models.Models_StartObjectResult;
import de.idnow.sdk.network.Callback;
import de.idnow.sdk.network.IDnowRestClient;
import de.idnow.sdk.network.Network_RESTCalls;
import de.idnow.sdk.network.RetrofitError;
import de.idnow.sdk.network.connectivityService.ConnectivityService;
import de.idnow.sdk.util.Util_CustomLogData;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_Util;
import de.idnow.sdk.util.Util_UtilRetrofit;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.Util_VideoSessionConfig;
import de.idnow.sdk.util.Util_VideoStreamService;
import retrofit2.Call;
import retrofit2.Response;

public class Activities_BeforeStartingActivity extends BaseActivity {

    Button vip_ready_button;
    TextView before_starting_title, vip_document_text, vip_well_text, vip_selfie_text;
    ProgressBar progressBar;
    Context context;
    LinearLayout document_layout, well_layout, selfie_layout, readyButtonLayout;

    ConstraintLayout before_starting_layout;

    //token retries user feedback
    private LinearLayout token_retries_layout;
    private TextView token_retries_title, token_retries_message, secondary_button;
    private Button main_button;

    private final String LOGTAG = "IDNOW_Activities_BeforeStartingActivity";

    private Intent onActivityResultIntent;

    LottieAnimationView document_gif, well_gif, ready_gif, token_retries_agent_image;

    private final Runnable startRESTCallRunnable = new Runnable() {
        @Override
        public void run() {
            fetchWaitingPositionAndDuration();
            makeStartRESTCall();
        }
    };
    private int remainingInternalTokenRetries = -1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Config.REMAINING_TRIES = -1;

        Util_CustomLogData.setEventData(EVENT_INSTRUCTION_SCREEN_SHOWN, "EVENT_INSTRUCTION_SCREEN_SHOWN", "Instructions screen", "Screen", null);

        setContentView(R.layout.actvity_before_starting);

        before_starting_layout = findViewById(R.id.before_starting_layout);
        // token retries layout user feedback
        token_retries_layout = findViewById(R.id.token_retries_layout);
        token_retries_title = findViewById(R.id.token_retries_title);
        token_retries_message = findViewById(R.id.token_retries_message);
        main_button = findViewById(R.id.main_button);
        secondary_button = findViewById(R.id.secondary_button);
        token_retries_agent_image = findViewById(R.id.token_retries_agent_image);

        token_retries_agent_image.setAnimation("static_agent_id_fail.json");
        token_retries_agent_image.playAnimation();

        if (Config.DARK_MODE) {
            Util_UtilUI.setColorLottieAnimation(WHITE, token_retries_agent_image, "SecondaryVariant");
        } else {
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, token_retries_agent_image, "SecondaryVariant");
        }

        context = this;
        vip_ready_button = findViewById(R.id.vip_ready_button);
        readyButtonLayout = findViewById(R.id.readyButtonLayout);
        vip_document_text = findViewById(R.id.vip_document_text);
        vip_well_text = findViewById(R.id.vip_well_text);
        vip_selfie_text = findViewById(R.id.vip_selfie_text);
        progressBar = findViewById(R.id.vip_starting_progressBar);
        progressBar.getIndeterminateDrawable().setColorFilter(getResources().getColor(R.color.primaryColor), PorterDuff.Mode.MULTIPLY);

        before_starting_title = findViewById(R.id.before_starting_title);
        document_gif = findViewById(R.id.document_gif);
        well_gif = findViewById(R.id.well_gif);
        ready_gif = findViewById(R.id.ready_gif);

        document_layout = findViewById(R.id.document_layout);
        well_layout = findViewById(R.id.well_layout);
        selfie_layout = findViewById(R.id.selfie_layout);

        document_gif.setAnimation("animate_step_id_scan.json");


        Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.primaryColor)), document_gif, "Shape Layer 2");
        document_gif.loop(true);

       /* document_gif.addValueCallback(
                new KeyPath( "**","Primary Variant"),
                LottieProperty.COLOR_FILTER,
                new SimpleLottieValueCallback<ColorFilter>() {
                    @Override
                    public ColorFilter getValue(LottieFrameInfo<ColorFilter> frameInfo) {
                        return new PorterDuffColorFilter(Color.GREEN, PorterDuff.Mode.SRC_ATOP);
                    }
                }
        );*/

        document_gif.playAnimation();

        well_gif.setAnimation("animate_step_agent.json");


        Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.primaryColor)), well_gif, "Shape Layer 2");


       /* well_gif.addValueCallback(
                new KeyPath( "**","Primary Variant"),
                LottieProperty.COLOR_FILTER,
                new SimpleLottieValueCallback<ColorFilter>() {
                    @Override
                    public ColorFilter getValue(LottieFrameInfo<ColorFilter> frameInfo) {
                        return new PorterDuffColorFilter(Color.GREEN, PorterDuff.Mode.SRC_ATOP);
                    }
                }
        );*/

        well_gif.playAnimation();

        ready_gif.setAnimation("animate_step_selfie.json");
        Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.primaryColor)), ready_gif, "Shape Layer 2");

       /* ready_gif.addValueCallback(
                new KeyPath( "**","Primary Variant"),
                LottieProperty.COLOR_FILTER,
                new SimpleLottieValueCallback<ColorFilter>() {
                    @Override
                    public ColorFilter getValue(LottieFrameInfo<ColorFilter> frameInfo) {
                        return new PorterDuffColorFilter(Color.GREEN, PorterDuff.Mode.SRC_ATOP);
                    }
                }
        ); */

        ready_gif.playAnimation();

        document_layout.setVisibility(View.GONE);
        well_layout.setVisibility(View.GONE);
        selfie_layout.setVisibility(View.GONE);
        vip_ready_button.setVisibility(View.GONE);

        vip_ready_button.setBackgroundResource(R.drawable.rounded_background_orange);

        vip_document_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_BEFORE_1, LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_1));
        vip_well_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_BEFORE_2, LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_2));
        vip_selfie_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_BEFORE_3, LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_3));
        before_starting_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BEFORE_STARTING, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BEFORE_STARTING));
        vip_ready_button.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_BEFORE_BUTTON, LOCAL_KEY_VIDEO_IDENT_PLUS_BEFORE_BUTTON));


        // Handler handler = new Handler()

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                document_layout.setVisibility(View.VISIBLE);

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        document_gif.loop(false);
                        well_layout.setVisibility(View.VISIBLE);

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                well_gif.loop(false);
                                selfie_layout.setVisibility(View.VISIBLE);
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        ready_gif.loop(false);

                                        vip_ready_button.setVisibility(View.VISIBLE);

                                    }
                                }, 1500);

                            }
                        }, 2000);

                    }
                }, 2000);
            }
        }, 2000);


        vip_ready_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleNextButtonClicked();
            }
        });
    }

    public void handleNextButtonClicked() {
        // check for internet connectivity
        if (ConnectivityService.INSTANCE.isOnline()) {
            progressBar.setVisibility(View.VISIBLE);

            fetchWaitingPositionAndDuration();
            proceedNextWithPermissionsGranted();
        } else {
            Util_UtilUI.showNoConnectionDialog(context, false);
        }
    }

    public void fetchWaitingPositionAndDuration() {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Models_OfficeHours> callback = new Callback<Models_OfficeHours>() {

            @Override
            public void failure(RetrofitError error) {
                handleRestCallFailure(error);
            }

            @Override
            public void success(Models_OfficeHours resultObject, Response response) {
                Util_Log.d(LOGTAG, "retrieving initial information about estimated waiting position/duration");

                if (resultObject != null) {
                    Config.IDENT_ESTIMATED_WAITING_TIME = resultObject.getEstimatedWaitingTime();
                    // we guesstimate that the position in the queue will be the number of waiting_chats + 1 (as there are X ppl in front of us, we will be at X+1)
                    Config.IDENT_POSITION_IN_QUEUE = resultObject.getNumberOfWaitingChatRequests() + 1;
                    Util_Log.d(LOGTAG, String.format("initial information about waiting duration: %d and numberOfWaitingChatReq: %d", resultObject.getEstimatedWaitingTime(), resultObject.getNumberOfWaitingChatRequests()));
                } else {
                    Util_Log.d(LOGTAG, "initial information about waiting pos and duration is null");
                }
            }
        };

        Call<Models_OfficeHours> result = service.getCompanyShortname(IDnowSDK.getTransactionToken());
        result.enqueue(callback);
    }

    private void proceedNextWithPermissionsGranted() {
        runWithPermissions(() -> {
            fetchWaitingPositionAndDuration();
            if (Config.AUTHENTICATED_POSSIBLE && !Config.RESTART_VIDEO_IDENT) {
                makeStartRESTCall();
            } else {
                if (shoudStartCQC()) {
                    doStartCQCActivity();
                } else {
                    makeStartRESTCall();
                }
            }
            return null;
        });
    }

    private void handleRestCallFailure(RetrofitError error) {
        progressBar.setVisibility(View.GONE);
        String resultError = "";
        String result = "";
        resultError = Util_UtilRetrofit.printRetrofitError(error);

        if (!result.equals("")) {
            result = Util_UtilRetrofit.getErrorIdRetrofit(resultError);
        }

        if (error != null && error.getResponse() != null) {
            Util_UtilUI.showRESTCallErrorDialog(context, error.getResponse().getStatus(), false, startRESTCallRunnable, result, true, false, resultError);

        } else {
            Util_UtilUI.showRESTCallErrorDialog(context, 0, true, startRESTCallRunnable, result, false, false, resultError);
        }
    }

    public void makeStartRESTCall() {

        String localPhoneNumber;
        String localEmail;

        if (IDnowSDK.getInstance().isStartCallIssued() && !Config.RESTART_VIDEO_IDENT) {
            Util_Log.i(LOGTAG, "start-Call already done, not reissuing it.");
            hideProgressbarAndLoadVideo();

            return;
        }

        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Models_StartObjectResult> callback = new Callback<Models_StartObjectResult>() {
            @Override
            public void failure(RetrofitError error) {
                String resultError, errorCause, errorType, errorID;

                resultError = Util_UtilRetrofit.printRetrofitError(error);
                errorCause = Util_UtilRetrofit.getErrorCauseRetrofit(resultError);
                errorType = Util_UtilRetrofit.getErrorTypeRetrofit(resultError);
                errorID = Util_UtilRetrofit.getErrorIdRetrofit(resultError);

                if (error != null && error.getResponse() != null && error.getResponse().getStatus() == 412) {
                    if (errorType != null && errorType.equals(IDnowSDK.DOCUSIGN_TOKEN_EXPIRING_SOON)) {
                        Util_UtilUI.showRESTCallErrorDialog(context, error.getResponse().getStatus(), false, startRESTCallRunnable, errorID, true, false, resultError);
                    } else {
                        remainingInternalTokenRetries = 0;
                        giveUserFeedback(remainingInternalTokenRetries);
                    }
                    return;
                }

                if (error != null && error.getResponse() != null && error.getResponse().getStatus() == 429) {
                    Util_Log.d(LOGTAG, "Forced waiting list active.");
                    progressBar.setVisibility(View.GONE);
                    loadForcedWaitingScreen();
                    return;
                }

                IDnowSDK.getInstance().setStartCallIssued(false);
                handleRestCallFailure(error);
            }

            @Override
            public void success(Models_StartObjectResult resultObject, Response response) {
                Config.IDENTIFICATION_SIGNATURE = resultObject.getRequest().getIdentification_Signature();

                if (resultObject.getEnableOTPForWallet() != null && Config.AUTHENTICATED_POSSIBLE || Config.AUTHENTICATED_SIGNED) {
                    Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTPForWallet().isSigning();
                    Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTPForWallet().isIdent();
                } else if (resultObject.getEnableOTP() != null) {
                    Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTP().isSigning();
                    Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTP().isIdent();
                }


                if (resultObject.mobile != null) {
                    Config.USER_PHONE_NO = resultObject.mobile;
                }

                if (resultObject.email != null) {
                    Config.EMAIL_ADDRESS = resultObject.email;
                }

                Util_Log.d(LOGTAG, "success");
                IDnowSDK.setForcedWaitingList(false);

                remainingInternalTokenRetries = resultObject.getRemainingInternalTokenRetries();
                Util_Log.d(LOGTAG, "remainingInternalTokenRetries = " + remainingInternalTokenRetries);


                if (resultObject != null && resultObject.getRequest() != null) {
                    Config.E_SIGNING_SECRET = resultObject.getRequest().getClientSecret();
                    Config.USER_SESSION_TOKEN = resultObject.getRequest().getSessionToken();
                }
                Util_VideoSessionConfig.setSessionIdAndToken(resultObject);

                if (remainingInternalTokenRetries == 1) {
                    giveUserFeedback(remainingInternalTokenRetries);
                } else {
                    IDnowSDK.getInstance().setStartCallIssued(true);
                    hideProgressbarAndLoadVideo();
                }

            }
        };

        String token = IDnowSDK.getTransactionToken();
        Models_ClientInfo clientInfo = Util_Util.getClientInfo();
        String companyID = IDnowSDK.getCompanyId();

        Call<Models_StartObjectResult> result;

        if (!Config.USER_PHONE_NO.contains("***")) {
            localPhoneNumber = Config.USER_PHONE_NO;
        } else {
            localPhoneNumber = null;
        }

        if (!Config.EMAIL_ADDRESS.contains("***")) {
            localEmail = Config.EMAIL_ADDRESS;
        } else {
            localEmail = null;
        }

        if (Config.AUTHENTICATED_POSSIBLE && !Config.RESTART_VIDEO_IDENT) {
            Util_Log.d(LOGTAG, "Start Called!");
            result = service.start(new Models_StartObject(token,
                            localPhoneNumber,
                            null,
                            localEmail,
                            Config.PREFERRED_LANG,
                            clientInfo,
                            true
                    ),
                    companyID,
                    token);
        } else {
            Util_Log.d(LOGTAG, "Start Called!");

            result = service.start(new Models_StartObject(token,
                            localPhoneNumber,
                            localEmail,
                            Config.PREFERRED_LANG,
                            clientInfo, null),
                    companyID,
                    token);
        }
        result.enqueue(callback);
    }

    private boolean shoudStartCQC() {
        return Config.CALL_QUALITY_CHECK_ENABLED && !Config.CALL_QUALITY_CHECK_PASSED;
    }

    private void doStartCQCActivity() {
        Intent intent = new Intent(this, Util_VideoStreamService.getClassForCallQualityCheck());
        startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
    }

    private void hideProgressbarAndLoadVideo() {
        progressBar.setVisibility(View.GONE);
        if (Config.HIDE_USERS_PII_DATA) {
            Util_Util.getMaskedData(this);
        } else {
            loadLiveScreen();
        }
    }

    /**
     * call the live stream activity
     */
    private void loadLiveScreen() {
        Intent intent = new Intent(context, Util_VideoStreamService.getClassForVideoLiveStreaming());
        startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
    }

    private void loadForcedWaitingScreen() {
        IDnowSDK.setForcedWaitingList(true);
        if (Config.HIDE_USERS_PII_DATA) {
            Util_Util.getMaskedData(this);
        } else {
            loadLiveScreen();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (IDnowSDK.RESULT_CODE == IDnowSDK.RESULT_CODE_CANCEL) {
            this.onBackPressed();
        }
        if (IDnowSDK.RESULT_CODE == IDnowSDK.RESULT_CODE_FAILED) {
            this.onBackPressed();
        } else if (IDnowSDK.RESULT_CODE == IDnowSDK.RESULT_CODE_SUCCESS || (resultCode == IDnowSDK.RESULT_CODE_SUCCESS)) {
            setResult(IDnowSDK.RESULT_CODE, data);
            IDnowSDK.getInstance().deliverResult(IDnowSDK.RESULT_CODE, data);
            Util_Util.clearApplicationData(context);
            finish();
        } else {
            if (requestCode == IDnowSDK.REQUEST_ID_NOW_SDK) {
                if (resultCode != IDnowSDK.RESULT_CODE_INTERNAL && resultCode != IDnowSDK.RESULT_CODE_CANCEL) {
                    // Means some important callback from the SDK came along. Pass it on and terminate
                    IDnowSDK.getInstance().deliverResult(resultCode, data);
                    setResult(resultCode, data);
                    Util_Util.clearApplicationData(context);
                    finish();
                } else {
                    // Usually just a back button press in the called activity
                    // Do nothing.
                }
            }
        }
    }

    private void giveUserFeedback(int remainingInternalTokenRetries) {

        switch (remainingInternalTokenRetries) {
            case 0:
                loadSpecificUI(remainingInternalTokenRetries);
                cancelAttemptUsing(main_button);
                break;
            case 1:
                loadSpecificUI(remainingInternalTokenRetries);
                proceedWithAttempt(remainingInternalTokenRetries);
                cancelAttemptUsing(secondary_button);
                break;
            default:
                break;
        }
    }

    private void cancelAttemptUsing(View button) {
        button.setOnClickListener(v -> {
            token_retries_layout.setVisibility(View.GONE);
            if (!IDnowSDK.getOverrideEntryActivity()) {

                Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity.class;
            }
            Intent intent = new Intent(this, Config.HOST_APP_START_ACTIVITY);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            this.finish();
            if ((!Config.BACK_TO_VID) || IDnowSDK.getOverrideEntryActivity()) {
                startActivity(intent);
            }
        });
    }

    private void proceedWithAttempt(int remainingInternalTokenRetries) {
        switch (remainingInternalTokenRetries) {
            case 0:
                cancelAttemptUsing(main_button);
                break;
            case 1:
                main_button.setOnClickListener(v -> {
                    token_retries_layout.setVisibility(View.GONE);
                    before_starting_layout.setVisibility(View.VISIBLE);
                    readyButtonLayout.setVisibility(View.VISIBLE);
                    IDnowSDK.getInstance().setStartCallIssued(true);
                    hideProgressbarAndLoadVideo();
                });
                break;
            default:
                break;
        }
    }

    private void loadSpecificUI(int remainingInternalTokenRetries) {

        before_starting_layout.setVisibility(View.GONE);
        readyButtonLayout.setVisibility(View.GONE);
        token_retries_layout.setVisibility(View.VISIBLE);

        switch (remainingInternalTokenRetries) {
            case 0:
                token_retries_title.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_TITLE, LOCAL_KEY_USER_FEEDBACK_BLOCKED_TITLE));
                token_retries_message.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_MESSAGE, LOCAL_KEY_USER_FEEDBACK_BLOCKED_MESSAGE));
                main_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_FINISH, LOCAL_KEY_USER_FEEDBACK_BLOCKED_FINISH));
                secondary_button.setVisibility(View.GONE);
                progressBar.setVisibility(View.GONE);
                break;
            case 1:
                token_retries_title.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TITLE, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TITLE));
                token_retries_message.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE));
                main_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN));
                secondary_button.setVisibility(View.VISIBLE);
                secondary_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER));
                progressBar.setVisibility(View.GONE);
                break;
            default:
                break;
        }
    }

    @Override
    public void onBackPressed() {

        if (Config.APP_ID.equals("com.commerzbank.ccbidn")) {
            Config.BACK_TO_VID = false;
            Intent backPressedIntent = new Intent();


            if ((IDnowSDK.RESULT_CODE != IDnowSDK.RESULT_CODE_FAILED)) {
                IDnowSDK.RESULT_CODE = IDnowSDK.RESULT_CODE_CANCEL;
            }

            if (IDnowSDK.RESULT_CODE == IDnowSDK.RESULT_CODE_CANCEL) {
                backPressedIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, getString(IDnowSDK.MESSAGE_USER_CANCELED));
            } else {
                if (onActivityResultIntent != null && onActivityResultIntent.hasExtra(IDnowSDK.RESULT_ERROR_CODE)) {
                    setResult(IDnowSDK.RESULT_CODE, onActivityResultIntent);
                    finish();
                } else {
                    backPressedIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, getString(IDnowSDK.MESSAGE_ID_FAILED));
                }
            }

            backPressedIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
            setResult(IDnowSDK.RESULT_CODE, backPressedIntent);
            finish();
        } else {
            Intent backPressedIntent = new Intent();
            backPressedIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            IDnowSDK.updateResultCode(RESULT_CODE_CANCEL);
            IDnowSDK.getInstance().deliverResult(RESULT_CODE_CANCEL, backPressedIntent);
            setResult(RESULT_CODE_CANCEL, backPressedIntent);
            finish();
        }
        super.onBackPressed();
    }

    @Override
    protected void onStop() {
        Util_CustomLogData.onStop();
        super.onStop();
    }

    @Override
    protected void onStart() {
        Util_CustomLogData.onStop();
        super.onStart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}