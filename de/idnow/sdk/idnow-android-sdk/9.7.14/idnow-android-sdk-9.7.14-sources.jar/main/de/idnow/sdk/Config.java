package de.idnow.sdk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.idnow.sdk.IDnowSDK.Server;
import de.idnow.sdk.models.Models_ApprovalPhrase;
import de.idnow.sdk.models.Models_PDFDocument;
import de.idnow.sdk.util.CheckboxForm;
import de.idnow.sdk.util.RemoteAnimationsCollection;
import de.idnow.sdk.util.Util_PhotoDataHolder;

/**
 * @author Mathias Grasy
 * @version 1.0
 */
public class Config
{

    public static  boolean VERIFY_IDENTITY = false ;
    public static  boolean ABORT_IDENT = false;
    public static Models_ApprovalPhrase[] MODEL_APPROVAL_PHRASES = {} ;
    public static  String USER_PHONE_NO_WALLET = "" ;
	public static  String EMAIL_ADDRESS_WALLET = "" ;

	public static boolean RESET_FIELD_EMAIL = false ;
	public static boolean RESET_FIELD = false;
	public static String AUTHADA_STAGING_URL = "" ;
	public static String AUTHADA_PRODUCTION_URL = "";
	public static boolean CHECK_SCREEN_LINES_LONG = false;
	public static boolean ENABLE_CHOOSE_EID_TYPE = false;

	// is overwritten during runtime
	public static Server CURRENT_SERVER = Server.DEV;

	public static boolean SHOW_TOKEN_DURING_CHECK_SCREEN = false;

	public static boolean VIDEOSERVER_DISABLED = false;

	public static final String DEBUG_TAG = "IDNOW";

	public static boolean E_SIGNING              = false;
	public static boolean E_SIGNING_IN_PROGRESS  = false;
	public static boolean E_SIGNING_HAND_WRITING = false;
	public static boolean E_SIGNING_ASK_FOR_USER_CONSENT = false;

	public static boolean OVERRIDE_BRANDING_COLOR = true;

	public static String E_SIGNING_SECRET = "";
	public static String USER_SESSION_TOKEN = "";

	// waiting informationE_SIGNING_HAND_WRITING
	public static int IDENT_ESTIMATED_WAITING_TIME = -1;
	public static int IDENT_POSITION_IN_QUEUE = -1;

	public static boolean CALL_QUALITY_CHECK_ENABLED = false;
	public static boolean CALL_QUALITY_CHECK_PASSED = false;
	public static int CALL_QUALITY_ARGS_WARM_UP = 3;
	public static int CALL_QUALITY_ARGS_MAX = 3;
	public static int CALL_QUALITY_ARGS_TIMEOUT = 40000;

	public static int REVIEW_TIME_LIMIT = -1;

	public static boolean CHECK_BOX_ORIENTATION_RIGHT = false;
	public static boolean CHECK_BOX_ORIENTATION_TOP = false;
	public static boolean CHECK_SCREEN_BOX_PHONENUMBER_REQUIRED = false;
	public static boolean CHECK_SCREEN_BOX_DOCUMENT_REQUIRED = false;
	public static boolean CHECK_SCREEN_BOX_EMAIL_REQUIRED = false;
	public static boolean CHECK_SCREEN_BOX_CONSENT_REQUIRED = false;
	public static boolean CHECK_SCREEN_EXPIRY_DATE_REQUIRED = false;
	public static boolean CHECKBOX_INSTRUCTIONS_SCREEN = true;
	public static boolean ONE_LINE_AGB = false;
	public static boolean HEADER_BOLDED = false;
	public static boolean SHOW_IMAGE_IN_RESULT_ACTIVITY = true;
	public static boolean CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED = false;

	public static boolean MOBILE_NUMBER_CHANGE_DISABLED = false;

	public static int SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE = 0;
	public static int VIDEO_MAX_DIMENSION_EDGE = 0;
	public static boolean SHOW_POWERED_BY_KEY = false;
	public static boolean SHOW_IDNOW_LOGO = false;

	public static boolean IS_Auto_Ident = false;
	public static boolean SHOW_REVIEW_GOOGLE_RATING = false;
	public static boolean HASH_SIGNING = false;
	public static boolean DTMAndPSM = false;
	public static boolean SHOW_REVIEW_GOOGLE_APPS_RATING = false;
	public static String  GOOGLE_RATING_LINK = "";
	public static boolean SHOW_APP_GOOGLE_RATING = false;


	public static boolean WAITING_LIST_NOTIFICATIONS_ENABLED = false;
	public static String WAITING_LIST_NOTIFICATIONS_CHANNEL = "";
	public static int WAITING_LIST_NOTIFICATIONS_TIMEOUT = -1;
	public static int WAITING_LIST_NOTIFICATIONS_TRESHOLD = -1;
	public static int WAITING_LIST_NOTIFICATIONS_ENFORCED_TRESHOLD = -1;

	// High call volume
	public static boolean SHOW_HIGH_CALL_VOLUME = false;

	// Has been notified by SMS/Push
	public static boolean WAITING_LIST_NOTIFICATIONS_FROM_QUEUE = false;
	// Is enrolled
	public static boolean WAITING_LIST_NOTIFICATIONS_ENROLLED = false;

	public static boolean IDENT_CODE_AUTO_FILL = false;

	public static String FIREBASE_NOTIFICATION_TOKEN = null;

	public static boolean IDENT_CODE_REQUIRED = true;

	public static boolean SHOW_NAME_VERIFICATION_SCREEN = false;

	// Waiting screen flags
	public static boolean SHOULD_DISPLAY_WAITING_SCREEN = false;
	public static boolean SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED= false;
	public static long DISPLAY_WAITING_SCREEN_CUSTOMISED_TIMER = 200000;
	public static int WAITING_SCREEN_PAGE_TRANSITION_DURATION_IN_MS = 1000;
	public static int WAITING_SCREEN_FIRST_PAGE_SPINNER_DURATION_IN_MS = 2000;

	public static Models_PDFDocument[] PDF_DOCUMENTS;
	public static String OPENTRUST_URL = "";

	public static final String API_NAMESPACE        = "api/v1/";
	public static final String API_NAMESPACE_SOCKET = "/api/v1/identifications/";

	// socket commands
	public static final String COMMAND_FINISHED                   = "finished";
	public static final String COMMAND_FINISHED_FACE              = "finishedFace";
	public static final String COMMAND_INITIAL_COMPARISON_DONE    = "initialComparisonDone";
	public static final String COMMAND_FINISHED_ID_TYPE           = "finishedIdType";
	public static final String COMMAND_FINISHED_ID_FRONTSIDE      = "finishedIdFrontside";
	public static final String COMMAND_FINISHED_ID_BACKSIDE       = "finishedIdBackside";
	public static final String COMMAND_WIGGLE_DONE                = "wiggleDone";
	public static final String COMMAND_ID_NUMBER_DONE             = "idNumberDone";
	public static final String COMMAND_FINISHED_CENSORING_FRONT   = "finishedCensoringFront";
	public static final String COMMAND_FINISHED_CENSORING_BACK    = "finishedCensoringBack";
	public static final String COMMAND_FINISHED_INTEGRITY_ID_DATA = "finishedIntegrityIdData";
	public static final String COMMAND_FINISHED_INTEGRITY_MRZ     = "finishedIntegrityMrz";
	public static final String COMMAND_TAN_DONE                   = "tanDone";
	public static final String COMMAND_CONNECTING                 = "connecting";
	public static final String COMMAND_FAILED                     = "failed";
	public static final String COMMAND_FLASHLIGHT                 = "showHelp";
	public static final String COMMAND_FOCUS                      = "focus";
	public static final String COMMAND_CONNECTION_ESTABLISHED     = "connectionEstablished";
	public static final String COMMAND_SCREENSHOT                 = "takeScreenshot";
	public static final String COMMAND_DO_USER_STEP = "doUserStep";
	public static final String COMMAND_AGENT_CONNECTED            = "agentConnected";
	public static final String COMMAND_SWITCH_CAMERA              = "switchCamera";
	public static final String COMMAND_WAITING_FOR_REVIEW = "waitingForReview";


// video ident + config

	public static String VIDEO_IDENT_PLUS_ID_FRONT_SIDE = "idfrontside";
	public static String VIDEO_IDENT_PLUS_ID_BACK_SIDE = "idbackside";
	public static String VIDEO_IDENT_PLUS_ID_SELFIE = "selfie";
	public static String VIDEO_IDENT_PLUS_STATUS = "";

	public static String VIDEO_IDENT_ACTION_TAKE_PICTURE = " takepicture";
	public static String VIDEO_IDENT_ACTION_RETAKE_PICTURE = "retakepicture";
	public static String VIDEO_IDENT_ACTION_CONTINUE = "continue";




	public static String HIGH_VOLUME_MESSAGE_FROM_SERVER = "";

	// USERSTEP SIGNATURE
	public static String DO_USER_STEP_EXPLANATION_TITLE = "";
	public static String DO_USER_STEP_EXPLANATION_CONTENT = "";
	public static String DO_USER_STEP_CAMERA_TO_USE = "";
	public static String DO_USER_STEP_TYPE = "";


	// E-SIGNING
	public static final String  COMMAND_START_ESIGNING = "startESigning";
	// TODO read the value from the server call.
	public static       boolean USE_NATIVE_ESIGNING    = false;

	// Text Chat
	public static final String COMMAND_CHAT_MESSAGE = "chatMessage";
	public static boolean LOG_INITIATED= false;


	public enum OverridableColorType {
		BACKGROUND, FOREGROUND, TEXT
	}

	public static Map<IDnowSDK.OverridableUIElement, Map<String, String>> overridableColorsMap = new HashMap<>();


	public static final Map<String, Integer> EXPLANATION_STEP_PER_SOCKET_RESPONSES = new HashMap<>();

	static
	{
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_CONNECTING, 0 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_CONNECTION_ESTABLISHED, 1 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_INITIAL_COMPARISON_DONE, 1 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_FINISHED_FACE, 2 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_FINISHED_ID_TYPE, 2 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_FINISHED_ID_FRONTSIDE, 3 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_FINISHED_ID_BACKSIDE, 4 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_WIGGLE_DONE, 5 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( "", 6 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_ID_NUMBER_DONE, 7 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_FINISHED_CENSORING_FRONT, 7 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_FINISHED_CENSORING_BACK, 7 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_FINISHED_INTEGRITY_ID_DATA, 7 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_FINISHED_INTEGRITY_MRZ, 7 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put( COMMAND_TAN_DONE, 8 );
		EXPLANATION_STEP_PER_SOCKET_RESPONSES.put(COMMAND_DO_USER_STEP, 25);
	}

	// random number
	public static final int NOTIFICATION_ID = 1010101013;

	public static String USER_PHONE_NO = "";
	public static String MASKED_USER_PHONE_NO = "";
	public static String TEST_ROBOT_TYPE;

	public static String PREFERRED_LANG = "";
	public static boolean VERIFY_PHONE_NO = false;

	public static final String EXTRA_IDENTIFICATION_SUCCESSFUL = "identification_successful";
	public static final String EXTRA_IDENT_TYPE = "ident_type";
	public static final String EXTRA_RESPONSE_CODE = "response_code";

	// timeout for videosession reconnect
	public static int RECONNECTION_TIMEOUT = 15;
	public static long FIST_SOCKET_CONNECTION = 0L;
	public static int SOCKET_TRIES = 0;

	public static boolean IDENT_CODE_BY_EMAIL = false;
	public static String  EMAIL_ADDRESS       = "";

	public static String FIRST_NAME = "";

	public static String LAST_NAME = "";
	public static String MASKED_EMAIL_ADDRESS = "";

	public static boolean IDENT_CODE_BY_SMS = false;

	// =====================
	// PHOTO IDENT
	// =====================
	public enum IDENTIFICATION_MODE
	{
		VIDEO, PHOTO
	}

	public static String PHOTO_IDENT_VIDEO_FILENAME = "/hologramvideo.mp4";

	// in seconds
	public static int PHOTO_IDENT_VIDEO_DURATION = 30;

	public static IDENTIFICATION_MODE ID_MODE = IDENTIFICATION_MODE.PHOTO;

	public static boolean SHOW_GTC                 = false;
	public static boolean SHOW_RECORDING_AGREEMENT = true;

	public static String FAILURE_MESSAGE = "";
	public static String SUCCESS_MESSAGE = "";
	public static String SUCCESS_URL     = "";
	public static String FAILURE_URL     = "";
	public static String FALLBACK_URL    = "";
	public static String TERMS_TEXT      = "";

	public static Class HOST_APP_START_ACTIVITY;
	public static CertificateProvider CERTIFICATE_PROVIDER = null;

	//dtls certificate provider
	public static CertificateProvider DTLS_CERTIFICATE = null;
	public static CertificateProvider DTLS_CERTIFICATE_OVER_UDP = null;

	public static CheckboxForm CHECKBOX_FORM = CheckboxForm.OVAL;

	public static Boolean FULL_SIZE_MODAL_SMS_WINDOW = true;

	public static Boolean TRANSPARENT_BACKGROUND_MODAL_SMS_WINDOW = false;

	/**
	 * Specify an alpha value for the drawable. 0 means fully transparent, and
	 *      * 255 means fully opaque.
	 */
	public static int TRANSPARENT_ALPHA_VALUE = 230;

	public static boolean WHITE_AGENT_THUMBNAIL_BACKGROUND = false;

	public static boolean AUTHENTICATED_SIGNED = false;
	public static boolean AUTHENTICATED_POSSIBLE = false;
	public static boolean EXPIRED_WALLET_EXISTS = false;
	public static boolean ERROR_LOGIN = false;
	public static boolean SUCCESS_LOGIN = false;
	public static boolean RESTART_VIDEO_IDENT = false;
	public static String SENTRY_DSN = "";
	public static boolean SHOW_CONTRACT_AGAIN = false;
	public static boolean ESIGN_UPDATE_PHONE_NUMBER=false;
	public static boolean START_ESIGNING=false;
	public static boolean CREATE_IDENT_RECORD_ATRUST = false;
	public static String REDIRECT_URL = "";


	public static String GET_CURRENT_SERVER_API_HOST()
	{
		return CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
	}

	public static int VIDEO_CONFIG_HEIGHT = 0;
	public static int VIDEO_CONFIG_WIDTH = 0;
	public static int VIDEO_CONFIG_FRAME_RATE = 0;
	public static int VIDEO_CONFIG_SCREENSHOT_WIDTH = 0;
	public static int VIDEO_CONFIG_SCREENSHOT_HEIGHT = 0;
	public static int VIDEO_CONFIG_PRE_ESTABLISH_RETRY_COUNT = -1;
	public static Boolean CHECK_NETWORK = true;
	public static boolean VIDEO_IDENT_PLUS = false;
	public static boolean VIDEO_IDENT_PLUS_UI = false;
	public static boolean VIDEO_IDENT_PLUS_IDImage = false;
	public static boolean VIDEO_IDENT_PLUS_SEGMENTATIONANDCLASSIFICATION = false;
	public static boolean VIDEO_IDENT_PLUS_DOCUMENT_CHECKING = false;
	public static boolean VIDEO_IDENT_PLUS_SELFIE_IMAGE = false;
	public static boolean VIDEO_IDENT_PLUS_REUSE_IMAGES = false;

	public static String VIDEO_IDENT_PLUS_COUNTRY = "Germany";

	public static Util_PhotoDataHolder.DocumentImages ID_DOCUMENT = Util_PhotoDataHolder.DocumentImages.idfrontside;
	public static boolean TAKE_PICTURE_LAYOUT=false;
	public static boolean CANT_CAPTURE_ID = false;



	public static boolean NFC_SUPPORT = false;
	public static boolean EID_CONFIG = false;
	public static boolean BANKID_CONFIG = false;


	public static String MESSAGE_USER_CANCEL_EID = "Identification candeled eid";
	public static int USER_CANCEL_EID_CODE = 10;
	public static int USER_BACK_HOME_EID_CODE = 12;
	public static boolean BACK_TO_VID = false;
	public static boolean OFFICE_HOUR = false;
	public static boolean PHONE_NUMBER_MAN_CHANGED = false;

	public static Util_PhotoDataHolder.DocumentImages DOCUMENT_IMAGES;
	public static Util_PhotoDataHolder.DocumentTypes DOCUMENT_TYPES;

	public static int ORIENTATION_VALUE ;

	public static boolean WAITING_DONE = false;
	public static String SAVED_TOKEN = "";
	public static boolean RETRY_FLOW = false;
	public static Boolean RETRY = false;
	public static Boolean RETRY_UPLOAD = false;
	public static Boolean CHECK_UPLOAP = false;
	public static Boolean WALLET_VIP = false;
	public static Boolean WALLET_REGISTRATION = false;
	public static Boolean WALLET_LOGIN = false;
	public static Boolean NORMAL_ESIGN = false;
	public static Boolean NORMAL_VIDEO_IDENT = false;
	public static Boolean VIDEO_IDENT_AGENT_FLOW = false;
	public static Boolean VIDEO_IDENT_BACKGROUND = false;
	public static Boolean ENABLE_AGENT_FEEDBACK = false;
	public static Boolean AGENT_CONNECTED = false;
	public static Boolean IDENT_STATUS = false;
	public static Boolean USER_CANCEL = false;
	public static Boolean DARK_MODE = false;
	public static Number MISSING_IMAGES = -1;
	public static Boolean ALL_PHOTO_USED = false;
	public static Boolean ONLY_BACK_SIDE_NULL = false;
	public static Boolean LOAD_URL = false;
	public static String CUSTOM_LOG_URL = "";
	public static String CUSTOM_LOG_APPKEY = "";
	public static int CQC_STATUS=0;
	public static int REMAINING_TRIES=-1;
	public static String SCREEN = "";
	public static Boolean DARK_MODE_ENABLED_CUSTOMER = true ;
	public static boolean AUTHENTICATED_SIGNING_HIDE_OPTION_TO_CONTINUE_WITHOUT_WALLET = false;
	public static String IDENTIFICATION_SIGNATURE="";
	public static String URL_DOCUMENT_NAMIRIAL = "";
	public static String APP_ID = "";
	public static Boolean EID_REROUTING=false;
	public static  Map<String, String> MESSAGES;

	public static RemoteAnimationsCollection REMOTE_ANIMATIONS;
	public static boolean ENABLE_ID_CAPTURE_EID = false;
	public static boolean ENABLE_PIN_CHANGE = false;
	public static boolean ENABLE_EID_STANDALONE = false;
	public static boolean CALL_ABORT_REASON_SCREEN = false;
	public static String [] USER_CANCELLATION_ENUM;
	// Tracks the current VideoIdent+ step, updated as each screen appears.
	public static String CANCELATION_STEP = null;
	// The step frozen at the moment the user cancels, delivered to the integrator once
	// at the final result screen (RESULT_CANCEL_STEP). Null when not canceled.
	public static String CANCELED_AT_STEP = null;
	public static String ALERT_DIALOG_TO_SHOW = "";
	public static boolean ENABLE_QES_EID = false;

	public static boolean SHOW_PREPARE_SCREEN = true;
	public static boolean VIDEO_CONFIG_PVID_ENABLED = false;
	public static float SUPPORTED_RESOLUTION = 0;
	public static int SOCKET_RECONNECT_INTERVAL = 0;
	public static int SOCKET_RECONNECT_ATTEMPTS = 0;
	public static boolean SOCKET_ENABLED = false;
	public static boolean ENABLE_BLUETOOTH_AUDIO = false;
	public static boolean HIDE_USERS_PII_DATA = false;
	public static boolean COBA_CUSTOMISED = false;
	public static boolean SHOW_DIALOGS_WITH_ICON = true;

	public static boolean INSTANT_SIGN = false;

	public static boolean STORED_IDENTITY_SCREEN = false;

	public static List<String> AGREEMENTS = new ArrayList<>();
	public static String INSTANTERROR_TYPE="";
	public static String EIDTSP = "";

	public static boolean ENABLE_PIP_ANDROID = false;
	public static final String SIGNATURE_CONTRACT_ACTION = "DOWNLOAD_SIGNATURE_CONTRACT";
	public static boolean ISSIGNATUREACTION=false;
	public static boolean OTP_DISPLAY_SIGNING = false;
	public static boolean OTP_DISPLAY_IDENT = false;

}