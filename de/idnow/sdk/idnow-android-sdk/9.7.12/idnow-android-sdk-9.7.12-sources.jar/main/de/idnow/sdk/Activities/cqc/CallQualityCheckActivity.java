package de.idnow.sdk.Activities.cqc;

import static de.idnow.sdk.Activities.cqc.CallQualityCheckActivity.CallQualityResult.EXCELLENT;
import static de.idnow.sdk.Activities.cqc.CallQualityCheckActivity.CallQualityResult.MODERATE;
import static de.idnow.sdk.Activities.cqc.CallQualityCheckActivity.CallQualityResult.UNKNOWN;
import static de.idnow.sdk.Config.CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED;
import static de.idnow.sdk.util.Util_CustomLogData.EVENT_CQC_SCREEN_SHOWN;
import static de.idnow.sdk.util.Util_Strings.KEY_CQC_ACTIVE_AUDIO;
import static de.idnow.sdk.util.Util_Strings.KEY_CQC_ACTIVE_NETWORK;
import static de.idnow.sdk.util.Util_Strings.KEY_CQC_ACTIVE_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_CQC_ACTIVE_VIDEO;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_FINISH;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_BLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN;
import static de.idnow.sdk.util.Util_Strings.KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CQC_MODERATE_1;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CQC_MODERATE_2;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CQC_MODERATE_3;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_BAD;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_BAD_1;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_BAD_2;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_DESC;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_MODERATE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_CQC_OTHER_STATUS;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_CQC_ACTIVE_AUDIO;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_CQC_ACTIVE_NETWORK;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_CQC_ACTIVE_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_CQC_ACTIVE_VIDEO;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_FINISH;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_BLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_1;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_2;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_3;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_1;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_2;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_DESC;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_MODERATE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_OTHER_STATUS;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import java.util.ArrayList;
import java.util.List;

import de.idnow.sdk.Activities.BaseActivity;
import de.idnow.sdk.Activities.entry.Activities_EntryActivity;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.Liveswitch.Conference;
import de.idnow.sdk.R;
import de.idnow.sdk.databinding.ActivityCallQualityCheckBinding;
import de.idnow.sdk.models.Model_ConferenceCallQualityMetrics;
import de.idnow.sdk.network.connectivityService.ConnectivityService;
import de.idnow.sdk.util.Util_CustomLogData;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_Util;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.Util_VideoStreamService;
import de.idnow.sdk.views.CallQualityLightView;
import de.idnow.sdk.views.LockableScrollView;
import fm.liveswitch.Candidate;
import fm.liveswitch.DataChannel;
import fm.liveswitch.DataChannelReceiveArgs;
import fm.liveswitch.Promise;
import fm.liveswitch.SessionDescription;

public class CallQualityCheckActivity extends BaseActivity {

    private CallQualityCheckViewModel viewModel;
    private ActivityCallQualityCheckBinding binding;

    private final static String LOGTAG = "CallQualityCheckActivity";

    private final Context context = this;

    // —— Views: shared layout roots ——
    private android.widget.RelativeLayout container;
    private android.widget.RelativeLayout containerSubscriber;
    private android.widget.RelativeLayout callQualityCheckRunningLayout;
    private android.widget.LinearLayout callQualityCheckResultLayout;
    private android.widget.Button callQualityResultButton;
    private android.widget.TextView callQualityRetryLink;
    private android.widget.ProgressBar progressBarLoading;
    private android.widget.ProgressBar callQualitySubscriberBar;
    private android.widget.TextView callQualityProgressText;
    private android.widget.TextView callQualityResultText;

    private Conference conference;

    // —— Views: old CQC ——
    private android.widget.ImageView callQualityImageConnection;
    private android.widget.ImageView callQualityImageAudio;
    private android.widget.ImageView callQualityImageVideo;
    private android.widget.TextView callQualityTitleText;
    private android.widget.TextView callQualityCheckBandwidthLabel;
    private android.widget.TextView callQualityAudioLabel;
    private android.widget.TextView callQualityVideoLabel;
    public android.widget.ProgressBar progressBar;
    private LockableScrollView scrollView;

    // —— Views: Fiducia customisation ——
    private android.widget.TextView title, description;
    private android.widget.Button retryCQC, actionCQC;
    private android.widget.LinearLayout linearlayoutAfterCQC;
    private View lineDivider;
    private android.widget.TextView description1, point1, point2, description2, description3, point3;

    public enum CallQualityResult {
        UNKNOWN,
        POOR,
        MODERATE,
        EXCELLENT;

        public int getInt() {
            return ordinal();
        }
    }

    private int callQualitySampleCounter = 0;
    private List<Integer> callQualitySampleList;

    // —— Views: CQC layout switchers ——
    public android.widget.RelativeLayout old_cqc, new_cqc, other_internet_connection;
    public android.widget.LinearLayout good_internet_connection;

    // —— Views: VIP connection labels ——
    public android.widget.TextView connection_vip_title, connection_vip_desc,
            connection_vip_good_1, connection_vip_good_2, connection_vip_good_3,
            connection_vip_other_title, connection_vip_status,
            connection_vip_other_desc_1, connection_vip_troubleshooting,
            connection_vip_other_desc_2, connection_vip_other_desc_3,
            connection_vip_other_result;
    public android.widget.Button connection_vip_other_button;

    // —— Views: Lottie animations ——
    public LottieAnimationView token_retries_agent_image, sfGifView,
            callQualityImageVideo_vip, callQualityImageAudio_vip,
            callQualityImageBandwith_vip, status_image,
            used_logo_cqc, used_logo_cqc_other, status_image_good;

    // —— Views: token retries user feedback ——
    private android.widget.LinearLayout token_retries_layout;
    private android.widget.TextView token_retries_title, token_retries_message, secondary_button;
    private android.widget.Button main_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = new ViewModelProvider(this).get(CallQualityCheckViewModel.class);

        Config.REMAINING_TRIES = -1;
        Util_CustomLogData.setEventData(EVENT_CQC_SCREEN_SHOWN, "EVENT_CQC_SCREEN_SHOWN", "CQC", "Screen", null);
        Util_Log.d("COUNTLY LOG", "EVENT_CQC_SCREEN_SHOWN");
        callQualitySampleList = new ArrayList<>();

        binding = ActivityCallQualityCheckBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupObservers();

        old_cqc = binding.oldCqc;
        new_cqc = binding.newCqc;
        used_logo_cqc = binding.usedLogoCqc;
        used_logo_cqc_other = binding.usedLogoCqcOther;

        token_retries_layout = binding.tokenRetriesLayout;
        token_retries_title = binding.tokenRetriesTitle;
        token_retries_message = binding.tokenRetriesMessage;
        main_button = binding.mainButton;
        secondary_button = binding.secondaryButton;
        token_retries_agent_image = binding.tokenRetriesAgentImage;

        token_retries_agent_image.setAnimation("static_agent_id_fail.json");
        used_logo_cqc.setAnimation("static_logo.json");
        used_logo_cqc_other.setAnimation("static_logo.json");

        if (IDnowSDK.getShowIDnowLogo()) {
            used_logo_cqc.setVisibility(View.VISIBLE);
            used_logo_cqc_other.setVisibility(View.VISIBLE);
        } else {
            used_logo_cqc.setVisibility(View.GONE);
            used_logo_cqc_other.setVisibility(View.GONE);
        }

        if (Config.DARK_MODE) {
            Util_UtilUI.setColorLottieAnimation(Color.WHITE, used_logo_cqc, "SecondaryVariant");
            Util_UtilUI.setColorLottieAnimation(Color.WHITE, token_retries_agent_image, "SecondaryVariant");
            Util_UtilUI.setColorLottieAnimation(Color.WHITE, used_logo_cqc_other, "SecondaryVariant");
        } else {
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, used_logo_cqc, "SecondaryVariant");
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, token_retries_agent_image, "SecondaryVariant");
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, used_logo_cqc_other, "SecondaryVariant");
        }

        container = binding.callQualityPublisherView;
        containerSubscriber = binding.callQualityCheckSubscriberView;
        callQualityProgressText = binding.callQualityProgressText;
        callQualityResultText = binding.callQualityResultText;
        callQualitySubscriberBar = binding.callQualitySubscriberBar;
        callQualityCheckRunningLayout = binding.callQualityCheckRunningLayout;
        callQualityCheckResultLayout = binding.callQualityCheckResultLayout;
        callQualityCheckResultLayout.setVisibility(View.GONE);
        callQualityResultButton = binding.callQualityResultButton;
        callQualityRetryLink = binding.callQualityRetryLink;
        callQualityRetryLink.setPaintFlags(callQualityRetryLink.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        container = binding.callQualityPublisherView;
        containerSubscriber = binding.callQualityCheckSubscriberView;
        callQualityProgressText = binding.callQualityProgressText;
        callQualityResultText = binding.callQualityResultText;
        callQualitySubscriberBar = binding.callQualitySubscriberBar;
        callQualityCheckRunningLayout = binding.callQualityCheckRunningLayout;
        callQualityCheckResultLayout = binding.callQualityCheckResultLayout;
        callQualityCheckResultLayout.setVisibility(View.GONE);
        callQualityResultButton = binding.callQualityResultButton;
        callQualityRetryLink = binding.callQualityRetryLink;
        callQualityRetryLink.setPaintFlags(callQualityRetryLink.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        if (Config.VIDEO_IDENT_PLUS) {
            old_cqc.setVisibility(View.GONE);
            new_cqc.setVisibility(View.VISIBLE);

            // —— Bind VIP-specific views ——
            good_internet_connection = binding.goodInternetConnection;
            other_internet_connection = binding.otherInternetConnection;
            callQualityImageVideo_vip = binding.callQualityImageVideoVip;
            callQualityImageAudio_vip = binding.callQualityImageAudioVip;
            callQualityImageBandwith_vip = binding.callQualityImageBandwidthVip;
            connection_vip_other_title = binding.connectionVipOtherTitle;
            connection_vip_status = binding.connectionVipStatus;
            connection_vip_other_desc_1 = binding.connectionVipOtherDesc1;
            connection_vip_other_desc_2 = binding.connectionVipOtherDesc2;
            connection_vip_other_desc_3 = binding.connectionVipOtherDesc3;
            connection_vip_other_button = binding.connectionVipOtherButton;
            status_image_good = binding.statusImageGood;

            callQualityImageVideo_vip.setAnimation("static_loading_round.json");
            callQualityImageVideo_vip.playAnimation();
            callQualityImageAudio_vip.setAnimation("static_loading_round.json");
            callQualityImageAudio_vip.playAnimation();
            callQualityImageBandwith_vip.setAnimation("static_loading_round.json");
            callQualityImageBandwith_vip.playAnimation();
            status_image_good.setAnimation("static_wifi_check.json");
            status_image_good.playAnimation();

            connection_vip_other_result = binding.connectionVipOtherResult;
            connection_vip_title = binding.connectionVipTitle;
            connection_vip_desc = binding.connectionVipDesc;
            connection_vip_good_1 = binding.connectionVipGood1;
            connection_vip_good_2 = binding.connectionVipGood2;
            connection_vip_good_3 = binding.connectionVipGood3;

            connection_vip_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_CQC_ACTIVE_TITLE, LOCAL_KEY_CQC_ACTIVE_TITLE));
            connection_vip_desc.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_DESC, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_DESC));
            connection_vip_good_1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_CQC_ACTIVE_NETWORK, LOCAL_KEY_CQC_ACTIVE_NETWORK));
            connection_vip_good_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_CQC_ACTIVE_AUDIO, LOCAL_KEY_CQC_ACTIVE_AUDIO));
            connection_vip_good_3.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_CQC_ACTIVE_VIDEO, LOCAL_KEY_CQC_ACTIVE_VIDEO));

            status_image = binding.statusImage;

            sfGifView = binding.loaderSpinner;
            sfGifView.setAnimation("loading.json");
            sfGifView.setRepeatCount(LottieDrawable.INFINITE);
            sfGifView.playAnimation();

            good_internet_connection.setVisibility(View.VISIBLE);
            other_internet_connection.setVisibility(View.GONE);

        } else {
            old_cqc.setVisibility(View.VISIBLE);
            new_cqc.setVisibility(View.GONE);

            if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                customiseCallQualityCheckScreenFiducia();
            }

            callQualityRetryLink.setOnClickListener(view -> restartTest());

            scrollView = binding.callQualityCheckScollView;
            setScrollingEnabled(false);
            callQualitySubscriberBar.setVisibility(View.VISIBLE);
            callQualityProgressText.setVisibility(View.GONE);

            progressBarLoading = binding.callQualityLoadingSpinner;
            progressBarLoading.setVisibility(View.GONE);

            progressBar = binding.progress;
            progressBar.getIndeterminateDrawable().setColorFilter(
                    getResources().getColor(R.color.primary, null), PorterDuff.Mode.MULTIPLY);
            progressBar.setVisibility(View.GONE);

            callQualityImageConnection = binding.callQualityImageBandwidth;
            Util_UtilUI.setTintedIcon(callQualityImageConnection, R.drawable.ic_network_check_black_36dp, R.color.call_quality_check_icon_desactivated_color);
            callQualityImageAudio = binding.callQualityImageAudio;
            Util_UtilUI.setTintedIcon(callQualityImageAudio, R.drawable.ic_mic_black_36dp, R.color.call_quality_check_icon_desactivated_color);
            callQualityImageVideo = binding.callQualityImageVideo;
            Util_UtilUI.setTintedIcon(callQualityImageVideo, R.drawable.ic_videocam_black_36dp, R.color.call_quality_check_icon_desactivated_color);

            callQualityTitleText = binding.callQualityTitleText;
            callQualityTitleText.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_CQC_ACTIVE_TITLE, Util_Strings.LOCAL_KEY_CQC_ACTIVE_TITLE));

            if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                callQualityTitleText.setTextColor(getResources().getColor(R.color.call_quality_title_text_color, null));
            }

            callQualityTitleText.setVisibility(View.VISIBLE);

            callQualityCheckBandwidthLabel = binding.callQualityCheckBandwidthLabel;
            callQualityCheckBandwidthLabel.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_CQC_ACTIVE_NETWORK, LOCAL_KEY_CQC_ACTIVE_NETWORK));
            callQualityCheckBandwidthLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color, null));

            callQualityAudioLabel = binding.callQualityCheckAudioLabel;
            callQualityAudioLabel.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_CQC_ACTIVE_AUDIO, Util_Strings.LOCAL_KEY_CQC_ACTIVE_AUDIO));
            callQualityAudioLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color, null));

            callQualityVideoLabel = binding.callQualityCheckVideoLabel;
            callQualityVideoLabel.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_CQC_ACTIVE_VIDEO, Util_Strings.LOCAL_KEY_CQC_ACTIVE_VIDEO));
            callQualityVideoLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color, null));

            if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                progressBarLoading.setVisibility(View.GONE);
                progressBar.setVisibility(View.GONE);
                callQualitySubscriberBar.setIndeterminate(false);
            }
        }
    }

    private void setupObservers() {
        observeStartCallResult();
        observeStartTestState();
        observeStopTestState();
        observeCallQualityConferenceState();
    }

    private void observeStartCallResult() {
        viewModel.getStartCallResult().observe(this, state -> {
            Util_Log.i(LOGTAG, "Start call result: " + state);
            if (state instanceof CallQualityCheckViewModel.StartCallResult.ShowErrorDialog) {
                CallQualityCheckViewModel.StartCallError error = ((CallQualityCheckViewModel.StartCallResult.ShowErrorDialog) state).getError();
                Util_UtilUI.showRESTCallErrorDialog(
                        context,
                        error.getErrorStatus(),
                        false,
                        proceedToNextStepRunnable,
                        error.getErrorId(),
                        true,
                        false,
                        error.getError());
                return;
            }

            if (state instanceof CallQualityCheckViewModel.StartCallResult.StartCallDone) {
                proceedToNextStep();
                return;
            }

            if (state instanceof CallQualityCheckViewModel.StartCallResult.GiveUserFeedback) {
                giveUserFeedback(viewModel.getRemainingInternalTokenRetries());
                return;
            }

            if (state instanceof CallQualityCheckViewModel.StartCallResult.LoadWaitingScreen) {
                loadForcedWaitingScreen();
                return;
            }

            if (state instanceof CallQualityCheckViewModel.StartCallResult.ShowCheckResultScreenCustomise) {
                showCheckResultScreenCustomise(CallQualityResult.UNKNOWN.getInt());
            }
        });
    }

    private void observeStartTestState() {
        viewModel.getStartTestState().observe(this, state -> {
            Util_Log.i(LOGTAG, "Start test state: " + state);
            if (state instanceof CallQualityCheckViewModel.StartTestState.Success) {
                hideProgressBar();
                startConference();
            }

            if (state instanceof CallQualityCheckViewModel.StartTestState.Failure) {
                hideProgressBar();
                handleUnknownFailure(false);
            }

            if (state instanceof CallQualityCheckViewModel.StartTestState.ShowErrorDialog) {
                hideProgressBar();
                CallQualityCheckViewModel.StartCallError error =
                        ((CallQualityCheckViewModel.StartTestState.ShowErrorDialog) state).getError();
                Util_UtilUI.showRESTCallErrorDialog(
                        context,
                        error.getErrorStatus(),
                        false,
                        this::restartTest,
                        error.getErrorId(),
                        true,
                        false,
                        error.getError());
            }
        });
    }

    private void observeStopTestState() {
        viewModel.getStopTestState().observe(this, state -> {
            Util_Log.i(LOGTAG, "Stop test state: " + state);
            if (state instanceof CallQualityCheckViewModel.StopTestState.Failure) {
                handleUnknownFailure(false);
            }
        });
    }

    private void observeCallQualityConferenceState() {
        viewModel.getCallQualityConferenceState().observe(this, state -> {
            Util_Log.i(LOGTAG, "Start call result: " + state);
            if (state instanceof CallQualityCheckViewModel.CallQualityConferenceState.Failure) {
                handleUnknownFailure(true);
            }
        });
    }

    private void customiseCallQualityCheckScreenFiducia() {
        title = binding.title;
        description = binding.description;
        retryCQC = binding.retrycqc;
        actionCQC = binding.startident;
        linearlayoutAfterCQC = binding.linearlayoutAfterCQC;
        lineDivider = binding.linedivider;
        description1 = binding.description1;
        point1 = binding.point1;
        description2 = binding.description2;
        point2 = binding.point2;
        description3 = binding.description3;
        point3 = binding.point3;

        callQualitySubscriberBar.setScaleY(4f);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        viewModel.startTest();
    }

    @Override
    protected void onDestroy() {
        AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_NORMAL);
        Util_CustomLogData.endSession();
        super.onDestroy();
    }

    protected void setupConferenceAudio() {
        AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_IN_COMMUNICATION);
        boolean headset = am.isWiredHeadsetOn();
        float percent = 0.5f;
        if (!headset) {
            am.setSpeakerphoneOn(true);
            percent = 0.75f;
        }

        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        int currentVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        int maxVolume = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        float currentVolumePercent = 0.1f;
        if (currentVolume != 0 && maxVolume != 0) {
            currentVolumePercent = (float) currentVolume / maxVolume;
        }

        if (currentVolumePercent < percent) {
            int newVolume = (int) (maxVolume * percent);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0);
        }

        try {
            float musicVolume = (float) am.getStreamVolume(AudioManager.STREAM_MUSIC);
            float musicPercent = musicVolume / ((float) am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
            int newVoiceVolume = (int) (am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL) * musicPercent);
            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, newVoiceVolume, 0);
        } catch (Exception e) {
            // ignore
        }

        int result = am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            Util_Log.i(LOGTAG, "Focus request granted");
        } else {
            Util_Log.i(LOGTAG, "Focus request not granted");
        }
    }

    public void connectConference() {
        conference.connect(container, containerSubscriber).then(localMedia -> {
            localMedia.setAudioMuted(true);
            attachQualitySampleListener();
        });

        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        audioManager.setStreamMute(AudioManager.STREAM_MUSIC, true);
        audioManager.setStreamMute(AudioManager.STREAM_VOICE_CALL, true);
    }

    private void startTest() {
        viewModel.startTest();
    }

    private void stopTest() {
        viewModel.stopTest();
    }

    private void cancelTest() {
        stopConference();
        cancelPendingApiCalls();
    }

    private void cancelPendingApiCalls() {
        viewModel.cancelPendingApiCalls();
    }

    private void handleResult(int result, Boolean stopRequired) {
        detachQualitySampleListener();
        stopConference();

        if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
            showCheckResultScreenCustomise(result);
        } else {
            if (Config.VIDEO_IDENT_PLUS) {
                showCheckResultScreen_vip(result);
            } else {
                showCheckResultScreen(result);
            }
        }

        if (stopRequired) {
            stopTest();
        }
    }

    private void handleUnknownFailure(Boolean stopRequired) {
        handleResult(CallQualityResult.UNKNOWN.getInt(), stopRequired);
    }

    private void startConference() {
        Util_Log.i(LOGTAG, "Start Conference");
        try {
            conference = new CallQualityConference(this);
            conference.setSubscriberProgressBar(callQualitySubscriberBar);
            setupConferenceAudio();
            connectConference();
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Start conference failed", e);
            handleUnknownFailure(true);
        }
    }

    private void attachQualitySampleListener() {
        if (!Config.VIDEO_IDENT_PLUS) {
            runOnUiThread(() -> {
                callQualitySubscriberBar.setIndeterminate(false);
                callQualitySubscriberBar.setMax(100);
                callQualitySubscriberBar.setProgress(0);
            });
        }

        callQualitySampleCounter -= Config.CALL_QUALITY_ARGS_WARM_UP;
        Util_Log.d(LOGTAG, "Warm up: " + Config.CALL_QUALITY_ARGS_WARM_UP);
        final long startTime = SystemClock.uptimeMillis();

        if (conference.connectionHasDataStream()) {
            DataChannel dataChannel = conference.getDataChannel();
            dataChannel.setOnReceive(args -> onQualitySampleReceived(args, startTime));
        }
    }

    private void detachQualitySampleListener() {
        if (conference != null &&
                conference.getConnection() != null &&
                conference.connectionHasDataStream()) {
            DataChannel dataChannel = conference.getDataChannel();
            dataChannel.setOnReceive(null);
        }
    }

    private void stopConference() {
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        audioManager.setStreamMute(AudioManager.STREAM_MUSIC, false);
        audioManager.setStreamMute(AudioManager.STREAM_VOICE_CALL, false);

        if (conference != null) {
            try {
                conference
                        .stopConference()
                        .fail(e -> {
                            Util_Log.i(LOGTAG, "Stopped connection with error: " + e.getMessage());
                        });
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Stop conference failed", e);
            }
        }
    }

    public void onQualitySampleReceived(DataChannelReceiveArgs args, long startTime) {
        if (args != null) {
            Util_Log.d(LOGTAG, "Call Quality data: " + args.getDataString());
            callQualitySampleCounter++;
            long now = SystemClock.uptimeMillis();
            long elapsed = now - startTime;
            if (callQualitySampleCounter >= 0 && callQualitySampleCounter < Config.CALL_QUALITY_ARGS_MAX && (elapsed <= Config.CALL_QUALITY_ARGS_TIMEOUT)) {
                float progress = ((float) callQualitySampleCounter / (float) Config.CALL_QUALITY_ARGS_MAX) * 100f;
                String dataJSON = args.getDataString();
                try {
                    Gson gson = new Gson();
                    Model_ConferenceCallQualityMetrics callQualityMetrics = gson.fromJson(dataJSON, Model_ConferenceCallQualityMetrics.class);
                    int video = callQualityMetrics.getCallQuality().getUser().getVideo().getQuality();
                    int audio = callQualityMetrics.getCallQuality().getUser().getAudio().getQuality();
                    int sampleCallQuality = Math.min(audio, video);
                    callQualitySampleList.add(sampleCallQuality);
                    Util_Log.i(LOGTAG, "Received call quality sample with video: " + video + " / audio: " + audio);
                    if (!Config.VIDEO_IDENT_PLUS) {
                        if (progress > 50) {
                            callQualitySubscriberBar.setProgress(100, true);
                        } else {
                            callQualitySubscriberBar.setProgress(Math.round(progress), true);
                        }
                    }
                    switchActiveIconAndLabelForProgress(progress);
                } catch (JsonSyntaxException e) {
                    Util_Log.e(LOGTAG, "Parse call quality data from json failed", e);
                }
            } else if ((callQualitySampleCounter >= 0 && callQualitySampleCounter >= Config.CALL_QUALITY_ARGS_MAX) || (elapsed >= Config.CALL_QUALITY_ARGS_TIMEOUT)) {
                int result = evaluateResultsForCurrentTest();
                boolean stopRequired = result < MODERATE.getInt();
                handleResult(result, stopRequired);
            }
        }
    }

    private void switchActiveIconAndLabelForProgress(final float progress) {
        runOnUiThread(() -> {
            if (progress == 0f) {
                if (Config.VIDEO_IDENT_PLUS) {
                    new Handler().postDelayed(() -> {
                        callQualityImageBandwith_vip.setAnimation("static_checkbox_round.json");
                        Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.cqc_bandwitch_color)), callQualityImageBandwith_vip, "Success");
                        callQualityImageBandwith_vip.playAnimation();
                    }, 500);
                } else {
                    Util_UtilUI.setTintedIcon(callQualityImageConnection, R.drawable.ic_network_check_black_36dp, R.color.call_quality_check_icon_activated_color);
                    callQualityCheckBandwidthLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_activated_text_color));
                }

            } else if (progress >= 30f && progress < 50f) {
                if (Config.VIDEO_IDENT_PLUS) {
                    new Handler().postDelayed(() -> {
                        callQualityImageAudio_vip.setAnimation("static_checkbox_round.json");
                        Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.cqc_bandwitch_color)), callQualityImageAudio_vip, "Success");
                        callQualityImageAudio_vip.playAnimation();
                    }, 500);
                    new Handler().postDelayed(() -> {
                        callQualityImageVideo_vip.setAnimation("static_checkbox_round.json");
                        Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.cqc_bandwitch_color)), callQualityImageVideo_vip, "Success");
                        callQualityImageVideo_vip.playAnimation();
                    }, 2000);
                } else {
                    Util_UtilUI.setTintedIcon(callQualityImageConnection, R.drawable.ic_network_check_black_36dp, R.color.call_quality_check_icon_desactivated_color);
                    callQualityCheckBandwidthLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));
                    Util_UtilUI.setTintedIcon(callQualityImageAudio, R.drawable.ic_mic_black_36dp, R.color.call_quality_check_icon_activated_color);
                    callQualityAudioLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_activated_text_color));
                }

            } else if (progress >= 50f) {
                if (Config.VIDEO_IDENT_PLUS) {
                    callQualityImageVideo_vip.setAnimation("static_checkbox_round.json");
                    Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.cqc_bandwitch_color)), callQualityImageVideo_vip, "Success");
                    callQualityImageVideo_vip.playAnimation();
                } else {
                    Util_UtilUI.setTintedIcon(callQualityImageAudio, R.drawable.ic_mic_black_36dp, R.color.call_quality_check_icon_desactivated_color);
                    callQualityAudioLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));
                    Util_UtilUI.setTintedIcon(callQualityImageVideo, R.drawable.ic_videocam_black_36dp, R.color.call_quality_check_icon_activated_color);
                    callQualityVideoLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_activated_text_color));
                }

            } else if (progress < 0f) {
                if (Config.VIDEO_IDENT_PLUS) {
                    callQualityImageVideo_vip.setAnimation("static_loading_round.json");
                    callQualityImageVideo_vip.playAnimation();
                    callQualityImageBandwith_vip.setAnimation("static_loading_round.json");
                    callQualityImageBandwith_vip.playAnimation();
                    callQualityImageAudio_vip.setAnimation("static_loading_round.json");
                    callQualityImageAudio_vip.playAnimation();
                } else {
                    Util_UtilUI.setTintedIcon(callQualityImageConnection, R.drawable.ic_network_check_black_36dp, R.color.call_quality_check_icon_desactivated_color);
                    callQualityCheckBandwidthLabel.setTextColor(getResources().getColor(R.color.light_gray));
                    Util_UtilUI.setTintedIcon(callQualityImageAudio, R.drawable.ic_mic_black_36dp, R.color.call_quality_check_icon_desactivated_color);
                    callQualityAudioLabel.setTextColor(getResources().getColor(R.color.light_gray));
                    Util_UtilUI.setTintedIcon(callQualityImageVideo, R.drawable.ic_videocam_black_36dp, R.color.call_quality_check_icon_desactivated_color);
                    callQualityVideoLabel.setTextColor(getResources().getColor(R.color.light_gray));
                }
            }

            if (!Config.VIDEO_IDENT_PLUS) {
                callQualityCheckRunningLayout.invalidate();
            }
        });
    }

    private void resetUI() {
        callQualityResultButton.setEnabled(true);
        token_retries_layout.setVisibility(View.GONE);
        token_retries_agent_image.setAnimation("static_agent_id_fail.json");
        used_logo_cqc.setAnimation("static_logo.json");
        used_logo_cqc_other.setAnimation("static_logo.json");
        secondary_button.setVisibility(View.INVISIBLE);

        if (IDnowSDK.getShowIDnowLogo()) {
            used_logo_cqc.setVisibility(View.VISIBLE);
            used_logo_cqc_other.setVisibility(View.VISIBLE);
        } else {
            used_logo_cqc.setVisibility(View.GONE);
            used_logo_cqc_other.setVisibility(View.GONE);
        }

        if (Config.VIDEO_IDENT_PLUS) {
            old_cqc.setVisibility(View.GONE);
            new_cqc.setVisibility(View.VISIBLE);

            callQualityImageVideo_vip.setAnimation("static_loading_round.json");
            callQualityImageVideo_vip.playAnimation();
            callQualityImageAudio_vip.setAnimation("static_loading_round.json");
            callQualityImageAudio_vip.playAnimation();
            callQualityImageBandwith_vip.setAnimation("static_loading_round.json");
            callQualityImageBandwith_vip.playAnimation();
            status_image_good.playAnimation();
            sfGifView.playAnimation();
            callQualityCheckResultLayout.setVisibility(View.GONE);
            good_internet_connection.setVisibility(View.VISIBLE);
            other_internet_connection.setVisibility(View.GONE);
            callQualityCheckRunningLayout.setVisibility(View.VISIBLE);
            callQualityResultText.setVisibility(View.VISIBLE);
            callQualityRetryLink.setVisibility(View.GONE);
            callQualityRetryLink.setPaintFlags(callQualityRetryLink.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            callQualityResultButton.setVisibility(View.VISIBLE);
            connection_vip_other_desc_3.setVisibility(View.VISIBLE);
        } else {
            old_cqc.setVisibility(View.VISIBLE);
            new_cqc.setVisibility(View.GONE);

            callQualityCheckResultLayout.setVisibility(View.GONE);
            callQualityRetryLink.setPaintFlags(callQualityRetryLink.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            callQualitySubscriberBar.setVisibility(View.VISIBLE);
            callQualityProgressText.setVisibility(View.GONE);
            progressBarLoading.setVisibility(View.GONE);
            progressBar.setVisibility(View.GONE);
            Util_UtilUI.setTintedIcon(callQualityImageConnection, R.drawable.ic_network_check_black_36dp, R.color.call_quality_check_icon_desactivated_color);
            Util_UtilUI.setTintedIcon(callQualityImageAudio, R.drawable.ic_mic_black_36dp, R.color.call_quality_check_icon_desactivated_color);
            Util_UtilUI.setTintedIcon(callQualityImageVideo, R.drawable.ic_videocam_black_36dp, R.color.call_quality_check_icon_desactivated_color);
            callQualityTitleText.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_CQC_ACTIVE_TITLE, Util_Strings.LOCAL_KEY_CQC_ACTIVE_TITLE));
            callQualityTitleText.setVisibility(View.VISIBLE);
            callQualityCheckBandwidthLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));
            callQualityAudioLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));
            callQualityVideoLabel.setTextColor(getResources().getColor(R.color.call_quality_check_icon_desactivated_text_color));

            if (CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED) {
                lineDivider.setVisibility(View.VISIBLE);
                linearlayoutAfterCQC.setVisibility(View.GONE);
                callQualityTitleText.setTextColor(getResources().getColor(R.color.call_quality_title_text_color));
                callQualitySubscriberBar.setIndeterminate(false);
                callQualitySubscriberBar.setScaleY(4f);
                retryCQC.setVisibility(View.VISIBLE);
                actionCQC.setVisibility(View.VISIBLE);
            } else {
                callQualitySubscriberBar.setProgress(0);
                callQualitySubscriberBar.setIndeterminate(true);
            }

            callQualityCheckRunningLayout.setVisibility(View.VISIBLE);
            callQualityResultText.setText("");
            callQualityResultText.setVisibility(View.GONE);
            callQualityRetryLink.setVisibility(View.GONE);
            callQualityResultButton.setVisibility(View.VISIBLE);
            setScrollingEnabled(false);
            switchActiveIconAndLabelForProgress(-1f);
        }

        callQualityResultButton.setVisibility(View.GONE);
        resetSuggestionBoxes();
    }

    private void restartTest() {
        resetUI();
        callQualitySampleCounter = 0;
        callQualitySampleList.clear();
        startTest();
    }

    public void showCheckResultScreenCustomise(final int result) {
        progressBar.setVisibility(View.GONE);

        runOnUiThread(() -> {
            CallQualityResult callQuality = CallQualityResult.values()[result];
            Util_UtilUI.setProceedButtonBackgroundSelector(callQualityResultButton);

            callQualityResultButton.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.button.continue", null));
            callQualityResultButton.setOnClickListener(view -> {
                progressBar.setVisibility(View.VISIBLE);
                callQualityResultButton.setEnabled(false);
                markTestPassed(CallQualityResult.MODERATE);
            });

            switch (callQuality) {
                case UNKNOWN, POOR:
                    ShowPreCheckFails();
                    break;
                case MODERATE:
                    callQualityCheckRunningLayout.setVisibility(View.GONE);
                    scrollView.setVisibility(View.GONE);
                    lineDivider.setVisibility(View.VISIBLE);
                    linearlayoutAfterCQC.setVisibility(View.VISIBLE);
                    title.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.title.moderate.short", null));
                    title.setTextColor(getResources().getColor(R.color.vr_color_text_title_moderate));
                    description.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.title.moderate", null));
                    displaySuggestionBoxesCustomise(MODERATE);
                    retryCQC.setVisibility(View.VISIBLE);
                    retryCQC.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.button.retest", null));
                    actionCQC.setVisibility(View.VISIBLE);
                    actionCQC.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.button.continue", null));
                    actionCQC.setOnClickListener(view -> {
                        progressBar.setVisibility(View.VISIBLE);
                        callQualityResultButton.setEnabled(false);
                        markTestPassed(CallQualityResult.MODERATE);
                    });
                    retryCQC.setOnClickListener(view -> restartTest());
                    break;
                case EXCELLENT:
                    markTestPassed(EXCELLENT);
                    break;
            }

            setScrollingEnabled(true);
        });
    }

    private void setScrollingEnabled(Boolean enabled) {
        runOnUiThread(() -> {
            if (scrollView != null) {
                scrollView.post(() -> scrollView.fullScroll(ScrollView.FOCUS_UP));
                scrollView.setScrollingEnabled(enabled);
            }
        });
    }

    private void ShowPreCheckFails() {
        callQualityCheckRunningLayout.setVisibility(View.GONE);
        callQualityCheckResultLayout.setVisibility(View.GONE);
        lineDivider.setVisibility(View.GONE);
        retryCQC.setVisibility(View.GONE);
        actionCQC.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.button.continue", null));
        linearlayoutAfterCQC.setVisibility(View.VISIBLE);
        title.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.title.unknown.short", null));
        title.setTextColor(getResources().getColor(R.color.vr_color_text_title_failed));
        description.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.title.poor", null));
        displaySuggestionBoxesCustomise(UNKNOWN);
        retryCQC.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.button.retest", null));
        actionCQC.setVisibility(View.VISIBLE);
        actionCQC.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.button.retest", null));
        retryCQC.setVisibility(View.GONE);
        actionCQC.setOnClickListener(view -> {
            if (ConnectivityService.INSTANCE.isOnline()) {
                linearlayoutAfterCQC.setVisibility(View.GONE);
                restartTest();
            } else {
                Util_UtilUI.showNoConnectionDialog(context, false);
            }
        });
    }

    public void showCheckResultScreen(final int result) {
        progressBar.setVisibility(View.GONE);

        runOnUiThread(() -> {
            callQualityCheckRunningLayout.setVisibility(View.GONE);
            callQualityCheckResultLayout.setVisibility(View.VISIBLE);

            // Local variables: scoped to this method only, no reason to be fields
            CallQualityLightView lightOne = binding.callQualityLightOne;
            CallQualityLightView lightTwo = binding.callQualityLightTwo;
            CallQualityLightView lightThree = binding.callQualityLightThree;

            CallQualityResult callQuality = CallQualityResult.values()[result];

            Util_UtilUI.setProceedButtonBackgroundSelector(callQualityResultButton);
            callQualityResultButton.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.button.continue", null));
            callQualityResultButton.setOnClickListener(view -> {
                progressBar.setVisibility(View.VISIBLE);
                callQualityResultButton.setEnabled(false);
                markTestPassed(CallQualityResult.MODERATE);
            });

            displaySuggestionBoxes(callQuality);

            switch (callQuality) {
                case UNKNOWN:
                    lightOne.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_first_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightTwo.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_second_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightThree.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_third_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    callQualityResultText.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.title.unknown", null));
                    callQualityResultText.setVisibility(View.VISIBLE);
                    callQualityRetryLink.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.button.retest", null));
                    callQualityRetryLink.setVisibility(View.VISIBLE);
                    callQualityResultButton.setVisibility(View.GONE);
                    break;
                case POOR:
                    lightOne.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_first_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightTwo.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_second_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightThree.setCircleColors(getResources().getColor(R.color.cqc_poor_quality_third_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    callQualityResultText.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.title.poor", null));
                    callQualityResultText.setVisibility(View.VISIBLE);
                    callQualityRetryLink.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.button.retest", null));
                    callQualityRetryLink.setVisibility(View.VISIBLE);
                    callQualityResultButton.setVisibility(View.GONE);
                    break;
                case MODERATE:
                    lightOne.setCircleColors(getResources().getColor(R.color.cqc_moderate_quality_first_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightTwo.setCircleColors(getResources().getColor(R.color.cqc_moderate_quality_second_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightThree.setCircleColors(getResources().getColor(R.color.cqc_moderate_quality_third_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    callQualityResultText.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.title.moderate", null));
                    callQualityResultText.setVisibility(View.VISIBLE);
                    callQualityRetryLink.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.button.retest", null));
                    callQualityRetryLink.setVisibility(View.VISIBLE);
                    callQualityResultButton.setVisibility(View.VISIBLE);
                    break;
                case EXCELLENT:
                    lightOne.setCircleColors(getResources().getColor(R.color.cqc_excellent_quality_first_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightTwo.setCircleColors(getResources().getColor(R.color.cqc_excellent_quality_second_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    lightThree.setCircleColors(getResources().getColor(R.color.cqc_excellent_quality_third_circle_inner_color), getResources().getColor(R.color.cqc_outer_circle_color));
                    callQualityResultText.setText(IDnowSDK.getInstance().getStringWithDefault(CallQualityCheckActivity.this, "js.precheck.mobile.result.title.excellent", null));
                    callQualityResultText.setVisibility(View.VISIBLE);
                    callQualityResultButton.setVisibility(View.GONE);
                    callQualityRetryLink.setVisibility(View.GONE);
                    markTestPassed(EXCELLENT);
                    break;
            }
            setScrollingEnabled(true);
        });
    }

    public void showCheckResultScreen_vip(final int result) {
        runOnUiThread(() -> {
            CallQualityResult callQuality = CallQualityResult.values()[result];

            switch (callQuality) {
                case UNKNOWN, POOR:
                    Config.CQC_STATUS = 1;
                    if (good_internet_connection != null)
                        good_internet_connection.setVisibility(View.GONE);
                    if (other_internet_connection != null)
                        other_internet_connection.setVisibility(View.VISIBLE);
                    connection_vip_other_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_TITLE));
                    connection_vip_status.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD));
                    connection_vip_other_desc_1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_1, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_1));
                    connection_vip_other_desc_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_2, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_2));
                    connection_vip_other_desc_3.setVisibility(View.GONE);
                    connection_vip_other_button.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_BAD_BUTTON));
                    connection_vip_other_button.setOnClickListener(v -> restartTest());
                    status_image.setAnimation("static_wifi_check_problem.json");
                    status_image.playAnimation();
                    break;
                case MODERATE:
                    Config.CQC_STATUS = 2;
                    if (good_internet_connection != null)
                        good_internet_connection.setVisibility(View.GONE);
                    if (other_internet_connection != null)
                        other_internet_connection.setVisibility(View.VISIBLE);
                    connection_vip_other_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_OTHER_STATUS, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_OTHER_STATUS));
                    status_image.setAnimation("static_wifi_check_problem.json");
                    status_image.playAnimation();
                    connection_vip_status.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CQC_MODERATE, LOCAL_KEY_VIDEO_IDENT_PLUS_CQC_MODERATE));
                    connection_vip_other_desc_1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CQC_MODERATE_1, LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_1));
                    connection_vip_other_desc_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CQC_MODERATE_2, LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_2));
                    connection_vip_other_desc_3.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CQC_MODERATE_3, LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_3));
                    connection_vip_other_button.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON, LOCAL_KEY_VIDEO_IDENT_CQC_MODERATE_BUTTON));
                    connection_vip_other_button.setOnClickListener(v -> {
                        markTestPassed(CallQualityResult.MODERATE);
                    });
                    break;
                case EXCELLENT:
                    Config.CQC_STATUS = 3;
                    status_image.setAnimation("static_wifi_check.json");
                    status_image.playAnimation();
                    markTestPassed(EXCELLENT);
                    break;
            }
        });
    }

    private void displaySuggestionBoxes(CallQualityResult callQuality) {
        int boxesWithValues = 0;
        for (int i = 1; i <= 10; i++) {
            Resources res = getResources();
            int id = res.getIdentifier("callQualitySuggestionBox" + i, "id", context.getPackageName());
            TextView textView = findViewById(id);
            if (textView != null) {
                String label = null;
                if (callQuality.equals(CallQualityResult.MODERATE)) {
                    label = IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion" + i, null);
                } else if (callQuality.equals(CallQualityResult.POOR)) {
                    label = IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion.poor" + i, null);
                } else if (callQuality.equals(CallQualityResult.UNKNOWN)) {
                    label = IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion.unknown" + i, null);
                }

                if (label == null || TextUtils.isEmpty(label)) {
                    textView.setVisibility(View.GONE);
                } else {
                    textView.setText(label);
                    textView.setVisibility(View.VISIBLE);
                    boxesWithValues++;
                }
            }
        }

        if (boxesWithValues == 0) {
            // Dynamic lookup — cannot use binding here
            LinearLayout callQualitySuggestionBoxContainer = findViewById(R.id.callQualitySuggestionBoxContainer);
            if (callQualitySuggestionBoxContainer != null) {
                callQualitySuggestionBoxContainer.setVisibility(View.GONE);
            }
        }
    }

    private void displaySuggestionBoxesCustomise(CallQualityResult callQuality) {
        int boxesWithValues = 0;
        String label = "";
        for (int i = 1; i <= 3; i++) {
            if (callQuality.equals(CallQualityResult.MODERATE)) {
                if (label.isEmpty()) {
                    label = IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion" + i, null);
                    point1.setText(R.string.filled_bullet);
                    description1.setText(label);
                } else {
                    label = label + "\n" + IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion" + i, null);
                    createListText(i, "js.precheck.mobile.suggestion");
                }
            } else if (callQuality.equals(CallQualityResult.POOR) || callQuality.equals(CallQualityResult.UNKNOWN)) {
                if (label.isEmpty()) {
                    label = IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion.poor" + i, null);
                    point1.setText(R.string.filled_bullet);
                    description1.setText(label);
                } else {
                    label = label + "\n" + IDnowSDK.getInstance().getStringWithDefault(this, "js.precheck.mobile.suggestion.poor" + i, null);
                    createListText(i, "js.precheck.mobile.suggestion.poor");
                }
            }

            if (!label.isEmpty()) {
                boxesWithValues++;
            }
        }

        if (boxesWithValues == 0) {
            // Dynamic lookup — cannot use binding here
            LinearLayout callQualitySuggestionBoxContainer = findViewById(R.id.callQualitySuggestionBoxContainer);
            if (callQualitySuggestionBoxContainer != null) {
                callQualitySuggestionBoxContainer.setVisibility(View.GONE);
            }
        }
    }

    private void createListText(int i, String key) {
        if (i == 2) {
            point2.setText(R.string.filled_bullet);
            description2.setText(IDnowSDK.getInstance().getStringWithDefault(this, key + i, null));
        } else if (i == 3) {
            point3.setText(R.string.filled_bullet);
            description3.setText(IDnowSDK.getInstance().getStringWithDefault(this, key + i, null));
        }
    }

    private boolean shouldStartCQC() {
        return Config.CALL_QUALITY_CHECK_ENABLED && !Config.CALL_QUALITY_CHECK_PASSED;
    }

    private void proceedToNextStep() {
        if (shouldStartCQC()) {
            restartTest();
        } else {
            if (Config.HIDE_USERS_PII_DATA) {
                Util_Util.getMaskedData(this);
            } else {
                Intent intent = new Intent(context, Util_VideoStreamService.getClassForVideoLiveStreaming());
                startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
            }
        }
    }

    private final Runnable proceedToNextStepRunnable = () -> {
        viewModel.makeStartRESTCall();
        proceedToNextStep();
    };

    private void loadForcedWaitingScreen() {
        IDnowSDK.setForcedWaitingList(true);
        if (Config.HIDE_USERS_PII_DATA) {
            Util_Util.getMaskedData(this);
        } else {
            loadLiveScreen();
        }
    }

    private void loadLiveScreen() {
        Intent intent = new Intent(context, Util_VideoStreamService.getClassForVideoLiveStreaming());
        startActivityForResult(intent, IDnowSDK.REQUEST_ID_NOW_SDK);
    }

    private void giveUserFeedback(int remainingInternalTokenRetries) {
        switch (remainingInternalTokenRetries) {
            case 0:
                loadSpecificUI(remainingInternalTokenRetries);
                cancelAttemptUsing(main_button);
                break;
            case 1:
                loadSpecificUI(remainingInternalTokenRetries);
                proceedWithAttempt(remainingInternalTokenRetries);
                cancelAttemptUsing(secondary_button);
                break;
            default:
                break;
        }
    }

    private void cancelAttemptUsing(View button) {
        button.setOnClickListener(v -> {
            token_retries_layout.setVisibility(View.GONE);
            this.finish();
        });
    }

    private void proceedWithAttempt(int remainingInternalTokenRetries) {
        switch (remainingInternalTokenRetries) {
            case 0:
                cancelAttemptUsing(main_button);
                break;
            case 1:
                main_button.setOnClickListener(v -> {
                    token_retries_layout.setVisibility(View.GONE);
                    if (Config.VIDEO_IDENT_PLUS) {
                        old_cqc.setVisibility(View.GONE);
                        new_cqc.setVisibility(View.VISIBLE);
                    } else {
                        old_cqc.setVisibility(View.VISIBLE);
                        new_cqc.setVisibility(View.GONE);
                    }
                    proceedToNextStep();
                });
                break;
            default:
                break;
        }
    }

    private void loadSpecificUI(int remainingInternalTokenRetries) {
        old_cqc.setVisibility(View.GONE);
        new_cqc.setVisibility(View.GONE);
        token_retries_layout.setVisibility(View.VISIBLE);
        Config.REMAINING_TRIES = remainingInternalTokenRetries;

        switch (remainingInternalTokenRetries) {
            case 0:
                token_retries_title.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_TITLE, LOCAL_KEY_USER_FEEDBACK_BLOCKED_TITLE));
                token_retries_message.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_MESSAGE, LOCAL_KEY_USER_FEEDBACK_BLOCKED_MESSAGE));
                main_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_BLOCKED_FINISH, LOCAL_KEY_USER_FEEDBACK_BLOCKED_FINISH));
                secondary_button.setVisibility(View.GONE);
                break;
            case 1:
                token_retries_title.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TITLE, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TITLE));
                token_retries_message.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_MESSAGE));
                main_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_AGAIN));
                secondary_button.setVisibility(View.VISIBLE);
                secondary_button.setText(IDnowSDK.getInstance().getStringWithDefault(context, KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER, LOCAL_KEY_USER_FEEDBACK_UNBLOCKED_TRY_LATER));
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IDnowSDK.getInstance().deliverResult(resultCode, data);
        setResult(resultCode, data);
        finish();
    }

    private void resetSuggestionBoxes() {
        for (int i = 1; i <= 10; i++) {
            Resources res = getResources();
            int id = res.getIdentifier("callQualitySuggestionBox" + i, "id", context.getPackageName());
            TextView textView = findViewById(id);
            if (textView != null) {
                textView.setText("");
                textView.setVisibility(View.GONE);
            }
        }
    }

    private int evaluateResultsForCurrentTest() {
        int sum = 0;
        for (int result : callQualitySampleList) {
            sum += result;
        }
        return sum == 0 ? 0 : sum / callQualitySampleList.size();
    }

    private void markTestPassed(CallQualityResult result) {
        Util_Log.i(LOGTAG, "Call quality was " + result.name() + ". Proceeding to next step.");
        Config.CALL_QUALITY_CHECK_PASSED = true;
        viewModel.makeStartRESTCall();
    }

    @Override
    public void onBackPressed() {
        cancelTest();

        Config.CQC_STATUS = 0;
        Config.CALL_QUALITY_CHECK_PASSED = false;

        int resultCode = IDnowSDK.RESULT_CODE_CANCEL;
        Intent onBackPressedIntent = new Intent();
        onBackPressedIntent.putExtra(Config.EXTRA_RESPONSE_CODE, resultCode);
        IDnowSDK.getInstance().deliverResult(resultCode, onBackPressedIntent);
        setResult(resultCode, onBackPressedIntent);

        AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_NORMAL);

        super.onBackPressed();
    }

    public void postCandidate(final Candidate candidate) {
        viewModel.postCandidate(candidate);
    }

    private void hideProgressBar() {
        if (!Config.VIDEO_IDENT_PLUS) {
            progressBar.setVisibility(View.GONE);
        }
    }

    public Promise<SessionDescription> makeSendSdpOfferCall(SessionDescription sessionDescription) {
        return viewModel.makeSendSdpOffer(sessionDescription);
    }

    class CallQualityConference extends Conference {
        @Override
        public Promise<SessionDescription> sendSdpOffer(SessionDescription sessionDescription) {
            return makeSendSdpOfferCall(sessionDescription);
        }

        @Override
        public void sendCandidate(Candidate candidate) {
            postCandidate(candidate);
        }

        CallQualityConference(Activity activity) {
            super(activity, false, Mode.CQC);
        }
    }

    @Override
    protected void onStart() {
        Util_CustomLogData.onStart(this);
        super.onStart();
    }

    @Override
    protected void onStop() {
        Util_CustomLogData.onStop();
        super.onStop();
    }
}