package de.idnow.sdk.Activities;

import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothHeadset;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.net.SocketTimeoutException;

import javax.net.ssl.SSLHandshakeException;

import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.Interface_VideoLiveStream;
import de.idnow.sdk.Liveswitch.Conference;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Models_Customer;
import de.idnow.sdk.models.Models_Request;
import de.idnow.sdk.models.Models_SdpOffer;
import de.idnow.sdk.network.Callback;
import de.idnow.sdk.network.IDnowRestClient;
import de.idnow.sdk.network.Network_RESTCalls;
import de.idnow.sdk.network.Network_WebSocketService;
import de.idnow.sdk.network.RetrofitError;
import de.idnow.sdk.network.connectivityService.ConnectivityService;
import de.idnow.sdk.util.Util_CustomLogData;
import de.idnow.sdk.util.Util_IdentSessionAssistant;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_UtilRetrofit;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.Util_UtilWebsocket;
import de.idnow.sdk.util.Util_VideoSessionConfig;
import de.idnow.sdk.util.camera.CameraType;
import fm.liveswitch.Candidate;
import fm.liveswitch.Promise;
import fm.liveswitch.SessionDescription;
import fm.liveswitch.SessionDescriptionType;
import fm.liveswitch.sdp.Message;
import retrofit2.Call;
import retrofit2.Response;


public class Activities_VideoLiveStreamActivity_LIVESWITCH extends Activities_VideoLiveStreamActivity_Super implements Interface_VideoLiveStream, ConnectivityService.Listener {

    private final static String LOGTAG = "IDNOW_Activities_VideoLiveStreamActivity_LIVESWITCH";

    private Conference conference;
    private boolean conferenceStopped = false;

    private RelativeLayout userVideoContainer;
    private RelativeLayout agentVideoContainer;
    public AlertDialog connectionLossAlertDialog;
    private MusicIntentReceiver musicIntentReceiver = null;

    private Integer oldAudioMode = null;
    private Boolean isSpeakerPhoneOn = null;

    public boolean reachable = false;

    private boolean shouldRestoreWaitingScreen = false;
    private boolean isInPictureInPictureModeBkp = false;
    private boolean isDeviceOnline = false;

    private Call<Models_Customer> checkAgentConnectCall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Util_Log.i(LOGTAG, "Instance ID: " + this);

        try {
            if (!Config.ENABLE_BLUETOOTH_AUDIO && checkBluetoothPermissions() && isBluetoothHeadsetConnected()) {
                Util_UtilUI.showBluetoothNotPossible(mContext, true);
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Check bluetooth permissions failed, proceed anyway", e);
        }

        Config.WALLET_VIP = Config.AUTHENTICATED_POSSIBLE;

        if (!Config.VIDEO_IDENT_PLUS || Config.WALLET_LOGIN && !Config.RESTART_VIDEO_IDENT) {
            LiveswitchCalled();
        }
        // Allows apps outside the SDK be aware of what happens inside
        Util_IdentSessionAssistant.getInstance().indicateSessionStarted(IDnowSDK.SessionType.VIDEO_IDENT);

        if (Config.DARK_MODE) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }

        if (Config.CHECK_NETWORK) {
            ConnectivityService.INSTANCE.registerListener(this);
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (Config.ENABLE_PIP_ANDROID && isAgentView)
            enterPictureInPictureSupport();
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode);
        isInPictureInPictureModeBkp = isInPictureInPictureMode;
        if (isInPictureInPictureMode) {
            minimize();
        } else {
            maximize();
        }
    }

    private void enterPictureInPictureSupport() {
        enterPictureInPictureMode(resolvePictureInPictureParams());
    }

    protected void setupPIP() {
        if (Config.ENABLE_PIP_ANDROID)
            setPictureInPictureParams(resolvePictureInPictureParams());
    }

    protected PictureInPictureParams resolvePictureInPictureParams() {
        Rational aspectRatio = new Rational(3, 4);
        PictureInPictureParams.Builder paramsBuilder = new PictureInPictureParams.Builder().setAspectRatio(aspectRatio);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            paramsBuilder = paramsBuilder.setAutoEnterEnabled(true);
        }
        return paramsBuilder.build();
    }

    private void minimize() {
        if (takePictureLayout.getVisibility() == View.VISIBLE)
            setTakePictureLayoutVisibility(View.GONE, true);
        if (video_ident_steps_layout.getVisibility() == View.VISIBLE)
            setVideoIdentStepsLayoutVisibility(View.GONE, true);

        if (waitingSheetDialog != null && waitingSheetDialog.isShowing()) {
            shouldRestoreWaitingScreen = true;
            waitingSheetDialog.dismiss();
            connecting_with_agent_text.setVisibility(View.INVISIBLE);
            progressBarLoading.setVisibility(View.VISIBLE);
            spinnerWL.setVisibility(View.INVISIBLE);
        }
    }

    private void maximize() {
        if (shouldRestoreTakePictureLayout)
            setTakePictureLayoutVisibility(View.VISIBLE, false);
        if (shouldRestoreVideoIdentStepsLayout)
            setVideoIdentStepsLayoutVisibility(View.VISIBLE, false);

        if (!conferenceStarted && shouldRestoreWaitingScreen) {
            shouldRestoreWaitingScreen = false;
            waitingSheetDialog.show();
            connecting_with_agent_text.setVisibility(View.VISIBLE);
            progressBarLoading.setVisibility(View.GONE);
            spinnerWL.setVisibility(View.VISIBLE);
        }
    }

    public void LiveswitchCalled() {
        startService();

        if (Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE) {
            IDnowSDK.setForcedWaitingList(false);
        }

        if (Config.VIDEO_IDENT_PLUS && Config.WAITING_LIST_NOTIFICATIONS_ENROLLED && !Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE) {
            setTakePictureLayoutVisibility(View.GONE, false);
            setVideoIdentStepsLayoutVisibility(View.GONE, false);
            openPushSuccessPanel();
        }

        if (Config.WAITING_LIST_NOTIFICATIONS_ENROLLED && !Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE) {
            openPushSuccessPanel();
            if (Config.SHOULD_DISPLAY_WAITING_SCREEN) {
                hideWaitingScreen();
            }
            if (Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED) {
                hideWaitingScreeenCustomised();
            }
        }

        if (IDnowSDK.isForcedWaitingList()) {

            progressBarLoading.setVisibility(View.GONE);

            if (Config.WAITING_LIST_NOTIFICATIONS_ENROLLED && !Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE) {
                openPushSuccessPanel();

                if (Config.SHOULD_DISPLAY_WAITING_SCREEN) {
                    hideWaitingScreen();
                }

                if (Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED) {
                    hideWaitingScreeenCustomised();
                }

            } else if (!Config.WAITING_LIST_NOTIFICATIONS_ENROLLED && !Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE) {
                openPushDialogPanel();
                openPushLowerPanel();
                if (Config.SHOULD_DISPLAY_WAITING_SCREEN) {
                    hideWaitingScreen();
                }
                if (Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED) {
                    hideWaitingScreeenCustomised();
                }
            }
        } else {
            ((View) mPublisherViewContainer.getParent()).setBackgroundColor(getResources().getColor(R.color.background_view, null));

            try {
                conference = new AgentConference(this);
                conference.setSubscriberProgressBar(mLoadingSub);

                // Preserve a static container across
                // activity destruction/recreation.
                RelativeLayout c = findViewById(R.id.publisherView);

                agentVideoContainer = findViewById(R.id.subscriberView);

                if (userVideoContainer == null) {
                    userVideoContainer = c;
                }

                sessionConnect();

            } catch (Exception ex) {
                Util_Log.e(LOGTAG, "Initialize conference failed", ex);
                throw new RuntimeException(ex); //Propagate error for now, should be replaced with server side logging
            }
        }


    }

    @Override
    protected void onNewIntent(Intent intent) {
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        super.onNewIntent(intent);
    }

    @Override
    public void onDestroy() {
        Util_Log.i(LOGTAG, "onDestroy");
        super.onDestroy();

        if (connectionLossAlertDialog != null) {
            try {
                if (connectionLossAlertDialog.isShowing()) connectionLossAlertDialog.dismiss();
            } catch (Exception ignored) {}
            connectionLossAlertDialog = null;
        }

        AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_NORMAL);
        Util_IdentSessionAssistant.getInstance().indicateSessionStopped(IDnowSDK.SessionType.VIDEO_IDENT);
        Network_WebSocketService.getInstance().removeSink();
        if (Config.CHECK_NETWORK) {
            ConnectivityService.INSTANCE.unregisterListener(this);
        }
    }

    @Override
    public void onConnectivityStateChanged(boolean isOnline) {
        isDeviceOnline = isOnline;
        runOnUiThread(() -> {
            if (isOnline) {
                if (connectionLossAlertDialog != null && connectionLossAlertDialog.isShowing())
                    connectionLossAlertDialog.dismiss();
                if (!Config.AGENT_CONNECTED)
                    checkAgentConnected();
                if (!Network_WebSocketService.getInstance().isRunning()) {
                    Network_WebSocketService.getInstance().setSink(this);
                    Network_WebSocketService.getInstance().run();
                }
            } else {
                showConnectionLossDialog();
            }
        });
    }

    private synchronized void checkAgentConnected() {
        Util_Log.i(LOGTAG, "Prepare check agent call");
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());
        Callback<Models_Customer> callback = new Callback<>() {

            @Override
            public void failure(RetrofitError error) {}

            @Override
            public void success(Models_Customer resultObject, Response response) {
                Models_Request request = resultObject.getRequest();
                if (request == null || request.getStatus() == null)
                    return;

                if (request.computeStatus() == Models_Request.Status.ACCEPTED && !Config.AGENT_CONNECTED)
                    agentConnected();
            }
        };

        if (checkAgentConnectCall != null) {
            Util_Log.w(LOGTAG, "Check agent call was already in progress. It will be canceled");
            checkAgentConnectCall.cancel();
        }
        checkAgentConnectCall = service
                .getCustomer(IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        checkAgentConnectCall.enqueue(callback);
        Util_Log.i(LOGTAG, "Check agent call enqueued");
    }

    private static class MusicIntentReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            final PendingResult result = goAsync();
            Thread thread = new Thread(() -> {
                int code = 101;
                // Do processing
                if (intent.getAction() != null && intent.getAction().equals(Intent.ACTION_HEADSET_PLUG)) {
                    AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                    int state = intent.getIntExtra("state", -1);
                    switch (state) {
                        case 0:
                            Util_Log.i(LOGTAG, "Headset is unplugged");
                            am.setSpeakerphoneOn(true);
                            break;
                        case 1:
                            Util_Log.i(LOGTAG, "Headset is plugged");
                            am.setSpeakerphoneOn(false);
                            break;
                        default:
                            Util_Log.i(LOGTAG, "I have no idea what the headset state is");
                    }
                }

                result.setResultCode(code);
                result.finish();
            });
            thread.start();

        }
    }

    private boolean isBluetoothHeadsetConnected() {
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            return mBluetoothAdapter != null &&
                    mBluetoothAdapter.isEnabled() &&
                    mBluetoothAdapter.getProfileConnectionState(BluetoothHeadset.HEADSET) == BluetoothAdapter.STATE_CONNECTED;
        }
        return false;
    }

    private boolean checkBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {

            boolean btPermStatus = ContextCompat.checkSelfPermission(this,
                    Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED;
            boolean btAdminPermStatus = ContextCompat.checkSelfPermission(this,
                    Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED;
            return btPermStatus && btAdminPermStatus;
        } else
            return true;
    }

    private void setupAudioService() {
        AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);

        oldAudioMode = am.getMode();
        isSpeakerPhoneOn = am.isSpeakerphoneOn();

        am.setMode(AudioManager.MODE_IN_COMMUNICATION);

        boolean headset = am.isWiredHeadsetOn();

        float percent = 0.5f;
        if (!headset) {
            am.setSpeakerphoneOn(true);
            percent = 0.75f;
        }
        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        int musicCurrentVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC);

        int musicMaxVolume = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int voiceMaxVolume = am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL);

        float currentVolumePercent = 0.1f;
        if (musicCurrentVolume != 0 && musicMaxVolume != 0) {
            currentVolumePercent = (float) musicCurrentVolume / musicMaxVolume;
        }

        // if volume to low, set it to 75%
        if (currentVolumePercent < percent) {
            int newVolume = (int) (musicMaxVolume * percent);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0);
        }

        try {
            int musicVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC);

            int newVoiceVolume = voiceMaxVolume * musicVolume / musicMaxVolume;

            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, newVoiceVolume, 0);
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Setup audio for conference failed", e);
        }

        // Request audio focus for playback
        int result = am.requestAudioFocus(null,
                // Use the music stream.
                AudioManager.STREAM_MUSIC,
                // Request permanent focus.
                AudioManager.AUDIOFOCUS_GAIN);

        if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            Util_Log.i(LOGTAG, "Focus request granted");
        } else {
            Util_Log.i(LOGTAG, "Focus request not granted");
        }
    }

    public void showConnectionLossDialog() {
        connectionLossAlertDialog = Util_UtilUI.showLiveswitchConnectionLossDialog(this);

        if (!((Activity) mContext).isFinishing()) {
            // show it
            Util_UtilUI.showBrandedDialog(connectionLossAlertDialog);
        }
    }

    public void stopConference() {
        Util_Log.i(LOGTAG, "stopConference");

        if (conferenceStopped || conference == null) return;
        conferenceStopped = true;

        conference.stopConference().fail(e -> {
            runOnUiThread(() -> showAlertDialog(e.getMessage()));
        });
    }

      public void agentConnected() {
        Config.AGENT_CONNECTED = true;
        Config.SCREEN = "AGENT";

        sessionConnect();

        conferenceStarted = true;

        runOnUiThread(() -> {
            if (Config.VIDEO_IDENT_PLUS) {
                setVideoIdentStepsLayoutVisibility(View.GONE, false);
            }
            hideWaitingScreen();

            if (Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED) {
                hideWaitingScreeenCustomised();
                hideWaitingScreenCustomisationUI();
            }

            if (!Config.VIDEO_IDENT_PLUS) {
                initChatLayout();
            }

            if (!Config.VIDEOSERVER_DISABLED) {
                closePushDialogPanel();
            }

            hideProgressBars();
        });

        conference.connectToAgent(userVideoContainer, agentVideoContainer)
                .then(localMedia -> {
                    runOnUiThread(this::startIdentification);
                })
                .then(localMedia -> {
                    try {
                        videoLiveStreamManager.setupCompleteRESTCall(mContext, isActivityRunning);
                    } catch (Exception ex) {
                        Util_Log.e(LOGTAG, "Call setup complete failed", ex);
                        runOnUiThread(() -> showAlertDialog(ex.getMessage()));
                        throw new RuntimeException(ex);
                    }
                });
    }

    @Override
    protected int getCurrentRetryCount() {
        return conference.getReconnectCount();
    }

    @Override
    protected void disconnectVideoConnection() {
        if (conference != null) {
            conference.disconnect();
        }
    }

    @Override
    protected void establishVideoConnection() {
        try {
            if (conference != null) {
                conference.connect(userVideoContainer, agentVideoContainer);
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Connect conference failed", e);
        }

    }

    private void showAlertDialog(String errorMessage) {
        try {
            Util_UtilUI.showLiveStreamErrorDialog(this, true);
        } catch (RuntimeException e) {
            Util_Log.e(LOGTAG, "Show alert dialog failed", e);
        }
    }

    public void hideProgressBars() {
        if (progressBarLoading != null) {
            progressBarLoading.setVisibility(View.GONE);
        }

        if (mLoadingSub != null) {
            mLoadingSub.setVisibility(View.INVISIBLE);
        }


        try {
            if (Config.VIDEO_IDENT_PLUS) {
                setTakePictureLayoutVisibility(View.GONE, false);
                if (isInPictureInPictureMode()) {
                    setVideoIdentStepsLayoutVisibility(View.GONE, true);
                } else {
                    setVideoIdentStepsLayoutVisibility(View.VISIBLE, false);
                }


                if (Config.VIDEO_IDENT_PLUS_UI) {
                    agent_steps.setVisibility(View.GONE);
                    agent_normal_steps.setVisibility(View.VISIBLE);
                    idcard_text_normal.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE));

                } else {
                    agent_steps.setVisibility(View.VISIBLE);
                    agent_normal_steps.setVisibility(View.GONE);
                }
            }
        } catch (NullPointerException e) {
            Util_Log.e(LOGTAG, "Hide progress bars failed. Layout is null", e);
        }


    }

    public void onBackPressed() {
        AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_NORMAL);
        super.onBackPressed();
    }

    private void stop() {
        Util_Log.i(LOGTAG, "stop Liveswitch");
        try {
            stopConference();

            AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
            am.abandonAudioFocus(null);

            if (oldAudioMode != null) {
                am.setMode(oldAudioMode);
            }
            oldAudioMode = null;

            if (isSpeakerPhoneOn != null) {
                am.setSpeakerphoneOn(isSpeakerPhoneOn);
            }
            isSpeakerPhoneOn = null;

            if (musicIntentReceiver != null) {
                unregisterReceiver(musicIntentReceiver);
                musicIntentReceiver = null;
            }

            agentVideoContainer = null;

            if (userVideoContainer != null) {
                runOnUiThread(() -> {
                    if (userVideoContainer != null) {
                        userVideoContainer = null;
                    }
                });
            }
        } catch (Exception ex) {
            Util_Log.e(LOGTAG, "Stop conference failed", ex);
        }
    }

    @Override
    protected void onPause() {
        Util_Log.i("Connectivity VideoLivestream Activity", "onPause");
        super.onPause();

        if (isInPictureInPictureMode())
            return;

        if (Config.ENABLE_PIP_ANDROID && isAgentView){
            enterPictureInPictureSupport();
            return;
        }

        boolean isOnlineTmp = isDeviceOnline;
        if (isOnlineTmp && connectionLossAlertDialog != null && connectionLossAlertDialog.isShowing()) {
            connectionLossAlertDialog.dismiss();
            Util_Log.i(LOGTAG, "connection dialog dismissed on pause");
        } else if (!isOnlineTmp && connectionLossAlertDialog != null && !connectionLossAlertDialog.isShowing()) {
            try {
                if (!isFinishing()) {
                    connectionLossAlertDialog.show();
                }
            } catch (RuntimeException e) {
                Util_Log.e(LOGTAG, "Show connection lost dialog failed", e);
            }
            Util_Log.i(LOGTAG, "connection dialog existed. shown on pause");
        } else if (!isOnlineTmp && connectionLossAlertDialog == null) {
            connectionLossAlertDialog = Util_UtilUI.showLiveswitchConnectionLossDialog(this);
            try {
                if (!isFinishing()) {
                    connectionLossAlertDialog.show();
                }
            } catch (RuntimeException e) {
                Util_Log.e(LOGTAG, "Show connection lost dialog failed", e);
            }
            Util_Log.i(LOGTAG, "connection dialog created. shown on pause");
        }

        // Remove the static container from the current layout.
        if (userVideoContainer != null) {
            userVideoContainer.setVisibility(View.INVISIBLE);
        }

        if (!Config.INSTANT_SIGN) {
            progressBarLoading.setVisibility(View.VISIBLE);
        }
        isActivityRunning = false;

        updateNotification();

        if (conference != null) {
            conference.pauseLocalVideo();
        }

        if (musicIntentReceiver != null) {
            unregisterReceiver(musicIntentReceiver);
            musicIntentReceiver = null;
        }
    }

    @Override
    public void onResume() {
        Util_Log.i("Connectivity VideoLivestream Activity", "onResume");
        super.onResume();

        boolean isOnlineTmp = isDeviceOnline;
        if (isOnlineTmp && connectionLossAlertDialog != null && connectionLossAlertDialog.isShowing()) {
            connectionLossAlertDialog.dismiss();
            Util_Log.i(LOGTAG, "connection dialog dismissed on resume");
        } else if (!isOnlineTmp && connectionLossAlertDialog != null && !connectionLossAlertDialog.isShowing()) {
            try {
                if (!isFinishing()) {
                    connectionLossAlertDialog.show();
                }
            } catch (RuntimeException e) {
                Util_Log.e(LOGTAG, "Show connection lost dialog failed", e);
            }
            Util_Log.i(LOGTAG, "connection dialog existed. shown on resume");
        } else if (!isOnlineTmp && connectionLossAlertDialog == null) {
            connectionLossAlertDialog = Util_UtilUI.showLiveswitchConnectionLossDialog(this);
            try {
                if (!isFinishing()) {
                    connectionLossAlertDialog.show();
                }
            } catch (RuntimeException e) {
                Util_Log.e(LOGTAG, "Show connection lost dialog failed", e);
            }
            Util_Log.i(LOGTAG, "connection dialog created. shown on resume");
        }

        // Add the static container to the current layout.
        if (userVideoContainer != null) {
            // layout.addView( container);
            userVideoContainer.setVisibility(View.VISIBLE);
        }

        // Resume the local video feed.
        if (conference != null) {
            conference.resumeLocalVideo();
            progressBarLoading.setVisibility(View.GONE);
            if (!Config.AGENT_CONNECTED) {
                checkAgentConnected();
            }
        }

        IntentFilter filter = new IntentFilter(Intent.ACTION_HEADSET_PLUG);
        if (musicIntentReceiver == null) {
            musicIntentReceiver = new MusicIntentReceiver();
            registerReceiver(musicIntentReceiver, filter);
        }

        Network_WebSocketService.getInstance().setSink(this);
        if (!Network_WebSocketService.getInstance().isRunning())
            Network_WebSocketService.getInstance().run();
    }


    @Override
    protected void onStart() {
        super.onStart();
        Util_CustomLogData.onStart(this);
        setupPIP();
    }

    @Override
    public void onStop() {
        Util_Log.i(LOGTAG, "http onStop liveswitch");
        Util_CustomLogData.onStop();

        boolean isInPictureInPictureModeSupport = Build.VERSION.SDK_INT == Build.VERSION_CODES.P
                ? (isFinishing() || (!isInPictureInPictureMode() && isInPictureInPictureModeBkp))
                : isInPictureInPictureMode();

        boolean isFinishingSupport = Build.VERSION.SDK_INT == Build.VERSION_CODES.P
                ? isInPictureInPictureModeSupport
                : isFinishing();

        if (isInPictureInPictureModeSupport) {
            videoLiveStreamManager.identificationCanceledRESTCall("USER_EXIT", pipCanceledCallback);
        }

        super.onStop();

        if (isFinishingSupport) {
            stop();
        }
    }

    // ==============================
    // ICE LINK METHODS
    // ==============================

    // ===============================
    // INTERFACE IMPLEMENTATION
    // ===============================

    @Override
    public void onEndCall(int result) {
        Util_Log.i(LOGTAG, "onEndCall");
        stop();

        super.onEndCall(result);
    }

    @Override
    public void identificationCanceledRESTCall() {

    }

    @Override
    public void triggerOnBackPressed(int resultCode) {
        Util_Log.i(LOGTAG, "triggerOnBackPressed");
        stop();

        super.triggerOnBackPressed(resultCode);
    }

    @Override
    public void openCamera(CameraType type) {
        Util_Log.i(LOGTAG, "openCamera " + type.name());
        try {
            if (conference != null) {
                conference.openCamera(type);
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Open camera " + type.name() + " failed", e);
        }
    }

    @Override
    public void setCameraTorchEnabled(Boolean enabled) {
        Util_Log.i(LOGTAG, "set camera torch enabled: " + enabled);
        try {
            if (conference != null) {
                conference.setCameraTorchEnabled(enabled);
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Set camera torch enabled (" + enabled.toString() + ")", e);
        }
    }

    @Override
    public void takeScreenshot(String type) {
        Config.SCREEN = "AGENT TAKING IMAGES";
        Util_Log.i(LOGTAG, "Starting to take screenshot");

        try {
            conference.takeScreenshot(
                    Config.VIDEO_CONFIG_SCREENSHOT_WIDTH,
                    Config.VIDEO_CONFIG_SCREENSHOT_HEIGHT,
                    new Conference.OnScreenshotCapturedCallback() {
                        @Override
                        public void onScreenshotCaptured(@NonNull Bitmap bitmap) {
                            Util_Log.i(LOGTAG, "Screenshot captured");
                            Util_UtilWebsocket.sendImageToServer(type, bitmap, Activities_VideoLiveStreamActivity_LIVESWITCH.this);
                            bitmap.recycle();
                        }

                        @Override
                        public void onError(Exception e) {
                            Util_Log.e(LOGTAG, "Take screenshot failed", e);
                        }
                    });
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Take screenshot failed", e);
        }
    }

    /**
     * has to be called only when the VideoOverviewCheckActivity hasn't been shown before.
     *
     * @param sessionDescription
     */

    public Promise<SessionDescription> makeSendSdpOfferCall(SessionDescription sessionDescription) {
        String endPoint = Config.CURRENT_SERVER.getVideoHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());
        final Promise<SessionDescription> sessionDescriptionPromise = new Promise<>();

        Callback<Models_SdpOffer> callback = new Callback<>() {

            @Override
            public void failure(RetrofitError error) {
                String result = Util_UtilRetrofit.printRetrofitError(error);

                Util_Log.i(LOGTAG, "SDP Error: " + error.getMessage());
                Util_Log.i(LOGTAG, "SDP result: " + result);

                String errorMessage = error.getMessage() == null ? "" : error.getMessage();

                // don't show the idnow failure dialog when currently the packet loss is at 100% and liveswitch tries to reconnect (this method is triggered as well)
                if (!(error.getCause() != null) &&
                        !(error.getCause() instanceof SocketTimeoutException) &&
                        !(error.getCause() instanceof SSLHandshakeException) &&
                        !errorMessage.equals("") &&
                        !errorMessage.equals("502 Bad Gateway")) {
                    if (!result.equals("")) {
                        result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                    }

                    if (error != null && error.getResponse() != null) {
                        Util_UtilUI.showRESTCallErrorDialog(mContext, error.getResponse().getStatus(), true, startRESTCallRunnable, result, false, false, "");

                    } else {
                        Util_UtilUI.showRESTCallErrorDialog(mContext, 0, true, startRESTCallRunnable, result, false, false, "");
                    }
                }

                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    try {
                        if (connectionLossAlertDialog != null && connectionLossAlertDialog.isShowing()) {
                            connectionLossAlertDialog.dismiss();
                        }
                    } catch (IllegalArgumentException ignored) {}
                    connectionLossAlertDialog = Util_UtilUI.showLiveswitchConnectionLossDialog(Activities_VideoLiveStreamActivity_LIVESWITCH.this);
                    Util_UtilUI.showBrandedDialog(connectionLossAlertDialog);
                });

                reachable = true;
                sessionDescriptionPromise.reject(new RuntimeException("Could not receive remote SDP anwser"));

            }

            @Override
            public void success(Models_SdpOffer resultObject, Response response) {
                Util_Log.i(LOGTAG, "Sent SDP: success");

                SessionDescription answer = new SessionDescription();
                answer.setType(resultObject.isOffer() ? SessionDescriptionType.Offer : SessionDescriptionType.Answer);
                answer.setSdpMessage(Message.parse(resultObject.getSdpMessage()));
                answer.setTieBreaker(resultObject.getTieBreaker());
                Util_Log.i(LOGTAG, "RECEIVED SDP: " + answer.toJson());

                sessionDescriptionPromise.resolve(answer);
            }

        };

        String sessionID = Util_VideoSessionConfig.getSessionId();
        String userToken = Util_VideoSessionConfig.getToken();
        Util_Log.i(LOGTAG, "Using session: " + sessionID);
        Util_Log.i(LOGTAG, "Using session user token: " + userToken);

        Util_Log.i(LOGTAG, "sendSdpOffer() Liveswitch");
        Util_Log.i(LOGTAG, "session description:\n" + sessionDescription.getSdpMessage().toString());

        Models_SdpOffer sdpOffer = new Models_SdpOffer(sessionDescription.getSdpMessage().toString(), sessionDescription.getIsOffer(), sessionDescription.getTieBreaker());
        Call<Models_SdpOffer> result = service
                .sendSdpOffer(sdpOffer, sessionID, userToken);
        result.enqueue(callback);

        return sessionDescriptionPromise;
    }

    @Override
    public void sessionConnect() {
        try {
            setupAudioService();
            if (userVideoContainer != null && subscriberContainer != null) {
                conference.setupConference(userVideoContainer, subscriberContainer).then(localMedia -> {

                    if (!Config.AGENT_CONNECTED) {
                        startWebsocket(true);
                    }
                });
            } else {
                Util_UtilUI.showRESTCallErrorDialog(this, 0, false, startRESTCallRunnable, "", true, true, "");
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Session connect failed", e);
            throw new RuntimeException(e); //Propagate error for now, should be replaced with server side logging
        }
    }

    @Override
    public void requestCameraFocusCenter() {
        try{
            if (conference != null){
                conference.requestCameraFocusCenter();
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Request camera focus center failed", e);
        }
    }

    private class AgentConference extends Conference {
        @Override
        public Promise<SessionDescription> sendSdpOffer(SessionDescription sessionDescription) {
            return makeSendSdpOfferCall(sessionDescription);
        }

        @Override
        public void sendCandidate(Candidate candidate) {

        }

        AgentConference(Activity activity) {
            super(activity, false, Mode.AGENT_CONFERENCE);
        }
    }
}
