package de.idnow.sdk;

import static de.idnow.sdk.Config.BACK_TO_VID;
import static de.idnow.sdk.Config.VIDEO_IDENT_AGENT_FLOW;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_RATING_MSG_GOOGLE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_RATING_NEGATIVE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_RATING_POSITIVE;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_RATING_SCREEN;
import static de.idnow.sdk.util.Util_Strings.KEY_VIDEO_IDENT_RATING_TITLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_RATING_MSG_GOOGLE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_RATING_NEGATIVE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_RATING_POSITIVE;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_RATING_SCREEN;
import static de.idnow.sdk.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_RATING_TITLE;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.net.Uri;
import android.nfc.NfcAdapter;
import android.nfc.NfcManager;
import android.os.Build;
import android.view.ContextThemeWrapper;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import de.idnow.sdk.Activities.Activities_HighCallVolumeActivity;
import de.idnow.sdk.Activities.Activities_VideoOverviewCheckActivity;
import de.idnow.sdk.Activities.entry.Activities_EntryActivity;
import de.idnow.sdk.messages.MessagesProvider;
import de.idnow.sdk.network.IDnowRestClient;
import de.idnow.sdk.network.connectivityService.ConnectivityService;
import de.idnow.sdk.util.CheckboxForm;
import de.idnow.sdk.util.IDnowErrorCode;
import de.idnow.sdk.util.PipConferenceManager;
import de.idnow.sdk.util.Util_IdentSessionAssistant;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_PhotoStrings;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_Util;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.Util_UtilWebsocket;
import de.idnow.sdk.util.Util_VideoStreamService;

/**
 * @author Vasyl Malinskyi
 * @date 03.03.2015
 * @brief Holds the variables to use when moving between some parts of the app. Also stores them in shared preferences.
 */

public class IDnowSDK {
    public static Intent RESULT_INTENT = null;
    private static IDnowSDK instance = null;

    private IDnowResultCallback resultCallback;
    private Intent startIdIntent;

    private Activity callingActivity;

    // If this token is passed during initialization the watermark icon is hidden.
    final private static String WATERMARK_TOKEN = "WaZFtzE1diMNoBwf5rFb";

    private static final String LOGTAG = "IDNOW_IDnowSDK";
    public static String language;

    /**
     * Keys for the passing data
     */
    private static final String SHOW_VIDEO_OVERVIEW_KEY = "showVideoOverview";
    private static final String SHOW_TNC_EID_KEY = "showTNCeID";
    private static final String WL_ANIMATION_NAME_KEY = "waitingListAnimationName";
    private static final String CALL_FROM_HIGH_CALL_VOLUME_KEY = "callFromHighCallVolume";
    private static final String CALLED_OFFICE_HOURS = "calledOfficeHours";
    private static final String CALLED_CUSTOMER_REST = "calledCustomerRest";
    private static final String SHOW_ERROR_SUCCESS_SCREEN_KEY = "showErrorSuccessScreen";
    private static final String SHOW_DIALOGS_WITH_ICON_KEY = "showDialogsWithIcon";
    private static final String TRANSACTION_TOKEN_KEY = "transactionToken";
    private static final String COMPANY_ID_KEY = "companyId";
    private static final String NAME_FOR_ACTIONBAR_KEY = "nameForActionBar";
    private static final String CALLED_FROM_ID_NOW_APP_KEY = "calledFromIdNowApp";
    private static final String API_HOST_KEY = "apiHost";
    private static final String WEBSOCKET_HOST_KEY = "websocketHost";
    private static final String WEB_HOST_KEY = "webHost";
    private static final String VIDEO_HOST_KEY = "videoHost";
    private static final String STUN_HOST_KEY = "stunHost";
    private static final String STUN_PORT_KEY = "stunPortHost";
    private static final String ALLOW_INVALID_CERTIFICATES_KEY = "allowInvalidCertificates";

    public static final String RESULT_DATA_TRANSACTION_TOKEN = "resultDataTransactionToken";
    public static final String RESULT_DATA_ERROR = "resultDataError";
    public static final String RESULT_ERROR_CODE = "resultErrorCode";
    public static final String RESULT_SERVER_STATUS_CODE = "resultServerStatusCode";

    public static final int MESSAGE_USER_CANCELED = R.string.message_user_canceled;
    public static final int MESSAGE_ID_FAILED = R.string.message_id_failed;
    public static final int MESSAGE_ID_FAILED_NO_CONNECTION = R.string.message_id_failed_no_connection;
    public static final int MESSAGE_WRONG_TOKEN = R.string.wrong_token;

    public static final String WRONG_CONFIRMATION_TOKEN = "WRONG_CONFIRMATION_TOKEN";
    public static final String CONFIRMATION_TOKEN_LIMIT_EXCEEDED = "CONFIRMATION_TOKEN_LIMIT_EXCEEDED";
    public static final String DOCUSIGN_TOKEN_EXPIRING_SOON = "DOCUSIGN_TOKEN_EXPIRING_SOON";

    public static final String INSTANTSIGN_ERROR_ID = "USER_ID_DOCUMENT_EXPIRED_NO_FALLBACK";

    private static Class<?> VIDEO_CHECKSCREEN_CLASS = Activities_VideoOverviewCheckActivity.class;
    private static final Class<?> HIGH_CALL_VOLUME_CLASS = Activities_HighCallVolumeActivity.class;

    /**
     * Codes passed
     */
    public static final int REQUEST_ID_NOW_SDK = 2;

    public static int RESULT_CODE = -1;
    public static final int RESULT_CODE_FAILED = 1;
    public static final int RESULT_CODE_SUCCESS = 2;
    public static final int RESULT_CODE_CANCEL = 3;
    public static final int RESULT_CODE_WRONG_IDENT = 4;
    public static final int RESULT_CODE_FALLBACK_VID = 5;
    public static final int RESULT_CODE_INTERNAL = 123456789;
    public static final int RESULT_USER_IN_QUEUE = 13;
    public static final int RESULT_CALL_QUALITY_DONE = 14;
    public static final int RESULT_LANGUAGE_SELECTOR_CANCELED = 15;
    public static final int CHOOSER_SCREEN = 7;
    public static final int HOME_SCREEN = 8;
    /**
     * Variables which are also persisted in preferences
     */
    private static Boolean showVideoOverviewCheck = null;
    private static Boolean showTermsConditionsEID = null;
    private static Boolean callFromHighCallVolume = null;
    private static final Boolean calledOfficeHours = null;
    private static final Boolean calledCustomerRest = null;
    private static Boolean showErrorSuccessScreen = null;
    private static boolean showRatingDialog = false;
    private static Boolean showDialogsWithIcon = true;
    private static Server environment = null;
    private static String waitingListAnimationName = null;
    private static String apiHost = "";
    private static String websocketHost = "";
    private static String webHost = "";
    private static String videoHost = "";
    private static String stunHost = "";
    private static Integer stunPort = 3478;
    private static final Integer showSMSDialog = -1;
    private static ConnectionType connectionType = ConnectionType.WEBSOCKET;

    private static boolean forcedWaitingList = false;

    private static boolean isDarkModeFlagInitialized = false;

    private static String nameForActionBar = "";

    private static String transactionToken = "";
    // Corresponds to "shortname" in the ios project.
    private static String companyId = "";
    private static Boolean calledFromIDnowApp = false;

    private static final String INITIALIZE = "initialize";
    private static final String START = "start";

    private static boolean LOGGING_ENABLED = true;

    // taking screenshots per default is disabled. to enable it, change this flag to "false"
    public static final boolean preventScreenshot = false;

    public static boolean enableChat = true;

    private Context appContext;

    private boolean startCallIssued = false;

    private IDnowErrorCode resultErrorCode;

    public static void updateResultCode(int resultCode) {
        if (resultCode < 1 || resultCode > 3) {
            Util_Log.e(LOGTAG, "WRONG resultCode: " + resultCode);
            return;
        }

        RESULT_CODE = resultCode;
    }

    public static int getResultCode() {
        return IDnowSDK.RESULT_CODE;
    }

    public static Intent getResultIntent() {
        return IDnowSDK.RESULT_INTENT;
    }

    // =====================
    // ACTIVITY METHODS
    // =====================

    public enum SessionType {
        UNKNOWN, VIDEO_IDENT, PHOTO_IDENT
    }

    public enum ConnectionType {
        WEBSOCKET, LONG_POLLING
    }

    public enum OverridableUIElement {
        E_SIGNING_DOCUSIGN_BACK_BUTTON
    }

    // INT environment means "intrum"
    public enum Server {
        DEV, DEV2, TEST, TEST1, TEST2, TEST3, LIVE, CUSTOM, INT, DV3, DV4, DV5, DV7, DV0, DV8, DV9,
        DV10, DV11, DV12, DV13, DV14, DV15, DV16, DV17, DV18, DV19, DV20, DV1, SG1;

        public String getApiHost(String token) {
            if (token.toUpperCase().startsWith("DV")) {
                return "https://api.dev" + token.toUpperCase().split("-")[0].replace("DV", "") + ".idnow.de";
            }
            switch (this) {
                case DEV:
                    return "https://api.dev.idnow.de";
                case DEV2:
                    return "https://api.dev2.idnow.de";
                case TEST:
                    if (token.length() == 13) {
                        return "https://api.test.online-ident.ch";
                    } else {
                        return "https://api.test.idnow.de";
                    }
                case TEST1:
                    return "https://api.test.idnow.de";
                case TEST2:
                    return "https://api.test.idnow.de";
                case TEST3:
                    return "https://api.test.idnow.de";
                case SG1:
                    return "https://api.staging1.idnow.de";
                case LIVE:
                    return "https://api.idnow.de";
                case INT:
                    return "https://api.online-ident.ch";
                case CUSTOM:
                    return apiHost;
                default:
                    return "";
            }
        }

        public String getSocketHost(String token) {
            if (token.startsWith("DV")) {
                return "https://api.dev" + token.replaceAll("[^0-9]", "") + ".idnow.de";
            }
            switch (this) {
                case DEV:
                    return "https://api.dev.idnow.de";
                case DEV2:
                    return "https://api.dev2.idnow.de";
                case TEST:
                    if (token.length() == 13) {
                        return "https://api.test.online-ident.ch";
                    } else {
                        return "https://api.test.idnow.de";
                    }
                case TEST1:
                    return "https://api.test.idnow.de";
                case TEST2:
                    return "https://api.test.idnow.de";
                case TEST3:
                    return "https://api.test.idnow.de";
                case SG1:
                    return "https://api.staging1.idnow.de";
                case LIVE:
                    return "https://api.idnow.de";
                case INT:
                    return "https://api.online-ident.ch";
                case CUSTOM:
                    return websocketHost;
                default:
                    return "";
            }
        }

        public String getWebHost(String token) {
            if (token.startsWith("DV")) {
                return "https://go.dev" + token.replaceAll("[^0-9]", "") + ".idnow.de";
            }
            switch (this) {
                case DEV:
                    return "https://go.dev.idnow.de";
                case DEV2:
                    return "https://go.dev2.idnow.de";
                case TEST:
                    if (token.length() == 13) {
                        return "https://go.test.online-ident.ch";
                    } else {
                        return "https://go.test.idnow.de";
                    }
                case TEST1:
                    return "https://go.test.idnow.de";
                case TEST2:
                    return "https://go.test.idnow.de";
                case TEST3:
                    return "https://go.test.idnow.de";
                case SG1:
                    return "https://go.staging1.idnow.de";
                case LIVE:
                    return "https://go.idnow.de";
                case INT:
                    return "https://go.online-ident.ch";
                case CUSTOM:
                    return webHost;
                default:
                    return "";
            }
        }

        public String getVideoHost(String token) {
            if (token.startsWith("DV")) {
                return "https://video.dev" + token.replaceAll("[^0-9]", "") + ".idnow.de";
            }
            switch (this) {
                case DEV:
                    return "https://video.dev.idnow.de";
                case DEV2:
                    return "https://video.dev2.idnow.de";
                case TEST:
                    if (token.length() == 13) {
                        return "https://video.test.online-ident.ch";
                    } else {
                        return "https://video.test.idnow.de";
                    }
                case TEST1:
                    return "https://video.test.idnow.de";
                case TEST2:
                    return "https://video.test.idnow.de";
                case TEST3:
                    return "https://video.test.idnow.de";
                case SG1:
                    return "https://video.staging1.idnow.de";
                case LIVE:
                    return "https://video.idnow.de";
                case INT:
                    return "https://video.online-ident.ch";
                case CUSTOM:
                    return videoHost;
                default:
                    return "";
            }
        }

        public String getStunHost(String token) {
            if (token.startsWith("DV")) {
                return "video.dev" + token.replaceAll("[^0-9]", "") + ".idnow.de";
            }
            switch (this) {
                case DEV:
                    return "video.dev.idnow.de";
                case DEV2:
                    return "video.dev2.idnow.de";
                case TEST:
                    if (token.length() == 13) {
                        return "video.test.online-ident.ch";
                    } else {
                        return "video.test.idnow.de";
                    }
                case TEST1:
                    return "video.test.idnow.de";
                case TEST2:
                    return "video.test.idnow.de";
                case TEST3:
                    return "video.test.idnow.de";
                case SG1:
                    return "video.staging1.idnow.de";
                case LIVE:
                    return "video.idnow.de";
                case INT:
                    return "video.online-ident.ch";
                case CUSTOM:
                    return stunHost;
                default:
                    return "";
            }
        }

        public Integer getStunPort() {
            switch (this) {
                case CUSTOM:
                    return stunPort;
                default:
                    return 3478;
            }
        }
    }

    private IDnowSDK() {
    }

    public static IDnowSDK getInstance() {
        if (instance == null) {
            instance = new IDnowSDK();
        }
        return instance;
    }

    /**
     * resetting all static values. this prevents error states after multiple idents.
     * the static values may be changed during an ident and not be changed back to their
     * default values without calling this method the next time the user starts a new ident.
     */
    public static void resetStaticFields() {
        Config.E_SIGNING = false;
        Config.E_SIGNING_HAND_WRITING = false;
        Config.IDENT_CODE_REQUIRED = true;
        Config.VIDEOSERVER_DISABLED = false;
        Config.IDENT_CODE_BY_EMAIL = false;
        Config.OPENTRUST_URL = "";
        Config.USER_PHONE_NO = "";
        Config.SHOW_GTC = false;
        Config.SHOW_RECORDING_AGREEMENT = true;
        Config.SUCCESS_MESSAGE = "";
        Config.FAILURE_MESSAGE = "";
        Config.SUCCESS_URL = "";
        Config.FAILURE_URL = "";
        Config.FALLBACK_URL = "";
        Config.TERMS_TEXT = "";
        Config.EMAIL_ADDRESS = "";
        Config.E_SIGNING_SECRET = "";
        Config.USER_SESSION_TOKEN = "";
        Config.AGENT_CONNECTED = false;
        Config.PHOTO_IDENT_VIDEO_DURATION = 30;
        IDnowSDK.transactionToken = "";
        IDnowSDK.companyId = "";
        Config.VERIFY_PHONE_NO = false;
        Config.RESTART_VIDEO_IDENT = false;
        VIDEO_IDENT_AGENT_FLOW = false;
        Config.WALLET_LOGIN = false;
        Config.MODEL_APPROVAL_PHRASES = null;
        Config.URL_DOCUMENT_NAMIRIAL = "";
        Config.INSTANTERROR_TYPE = "";
        Config.ABORT_IDENT = false;
        Config.VERIFY_IDENTITY = false;
        Config.WALLET_REGISTRATION = false;
        Config.NORMAL_ESIGN = false;
        Config.AUTHENTICATED_POSSIBLE = false;
        Config.AUTHENTICATED_SIGNED = false;
        Config.WALLET_VIP = false;
        Config.SUCCESS_LOGIN = false;
        Config.USE_NATIVE_ESIGNING = false;

        MessagesProvider.INSTANCE.reset();
        Config.MESSAGES = null;
        Config.REMOTE_ANIMATIONS = null;
    }

    public static void resetStativFieldsTryAgain() {
        Config.AGENT_CONNECTED = false;
        VIDEO_IDENT_AGENT_FLOW = false;
        Config.WALLET_LOGIN = false;
        Config.OPENTRUST_URL = "";
    }


    // initialise with default device locale
    public void initialize(Activity callingActivity, String companyId) throws Exception {
        initialize(callingActivity, companyId, getCurrentLocale(callingActivity).getLanguage());

    }

    public static void setLocale(Context c, String language) {
        setNewLocale(c, language);
    }

    public static void setNewLocale(Context c, String language) {
        updateResources(c, language);
    }

    private static void updateResources(Context context, String language) {
        if (language != null && !language.isEmpty()) {
            IDnowSDK.language = language;
        }

        Locale locale = new Locale(language);
        Locale.setDefault(locale);

        Resources res = context.getResources();
        Configuration config = new Configuration(res.getConfiguration());
        config.locale = locale;
        res.updateConfiguration(config, res.getDisplayMetrics());
    }

    public void initialize(Activity callingActivity, String companyId, String language) throws Exception {
        ConnectivityService.INSTANCE.init(callingActivity.getApplication());
        BACK_TO_VID = false;
        PipConferenceManager.INSTANCE.initialize(callingActivity.getApplication());
        IDnowSDK.setCallFromHighCallVolumeActivity(false, callingActivity);

        int nightModeFlags =
                callingActivity.getResources().getConfiguration().uiMode &
                        Configuration.UI_MODE_NIGHT_MASK;
        switch (nightModeFlags) {
            case Configuration.UI_MODE_NIGHT_YES:
                Config.DARK_MODE = true;
                break;

            case Configuration.UI_MODE_NIGHT_NO:
                Config.DARK_MODE = false;
                break;

            case Configuration.UI_MODE_NIGHT_UNDEFINED:
                break;
        }

        language = language == null || language.isEmpty() ? "en" : language;
        IDnowSDK.language = language;
        if (!isValidLocaleLanguage(language)) {
            setLocale(callingActivity, getCurrentLocale(callingActivity).getLanguage());
        } else {
            setLocale(callingActivity, language);
        }
        this.callingActivity = callingActivity;
        this.appContext = callingActivity.getApplicationContext();
        resetStaticFields();
        Config.HOST_APP_START_ACTIVITY = this.callingActivity.getClass();

        // First check for context.
        if (null == this.callingActivity) {
            StringBuilder message = new StringBuilder();
            message.append("Called from: initialize()").append("\n Passed invalid context to SDK. \n");
            throw (new Exception(message.toString()));
        }

        // Call this before using context
        checkParameters("initialize()");

        setCompanyId(companyId);
        startIdIntent = new Intent(this.callingActivity.getBaseContext(), Activities_EntryActivity.class);

        // Try getting name of calling application
        String appName = getApplicationName(callingActivity.getBaseContext());
//        String appName = getApplicationName(appContext);
        if (!appName.isEmpty()) {
            setNameForActionBar(appName, appContext);
        }

        deviceHasNfc();
    }

    public void start(String transactionToken, IDnowResultCallback resultCallback) throws Exception {
        this.resultCallback = resultCallback;
        start(transactionToken);
    }

    /**
     * let the SDK take over
     *
     * @param transactionToken
     * @throws Exception
     */
    public void start(String transactionToken) throws Exception {
        Config.CANCELATION_STEP = null;
        Config.CANCELED_AT_STEP = null;
        Config.ABORT_IDENT = false;
        RESULT_CODE = -1;
        int nightModeFlags =
                callingActivity.getResources().getConfiguration().uiMode &
                        Configuration.UI_MODE_NIGHT_MASK;
        switch (nightModeFlags) {
            case Configuration.UI_MODE_NIGHT_YES:
                Config.DARK_MODE = true;
                break;

            case Configuration.UI_MODE_NIGHT_NO:
                Config.DARK_MODE = false;
                break;
            case Configuration.UI_MODE_NIGHT_UNDEFINED:
                break;
        }

        // First check for context.
        if (null == this.callingActivity) {
            StringBuilder message = new StringBuilder();
            message.append("Called from: start()").append("\n Passed invalid context to SDK. \n");
            throw (new Exception(message.toString()));
        }

        setTransactionToken(transactionToken);
        Util_Util.handleServerSelection(getTransactionToken());

        checkParameters("start()");


        Config.APP_ID = callingActivity.getPackageName();

        // hiding the poweredBy logo, when the calling app is idnow host app
        if (Config.APP_ID.equals("de.idnow")) {
            setCalledFromIDnowApp(true, appContext);
        }

        callingActivity.startActivityForResult(startIdIntent, REQUEST_ID_NOW_SDK);
    }

    public boolean isSessionActive() {
        // As other ident types will be integrated, the logic must be revisited
        return Util_IdentSessionAssistant.getInstance().isSessionActive(SessionType.VIDEO_IDENT);
    }

    public void bringUpActiveSession(@NonNull Activity callingActivity, @Nullable Intent passThroughIntent) {

        if (Util_IdentSessionAssistant.getInstance().isSessionActive(SessionType.VIDEO_IDENT)) {

            Intent videoActivityIntent = new Intent(callingActivity, Util_VideoStreamService.getClassForVideoLiveStreaming());
            videoActivityIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            if (passThroughIntent != null) {
                videoActivityIntent.setData(passThroughIntent.getData());
                videoActivityIntent.setAction(passThroughIntent.getAction());
            }

            callingActivity.startActivityForResult(videoActivityIntent, IDnowSDK.REQUEST_ID_NOW_SDK);
        }
    }

    public static void fillTokenField(EditText field, Intent intent) {
        // Set field value after create so that text widget isn't null
        if (intent != null && intent.getData() != null && field != null) {
            String transactionToken = IDnowSDK.extractUriToken(intent.getData());
            if (transactionToken != null && !transactionToken.isEmpty()) {
                field.setText(transactionToken);
                // Workaround that fixes extra hyphen being added at the end - god knows why
                transactionToken = transactionToken.replace("-$", "");
                field.setText(transactionToken);
            }
        }
    }

    private static String extractUriToken(Uri uri) {
        String path = uri.getPath();
        String[] parts = path.split("/");
        String token = parts[parts.length - 1].replaceFirst("/", "");

        return token;
    }

    /**
     * Assumes valid context!
     * Checks if the parameters passed to the SDK seem to be correct
     *
     * @throws Exception
     */
    private void checkParameters(String callingMethod) throws Exception {
        StringBuilder message = new StringBuilder();
        boolean doThrow = false;

        // Prepare message
        message.append("Called from: ").append(callingMethod).append("\n Passed wrong values to SDK! \n");

        // Check for companyId
        if (null == getCompanyId() || getCompanyId().equals("")) {

            message.append("companyId: ").append(getCompanyId()).append(" shouldn't be null, after calling initialize()\n");
        }

        // Transaction token has to be checked only on start, so don't check it
        // otherwise
        if (callingMethod.equals(START)) {
            if (null == getTransactionToken() || getTransactionToken().equals("")) {
                message.append("\n TOKEN: ").append(getTransactionToken()).append("shouldn't be null if you already called start. ");
            }
        }

        if (doThrow) {
            throw (new Exception(message.toString()));
        }
    }

    /**
     * Is used to display the AppName as ActionBar title
     *
     * @param context
     * @return
     */
    private static String getApplicationName(Context context) {
        try {
            int stringId = context.getApplicationInfo().labelRes;
            return context.getString(stringId);
        } catch (NotFoundException e) {
            Util_Log.e(LOGTAG, "Read application name failed", e);
            return "";
        }
    }

    // =====================
    // GETTERS & SETTERS
    // =====================

    public void deliverResult(int resultCode, Intent data) {
        if (resultCode == RESULT_CODE_CANCEL && data != null) {
            // Freeze the step on the FIRST cancel delivery (before teardown mutates the live
            // value), then attach the same frozen value to every subsequent cancel delivery so
            // the integrator always sees the screen the user actually canceled on.
            if (Config.CANCELED_AT_STEP == null) {
                Config.CANCELED_AT_STEP = Config.CANCELATION_STEP;
            }
            if (Config.CANCELED_AT_STEP != null) {
                data.putExtra(Config.EXTRA_CANCELATION_STEP, Config.CANCELED_AT_STEP);
            }
        }
        if (resultCallback != null) {
            resultCallback.onResult(resultCode, data);
        }
    }

    public static Boolean isShowVideoOverviewCheck(Context context) {
        if (null == showVideoOverviewCheck) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            showVideoOverviewCheck = prefs.getBoolean(SHOW_VIDEO_OVERVIEW_KEY, true);
        }
        return showVideoOverviewCheck;
    }

    public static Boolean isShowTermsConditionsEID() {
        if (null == showTermsConditionsEID) {
            SharedPreferences prefs = IDnowSDK.getInstance().getAppContext()
                    .getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            showTermsConditionsEID = prefs.getBoolean(SHOW_TNC_EID_KEY, true);
        }
        return showTermsConditionsEID;
    }

    public static String getWaitingListAnimationName(Context context) {
        if (null == waitingListAnimationName) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            waitingListAnimationName = prefs.getString(WL_ANIMATION_NAME_KEY, null);
        }
        return waitingListAnimationName;
    }

    public static Boolean getShowPoweredBy() {
        return Config.SHOW_POWERED_BY_KEY;
    }

    public static Boolean getShowIDnowLogo() {
        return Config.SHOW_IDNOW_LOGO;
    }

    public static void setShowIDnowLogo(boolean showIDnowLogo) {
        Config.SHOW_IDNOW_LOGO = showIDnowLogo;
    }

    public static Boolean isLoggingEnabled() {
        return LOGGING_ENABLED;
    }

    public static void enableLogging() {
        LOGGING_ENABLED = true;
    }

    public static void disableLogging() {
        LOGGING_ENABLED = false;
    }

    /**
     * Initializing the SDK the developer of the hostApp can decide if the CheckScreen is supposed to be shown or not
     *
     * @param context
     * @return
     */
    public static void setShowVideoOverviewCheck(Boolean showVideoOverviewCheck, Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        IDnowSDK.showVideoOverviewCheck = showVideoOverviewCheck;
        prefs.edit().putBoolean(SHOW_VIDEO_OVERVIEW_KEY, IDnowSDK.showVideoOverviewCheck).apply();
    }

    /**
     * Method provided for SDK initialization that sets a custom local WL animation
     *
     * @param context
     * @return
     */
    public static void setWaitingListAnimationName(String waitingListAnimationName, Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        IDnowSDK.waitingListAnimationName = waitingListAnimationName;
        prefs.edit().putString(WL_ANIMATION_NAME_KEY, IDnowSDK.waitingListAnimationName).apply();
    }

    /**
     * Method provided for SDK initialization that controls displaying the Terms&Conditions for eID
     *
     * @param context
     * @return
     */
    public static void setShowTermsConditionsEID(Boolean showTermsConditionsEID, Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        IDnowSDK.showTermsConditionsEID = showTermsConditionsEID;
        prefs.edit().putBoolean(SHOW_TNC_EID_KEY, IDnowSDK.showTermsConditionsEID).apply();
    }

    public static Boolean getShowErrorSuccessScreen(Context context) {
        if (null == showErrorSuccessScreen) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            showErrorSuccessScreen = prefs.getBoolean(SHOW_ERROR_SUCCESS_SCREEN_KEY, true);
        }
        return showErrorSuccessScreen;
    }

    public static void setCallFromHighCallVolumeActivity(Boolean callFromHighCallVolume, Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        IDnowSDK.callFromHighCallVolume = callFromHighCallVolume;
        prefs.edit().putBoolean(CALL_FROM_HIGH_CALL_VOLUME_KEY, IDnowSDK.callFromHighCallVolume).apply();
    }

    public static Boolean getCallFromHighCallVolumeActivity(Context context) {
        if (null == callFromHighCallVolume) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            callFromHighCallVolume = prefs.getBoolean(CALL_FROM_HIGH_CALL_VOLUME_KEY, false);
        }
        return callFromHighCallVolume;
    }

//    public static void setCalledOfficeHours(Boolean calledOfficeHours, Context context) {
//        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
//        IDnowSDK.calledOfficeHours = calledOfficeHours;
//        prefs.edit().putBoolean(CALLED_OFFICE_HOURS, IDnowSDK.calledOfficeHours).apply();
//    }
//
//    public static Boolean getCalledOfficeHours(Context context) {
//        if (null == calledOfficeHours) {
//            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
//            calledOfficeHours = prefs.getBoolean(CALLED_OFFICE_HOURS, false);
//        }
//        return calledOfficeHours;
//    }
//
//    public static void setCalledCustomerRest(Boolean calledCustomerRest, Context context) {
//        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
//        IDnowSDK.calledCustomerRest = calledCustomerRest;
//        prefs.edit().putBoolean(CALLED_CUSTOMER_REST, IDnowSDK.calledCustomerRest).apply();
//    }
//
//    public static Boolean getCalledCustomerRest(Context context) {
//        if (null == calledCustomerRest) {
//            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
//            calledCustomerRest = prefs.getBoolean(CALLED_CUSTOMER_REST, false);
//        }
//        return calledCustomerRest;
//    }


    /**
     * Initializing the SDK the developer of the hostApp can decide if the ResultScreen is supposed to be shown or not.
     *
     * @param context
     * @return
     */
    public static void setShowErrorSuccessScreen(Boolean showErrorSuccessScreen, Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        IDnowSDK.showErrorSuccessScreen = showErrorSuccessScreen;
        prefs.edit().putBoolean(SHOW_ERROR_SUCCESS_SCREEN_KEY, IDnowSDK.showErrorSuccessScreen).apply();
    }

    public static String getTransactionToken() {
        return IDnowSDK.transactionToken;
    }

    public static void setTransactionToken(String transactionToken) {
        IDnowSDK.transactionToken = transactionToken;
    }

    public static String getCompanyId() {
        return IDnowSDK.companyId;
    }

    public static void setCompanyId(String companyId) {
        IDnowSDK.companyId = companyId;
    }

    public static String getNameForActionBar(Context context) {
        if (null == nameForActionBar) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            nameForActionBar = prefs.getString(NAME_FOR_ACTIONBAR_KEY, "");
        }
        return nameForActionBar;
    }

    public static void setNameForActionBar(String nameForActionBar, Context context) {
        IDnowSDK.nameForActionBar = nameForActionBar;
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(NAME_FOR_ACTIONBAR_KEY, IDnowSDK.nameForActionBar).apply();
    }

    public static boolean getCheckScreenLinesLong() {
        return Config.CHECK_SCREEN_LINES_LONG;
    }

    public static boolean getCheckBoxOrientationRight() {
        return Config.CHECK_BOX_ORIENTATION_RIGHT;
    }

    public static boolean getCheckScreenBoxPhoneNumberRequired() {
        return Config.CHECK_SCREEN_BOX_PHONENUMBER_REQUIRED;
    }

    public static boolean getCheckScreenBoxDocumentRequired() {
        return Config.CHECK_SCREEN_BOX_DOCUMENT_REQUIRED;
    }

    public static boolean getCheckScreenBoxEMailRequired() {
        return Config.CHECK_SCREEN_BOX_EMAIL_REQUIRED;
    }

    public static boolean getCheckScreenBoxConsentRequired() {
        return Config.CHECK_SCREEN_BOX_CONSENT_REQUIRED;
    }

    public static boolean getShowTokenDuringCheckScreen() {
        return Config.SHOW_TOKEN_DURING_CHECK_SCREEN;
    }

    public static String getApiHost(Context context) {
        if (null == apiHost) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            apiHost = prefs.getString(API_HOST_KEY, "");
        }
        return apiHost;
    }

    public static void setApiHost(String apiHost, Context context) {
        IDnowSDK.apiHost = apiHost;
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(API_HOST_KEY, IDnowSDK.apiHost).apply();
    }

    public static void setCertificateProvider(CertificateProvider provider) {
        IDnowRestClient.clearInstance();
        Config.CERTIFICATE_PROVIDER = provider;
    }

    public static void setDtlsCertificateProvider(CertificateProvider dtlsCertificateProvider) {
        Config.DTLS_CERTIFICATE = dtlsCertificateProvider;
    }

    public static void setDtlsCertificateProviderOverUDP(CertificateProvider dtlsCertificateProvider) {
        Config.DTLS_CERTIFICATE_OVER_UDP = dtlsCertificateProvider;
    }

    static String getWebsocketHost(Context context) {
        if (null == websocketHost) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            websocketHost = prefs.getString(WEBSOCKET_HOST_KEY, "");
        }
        return websocketHost;
    }

    public static void setWebsocketHost(String websocketHost, Context context) {
        IDnowSDK.websocketHost = websocketHost;
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(WEBSOCKET_HOST_KEY, IDnowSDK.websocketHost).apply();
    }

    public static String getWebHost(Context context) {
        if (null == webHost) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            webHost = prefs.getString(WEB_HOST_KEY, "");
        }
        return webHost;
    }

    public static void setWebHost(String webHost, Context context) {
        IDnowSDK.webHost = webHost;
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(WEB_HOST_KEY, IDnowSDK.webHost).apply();
    }

    public static String getVideoHost(Context context) {
        if (null == videoHost) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            videoHost = prefs.getString(VIDEO_HOST_KEY, "");
        }
        return videoHost;
    }

    public static void setVideoHost(String videoHost, Context context) {
        IDnowSDK.videoHost = videoHost;
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(VIDEO_HOST_KEY, IDnowSDK.videoHost).apply();
    }

    public static String getStunHost(Context context) {
        if (null == stunHost) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            stunHost = prefs.getString(STUN_HOST_KEY, "");
        }
        return stunHost;
    }

    public static void setStunHost(String stunHost, Context context) {
        IDnowSDK.stunHost = stunHost;
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(STUN_HOST_KEY, IDnowSDK.stunHost).apply();
    }

    public static Integer getStunPort(Context context) {
        if (null == stunPort) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            stunPort = prefs.getInt(STUN_PORT_KEY, 3478);
        }
        return stunPort;
    }

    public static void setStunPort(Integer stunPort, Context context) {
        IDnowSDK.stunPort = stunPort;
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(STUN_PORT_KEY, IDnowSDK.stunPort).apply();
    }

    public static ConnectionType getConnectionType(Context context) {
        return connectionType;
    }

    public static void setConnectionType(ConnectionType connectionType, Context context) {
        IDnowSDK.connectionType = connectionType;
    }

    public static Boolean calledFromIDnowApp(Context context) {
        if (null == calledFromIDnowApp) {
            SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            calledFromIDnowApp = prefs.getBoolean(CALLED_FROM_ID_NOW_APP_KEY, false);
        }
        return calledFromIDnowApp;
    }

    static void setCalledFromIDnowApp(Boolean calledFromIDnowApp, Context context) {
        IDnowSDK.calledFromIDnowApp = calledFromIDnowApp;
        SharedPreferences prefs = context.getSharedPreferences(Util_PhotoStrings.SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(CALLED_FROM_ID_NOW_APP_KEY, IDnowSDK.calledFromIDnowApp).apply();
    }

    public static Server getEnvironment() {
        return environment;
    }

    public static void setEnvironment(Server environment) {
        IDnowSDK.environment = environment;
    }

    public static void setCheckScreenLinesLong(boolean value) {
        Config.CHECK_SCREEN_LINES_LONG = value;
    }

    public static void setCheckBoxOrientationRight(boolean value) {
        Config.CHECK_BOX_ORIENTATION_RIGHT = value;
    }

    public static void setCheckScreenBoxPhoneNumberRequired(boolean value) {
        Config.CHECK_SCREEN_BOX_PHONENUMBER_REQUIRED = value;
    }

    public static void setCheckScreenBoxDocumentRequired(boolean value) {
        Config.CHECK_SCREEN_BOX_DOCUMENT_REQUIRED = value;
    }

    public static void setCheckScreenBoxEMailRequired(boolean value) {
        Config.CHECK_SCREEN_BOX_EMAIL_REQUIRED = value;
    }

    public static void setCheckScreenBoxConsentRequired(boolean value) {
        Config.CHECK_SCREEN_BOX_CONSENT_REQUIRED = value;
    }

    public static void setCustomiseCallQualityCheckScreen(boolean value) {
        Config.CHECK_CALL_QUALITY_CHECK_SCREEN_ENABLED = value;
    }

    public static void setShowTokenDuringCheckScreen(boolean value) {
        Config.SHOW_TOKEN_DURING_CHECK_SCREEN = value;
    }

    public static void setSquareCheckboxForm() {
        Config.CHECKBOX_FORM = CheckboxForm.SQUARE;
    }

    public static void setAGBInOneLine(boolean agbInOneLine) {
        Config.ONE_LINE_AGB = agbInOneLine;
    }

    public static void setCheckboxesOrientationTop(boolean checkboxesOrientationTop) {
        Config.CHECK_BOX_ORIENTATION_TOP = checkboxesOrientationTop;
    }

    public static void doNotShowCompanyImageInResultActivity() {
        Config.SHOW_IMAGE_IN_RESULT_ACTIVITY = false;
    }

    public static void setHeaderBolded(boolean headerBolded) {
        Config.HEADER_BOLDED = headerBolded;
    }

    public static void setFullSizeModalSmsWindow(boolean smsWindowSizeToHalf) {
        Config.FULL_SIZE_MODAL_SMS_WINDOW = smsWindowSizeToHalf;
    }

    public static void setTransparentBackgroundModalSmsWindow(boolean isTransparentModalSmsWindow) {
        Config.TRANSPARENT_BACKGROUND_MODAL_SMS_WINDOW = isTransparentModalSmsWindow;
    }

    public static void setWhiteAgentThumbnailBackground(boolean isisWhiteAgentThumbnailBackground) {
        Config.WHITE_AGENT_THUMBNAIL_BACKGROUND = isisWhiteAgentThumbnailBackground;
    }

    /**
     * Access the phoneNumber from outside the SDK. This is needed if one wants to set a custom CheckScreen.
     *
     * @return
     */
    public static String getPhoneNo() {
        return Config.USER_PHONE_NO;
    }

    /**
     * Access the email address of the user from outside the SDK. This is needed for the ResultScreen for example.
     *
     * @return
     */
    public static String getEmailAddress() {
        return Config.EMAIL_ADDRESS;
    }

    public static void setPhoneNo(String number) {
        Config.USER_PHONE_NO = number;
    }

    /**
     * Call this method, if you want to use a custom checkScreen. After the EntryActivity the custom CheckScreen is called (if a custom CheckScreen is set). Don't use
     * this, if you aren't familiar with the REST calls that have to be performed to start the identification!
     *
     * @param cls
     */
    public static void setCheckScreenActivity(Class<?> cls) {
        VIDEO_CHECKSCREEN_CLASS = cls;
    }

    public static Class<?> getCheckScreenActivity() {
        return VIDEO_CHECKSCREEN_CLASS;
    }

    public static Class<?> getHighCallVolumeClass() {
        return HIGH_CALL_VOLUME_CLASS;
    }

    public static Boolean showDialogsWithIcon() {
        return Config.SHOW_DIALOGS_WITH_ICON;
    }

    public static void setShowDialogsWithIcon(Boolean showDialogsWithIcon) {
        Config.SHOW_DIALOGS_WITH_ICON = showDialogsWithIcon;
    }

    public static void setFirebaseToken(String token) {
        Config.FIREBASE_NOTIFICATION_TOKEN = token;
    }

    public static boolean isForcedWaitingList() {
        Util_Log.d(LOGTAG, "return isForcedWaitingList");
        return forcedWaitingList;
    }

    public static boolean isIsDarkModeFlagInitialized() {
        return isDarkModeFlagInitialized;
    }

    public static boolean isShowRatingDialog() {
        return showRatingDialog;
    }

    public static void setShowRatingDialog(boolean showRatingDialog) {
        IDnowSDK.showRatingDialog = showRatingDialog;
    }

    public static void setForcedWaitingList(boolean forcedWaitingList) {
        Util_Log.d(LOGTAG, "set ForcedWaitingList");
        IDnowSDK.forcedWaitingList = forcedWaitingList;
    }

    public static void setAndroidDarkModeEnabled(boolean darkModeEnabled) {
        isDarkModeFlagInitialized = true;
        Config.DARK_MODE_ENABLED_CUSTOMER = darkModeEnabled;
    }

    public static void showRatingDialog(final Context localContext, final Runnable runnable) {
        if (Config.SHOW_REVIEW_GOOGLE_APPS_RATING && Config.SHOW_APP_GOOGLE_RATING) {
            ((Activity) localContext).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(localContext, R.style.IDnowAlertDialogStyle));
                    builder.setTitle(Util_Strings.getStringWithDefault(localContext, KEY_VIDEO_IDENT_RATING_TITLE, LOCAL_KEY_VIDEO_IDENT_RATING_TITLE));
                    builder.setMessage(Util_Strings.getStringWithDefault(localContext, KEY_VIDEO_IDENT_RATING_SCREEN, LOCAL_KEY_VIDEO_IDENT_RATING_SCREEN));
                    builder.setCancelable(true);

                    builder.setPositiveButton(
                            Util_Strings.getStringWithDefault(localContext, KEY_VIDEO_IDENT_RATING_POSITIVE, LOCAL_KEY_VIDEO_IDENT_RATING_POSITIVE),
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    Intent rateIntent = openPlayStoreSiteIntent("market://details", localContext);
                                    localContext.startActivity(rateIntent);
                                    dialog.cancel();
                                }
                            });

                    builder.setNegativeButton(
                            Util_Strings.getStringWithDefault(localContext, KEY_VIDEO_IDENT_RATING_NEGATIVE, LOCAL_KEY_VIDEO_IDENT_RATING_NEGATIVE),
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();

                                    try {
                                        runnable.run();
                                    } catch (Exception e) {
                                        Util_Log.e(LOGTAG, "Execute lambda failed", e);
                                    }
                                }
                            });

                    AlertDialog alert = builder.create();
                    Util_UtilUI.showBrandedDialog(alert);
                }
            });
        } else if (Config.SHOW_REVIEW_GOOGLE_RATING && Config.SHOW_APP_GOOGLE_RATING) {
            ((Activity) localContext).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(localContext, R.style.IDnowAlertDialogStyle));
                    builder.setTitle(Util_Strings.getStringWithDefault(localContext, KEY_VIDEO_IDENT_RATING_TITLE, LOCAL_KEY_VIDEO_IDENT_RATING_TITLE));
                    builder.setMessage(Util_Strings.getStringWithDefault(localContext, KEY_VIDEO_IDENT_RATING_MSG_GOOGLE, LOCAL_KEY_VIDEO_IDENT_RATING_MSG_GOOGLE));
                    builder.setCancelable(true);

                    builder.setPositiveButton(
                            Util_Strings.getStringWithDefault(localContext, KEY_VIDEO_IDENT_RATING_POSITIVE, LOCAL_KEY_VIDEO_IDENT_RATING_POSITIVE),
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                    Util_UtilWebsocket.openUrlInNewBrowserTask(localContext, Util_Strings.GOOGLE_RATING_URL);

                                }
                            });

                    builder.setNegativeButton(
                            Util_Strings.getStringWithDefault(localContext, KEY_VIDEO_IDENT_RATING_NEGATIVE, LOCAL_KEY_VIDEO_IDENT_RATING_NEGATIVE),
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();

                                    try {
                                        runnable.run();
                                    } catch (Exception e) {
                                        Util_Log.e(LOGTAG, "Execute lambda failed", e);
                                    }
                                }
                            });

                    AlertDialog alert = builder.create();
                    Util_UtilUI.showBrandedDialog(alert);
                }
            });
        } else {
            try {
                runnable.run();
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Execute lambda failed", e);
            }
        }
    }

    private static Intent openPlayStoreSiteIntent(String url, Context localContext) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(String.format("%s?id=%s", url, localContext.getPackageName())));
        int flags = Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_MULTIPLE_TASK;
        if (Build.VERSION.SDK_INT >= 21) {
            flags |= Intent.FLAG_ACTIVITY_NEW_DOCUMENT;
        } else {
            flags |= Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET;
        }
        intent.addFlags(flags);

        return intent;
    }

    public Context getAppContext() {
        return appContext;
    }

    public void overrideBrandingColorsForUIElement(OverridableUIElement element, String backgroundColorString, String textColorString) {
        Map colorMap = new HashMap<String, String>();
        colorMap.put(Config.OverridableColorType.BACKGROUND, backgroundColorString);
        colorMap.put(Config.OverridableColorType.TEXT, textColorString);
        Config.overridableColorsMap.put(element, colorMap);
    }

    public @NonNull
    String getStringWithDefault(@NonNull Context context, @NonNull String serverStringKey, @StringRes Integer fallbackStringResId) {
        return Util_Strings.getStringWithDefault(context, serverStringKey, fallbackStringResId);
    }

    public IDnowErrorCode getResultErrorCode() {
        return resultErrorCode;
    }

    public void setResultErrorCode(IDnowErrorCode errorCode) {
        resultErrorCode = errorCode;
    }

    public boolean isStartCallIssued() {
        return startCallIssued;
    }

    public void setStartCallIssued(boolean startCallIssued) {
        this.startCallIssued = startCallIssued;
    }

    public void setCallingActivity(Activity callingActivity) {
        this.callingActivity = callingActivity;
    }

    public Activity getCallingActivity(){
        return callingActivity;
    }

    public static String getCurrentServer() {
        return Config.GET_CURRENT_SERVER_API_HOST();
    }

    /**
     * @return false always.
     * @deprecated Does nothing anymore. Legacy code that will be removed in future version
     */
    @Deprecated(since = "9.7.12")
    public static boolean getOverrideEntryActivity() {
        return false;
    }

    /**
     * @deprecated Does nothing anymore. Legacy code that will be removed in future version
     */
    @Deprecated(since = "9.7.12")
    public static void setOverrideEntryActivity(Boolean overrideHostApp) {
    }

    public static void setApp_GoogleRating(Boolean app_google_rating) {
        Config.SHOW_APP_GOOGLE_RATING = app_google_rating;
    }

    public void deviceHasNfc() {
        NfcManager nfcManager = (NfcManager) appContext.getSystemService(Context.NFC_SERVICE);
        NfcAdapter nfcAdapter = nfcManager.getDefaultAdapter();
        // Device not compatible for NFC support
        Config.NFC_SUPPORT = nfcAdapter != null;
    }

    Locale getCurrentLocale(Context context) {
        return context.getResources().getConfiguration().getLocales().get(0);
    }

    // method that checks the validity of the language String input in SDK initialization
    boolean isValidLocaleLanguage(String language) {
        Locale[] locales = Locale.getAvailableLocales();
        for (Locale locale : locales) {
            if (language.equals(locale.getLanguage())) {
                return true;
            }
        }
        return false;
    }

}
