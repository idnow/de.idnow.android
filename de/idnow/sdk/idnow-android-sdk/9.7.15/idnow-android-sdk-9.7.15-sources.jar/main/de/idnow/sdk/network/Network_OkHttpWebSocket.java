package de.idnow.sdk.network;

import static de.idnow.sdk.Config.SOCKET_RECONNECT_INTERVAL;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.SystemClock;

import androidx.annotation.NonNull;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.Interface_VideoLiveStream;
import de.idnow.sdk.models.Models_WebSocketResponse;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_UtilWebsocket;
import de.idnow.sdk.util.camera.CameraType;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;


/**
 * Created by Mathias Grasy on 24.10.2016.
 */

//TODO reformat code
public class Network_OkHttpWebSocket extends WebSocketListener implements Callback
{
	private static final String LOGTAG = "IDNOW_Network_OkHttpWebSocket";

	private final Executor writeExecutor = Executors.newSingleThreadExecutor();

	public Context getContext() {
		return context;
	}

	private final Context context;
	private final Gson    gson;
	private int tries = 0;

	// Okhttp
	private Call          currentCall;
	private OkHttpClient  client;
	private Request       request;
	private WebSocket     webSocketCall;
	private boolean       opened;

	// long polling
	private boolean useLongPolling     = false;

	private final static String TAG = "requestTag";

	private Runnable connectedCallback;
	private Runnable errorCallback;
	long timeInMilliseconds = 0L;
	long timeSwapBuff = 0L;
	int secs;

	public Network_OkHttpWebSocket( Context context, Runnable connectedCallback, Runnable errorCallback, boolean useLongPolling )
	{
		this.context = context;
		this.useLongPolling = useLongPolling;
		this.connectedCallback = connectedCallback;
		this.errorCallback = errorCallback;
		gson = new Gson();

		Config.FIST_SOCKET_CONNECTION = SystemClock.uptimeMillis();
	}

	public Boolean isRunning(){
		return opened;
	}

	public void run() throws IOException
	{
		try
		{
			client = IDNowOkHttpFactory.Companion.createOkHttpClient();

			if(Config.SOCKET_ENABLED){
				timeInMilliseconds = SystemClock.uptimeMillis() - Config.FIST_SOCKET_CONNECTION;

				secs = (int) (timeInMilliseconds / 1000);
				secs = secs % 60;

				Util_Log.i(LOGTAG, "secs: " + secs);

				if((secs-(SOCKET_RECONNECT_INTERVAL*Config.SOCKET_TRIES)) >= SOCKET_RECONNECT_INTERVAL){
					Config.SOCKET_TRIES = Config.SOCKET_TRIES+1;
					timeSwapBuff = secs;
					secs = 0;
				}
			}

		}
		catch ( Exception e )
		{
			throw new RuntimeException(e);
		}

		HttpUrl.Builder websocketUrl = Objects.requireNonNull(HttpUrl.parse(Config.CURRENT_SERVER.getSocketHost(IDnowSDK.getTransactionToken()) + Config.API_NAMESPACE_SOCKET + IDnowSDK.getTransactionToken() + "/websocket")).newBuilder();

		if (Config.USER_SESSION_TOKEN != null && !Config.USER_SESSION_TOKEN.isEmpty()) {
			websocketUrl.addQueryParameter("sessionToken", Config.USER_SESSION_TOKEN);
		}

		if (useLongPolling) {
			HttpUrl.Builder websocketUrlWithQueryParameter = websocketUrl
					.addQueryParameter("X-Atmosphere-Transport", "long-polling")
					.addQueryParameter("X-Atmosphere-TrackMessageSize", "false")
					.addQueryParameter("X-atmo-protocol", "false");

			request = request.newBuilder().url(websocketUrlWithQueryParameter.build()).tag(TAG).build();
			Util_Log.i(LOGTAG, "Using long polling");
			currentCall = client.newCall(request);
			currentCall.enqueue(this);
		} else {
			request = new Request.Builder()
					.url(websocketUrl.build())
					.build();

			Util_Log.i(LOGTAG, "Using webSocket");
			webSocketCall = client.newWebSocket(request, this);
			// Trigger shutdown of the dispatcher's executor so this process can exit cleanly.
			client.dispatcher().executorService().shutdown();
		}
	}

	private Interface_VideoLiveStream sink;

	public synchronized void setSink(Interface_VideoLiveStream sink){
		Util_Log.i( LOGTAG, "Set sink for video live stream" );
		this.sink = sink;
	}

	public synchronized void removeSink(){
		Util_Log.i( LOGTAG, "Remove sink for video live stream" );
		sink = null;
	}

	private void internalClose()
	{
		Util_Log.i( LOGTAG, "Closing for socket" );

		if ( webSocketCall != null )
		{
			Util_Log.i( LOGTAG, "Closing socket" );
			if (webSocketCall.close(1001, null)) {
				Util_Log.i( LOGTAG, "Gracefully closed socket" );
			}
		}

		if ( currentCall != null )
		{
			Util_Log.i( LOGTAG, "Closing long polling" );
			currentCall.cancel();
		}
	}

	public void close()
	{
		opened = false;
		internalClose();
		client.connectionPool().evictAll();
		client.dispatcher().executorService().shutdown();
	}


	// ==============
	// WEBSOCKET
	// ==============

	@Override
	public void onOpen( final WebSocket webSocket, Response response )
	{

		Util_Log.i( LOGTAG, "OPEN SOCKET" );

		final boolean runCallback = !opened;
		opened = true;
		writeExecutor.execute( new Runnable()
		{
			@Override
			public void run()
			{
				if (runCallback) {
					if (Network_OkHttpWebSocket.this.connectedCallback != null){
						Network_OkHttpWebSocket.this.connectedCallback.run();
						Network_OkHttpWebSocket.this.connectedCallback = null;
					}

				}
			}
		} );
	}

	@Override
	public void onMessage( WebSocket s, String data )
	{
		Util_Log.i( LOGTAG, "onMessage" + data );
		tries = 0;

		if (!opened) {
			// socket already closed or not yet opened
			return;
		}

		if ( data != null )
		{
			// check if data contains "command", otherwise its not a valid json
			if ( ( data.contains( "command" ) ) )
			{
				try
				{
					// parse the string to a WebSocketResponse model
					Models_WebSocketResponse response = gson.fromJson( data, Models_WebSocketResponse.class );
					Util_UtilWebsocket.handleSocketMessage( response, context, getSink() );
				}
				catch ( Exception e )
				{
					Util_Log.e(LOGTAG, "Error in parsing the websocket reponse: ", e);
				}
			}
		}
		else {
            Util_Log.i(LOGTAG, "onMessage empty text");
        }
	}

	@Override
	public void onClosing( WebSocket s, int code, String reason )
	{
		Util_Log.i( LOGTAG, "CLOSE: " + code + " " + reason );
	}

	/**
	 * if websocket connection fails, try to reconnect several times.
	 * if the websocket connection cannot be established, give up and show a dialog to the user.
	 *
	 * @param t
	 * @param response
	 */
	@Override
	public void onFailure(WebSocket s, Throwable t, Response response) {
		if (t.getMessage() != null && t.getMessage().contains("Socket closed")) {
			Util_Log.i(LOGTAG, "Failure: socket closed.");
			return;
		}

		Util_Log.e(LOGTAG, "Websocket failure", t);

		if (response != null) {
			Util_Log.d(LOGTAG, "Failure: " + response.message());
		}

		// closing the socket and create a new one.
		try {
			internalClose();
		} catch (Exception ex) {
			Util_Log.e(LOGTAG, "Close websocket failed", ex);
		}

		if (!opened) {

			if (Config.SOCKET_ENABLED) {
				if (Config.SOCKET_TRIES == Config.SOCKET_RECONNECT_ATTEMPTS) {
					Util_Log.e(LOGTAG, "WebSocket reconnect attempts exceeded limit");
					Config.SOCKET_TRIES = 0;

					if (errorCallback != null) {
						errorCallback.run();
						errorCallback = null;
					}

					return;
				}
			} else {
				tries++;
				if (tries > 5) {
					Util_Log.e(LOGTAG, "WebSocket reconnect attempts exceeded limit");
					tries = 0;

					if (errorCallback != null) {
						errorCallback.run();
						errorCallback = null;
					}
					return;
				}
			}


		}

		// retry
		try {
			Thread.sleep(2000);
			run();
		} catch (Exception exe) {
			Util_Log.e(LOGTAG, "Connect websocket failed", exe);
		}
	}

	// =============
	// LONG POLLING
	// =============

	@Override
	public void onFailure( Call call, IOException e )
	{
		Util_Log.e(LOGTAG, "Failure on long polling", e);
		retryLongPolling();
	}

	private void retryLongPolling() {
		// closing the socket and create a new one.
		try
		{
			internalClose();
		}
		catch ( Exception ex )
		{
			Util_Log.e(LOGTAG, "Failure on stopping long polling", ex);
		}

		if (!opened) {
			tries++;
			if (tries > 5) {
				Util_Log.e(LOGTAG, "Reconnect attempts exceeded limit");
				tries = 0;

				if (errorCallback != null){
					errorCallback.run();
					errorCallback = null;
				}

				return;
			}
		}

		try
		{
			if( !opened ) {
				Thread.sleep(2000);

				// start new call
				currentCall = client.newCall(request);
				currentCall.enqueue(this);
			}
		}
		catch ( Exception exe )
		{
			Util_Log.e(LOGTAG, "Start long polling failed", exe);
		}
	}

	@Override
	public void onResponse( Call call, Response response ) throws IOException
	{
		Util_Log.i( LOGTAG, "onResponse" );

		if (!opened) {

			Util_Log.i( LOGTAG, "first on response" );
			if (connectedCallback != null){
				connectedCallback.run();
				connectedCallback = null;
			}

			opened = true;
		}

		ResponseBody body = response.body();

		try
		{
			String responseString = body.string();
			Util_Log.i( LOGTAG, "response length before trim: " + responseString.length());

			// throw away everything which comes before "{", because currently more than 4000 spaces are at the beginning of the string.
			if (responseString.contains( "{" ))
			{
				responseString = responseString.substring( responseString.indexOf( "{" ) );
			}

			if ( responseString.contains( "command" ) )
			{
					try
					{
						// parse the string to a WebSocketResponse model
						Models_WebSocketResponse longPollingResponse = gson.fromJson( responseString, Models_WebSocketResponse.class );
						Util_UtilWebsocket.handleSocketMessage( longPollingResponse, context, getSink() );
					}
					catch ( Exception e )
					{
						Util_Log.e(LOGTAG, "Parse websocket response failed", e);
					}

			}

			// start new call
			currentCall = client.newCall( request );
			currentCall.enqueue( this );
			return;
		}

		// this exception gets triggered, when socket is closed.
		catch ( Exception e )
		{
			Util_Log.e(LOGTAG, "Parse websocket response failed. Invalid state", e);
		}

		finally
		{
			body.close();
		}

		retryLongPolling();
	}


	private @NonNull Interface_VideoLiveStream getSink (){
		if (sink != null){
			return sink;
		} else {
			return new Interface_VideoLiveStream() {
				@Override
				public void setupImageStreamPush(byte[] imageString, String imageType) {

				}

				@Override
				public void takeScreenshot(String type) {

				}

				@Override
				public void startESigning() {

				}

				@Override
				public void signingCanceledRESTCall() {

				}

				@Override
				public void onEndCall(int result) {

				}

				@Override
				public void setCurrentStep(int step) {

				}

				@Override
				public void updateExplanationView(String websocketResponse) {

				}

				@Override
				public void identificationFailedRESTCall() {

				}

				@Override
				public void identificationCanceledRESTCall() {

				}

				@Override
				public void startActivityForResult(Intent intent, int result) {

				}

				@Override
				public void agentConnected() {

				}

				@Override
				public void requestCameraFocusCenter() {

				}

				@Override
				public void openCamera(CameraType type) {

				}

				@Override
				public void setCameraTorchEnabled(Boolean enabled) {

				}

				@Override
				public Handler getHandler() {
					return null;
				}

				@Override
				public void identificationCanceled() {

				}
			};
		}
	}


}
