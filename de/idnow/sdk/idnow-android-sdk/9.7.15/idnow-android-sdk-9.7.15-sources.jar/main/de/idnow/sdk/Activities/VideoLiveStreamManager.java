package de.idnow.sdk.Activities;

import static android.content.Context.MODE_PRIVATE;
import static de.idnow.sdk.Config.IDENTIFICATION_SIGNATURE;
import static de.idnow.sdk.Config.VIDEO_IDENT_PLUS_REUSE_IMAGES;
import static de.idnow.sdk.util.Util_CustomLogData.EVENT_MANUAL_DOC_CLASSIFICATION_SHOWN;
import static de.idnow.sdk.util.Util_UtilWebsocket.openReportActivity;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Base64;
import android.webkit.WebView;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import de.idnow.sdk.Activities.callbacks.ClassificationCallback;
import de.idnow.sdk.Activities.callbacks.ContinueSignCallback;
import de.idnow.sdk.Activities.callbacks.EnrollWaitingListCallback;
import de.idnow.sdk.Activities.callbacks.FetchWaitingInformationCallback;
import de.idnow.sdk.Activities.callbacks.GetApprovalPhrasesCallback;
import de.idnow.sdk.Activities.callbacks.IdentificationCanceledCallback;
import de.idnow.sdk.Activities.callbacks.IdentificationFailedCallback;
import de.idnow.sdk.Activities.callbacks.LoginAccountCallback;
import de.idnow.sdk.Activities.callbacks.PrepareCustomMessageCallback;
import de.idnow.sdk.Activities.callbacks.RequestVideoChatCallback;
import de.idnow.sdk.Activities.callbacks.SaveAccountPasswordCallback;
import de.idnow.sdk.Activities.callbacks.SendChatMessageCallback;
import de.idnow.sdk.Activities.callbacks.SendConfirmationCodeCallback;
import de.idnow.sdk.Activities.callbacks.SendIdentToPhoneCallback;
import de.idnow.sdk.Activities.callbacks.SigningCanceledCallback;
import de.idnow.sdk.Activities.callbacks.StartCallback;
import de.idnow.sdk.Activities.callbacks.SubscribeForPushNotificationsCallback;
import de.idnow.sdk.Activities.callbacks.UpdateMobileNumberCallback;
import de.idnow.sdk.Activities.callbacks.UploadScreenshotCallback;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.Interface_VideoLiveStream;
import de.idnow.sdk.models.Model_Classification;
import de.idnow.sdk.models.Model_failedReason;
import de.idnow.sdk.models.Models_ApprovalPhrase;
import de.idnow.sdk.models.Models_AuthPassword;
import de.idnow.sdk.models.Models_Classification;
import de.idnow.sdk.models.Models_ConfirmationToken;
import de.idnow.sdk.models.Models_Customer;
import de.idnow.sdk.models.Models_DocumentInfo;
import de.idnow.sdk.models.Models_Email;
import de.idnow.sdk.models.Models_EmptyJson;
import de.idnow.sdk.models.Models_Enrollment;
import de.idnow.sdk.models.Models_MobileNumber;
import de.idnow.sdk.models.Models_PDFDocument;
import de.idnow.sdk.models.Models_Password;
import de.idnow.sdk.models.Models_RegistrationeSign;
import de.idnow.sdk.models.Models_StartObject;
import de.idnow.sdk.models.Models_StartObjectResult;
import de.idnow.sdk.models.Models_TextMessage;
import de.idnow.sdk.models.Models_UpdateMobile;
import de.idnow.sdk.models.Models_WaitingListNotificationSub;
import de.idnow.sdk.models.Models_eSignRefused;
import de.idnow.sdk.network.Callback;
import de.idnow.sdk.network.IDNowOkHttpFactory;
import de.idnow.sdk.network.IDnowRestClient;
import de.idnow.sdk.network.Network_RESTCalls;
import de.idnow.sdk.network.RetrofitError;
import de.idnow.sdk.util.UI_SMSWaitScreen;
import de.idnow.sdk.util.Util_CustomLogData;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_PhotoDataHolder;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_Util;
import de.idnow.sdk.util.Util_UtilRetrofit;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.Util_UtilWebsocket;
import de.idnow.sdk.util.Util_VideoSessionConfig;
import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Response;

public class VideoLiveStreamManager {

    public static final String LOGTAG = "IDNOW_VideoLiveStreamManager";
    Context applicationContext;

    boolean setupCompleteCallAlreadyTriggered = false;

    public VideoLiveStreamManager(Context applicationContext) {
        this.applicationContext = applicationContext;
    }


    /**
     * has to be called only when the VideoOverviewCheckActivity hasn't been shown before.
     */
    public void makeStartRESTCall(Context mContext, StartCallback startCallback) {
        String localPhoneNumber;
        String localEmail;
        Runnable startRESTCallRunnable = () -> makeStartRESTCall(mContext, startCallback);

        if (IDnowSDK.getInstance().isStartCallIssued()) {
            Util_Log.i(LOGTAG, "start-Call already done, not reissuing it.");
//            hideHelpertextAndConnect();
            startCallback.onSuccess();

            return;
        }

        Util_Log.i(LOGTAG, "-------------------------------===== STARTED");
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Models_StartObjectResult> callback = new Callback<Models_StartObjectResult>() {

            @Override
            public void failure(RetrofitError error) {

                String result;
                result = Util_UtilRetrofit.printRetrofitError(error);

                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                }

                if (error != null && error.getResponse() != null) {
                    if (error.getResponse().getStatus() == 429) {
                        IDnowSDK.setForcedWaitingList(true);
                        return;
                    }

                    Util_UtilUI.showRESTCallErrorDialog(mContext, error.getResponse().getStatus(), true, startRESTCallRunnable, result, false, false, "");

                } else {
                    Util_UtilUI.showRESTCallErrorDialog(mContext, 0, true, startRESTCallRunnable, result, false, false, "");
                }

                IDnowSDK.getInstance().setStartCallIssued(false);
            }

            @Override
            public void success(Models_StartObjectResult resultObject, Response response) {

                if(resultObject.getEnableOTPForWallet()!=null&&Config.AUTHENTICATED_POSSIBLE||Config.AUTHENTICATED_SIGNED){
                    Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTPForWallet().isSigning();
                    Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTPForWallet().isIdent();
                }
                else
                if(resultObject.getEnableOTP()!=null){
                    Config.OTP_DISPLAY_SIGNING = resultObject.getEnableOTP().isSigning();
                    Config.OTP_DISPLAY_IDENT = resultObject.getEnableOTP().isIdent();
                }

                if (resultObject.mobile != null) {
                    Config.USER_PHONE_NO = resultObject.mobile;
                }

                if (resultObject.email != null) {
                    Config.EMAIL_ADDRESS = resultObject.email;
                }

                IDENTIFICATION_SIGNATURE = resultObject.getRequest().getIdentification_Signature();

                Util_Log.i(LOGTAG, "success");

                IDnowSDK.setForcedWaitingList(false);

                int remainingInternalTokenRetries = resultObject.getRemainingInternalTokenRetries();
                Util_Log.d(LOGTAG, "remainingInternalTokenRetries = " + remainingInternalTokenRetries);

                // set the openTok/icelink configs
                Util_VideoSessionConfig.setSessionIdAndToken(resultObject);

                if (resultObject.getRequest() != null) {
                    Config.E_SIGNING_SECRET = resultObject.getRequest().getClientSecret();
                    Config.USER_SESSION_TOKEN = resultObject.getRequest().getSessionToken();
                }

                IDnowSDK.getInstance().setStartCallIssued(true);
//                hideHelpertextAndConnect();
                startCallback.onSuccess();
            }
        };

        if (!Config.USER_PHONE_NO.contains("***")) {
            localPhoneNumber = Config.USER_PHONE_NO;
        } else {
            localPhoneNumber = null;
        }

        if (!Config.EMAIL_ADDRESS.contains("***")) {
            localEmail = Config.EMAIL_ADDRESS;
        } else {
            localEmail = null;

        }

        retrofit2.Call<Models_StartObjectResult> result = service.start(
                new Models_StartObject(IDnowSDK.getTransactionToken(),
                        localPhoneNumber,
                        localEmail,
                        Config.PREFERRED_LANG,
                        Util_Util.getClientInfo(),
                        null
                ),
                IDnowSDK.getCompanyId(),
                IDnowSDK.getTransactionToken()
        );
        result.enqueue(callback);
    }

    public void appEnteredBackgroundRESTCall(boolean isActivityRunning) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Models_EmptyJson> callback = new Callback<Models_EmptyJson>() {

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "appEnteredBackground REST Call failed");
                String result;
                result = Util_UtilRetrofit.printRetrofitError(error);

                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                }

                if (error != null && error.getResponse() != null && isActivityRunning) {
                    Util_Log.i(LOGTAG, "appEnteredBackground: " + error.getResponse().getStatus() + " " + result);
                }
            }

            @Override
            public void success(Models_EmptyJson resultObject, Response response) {
                Util_Log.i(LOGTAG, "appEnteredBackground REST Call was successful");
            }
        };

        retrofit2.Call<Models_EmptyJson> result = service
                .appEnteredBackground(new Models_EmptyJson(), IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        result.enqueue(callback);
    }


    public void setupCompleteRESTCall(Context context, boolean isActivityRunning) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Runnable setupCompleteRESTCallRunnable = () -> setupCompleteRESTCall(context, isActivityRunning);

        Callback<Models_EmptyJson> callback = new Callback<Models_EmptyJson>() {

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "setupComplete REST Call failed");
                String result;
                result = Util_UtilRetrofit.printRetrofitError(error);

                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                }

                if (error != null && error.getResponse() != null && isActivityRunning) {
                    Util_UtilUI.showRESTCallErrorDialog(
                            context,
                            error.getResponse().getStatus(),
                            true,
                            setupCompleteRESTCallRunnable,
                            result,
                            true,
                            true,
                            ""
                    );

                } else {
                    if (isActivityRunning) {
                        Util_UtilUI.showRESTCallErrorDialog(context,
                                0,
                                true,
                                setupCompleteRESTCallRunnable,
                                result,
                                true,
                                true,
                                ""
                        );
                    }
                }

            }

            @Override
            public void success(Models_EmptyJson resultObject, Response response) {
                Util_Log.i(LOGTAG, "setupComplete REST Call was successful");
                setupCompleteCallAlreadyTriggered = true;
            }

        };

        retrofit2.Call<Models_EmptyJson> result =
                service.setupComplete(new Models_EmptyJson(), IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());

        result.enqueue(callback);

    }

    public void subscribeToForPushNotifications(final String companyId, final String token, SubscribeForPushNotificationsCallback subscribeCallback) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Util_Log.i(LOGTAG, "Issuing waiting list subscription");
        Callback<Models_WaitingListNotificationSub> callback = new Callback<Models_WaitingListNotificationSub>() {
            @Override
            public void success(Models_WaitingListNotificationSub enrollment, Response response) {
                Util_Log.i(LOGTAG, "Done subscribing, enrolling...");

                subscribeCallback.onSuccess(companyId, token);

            }

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "Failed to enroll to waiting list service!");

                subscribeCallback.onFailure();
            }
        };

        if (Config.FIREBASE_NOTIFICATION_TOKEN != null) {
            retrofit2.Call<Models_WaitingListNotificationSub> result = service.sendNotificationSubscription(
                    new Models_WaitingListNotificationSub(
                            Config.WAITING_LIST_NOTIFICATIONS_CHANNEL,
//						IDnowSDK.getCompanyId(mContext) != null ? IDnowSDK.getCompanyId(mContext) : "idnow",
                            "idnow",
                            Config.FIREBASE_NOTIFICATION_TOKEN),
                    companyId,
                    token);
            result.enqueue(callback);
        }
    }

    public void createAccountRESTCall(final Context context, Models_RegistrationeSign models_registrationeSign, final Dialog dialog, final WebView webView, boolean isActivityRunning) {

        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Models_RegistrationeSign> callback = new Callback<Models_RegistrationeSign>() {
            @Override
            public void success(Models_RegistrationeSign o, Response response) {
                dialog.dismiss();
                Util_UtilUI.showEsignDialog(context, Util_Strings.KEY_ACCOUNT_PASSWORD, null, webView);

            }

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "create Account REST Call failed");

                String result;
                result = Util_UtilRetrofit.printRetrofitError(error);

                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                }

                if (error != null && error.getResponse() != null && isActivityRunning) {

                } else {

                }
                if (error.getResponse().getStatus() == 412) {
                    Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_ACCOUNT_REGISTER_FAILED);
                }
            }
        };

        retrofit2.Call<Models_RegistrationeSign> result = service.createAccount(models_registrationeSign, IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken());
        result.enqueue(callback);
    }

    public void saveAccountPasswordRESTCall(final Context context, Models_Password models_password, final Dialog dialog, SaveAccountPasswordCallback saveCallback) {

        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());

        String companyShort = IDnowSDK.getCompanyId();

        String transactionToken = IDnowSDK.getTransactionToken();

        endPoint = endPoint + "/api/v1/" + companyShort + "/identifications/" + transactionToken + "/saveAccountPassword";

        MediaType JSON = MediaType.parse(Util_Strings.LOGIN_CONTENT_TYPE);
        RequestBody body = RequestBody.create(JSON, new Gson().toJson(models_password));

        OkHttpClient client = IDNowOkHttpFactory.Companion.createOkHttpClient();

        final Request request = new Request.Builder()
                .url(endPoint)
                .post(body)
                .build();

        Call call = client.newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Util_Log.e(LOGTAG, "Save account password failed", e);
                Config.ERROR_LOGIN = true;
            }

            @Override
            public void onResponse(Call call, okhttp3.Response response) {
                Util_Log.i(LOGTAG, "SUCCESS: " + response);
                dialog.dismiss();

                if (!Config.OPENTRUST_URL.equals("") && Config.START_ESIGNING) {
                    saveCallback.onSaveAccountPassword();
                } else {
                    Config.SHOW_CONTRACT_AGAIN = true;
                    Config.LOAD_URL = true;
                }
            }
        });
    }


    public void continueSignRESTCall(final Context context, final String mobile, final Dialog dialog, ContinueSignCallback continueCallback)  {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());

        String companyShort = IDnowSDK.getCompanyId();

        String transactionToken = IDnowSDK.getTransactionToken();

        endPoint = endPoint + "/api/v1/" + companyShort + "/identifications/" + transactionToken + "/updateMobileNumber";

        Models_UpdateMobile updateMobileObj = new Models_UpdateMobile(mobile);

        MediaType JSON = MediaType.parse(Util_Strings.LOGIN_CONTENT_TYPE);
        RequestBody body = RequestBody.create(JSON, new Gson().toJson(updateMobileObj));

        OkHttpClient client = IDNowOkHttpFactory.Companion.createOkHttpClient();

        final Request request = new Request.Builder()
                .url(endPoint)
                .post(body)
                .build();

        Call call = client.newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Util_Log.e(LOGTAG, "Update mobile number failed", e);
                Config.ERROR_LOGIN = true;
            }

            @Override
            public void onResponse(Call call, okhttp3.Response response) {
                Util_Log.i(LOGTAG, "SUCCESS: " + response);
                Config.USER_PHONE_NO = mobile;
                dialog.dismiss();
                if (!Config.OPENTRUST_URL.equals("") && Config.START_ESIGNING) {
                    continueCallback.onContinueSign();
                } else {
                    Config.SHOW_CONTRACT_AGAIN = true;
                    Config.LOAD_URL = true;
                }

            }
        });
    }

    public void loginAccountRESTCall(final Context context, String password, final Dialog dialog, LoginAccountCallback loginCallback) {

        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());

        String companyShort = IDnowSDK.getCompanyId();

        String transactionToken = IDnowSDK.getTransactionToken();

        endPoint = endPoint + "/api/v1/" + companyShort + "/identifications/" + transactionToken + "/authentication/password";

        dialog.dismiss();

        Models_AuthPassword passwordObj = new Models_AuthPassword(password);

        MediaType JSON = MediaType.parse(Util_Strings.LOGIN_CONTENT_TYPE);
        RequestBody body = RequestBody.create(JSON, new Gson().toJson(passwordObj));

        OkHttpClient client = IDNowOkHttpFactory.Companion.createOkHttpClient();

        final Request request = new Request.Builder()
                .url(endPoint)
                .post(body)
                .build();

        Call call = client.newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Util_Log.e(LOGTAG, "Login failed", e);
                Config.ERROR_LOGIN = true;
            }

            @Override
            public void onResponse(Call call, okhttp3.Response response) {

                Util_Log.i(LOGTAG, "SUCCESS: " + response);
                Config.SHOW_CONTRACT_AGAIN = true;

                loginCallback.onLogin(response.code());
            }
        });
    }


    public void sendConfirmationCodeRESTCall(String textSMSCodeResult, SendConfirmationCodeCallback sendCallback) {
        if (Config.E_SIGNING && Config.USE_NATIVE_ESIGNING) {
            sendCallback.init();
        }

        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Util_CustomLogData.setEventData(Util_CustomLogData.EVENT_SECURITY_STEPS_CODE_CONFIRM_BTN, "EVENT_SECURITY_STEPS_CODE_CONFIRM_BTN", "security step code confirm", "Button click events", null);

        Callback<Object> callback = new Callback<Object>() {
            @Override
            public void failure(RetrofitError error) {

                Util_Log.i(LOGTAG, "sendConfirmationCode REST Call failed");

                String result, errorCause;
                int statusCode;
                result = Util_UtilRetrofit.printRetrofitError(error);
                errorCause = Util_UtilRetrofit.getErrorCauseRetrofit(result);
                statusCode = error.getResponse().getStatus();
                sendCallback.onFailure(error, result, errorCause, statusCode);
            }

            @Override
            public void success(Object resultObject, Response response) {
                sendCallback.onSuccess();
            }
        };

        retrofit2.Call<Object> result = service.sendConfirmationToken(new Models_ConfirmationToken(textSMSCodeResult), IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken());
        result.enqueue(callback);
    }

    public void getClassificationRESTCall(Context context, Activities_VideoLiveStreamActivity_Super activity, ClassificationCallback classificationCallback) {
        Util_Log.i(LOGTAG, "http Classification called ");
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Object> callback = new Callback<Object>() {
            @Override
            public void success(Object o, Response response) {
                Util_Log.i(LOGTAG, "http Classification called : success");
                try {
                    Gson gson = new Gson();
                    String json = gson.toJson(o);
                    Util_Log.i(LOGTAG, "http Classification called success json: " + json);
                    Models_Classification classification = gson.fromJson(json, Models_Classification.class);
                    if (classification.getCountry().isBlank()){
                        throw new IllegalStateException("Classification country is blank");
                    }

                    Locale loc = new Locale("", classification.getCountry());
                    loc.getDisplayCountry();

                    ArrayList<String> listCountries = (ArrayList<String>) Util_PhotoDataHolder.getCountryList(context);

                    if (listCountries.contains(loc.getDisplayCountry())) {
                        Models_DocumentInfo models_documentInfo = new Models_DocumentInfo();
                        if (classification.getCountry().equals("DE") && Config.EID_REROUTING && Config.EID_CONFIG) {
                            classificationCallback.onDismissProgress();
                            classificationCallback.onShowBottomSheet();
                        } else {
                            models_documentInfo.setIdCountry(classification.getCountry());
                            models_documentInfo.setIdType(classification.getIdType());
                            models_documentInfo.setidSubtype(classification.getIdSubtype());
                            sendDocumentInfoRESTCall(activity, models_documentInfo, classificationCallback);
                        }
                    }

                } catch (JsonSyntaxException | IllegalStateException e) {
                    Util_Log.e(LOGTAG, "Parse countries json failed", e);

                    if (activity.isDestroyed()) {
                        return;
                    }
                    classificationCallback.onDismissProgress();

                    if (Config.VIDEO_IDENT_PLUS_DOCUMENT_CHECKING) {
                        Util_CustomLogData.setEventData(EVENT_MANUAL_DOC_CLASSIFICATION_SHOWN, "EVENT_MANUAL_DOC_CLASSIFICATION_SHOWN", "Manual Document Classification screen", "Screen", null);
                        Util_Log.d("COUNTLY LOG", "EVENT_MANUAL_DOC_CLASSIFICATION_SHOWN");

                        classificationCallback.onShowDocumentClassification();
                    } else {
                        Util_UtilUI.showClassificationFailed(context);
                    }
                }
            }

            @Override
            public void failure(RetrofitError error) {

                if (activity.isDestroyed()) {
                    return;
                }
                classificationCallback.onDismissProgress();

                if (Config.VIDEO_IDENT_PLUS_DOCUMENT_CHECKING) {

                    String name = "name";
                    String event_name = "event_name";
                    String category = "category";
                    String type = "type";

                    String segName = "Manual Document Classification screen shown - VIP+";
                    String segEventName = "EVENT_MANUAL_DOC_CLASSIFICATION_SHOWN";
                    String segCategory = "Manual Document Classification screen";
                    String segType = "screen";

                    Map<String, Object> segMap = new HashMap<>();
                    segMap.put(name, segName);
                    segMap.put(event_name, segEventName);
                    segMap.put(category, segCategory);
                    segMap.put(type, segType);

                    Util_CustomLogData.setEventData(EVENT_MANUAL_DOC_CLASSIFICATION_SHOWN, "EVENT_MANUAL_DOC_CLASSIFICATION_SHOWN", "Manual Document Classification screen", "Screen", null);
                    Util_Log.d("COUNTLY LOG", "EVENT_MANUAL_DOC_CLASSIFICATION_SHOWN");

                    classificationCallback.onShowDocumentClassification();
                } else {
                    Util_UtilUI.showClassificationFailed(context);
                }
            }
        };

        retrofit2.Call<Object> result = service.getClassification(IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        result.enqueue(callback);
    }

    private void sendDocumentInfoRESTCall(Activities_VideoLiveStreamActivity_Super activity, Models_DocumentInfo models_documentInfo, ClassificationCallback classificationCallback) {
        //Util_Log.i(LOGTAG, "http sendScreenshot called Bis");
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Object> callback = new Callback<Object>() {
            @Override
            public void failure(RetrofitError error) {
                classificationCallback.onUpdateErrorScreen(false);
            }

            @Override
            public void success(Object resultObject, Response response) {
                if (activity.isDestroyed()) {
                    return;
                }
                classificationCallback.onSendDocumentSuccess();
            }
        };

        retrofit2.Call<Object> result = service.uploadDocumentInfo(models_documentInfo, IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        result.enqueue(callback);

    }

    public void sendUploadPhotoRESTCall(
            Context context,
            Activities_VideoLiveStreamActivity_Super activity,
            byte[] imageStringToPush,
            @NonNull final Util_PhotoDataHolder.DocumentImages imageType,
            ClassificationCallback classificationCallback) {


        Util_Log.i(LOGTAG, "http upload photo called Bis");
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Model_Classification> callback = new Callback<Model_Classification>() {

            @Override
            public void success(Model_Classification model_classification, Response response) {

                SharedPreferences prefs = applicationContext.getSharedPreferences("notifications", MODE_PRIVATE);

                SharedPreferences.Editor editor = prefs.edit();

                Config.RETRY = true;
                Config.SAVED_TOKEN = IDnowSDK.getTransactionToken();
                editor.putString("receiveToken", Config.SAVED_TOKEN).apply();
                editor.putBoolean("receiveNotifications", Config.RETRY).apply();

                prefs = applicationContext.getSharedPreferences("notifications", MODE_PRIVATE);
                Config.RETRY = prefs.getBoolean("receiveNotifications", false);
                Config.SAVED_TOKEN = prefs.getString("receiveToken", "nothing");

                if (VIDEO_IDENT_PLUS_REUSE_IMAGES) {
                    Config.CHECK_UPLOAP = true;
                }

                if (Config.VIDEO_IDENT_PLUS && Config.VIDEO_IDENT_PLUS_SEGMENTATIONANDCLASSIFICATION && ((imageType.equals(Util_PhotoDataHolder.DocumentImages.idfrontside)))) {
                    new Handler().postDelayed(() -> getClassificationRESTCall(context, activity, classificationCallback), 2000);
                } else {
                    classificationCallback.onSendUploadPhotoSuccess(imageType);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "sendScreenshot REST Call failed : ");

                if (Config.RETRY_UPLOAD) {
                    classificationCallback.onDismissProgress();
                    Util_UtilUI.showRetryFailed(context, error.getResponse().status);
                } else {
                    classificationCallback.onUpdateErrorScreen(true);
                }
            }
        };

        byte[] bytes = Base64.encode(imageStringToPush, Base64.DEFAULT);
        retrofit2.Call<Model_Classification> result = service.uploadImage(
                RequestBody.create(bytes),
                IDnowSDK.getTransactionToken(),
                IDnowSDK.getCompanyId(),
                Util_PhotoDataHolder.getServerStringFromDocumentImageType(imageType)
        );
        result.enqueue(callback);
    }

    /**
     * sending a text message to the agent
     */
    public void sendChatMessageRESTCall(String content, SendChatMessageCallback sendChatMessageCallback) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Object> callback = new Callback<Object>() {

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "sendChatMessageRESTCall failed");
                sendChatMessageCallback.onFailure();

            }

            @Override
            public void success(Object resultObject, Response response) {

                Util_Log.i(LOGTAG, "sendChatMessageRESTCall was successful");
                sendChatMessageCallback.onSuccess();
            }

        };

        retrofit2.Call<Object> result = service.sendMessage(new Models_TextMessage(content), IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        result.enqueue(callback);
    }

    public void getApprovalPhrasesViaREST(GetApprovalPhrasesCallback approvalPhrasesCallback) {
        String customer = IDnowSDK.getCompanyId();
        String token = IDnowSDK.getTransactionToken();
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());

        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());
        Callback<Models_ApprovalPhrase[]> callback = new Callback<Models_ApprovalPhrase[]>() {
            @Override
            public void success(Models_ApprovalPhrase[] approvalPhrases, Response response) {
                Util_Log.i(LOGTAG, "onSuccess getApprovalPhrasesViaREST : " + approvalPhrases.toString());

                Config.MODEL_APPROVAL_PHRASES = approvalPhrases;

                getTSPDocsViaREST(approvalPhrasesCallback);
            }

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "Failed to get approval phrases!");
                // Display default text if failed
                approvalPhrasesCallback.onUpdateEntries();
            }
        };

        retrofit2.Call<Models_ApprovalPhrase[]> result = service.getApprovalPhrases(customer, token);
        result.enqueue(callback);
    }

    public void getTSPDocsViaREST(GetApprovalPhrasesCallback approvalPhrasesCallback) {
        String customer = IDnowSDK.getCompanyId();
        String token = IDnowSDK.getTransactionToken();
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());

        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());
        Callback<okhttp3.ResponseBody> TSPcallback = new Callback<ResponseBody>() {
            @Override
            public void success(okhttp3.ResponseBody tspDoc, Response response) {
                Util_Log.i(LOGTAG, "onSuccess getTSPDocsViaREST : " + tspDoc.byteStream() + " " + response.body() + " " + response.isSuccessful() + " " + response.body());

                try {
                    approvalPhrasesCallback.dataToPDF(tspDoc);
                } catch (IOException e) {
                    Util_Log.e(LOGTAG, "Convert approval phrases to pdf failed", e);
                    throw new RuntimeException(e);
                }

            }

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "Failed getTSPDocsViaREST");
                try {
                    approvalPhrasesCallback.dataToPDF(null);
                } catch (IOException e) {
                    Util_Log.e(LOGTAG, "Convert approval phrases to pdf failed", e);
                    throw new RuntimeException(e);
                }
            }

        };

        retrofit2.Call<okhttp3.ResponseBody> result = service.getTSPDocuments(IDENTIFICATION_SIGNATURE, customer, token);
        result.enqueue(TSPcallback);

    }

    public void updateOpenTrustUrl(
            final Context context,
            final String userPhoneNo,
            boolean isActivityRunning,
            final WebView webView,
            final Models_RegistrationeSign models_registrationeSign,
            final Dialog dialog) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());

        String companyShort = IDnowSDK.getCompanyId();

        String transactionToken = IDnowSDK.getTransactionToken();

        endPoint = endPoint + "/api/v1/" + companyShort + "/identifications/" + transactionToken + "/updateMobileNumber";

        Models_UpdateMobile updateMobileObj = new Models_UpdateMobile(models_registrationeSign.mobile);

        MediaType JSON = MediaType.parse(Util_Strings.LOGIN_CONTENT_TYPE);
        RequestBody body = RequestBody.create(JSON, new Gson().toJson(updateMobileObj));

        OkHttpClient client = IDNowOkHttpFactory.Companion.createOkHttpClient();

        final Request request = new Request.Builder()
                .url(endPoint)
                .post(body)
                .build();

        Call call = client.newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Util_Log.e(LOGTAG, "Update mobile number failed", e);
            }

            @Override
            public void onResponse(Call call, okhttp3.Response response) {
                Util_Log.i(LOGTAG, "SUCCESS: " + response);
                Config.USER_PHONE_NO = userPhoneNo;
                createAccountRESTCall(context, models_registrationeSign, dialog, webView, isActivityRunning);
            }
        });
    }

    public void identificationFailedRESTCall(IdentificationFailedCallback identificationFailedCallback) {
        final String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Object> callback = new Callback<Object>() {
            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "identficiationFailed REST Call failed");
                identificationFailedCallback.onResult();
            }

            @Override
            public void success(Object resultObject, Response response) {
                Util_Log.i(LOGTAG, "identficiationFailed REST Call was successful");
                identificationFailedCallback.onResult();
                Config.USER_SESSION_TOKEN = "";
            }
        };

        retrofit2.Call<Object> result = service.identificationFailed(new Models_EmptyJson(), IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        result.enqueue(callback);
    }

    public void identificationCanceledRESTCall(String reason_cancellation, IdentificationCanceledCallback identificationCanceledCallback) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Object> callback = new Callback<Object>() {

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "identficiationCanceled REST Call failed");
                identificationCanceledCallback.onFailure();
            }

            @Override
            public void success(Object resultObject, Response response) {
                Util_Log.i(LOGTAG, "identficiationCanceled REST Call was successful");
                if (Config.CALL_ABORT_REASON_SCREEN) {
                    identificationCanceledCallback.onSuccess();
                }
                Config.USER_SESSION_TOKEN = "";
            }
        };

        retrofit2.Call<Object> result;
        if (Config.CALL_ABORT_REASON_SCREEN && reason_cancellation != null) {
            result = service.identificationCanceled(new Model_failedReason(reason_cancellation), IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        } else {
            result = service.identificationCanceled(new Models_EmptyJson(), IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        }
        result.enqueue(callback);
    }

    public void signingCanceledRESTCall(SigningCanceledCallback canceledCallback) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Object> callback = new Callback<Object>() {

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "signingRefused REST Call failed");
                canceledCallback.onResult();
            }

            @Override
            public void success(Object resultObject, Response response) {
                Util_Log.i(LOGTAG, "signingRefused REST Call was successful");
                canceledCallback.onResult();
            }

        };

        retrofit2.Call<Object> result = service.refuseSigning(new Models_eSignRefused(), IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken());
        result.enqueue(callback);
    }

    public void appEnteredForegroundRESTCall(Activities_VideoLiveStreamActivity_Super activity) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Models_EmptyJson> callback = new Callback<Models_EmptyJson>() {

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "appEnteredForeground REST Call failed");
                String result;
                result = Util_UtilRetrofit.printRetrofitError(error);

                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                }

                if (error != null && error.getResponse() != null && activity.isActivityRunning) {
                    Util_Log.i(LOGTAG, "appEnteredForeground: " + error.getResponse().getStatus() + " " + result);
                }
            }

            @Override
            public void success(Models_EmptyJson resultObject, Response response) {
                Util_Log.i(LOGTAG, "appEnteredForeground REST Call was successful");
            }
        };

        retrofit2.Call<Models_EmptyJson> result = service
                .appEnteredForeground(new Models_EmptyJson(), IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        result.enqueue(callback);
    }

    public void sendIdentCodeToPhoneRESTCall(SendIdentToPhoneCallback sendIdentToPhoneCallback, boolean smsChecked) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Object> callback = new Callback<Object>() {

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "http sendIdentCode REST Call was failed");

                String result, errorCause;
                result = Util_UtilRetrofit.printRetrofitError(error);
                errorCause = Util_UtilRetrofit.getErrorCauseRetrofit(result);
                sendIdentToPhoneCallback.onFailure(result, errorCause, error);
            }

            @Override
            public void success(Object resultObject, Response response) {
                Util_Log.i(LOGTAG, "http sendIdentCode REST Call was successful");
                sendIdentToPhoneCallback.onSuccess();
            }

        };

        if (Config.IDENT_CODE_BY_EMAIL && !Config.IDENT_CODE_BY_SMS) {
            Util_Log.i(LOGTAG, "http send code by email");

            sendIdentToPhoneCallback.onReceiveByEmail(true);
            retrofit2.Call<Object> result = service
                    .requestConfirmationTokenByEmail(
                            new Models_Email(Config.EMAIL_ADDRESS),
                            IDnowSDK.getCompanyId(),
                            IDnowSDK.getTransactionToken()
                    );
            result.enqueue(callback);
        } else if (Config.IDENT_CODE_BY_EMAIL && Config.IDENT_CODE_BY_SMS) {
            if (Config.VIDEO_IDENT_PLUS) {
                Util_Log.i(LOGTAG, "http send code by phone");

                retrofit2.Call<Object> result = service.requestConfirmationToken(new Models_MobileNumber(Config.USER_PHONE_NO), IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken());
                result.enqueue(callback);
            } else if (smsChecked) {
                Util_Log.i(LOGTAG, "http send code by phone");

                sendIdentToPhoneCallback.onReceiveByEmail(false);
                retrofit2.Call<Object> result = service.requestConfirmationToken(new Models_MobileNumber(Config.USER_PHONE_NO), IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken());
                result.enqueue(callback);

            } else {
                Util_Log.i(LOGTAG, "http send code by email");

                sendIdentToPhoneCallback.onReceiveByEmail(true);
                retrofit2.Call<Object> result = service
                        .requestConfirmationTokenByEmail(
                                new Models_Email(Config.EMAIL_ADDRESS),
                                IDnowSDK.getCompanyId(),
                                IDnowSDK.getTransactionToken()
                        );
                result.enqueue(callback);
            }
        } else {
            Util_Log.i(LOGTAG, "http send code by phone");
            retrofit2.Call<Object> result = service.requestConfirmationToken(new Models_MobileNumber(Config.USER_PHONE_NO), IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken());
            result.enqueue(callback);
        }
    }

    public void uploadScreenshotRESTCall(byte[] imageStringToPush, String imageTypeToPush, UploadScreenshotCallback uploadScreenshotCallback) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Object> callback = new Callback<Object>() {
            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "sendScreenshot REST Call failed");
                uploadScreenshotCallback.onResult();
            }

            @Override
            public void success(Object resultObject, Response response) {
                Util_Log.i(LOGTAG, "sendScreenshot REST Call was successful");
                uploadScreenshotCallback.onResult();
            }

        };

        byte[] bytes = Base64.encode(imageStringToPush, Base64.DEFAULT);
        retrofit2.Call<Object> result = service.uploadScreenshot(RequestBody.create(bytes), IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId(), imageTypeToPush);
        result.enqueue(callback);
    }

    public void updateMobilePhoneNumber(final String companyId, final String token, final CharSequence phoneNo, UI_SMSWaitScreen ui_smsWaitScreen, UpdateMobileNumberCallback updateMobileNumberCallback) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Util_Log.i(LOGTAG, "Updating phone number");
        Callback<Models_MobileNumber> callback = new Callback<Models_MobileNumber>() {
            @Override
            public void success(Models_MobileNumber mobileNumber, Response response) {
                Util_Log.i(LOGTAG, "Updating phone number - Success");
                updateMobileNumberCallback.onSuccess(ui_smsWaitScreen);
            }

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "Failed to update phone number");
                updateMobileNumberCallback.onFailure();
            }
        };

        if (phoneNo.toString().isEmpty()) {
            updateMobileNumberCallback.onSuccess(ui_smsWaitScreen);
        } else {
            retrofit2.Call<Models_MobileNumber> result = service.updateMobileNumber(new Models_MobileNumber(phoneNo.toString()), companyId, token);
            result.enqueue(callback);
        }
    }

    public void enrollForWaitingListNotifications(final String companyId, final String token, UI_SMSWaitScreen ui_smsWaitScreen, EnrollWaitingListCallback enrollCallback) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Util_Log.i(LOGTAG, "Enrolling for waiting list");
        Callback<Models_Enrollment> callback = new Callback<Models_Enrollment>() {
            @Override
            public void success(Models_Enrollment enrollment, Response response) {
                Util_Log.i(LOGTAG, "Enrolling for waiting list notifications.");
                enrollCallback.onSuccess(ui_smsWaitScreen);
            }

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "Failed to enroll to waiting list service!");
                enrollCallback.onFailure();
            }
        };

        retrofit2.Call<Models_Enrollment> result = service.sendWaitingListEnrollment(new Models_Enrollment(), companyId, token);
        result.enqueue(callback);
    }

    public void fetchWaitingInformation(Interface_VideoLiveStream sink, final Context context, boolean successful, FetchWaitingInformationCallback fetchCallback) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Models_Customer> callback = new Callback<Models_Customer>() {

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "fetching waiting information failed");

                if (sink != null && context != null) {
                    openReportActivity(sink, context, successful);
                }

                fetchCallback.updateInfo(null);
            }

            @Override
            public void success(Models_Customer resultObject, Response response) {
                Config.REDIRECT_URL = resultObject.getRedirectUrl();
                Util_Log.i(LOGTAG, "fetching waiting information successful");
                fetchCallback.updateInfo(resultObject);

                if (sink != null && context != null) {
                    openReportActivity(sink, context, successful);
                }
                fetchCallback.onSuccess(resultObject);
            }
        };

        retrofit2.Call<Models_Customer> result = service
                .getCustomer(IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        result.enqueue(callback);
    }

    public void requestVideoChatRESTCall(RequestVideoChatCallback requestVideoChatCallback) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Models_EmptyJson> callback = new Callback<Models_EmptyJson>() {

            @Override
            public void failure(RetrofitError error) {
                onRequestVideoChatFailure(requestVideoChatCallback, error);
            }

            @Override
            public void success(Models_EmptyJson resultObject, Response response) {
                if (response.code() == 200) {
                    onRequestVideoChatSuccess();
                } else {
                    RetrofitError error = RetrofitError.from(new Exception("requestVideoChat rest call was successful, but response code was " + response.code()));
                    onRequestVideoChatFailure(requestVideoChatCallback, error);
                }
            }
        };

        retrofit2.Call<Models_EmptyJson> result = service.requestVideoChat(new Models_EmptyJson(), IDnowSDK.getTransactionToken(), IDnowSDK.getCompanyId());
        result.enqueue(callback);
    }

    private void onRequestVideoChatSuccess() {
        Util_Log.i(LOGTAG, "requestVideoChat REST Call was successful");
        Util_UtilWebsocket.IDENT_START_TIME = SystemClock.uptimeMillis();
    }

    private void onRequestVideoChatFailure(RequestVideoChatCallback requestVideoChatCallback, RetrofitError error) {
        Util_Log.i(LOGTAG, "requestVideoChat REST Call failed");
        String result;
        result = Util_UtilRetrofit.printRetrofitError(error);
        if (!result.equals("")) {
            result = Util_UtilRetrofit.getErrorIdRetrofit(result);
        }

        requestVideoChatCallback.onFailure(error, result);
    }

    public void prepareCustomMessagesViaRestFromJSON(final String jsonKey, PrepareCustomMessageCallback prepareCustomMessageCallback) {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Map<String, String>> callback = new Callback<Map<String, String>>() {
            @Override
            public void success(Map<String, String> jsonMap, Response response) {
                Util_Log.i(LOGTAG, "Retrieved messages.json");

                if (jsonMap != null) {
                    try {
                        String detailMsg = jsonMap.get(jsonKey);
                        if (detailMsg != null) {
                            if (jsonKey.equals("js.signing.native.consentProtocol.documentsPhrase.plural")) {
                                List<String> tokens = new ArrayList();
                                tokens.add("\\{(0{1})\\}");
                                tokens.add("\\{[1]{1}\\}");

                                List<String> params = new ArrayList();
                                params.add(String.valueOf(Config.PDF_DOCUMENTS.length));
                                String documentNames = "";
                                for (Models_PDFDocument pdf : Config.PDF_DOCUMENTS) {
                                    documentNames += pdf.getName() + ", ";
                                }
                                params.add(documentNames);
                                detailMsg = replaceTokens(detailMsg, tokens, params);
                                detailMsg = detailMsg.replace(", .", ".");
                            }

                            if (jsonKey.equals("js.signing.native.consentProtocol.documentsPhrase.one")) {
                                List<String> tokens = new ArrayList();
                                tokens.add("\\{[0]{1}\\}");

                                List<String> params = new ArrayList();
                                params.add(String.valueOf(Config.PDF_DOCUMENTS.length));

                                detailMsg = replaceTokens(detailMsg, tokens, params);
                            }

                            prepareCustomMessageCallback.onMessage(detailMsg);
                        }
                    } catch (Exception e) {
                        Util_Log.e(LOGTAG, "Parse fetched custom messages failed", e);
                    }
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Util_Log.i(LOGTAG, "Failed to get custom messages.json for key " + jsonKey);
            }
        };

        retrofit2.Call<Map<String, String>> result = service.getMessagesJSON(IDnowSDK.getCompanyId());
        result.enqueue(callback);
    }

    private String replaceTokens(String detailMsg, List<String> tokens, List<String> params) {
        if (tokens.size() == params.size()) {
            for (int i = 0; i < tokens.size(); i++) {
                detailMsg = detailMsg.replaceFirst(tokens.get(i), params.get(i));
            }
        }

        return detailMsg;
    }

}
