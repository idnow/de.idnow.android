package de.idnow.sdk.Activities

import android.content.res.Configuration
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.util.permissionsManager.AppPermissionsManager

abstract class BaseActivity : AppCompatActivity() {
    private val appPermissionsManager: AppPermissionsManager
            by lazy { AppPermissionsManager(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (IDnowSDK.getTransactionToken().isEmpty()) {
            finish()
            return
        }
        appPermissionsManager.init()
    }

    override fun onResume() {
        if (IDnowSDK.getTransactionToken().isEmpty())
            finish()
        else {
            super.onResume()
            appPermissionsManager.onResume()

        }
    }

    fun runWithPermissions(onPermissionsGrantedCallback: () -> Unit) =
        appPermissionsManager.request(onPermissionsGrantedCallback)

    fun checkPermissionsGranted(): Boolean =
        appPermissionsManager.checkPermissionsGranted()

    internal fun isDarkUiMode(): Boolean {
        val nightModeFlags = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return nightModeFlags == Configuration.UI_MODE_NIGHT_YES
    }
}