package de.idnow.sdk.views

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import androidx.core.view.isVisible
import de.idnow.sdk.R
import de.idnow.sdk.databinding.ViewLiveScreenExplanationBinding

class ExplanationView @JvmOverloads constructor(
    context: Context,
    attributeSet: AttributeSet? = null,
    defStyle: Int = 0
) : LinearLayout(context, attributeSet, defStyle) {

    private var binding: ViewLiveScreenExplanationBinding

    var notifyViaPushView: WaitingListNotification

    init {
        binding = ViewLiveScreenExplanationBinding.inflate(LayoutInflater.from(context), this, true)
        notifyViaPushView = binding.notifyViaPushView
    }

    fun setDividerTopVisibility(isVisible: Boolean) {
        binding.videoIdentExplanationViewDividerTop.isVisible = isVisible
    }

    fun setNotifyViaPushViewVisibility(isVisible: Boolean) {
        val notifyViaPushView: AnimationAverseLinearLayout = findViewById(R.id.notifyViaPushView)
        notifyViaPushView.isVisible = isVisible
    }

    fun setTextViewExplanationTitleText(text: String) {
        binding.textViewExplanationTitle.text = text
    }

    fun setExplanationTitleVisibility(visibility: Int) {
        binding.textViewExplanationTitle.visibility = visibility
    }

    fun getExplanationTitleText(): String {
        return binding.textViewExplanationTitle.text.toString()
    }

    fun setTextViewExplanationContentText(text: String) {
        binding.textViewExplanationContent.text = text
    }

    fun setTextViewExplanationContentVisibility(isVisible: Boolean) {
        binding.textViewExplanationContent.isVisible = isVisible
    }


}