package de.idnow.sdk.views

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import de.idnow.sdk.databinding.ViewCompleteEsignBinding
import de.idnow.sdk.util.Util_Strings

class CompleteEsignView @JvmOverloads constructor(
    context: Context,
    attributeSet: AttributeSet? = null,
    defStyle: Int = 0
) : LinearLayout(context, attributeSet, defStyle) {

    init {
        val binding = ViewCompleteEsignBinding.inflate(LayoutInflater.from(context), this, true)

        binding.completeEsignText.text = Util_Strings.getStringWithDefault(
            context,
            Util_Strings.KEY_VIDEO_IDENT_COMPLETE_ESIGN,
            Util_Strings.LOCAL_KEY_VIDEO_IDENT_COMPLETE_ESIGN
        )
    }
}
