
package de.idnow.sdk.Activities;

import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP;
import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;
import static de.idnow.sdk.Config.DARK_MODE;
import static de.idnow.sdk.Config.DISPLAY_WAITING_SCREEN_CUSTOMISED_TIMER;
import static de.idnow.sdk.Config.DOCUMENT_IMAGES;
import static de.idnow.sdk.Config.EMAIL_ADDRESS;
import static de.idnow.sdk.Config.E_SIGNING;
import static de.idnow.sdk.Config.IDENTIFICATION_SIGNATURE;
import static de.idnow.sdk.Config.IDENT_CODE_BY_SMS;
import static de.idnow.sdk.Config.ID_DOCUMENT;
import static de.idnow.sdk.Config.NORMAL_ESIGN;
import static de.idnow.sdk.Config.NORMAL_VIDEO_IDENT;
import static de.idnow.sdk.Config.RECONNECTION_TIMEOUT;
import static de.idnow.sdk.Config.RESTART_VIDEO_IDENT;
import static de.idnow.sdk.Config.SHOW_IDNOW_LOGO;
import static de.idnow.sdk.Config.SHOW_POWERED_BY_KEY;
import static de.idnow.sdk.Config.SOCKET_RECONNECT_INTERVAL;
import static de.idnow.sdk.Config.TAKE_PICTURE_LAYOUT;
import static de.idnow.sdk.Config.URL_DOCUMENT_NAMIRIAL;
import static de.idnow.sdk.Config.USER_CANCELLATION_ENUM;
import static de.idnow.sdk.Config.USER_PHONE_NO;
import static de.idnow.sdk.Config.VIDEO_IDENT_AGENT_FLOW;
import static de.idnow.sdk.Config.VIDEO_IDENT_PLUS;
import static de.idnow.sdk.Config.VIDEO_IDENT_PLUS_REUSE_IMAGES;
import static de.idnow.sdk.Config.VIDEO_IDENT_PLUS_UI;
import static de.idnow.sdk.Config.WALLET_LOGIN;
import static de.idnow.sdk.IDnowSDK.CHOOSER_SCREEN;
import static de.idnow.sdk.IDnowSDK.REQUEST_ID_NOW_SDK;
import static de.idnow.sdk.IDnowSDK.RESULT_CODE_CANCEL;
import static de.idnow.sdk.IDnowSDK.RESULT_CODE_FALLBACK_VID;
import static de.idnow.sdk.IDnowSDK.getTransactionToken;
import static de.idnow.sdk.util.IDnowExternalLog.logExternally;
import static de.idnow.sdk.util.Util_CustomLogData.EVENT_ESIGN_CONTRACT_SIGN_SCREEN_SHOWN;
import static de.idnow.sdk.util.Util_CustomLogData.EVENT_WAITING_FOR_AN_AGENT_SCREEN_SHOWN;
import static de.idnow.sdk.util.Util_CustomLogData.EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_CROSS_BTN;
import static de.idnow.sdk.util.Util_CustomLogData.EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_SHOWN;
import static de.idnow.sdk.util.Util_PhotoDataHolder.DocumentImages.face;
import static de.idnow.sdk.util.Util_PhotoDataHolder.DocumentImages.facefrontside;
import static de.idnow.sdk.util.Util_PhotoDataHolder.DocumentImages.idbackside;
import static de.idnow.sdk.util.Util_PhotoDataHolder.DocumentImages.idfrontside;
import static de.idnow.sdk.util.Util_Strings.*;
import static de.idnow.sdk.util.Util_Util.hideEmail;
import static de.idnow.sdk.util.Util_UtilWebsocket.openReportActivity;

import android.Manifest;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.Camera;
import android.media.AudioManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Build.VERSION_CODES;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ImageProxy;
import androidx.camera.view.PreviewView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Guideline;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.idnow.android.eid.eIDSdk;
import de.idnow.sdk.Activities.callbacks.ClassificationCallback;
import de.idnow.sdk.Activities.callbacks.ContinueSignCallback;
import de.idnow.sdk.Activities.callbacks.EnrollWaitingListCallback;
import de.idnow.sdk.Activities.callbacks.FetchWaitingInformationCallback;
import de.idnow.sdk.Activities.callbacks.GetApprovalPhrasesCallback;
import de.idnow.sdk.Activities.callbacks.GetTspDocCallback;
import de.idnow.sdk.Activities.callbacks.IdentificationCanceledCallback;
import de.idnow.sdk.Activities.callbacks.IdentificationFailedCallback;
import de.idnow.sdk.Activities.callbacks.LoginAccountCallback;
import de.idnow.sdk.Activities.callbacks.RequestVideoChatCallback;
import de.idnow.sdk.Activities.callbacks.SaveAccountPasswordCallback;
import de.idnow.sdk.Activities.callbacks.SendChatMessageCallback;
import de.idnow.sdk.Activities.callbacks.SendConfirmationCodeCallback;
import de.idnow.sdk.Activities.callbacks.SendIdentToPhoneCallback;
import de.idnow.sdk.Activities.callbacks.SubscribeForPushNotificationsCallback;
import de.idnow.sdk.Activities.callbacks.UpdateMobileNumberCallback;
import de.idnow.sdk.Activities.entry.Activities_EntryActivity;
import de.idnow.sdk.Activities.storedidentity.StoredIdentityActivity;
import de.idnow.sdk.Adapters.Adapter_TextChat;
import de.idnow.sdk.Adapters.Adapters_DocumentSpinnerAdapter;
import de.idnow.sdk.Adapters.CustomLinearLayoutManager;
import de.idnow.sdk.Adapters.IDnowListCountryAdapterVIP;
import de.idnow.sdk.AssetsLoader;
import de.idnow.sdk.Config;
import de.idnow.sdk.IDnowSDK;
import de.idnow.sdk.IWaitScreenCallback;
import de.idnow.sdk.Interface_VideoLiveStream;
import de.idnow.sdk.R;
import de.idnow.sdk.models.Models_ApprovalPhrase;
import de.idnow.sdk.models.Models_ApprovalPhraseURL;
import de.idnow.sdk.models.Models_ChatMessage;
import de.idnow.sdk.models.Models_Customer;
import de.idnow.sdk.models.Models_Email;
import de.idnow.sdk.models.Models_EmptyJson;
import de.idnow.sdk.models.Models_MobileNumber;
import de.idnow.sdk.models.Models_Password;
import de.idnow.sdk.models.Models_RegistrationeSign;
import de.idnow.sdk.network.Callback;
import de.idnow.sdk.network.IDNowWebViewClient;
import de.idnow.sdk.network.IDnowRestClient;
import de.idnow.sdk.network.Network_RESTCalls;
import de.idnow.sdk.network.Network_WebSocketService;
import de.idnow.sdk.network.RetrofitError;
import de.idnow.sdk.util.IDnowForegroundBinder;
import de.idnow.sdk.util.IDnowForegroundService;
import de.idnow.sdk.util.LogEventTypeEnum;
import de.idnow.sdk.util.ResourceHelper;
import de.idnow.sdk.util.UI_CustomLinearLayoutRadioGroupOnClickListener;
import de.idnow.sdk.util.UI_CustomOnClickListenerCheckMark;
import de.idnow.sdk.util.UI_SMSWaitScreen;
import de.idnow.sdk.util.UI_WaitScreen;
import de.idnow.sdk.util.Util_CustomLogData;
import de.idnow.sdk.util.Util_Custom_WebViewClient;
import de.idnow.sdk.util.Util_Drawing_View;
import de.idnow.sdk.util.Util_KillNotificationService;
import de.idnow.sdk.util.Util_KillNotificationService.KillBinder;
import de.idnow.sdk.util.Util_Log;
import de.idnow.sdk.util.Util_PhotoDataHolder;
import de.idnow.sdk.util.Util_PhotoStrings;
import de.idnow.sdk.util.Util_Strings;
import de.idnow.sdk.util.Util_Util;
import de.idnow.sdk.util.Util_UtilRetrofit;
import de.idnow.sdk.util.Util_UtilUI;
import de.idnow.sdk.util.Util_UtilWebsocket;
import de.idnow.sdk.util.Util_VideoStreamService;
import de.idnow.sdk.util.camera.CameraType;
import de.idnow.sdk.util.camera.IDnowCamera;
import de.idnow.sdk.util.helper.ImageHelper;
import de.idnow.sdk.views.CompleteIdentificationView;
import de.idnow.sdk.views.ESignatureOverlayView;
import de.idnow.sdk.views.ExplanationView;
import de.idnow.sdk.views.cameraCutoutOverlay.CameraCutoutOverlayType;
import de.idnow.sdk.views.cameraCutoutOverlay.CameraCutoutOverlayView;
import okhttp3.ResponseBody;
import retrofit2.Response;

public abstract class Activities_VideoLiveStreamActivity_Super extends BaseActivity implements IWaitScreenCallback, View.OnClickListener, IDnowListCountryAdapterVIP.CountryItemClickListener {
    public static final String LOGTAG = "IDNOW_Activities_VideoLiveStreamActivity_Super";

    public Context mContext;

    public boolean isActivityRunning = false;
    public boolean isAgentView = false;

    public byte[] imageStringToPush;

    public String imageTypeToPush;

    public ServiceConnection mConnection;

    public boolean waitingForSubscriberThreadIsRunning = false;

    public boolean identificationIsAtStep1 = true;

    private long lastClickTime = 0;

    private boolean signed = false;
    private int eSignatureStep = 1;

    // Spinning wheel for loading subscriber view
    public ProgressBar mLoadingSub;
    public ProgressBar progressBarLoading;

    // Notification
    private Notification.Builder mNotifyBuilder;
    private NotificationManager mNotificationManager;

    private View insertTanView, retrieveTanView;

    private CompleteIdentificationView completeIdentificationView;
    private ExplanationView explanationView;
    private ESignatureOverlayView overlayView;
    private LinearLayout helperImageContainer;
    public TextView insertTanTextView, insertTanHintTextView, insertTanHintTextViewCode, explanationContent, explanationTitle, retrieveTanInfoTextView, retrieveTanInfoTextViewModal, notReceivedTanTextView, textRequestIdentCode, textEnterIdentCode;
    public Button noReceivedTanButton;
    private EditText insertTanEditText, insertPhoneNrEditText, insertEmailEditText, wait_screen_sms_edit_text;
    private Button insertTanButton, retrieveTanButton;

    private LinearLayout poweredByView;

    public boolean setupCompleteCallAlreadyTriggered = false;

    int currentUserStep = 0;

    // Socket stuff
    public boolean threadIsRunning = false;
    public final Handler uiHandler = new Handler();

    public boolean showedBusyMessage = false;

    private boolean showedConsent = false;

    public long startTime = 0L;
    public long timeInMilliseconds = 0L;
    public long timeSwapBuff = 0L;
    public long updatedTime = 0L;
    public int secs = 0;

    public long startTimeWaitingForSubscriber = 0L;
    public long timeInMillisecondsWaitingForSubscriber = 0L;
    public long timeSwapBuffWaitingForSubscriber = 0L;
    public long updatedTimeWaitingForSubscriber = 0L;

    public boolean manuallyClosedActivity = false;
    private boolean userInitiatedCancellation; // set to true when user executes pressBack

    // waiting information, fetch info every 10 seconds
    private final int refreshPeriod = 10000;
    private Util_Drawing_View drawingView;
    public WebView openTrustWebView;
    public WebView openTrustWebViewTC;
    private ArrayList<SpannableString> checkEntries;
    private ArrayList<ImageView> checkEntriesImageViews;
    // View related variables
    public RelativeLayout mPublisherViewContainer;
    public RelativeLayout mSubscriberViewContainer;
    public RelativeLayout mSubscriberAudioOnlyView;
    public RelativeLayout subscriberContainer;
    public FrameLayout subscriberLayout;
    private RelativeLayout bottomLayout;
    private TextView indicatorTextView;
    private View notifyViaPushLowerPanel;
    private View notifyViaPushOKButton;
    private int unreadAgentMessages = 0;

    protected boolean conferenceStarted;

    int subscriberLayoutY, subscriberLayoutX = 0;

    // signature
    ImageView signatureMask;

    public boolean activityIsFinishing;

    private Boolean currentlyUploadingPicture = false;

    // text chat
    private RelativeLayout chatLayout;
    private RelativeLayout chatButtonHolder;
    private RelativeLayout chatIndicatorLayout;
    private ImageView chatButton;
    private ImageView closeChatButton;
    private ListView chatListView;
    private Adapter_TextChat textChatAdapter;
    private ImageView sendMessageImageView;
    private final ArrayList<Models_ChatMessage> textMessages = new ArrayList<>();
    private EditText chatEditText;
    private FrameLayout closeButtonFrameLayout;

    private RelativeLayout buttonHolderTop, buttonHolderBottom;

    // request tan views
    private RelativeLayout codeByEmailContainer, codeBySmsContainer;
    private ImageView checkViewCodeBySMS, checkViewCodeByEmail;
    private boolean receiveTanByEmail = false;

    private long timer;

    // Wallet feature

    // * createAccount
    private TextView headlineAccount;
    private TextView instructionAccount;
    private TextView hintAccount;
    private TextView noRegistrationReg;
    private EditText emailAccount;
    private EditText mobilePhoneAccount;
    private Button confirmAccount;
    private Button abortAccount;
    private Button showContractTextViewRegister;

    // * savePassword
    private TextView headlinePassword;
    private TextView instructionPassword;
    private TextView hintPassword;
    private EditText passwordPassword;
    private EditText reconfirmPassword;
    private Button abortPassword;
    private Button confirmPassword;

    // * loadLoginAccountLayout
    private TextView headlineLogin;
    private TextView instructionLogin;
    private TextView hintLogin;
    private TextView rememberPasswordLogin;
    private EditText emailLogin;
    private EditText passwordLogin;
    private Button abortLogin;
    private Button confirmLogin;
    private Button showContractTextViewLogin;
    private Button showContractTextViewPassword;

    // * forgotPassword
    private TextView headlineForgotPassword;
    private TextView instructionForgotPassword;
    private Button continueVideoIdent;
    private Button abortForgotPassword;

	private UI_WaitScreen waitScreen;
	private UI_SMSWaitScreen smsWaitScreen;

    private int wrongSmsTries = 0;

    String manufacturer = android.os.Build.MANUFACTURER;
    String model = Build.MODEL;

    /******** Video Ident Plus ********/

    private CameraCutoutOverlayView cameraCutoutOverlay;
    public View takePictureLayout;

    public PreviewView cameraPreview;
    public IDnowCamera camera;
    LinearLayout circle1, circle2, circle3, circle4, layoutAction_1, layoutAction_2, retakeButton;
    ConstraintLayout video_ident_plus;

    public LottieAnimationView circleCheck1, circleCheck2, circleCheck3, circleCheck1_steps, circleCheck2_steps, circleCheck3_steps, takePictureButton, retake;

    public TextView num_text, idcard_text, mainTextDescription, id_selection_continue, textDescription, retakeAction, id_selection_document_title, num_text_steps, idcard_text_steps;

    EditText textSMSCode;

    public String textSMSCodeResult = "";

    Context contextVIP;

    Button continueButton, requestIdentCodeButton;

    private ImageCapture.OnImageCapturedCallback imageCapturedCallback;

    //TODO to be deleted
    public RelativeLayout relativeLayoutScreen;
    public Bitmap bmp;
    public String capturedImageFilePath = "";

    public ImageView imageViewPhoto;

    public RelativeLayout agentSide;
    public FrameLayout frameLayoutDescription;
    public FrameLayout mainlayout;
    public EditText searchCountryEdt;

    public RecyclerView list_country;

    private IDnowListCountryAdapterVIP listCountryAdapter;

    public FrameLayout listFragment;

    public LinearLayout selectdocumentLayout, document_not_supported_layout, video_ident_steps_layout, video_select_document_layout, video_ident_plus_layout_waiting_list, video_ident_plus_layout_retry_flow, card_vip;
    public ConstraintLayout video_ident_plus_layout;

    LottieAnimationView image_error_layout;
    TextView title_error_layout, description_error_layout;
    Button button_error_layout;

    public LinearLayout status_layout, search_bar_country, layout_countries_search, waiting_time_layout, agent_card_normal, agent_steps, agent_normal_steps;

    public Button vip_ok_waiting_list, vip_save_button;
    public TextView vip_cancel_waiting_list, idcard_text_normal_steps, idcard_text_normal;

    public TextView waiting_list_vip_title, vip_witinglist_text_1, vip_witinglist_text_2, vip_witinglist_time, vip_witinglist_text_3, vip_witinglist_text_4, vip_witinglist_text_cancel, id_selection_user_feedback, search_text, id_selection_title;

    public Boolean isFaceImage;

    public LottieAnimationView document_front, document_back, document_selfie;
    public LottieAnimationView check_1, check_2, check_3, poweredByViewVIP;
    public TextView vip_document_text_1, vip_document_text_2, vip_document_text_3, retakePhoto_retry, vip_document_front, vip_document_back, vip_document_selfie, reuse_title, reuse_desc;

    SharedPreferences prefs;
    SharedPreferences.Editor editor;


    public LottieAnimationView used_logo_country_documents, logo_retry_flow, icon_powered_by;

    File frontfile = null;
    File backfile = null;
    File selfiefile = null;
    public String frontfilename = "";
    public String backfilename = "";
    public String selfiefilename = "";

    public AlertDialog takingImageDialog = null;

    public LottieAnimationView animationWL, logo_screen_feedback;

    public LinearLayout rateAgent_view, userAbort_view;

    public View user_abort_feedback_view;

    public TextView feedback_title, feedback_description, feedback_cancel;

    public Button feedback_button;

    public RadioGroup userAbort_radio;

    public String reason_to_cancel;

    public int selectedId = 0;

    public BottomSheetDialog bottomSheetDialog, waitingSheetDialog;

    public LottieAnimationView animationWaitingL;

    public TextView animationWLtitle, waiting_estimated_text, dontleave_text, waiting_screen_desc, waiting_screen_no, delayedTextView;

    public ImageButton cancelRerouting;

    public TextView titleRerouting, descRerouting, continueRerouting;

    public Button tryRerouting, waiting_screen_yes;

    public TextView text_request_ident_code, mobile_number_textview;

    public LottieAnimationView spinnerWL;
    public TextView connecting_with_agent_text;
    public CountDownTimer countDownTimer;
    public boolean timeRunning = false;

    public boolean isTimerFinished = false;
    public TextView countDownText;
    public long timerinMilliSeconds = DISPLAY_WAITING_SCREEN_CUSTOMISED_TIMER;
    public LinearLayout estimation_layout;

    VideoLiveStreamManager videoLiveStreamManager;
    SubscribeForPushNotificationsCallback subscribeCallback;
    SendConfirmationCodeCallback sendConfirmationCodeCallback;
    ClassificationCallback classificationCallback;
    GetApprovalPhrasesCallback approvalPhrasesCallback;
    public GetTspDocCallback getTspDocCallback;
    IdentificationCanceledCallback identificationCanceledCallback;
    SendIdentToPhoneCallback sendIdentToPhoneCallback;
    UpdateMobileNumberCallback updateMobileNumberCallback;
    EnrollWaitingListCallback enrollWaitingListCallback;
    RequestVideoChatCallback requestVideoChatCallback;
    IdentificationCanceledCallback pipCanceledCallback;

    protected boolean shouldRestoreTakePictureLayout = false;
    protected boolean shouldRestoreVideoIdentStepsLayout = false;

    /****************************/

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTheme(androidx.appcompat.R.style.Theme_AppCompat_Light_NoActionBar);

        Config.VIDEO_IDENT_BACKGROUND = false;

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        timer = System.currentTimeMillis();

        mContext = this;
        manuallyClosedActivity = false;
        setupCompleteCallAlreadyTriggered = false;

        // remove the actionbar
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        if (IDnowSDK.preventScreenshot) {
            // secures against manual screenshots and automatic screenshots
//			getWindow().setFlags(LayoutParams.FLAG_SECURE, LayoutParams.FLAG_SECURE);
        }

        // resetting the Waiting Queue information, so the user doesn't get stuck in his old information, when he restarts the call.
        Config.IDENT_ESTIMATED_WAITING_TIME = -1;
        Config.IDENT_POSITION_IN_QUEUE = -1;

        if (!VIDEO_IDENT_PLUS && !WALLET_LOGIN) {
            Util_CustomLogData.setEventData(EVENT_WAITING_FOR_AN_AGENT_SCREEN_SHOWN, "EVENT_WAITING_FOR_AN_AGENT_SCREEN_SHOWN", "Waiting for an agent", "Screen", null);
        }

        loadInterface();

        mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (Config.E_SIGNING) {

            if (Config.AUTHENTICATED_POSSIBLE && Config.AUTHENTICATED_SIGNED) {
                Config.WALLET_LOGIN = true;
            } else if (!Config.AUTHENTICATED_POSSIBLE && Config.AUTHENTICATED_SIGNED) {
                Config.WALLET_REGISTRATION = true;
            } else {
                Config.NORMAL_ESIGN = true;
            }
        }

        videoLiveStreamManager = new VideoLiveStreamManager(getApplicationContext());
        subscribeCallback = new SubscribeForPushNotificationsCallback() {
            @Override
            public void onSuccess(String companyId, String token) {
                videoLiveStreamManager.enrollForWaitingListNotifications(companyId, token, null, enrollWaitingListCallback);
            }

            @Override
            public void onFailure() {
                closePushLowerPanel();
                closePushDialogPanel();
            }
        };
        sendConfirmationCodeCallback = new SendConfirmationCodeCallback() {
            @Override
            public void init() {
                overlayView.setESigningProgressContainerVisible(true);
                overlayView.setESigningNativeContentVisible(false);
                insertTanView.setVisibility(View.GONE);
            }

            @Override
            public void onSuccess() {
                if (Config.E_SIGNING && Config.USE_NATIVE_ESIGNING) {
                    overlayView.setESigningProgressContainerVisible(true);
                    overlayView.setESigningSuccessContainerVisible(true);
                    if (Config.INSTANT_SIGN) {
                        Handler mHandler = new Handler();
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                showResultActivity(IDnowSDK.RESULT_CODE_SUCCESS);
                            }
                        }, 2000);
                    }

                } else {
                    if (Config.VIDEO_IDENT_PLUS && !E_SIGNING) {

                        setRequestScreenVisible(Boolean.FALSE);
                        takePictureLayout.setVisibility(View.VISIBLE);
                        video_ident_steps_layout.setVisibility(View.GONE);
                        layoutAction_1.setVisibility(View.GONE);
                        layoutAction_2.setVisibility(View.GONE);
                        mainTextDescription.setVisibility(View.VISIBLE);
                        textDescription.setVisibility(View.VISIBLE);
                        textSMSCode.setVisibility(View.GONE);

                        if (Config.VIDEO_IDENT_PLUS_UI) {
                            card_vip.setVisibility(View.GONE);
                            agent_card_normal.setVisibility(View.VISIBLE);


                        }

                        mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC6, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC6));
                        textDescription.setVisibility(View.GONE);
                        circle1.setVisibility(View.GONE);
                        circle2.setVisibility(View.GONE);
                        circle3.setVisibility(View.GONE);
                        circle4.setVisibility(View.GONE);


                    } else {

                        insertTanView.setVisibility(View.GONE);
                        completeIdentificationView.setVisibility(View.VISIBLE);
                        mLoadingSub.setVisibility(View.VISIBLE);
                        overlayView.setVisibility(View.GONE);
                        bottomLayout.setVisibility(View.VISIBLE);
                        Util_Log.i(LOGTAG, "sendConfirmationCode REST Call was successful");
                        locateChatButton(true);
                    }
                }
            }

            @Override
            public void onFailure(RetrofitError error, String result, String errorCause, int statusCode) {

                if(E_SIGNING && Config.USE_NATIVE_ESIGNING && !Config.OTP_DISPLAY_SIGNING){
                    Util_UtilUI.showRESTCallErrorDialog(mContext, 500, false, null, result, true, false,"" );
                    pipCanceledCallback.onSuccess();
                }
                else {

                    if (Config.E_SIGNING && Config.USE_NATIVE_ESIGNING) {

                        wrongSmsTries = (statusCode == 400 && errorCause.equals(IDnowSDK.WRONG_CONFIRMATION_TOKEN)) ?
                                ++wrongSmsTries : wrongSmsTries;

                        insertTanView.setVisibility(View.VISIBLE);

                        overlayView.setESigningProgressContainerVisible(false);

                    } else if (!result.equals("")) {
                        result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                    }

                    if (wrongSmsTries > 2) {
                        identificationFailedRESTCall();
                    } else if (Config.E_SIGNING && Config.USE_NATIVE_ESIGNING) {
                        String message = Util_Strings.getStringWithDefault(getApplicationContext(), KEY_CONFIRMATION_TOKEN_WRONG_OTP_CODE, LOCAL_KEY_CONFIRMATION_TOKEN_WRONG_OTP_CODE);

                        message = message.replaceAll("\\{.*?\\}", 3 - wrongSmsTries + "");

                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(mContext, R.style.IDnowAlertDialogStyle))
                                .setMessage(message)
                                .setPositiveButton(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), (dialog, id) -> dialog.cancel());

                        if (mContext instanceof Activity && !((Activity) mContext).isFinishing()) {
                            Util_UtilUI.showBrandedDialog(alertDialogBuilder.create());
                        }

                    } else if (error.getResponse() != null && isActivityRunning) {
                        Util_UtilUI.showSendingTanErrorDialog(mContext, error.getResponse().getStatus(), true, result, errorCause, !receiveTanByEmail);

                    } else if (isActivityRunning) {
                        Util_UtilUI.showSendingTanErrorDialog(mContext, 0, true, result, errorCause, !receiveTanByEmail);
                    }
                }
            }
        };
        classificationCallback = new ClassificationCallback() {
            @Override
            public void onDismissProgress() {
                dismissProgressDialog();
            }

            @Override
            public void onShowBottomSheet() {
                bottomSheetDialog.show();
            }

            @Override
            public void onShowDocumentClassification() {
                video_ident_plus_layout.setVisibility(View.GONE);
                video_select_document_layout.setVisibility(View.VISIBLE);
                selectdocumentLayout.setVisibility(View.VISIBLE);
                document_not_supported_layout.setVisibility(View.GONE);
            }

            @Override
            public void onUpdateErrorScreen(boolean captureId) {
                updateErrorScreen(captureId);
            }

            @Override
            public void onSendDocumentSuccess() {
                if (!Config.ALL_PHOTO_USED) {
                    dismissProgressDialog();
                }
                if (Config.MISSING_IMAGES.equals(2)) {
                    if (video_ident_plus_layout_retry_flow != null && video_ident_plus_layout != null) {
                        video_ident_plus_layout_retry_flow.setVisibility(View.GONE);
                        video_ident_plus_layout.setVisibility(View.VISIBLE);
                    }
                }

                if (Config.MISSING_IMAGES.equals(1) || Config.MISSING_IMAGES.equals(0)) {
                    byte[] imageStringToPush = ImageHelper.INSTANCE.readAsBase64(backfilename, 90);
                    videoLiveStreamManager.sendUploadPhotoRESTCall(contextVIP, Activities_VideoLiveStreamActivity_Super.this, imageStringToPush, idbackside, classificationCallback);
                } else {
                    dismissProgressDialog();

                    DOCUMENT_IMAGES = Util_PhotoDataHolder.DocumentImages.idbackside;
                    setRightScreen(Util_PhotoDataHolder.DocumentImages.idbackside, false);
                }
            }

            @Override
            public void onSendUploadPhotoSuccess(Util_PhotoDataHolder.DocumentImages imageType) {
                if (Activities_VideoLiveStreamActivity_Super.this.isDestroyed()) {
                    return;
                }
                if (!Config.ALL_PHOTO_USED) {
                    classificationCallback.onDismissProgress();
                }

                if (imageType.equals(Util_PhotoDataHolder.DocumentImages.idfrontside)) {
                    if ((Config.VIDEO_IDENT_PLUS) && (Config.VIDEO_IDENT_PLUS_DOCUMENT_CHECKING)) {
                        video_ident_plus_layout.setVisibility(View.GONE);
                        video_select_document_layout.setVisibility(View.VISIBLE);
                    } else {

                        if (!Config.RETRY_UPLOAD) {
                            DOCUMENT_IMAGES = Util_PhotoDataHolder.DocumentImages.idbackside;
                            setRightScreen(Util_PhotoDataHolder.DocumentImages.idbackside, false);
                        }
                    }

                } else if (imageType.equals(Util_PhotoDataHolder.DocumentImages.idbackside)) {

                    if (Config.MISSING_IMAGES.equals(1)) {

                        if (!Config.VIDEO_IDENT_PLUS_SELFIE_IMAGE && Config.ONLY_BACK_SIDE_NULL) {
                            setRightScreen(Util_PhotoDataHolder.DocumentImages.agent, false);
                        } else {
                            if (video_ident_plus_layout_retry_flow != null && video_ident_plus_layout != null) {
                                video_ident_plus_layout_retry_flow.setVisibility(View.GONE);
                                video_ident_plus_layout.setVisibility(View.VISIBLE);
                                if (!Config.ALL_PHOTO_USED) {
                                    dismissProgressDialog();
                                }

                            }
                        }


                    }
                    if (!Config.MISSING_IMAGES.equals(0)) {
                        if (!Config.VIDEO_IDENT_PLUS_SELFIE_IMAGE) {
                            setRightScreen(Util_PhotoDataHolder.DocumentImages.agent, false);
                        } else {
                            if (Config.ONLY_BACK_SIDE_NULL) {
                                setRightScreen(Util_PhotoDataHolder.DocumentImages.agent, false);
                            } else {
                                DOCUMENT_IMAGES = Util_PhotoDataHolder.DocumentImages.face;
                                setRightScreen(Util_PhotoDataHolder.DocumentImages.face, false);
                            }

                        }
                    } else {
                        if (video_ident_plus_layout_retry_flow != null && video_ident_plus_layout != null) {
                            byte[] imageStringToPush = ImageHelper.INSTANCE.readAsBase64(selfiefilename, 90);
                            videoLiveStreamManager.sendUploadPhotoRESTCall(contextVIP, Activities_VideoLiveStreamActivity_Super.this, imageStringToPush, face, classificationCallback);
                        }
                    }

                } else if (imageType.equals(Util_PhotoDataHolder.DocumentImages.face)) {
                    if (Config.MISSING_IMAGES.equals(0) || Config.MISSING_IMAGES.equals(1)) {
                        if (video_ident_plus_layout_retry_flow != null && video_ident_plus != null) {
                            video_ident_plus_layout_retry_flow.setVisibility(View.GONE);

                            dismissProgressDialog();

                            if (VIDEO_IDENT_PLUS_REUSE_IMAGES) {
                                Config.ALL_PHOTO_USED = false;
                            }
                        }
                    }
                    setRightScreen(Util_PhotoDataHolder.DocumentImages.agent, false);
                }
            }
        };

        approvalPhrasesCallback = new GetApprovalPhrasesCallback() {
            @Override
            public void onAddEntry(SpannableString entry) {
                checkEntries.add(entry);
            }

            @Override
            public void onUpdateEntries() {
                updateCheckEntries();
            }

            @Override
            public void onNewEntries() {
                checkEntries = new ArrayList<>();
            }

            @Override
            public ClickableSpan onClickLink(String link) {
                return clickLink(link);
            }
            @Override
            public void implementView() {
                HashMap<String, String> listLabel = new HashMap<>();
                if (Config.MODEL_APPROVAL_PHRASES != null) {
                    progressBarLoading.setVisibility(View.INVISIBLE);
                    Util_Log.d(LOGTAG, "onSuccess implementView  : " + Config.MODEL_APPROVAL_PHRASES.toString() + " " + URL_DOCUMENT_NAMIRIAL.toString());
                    approvalPhrasesCallback.onNewEntries();
                    for (Models_ApprovalPhrase approvalPhrase : Config.MODEL_APPROVAL_PHRASES) {
                        if (approvalPhrase.getName() != null && approvalPhrase.getTranslationKey() != null && approvalPhrase.getValue() != null) {
                            Util_Log.i(LOGTAG, "Approval phrases : " + approvalPhrase.toString());

                            String text = approvalPhrase.getValue();
                            text = text.replaceAll("\\<.*?>", "");
                            SpannableString ss = new SpannableString(text);
                            if (approvalPhrase.getUrls() != null && !approvalPhrase.getUrls().isEmpty()) {
                                Util_Log.i(LOGTAG, "Approval phrases urls : " + approvalPhrase.getUrls().toString());

                                Iterator<String> it = approvalPhrase.getUrls().keySet().iterator();
                                while (it.hasNext()) {
                                    String key = it.next();
                                    Models_ApprovalPhraseURL url = approvalPhrase.getUrls().get(key);

                                    String link = "";
                                    String linkLabel = "";
                                    if (url != null) {
                                        link = url.getLink();
                                        linkLabel = url.getLabel();
                                        String action = url.getAction();
                                        boolean isSignatureAction = action != null
                                                && action.equals(Config.SIGNATURE_CONTRACT_ACTION);
                                        // key : gtu
                                        if (linkLabel.equals("Signature Contract") && isSignatureAction) {
                                            link = URL_DOCUMENT_NAMIRIAL;
                                        }
                                    }
                                    Pattern p = Pattern.compile("\\$\\(.*?\\)");
                                    Matcher m = p.matcher(text);

                                    listLabel.put(linkLabel, link);

                                    while (m.find()) {
                                        if (m.group().contains(key)) {
                                            text = text.replace(m.group(), url.getLabel());
                                        }
                                    }
                                }

                                ss = new SpannableString(text);

                                for (Map.Entry<String, String> entry : listLabel.entrySet()) {
                                    int startIndex = text.indexOf(entry.getKey());
                                    int lenghtIndex = entry.getKey().length();
                                    int endIndex = startIndex + lenghtIndex;
                                    ClickableSpan clickLink = approvalPhrasesCallback.onClickLink(entry.getValue());
                                    ss.setSpan(clickLink, startIndex,
                                            endIndex,
                                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                                }
                            }
                            Util_Log.i(LOGTAG, "Approval phrase " + approvalPhrase.getName());
                            Util_Log.i(LOGTAG, "   " + approvalPhrase.getTranslationKey() + " -> " + approvalPhrase.getValue());
                            approvalPhrasesCallback.onAddEntry(ss);
                        }
                    }
                }
                approvalPhrasesCallback.onUpdateEntries();


            }

            @Override
            public void dataToPDF(ResponseBody response) throws FileNotFoundException, IOException {
                if (response != null) {
                    InputStream in = response.byteStream();

                    byte[] bytesArray = inputToByte(in);

                    File folder = null;
                    String path = "";
                    String fileName = "";
                    path = getFilesDir().toString();
                    folder = new File(getFilesDir() + "/IDnow");
                    folder.mkdir();
                    fileName = "/IDnow" + "-File-" + System.currentTimeMillis() + ".pdf";
                    path = path + "/IDnow";

                    OutputStream outStream;
                    outStream = new FileOutputStream(path + fileName);
                    outStream.write(bytesArray);
                    outStream.close();

                    URL_DOCUMENT_NAMIRIAL = path + fileName;

                    startESigning();
                } else {
                    startESigning();
                }
            }
        };


        identificationCanceledCallback = new IdentificationCanceledCallback() {
            @Override
            public void onFailure() {
                triggerOnBackPressed(IDnowSDK.RESULT_CODE_CANCEL);
            }

            @Override
            public void onSuccess() {
                ((Activities_VideoLiveStreamActivity_Super) mContext).openResultActivity(IDnowSDK.RESULT_CODE_CANCEL);
            }
        };
        pipCanceledCallback = new IdentificationCanceledCallback() {
            @Override
            public void onFailure() {
                Util_Log.d(LOGTAG, "Identification canceled api call failed");
            }

            @Override
            public void onSuccess() {
                Util_Log.d(LOGTAG, "Identification canceled api call success");
            }
        };

        sendIdentToPhoneCallback = new SendIdentToPhoneCallback() {
            @Override
            public void onFailure(String result, String errorCause, RetrofitError error) {
                retrieveTanButton.setEnabled(true);
                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                }

                if (error != null && error.getResponse() != null && isActivityRunning) {
                    Util_UtilUI.showSendingTanErrorDialog(mContext, error.getResponse().getStatus(), false, result, errorCause, !receiveTanByEmail);

                } else {
                    if (isActivityRunning) {
                        Util_UtilUI.showSendingTanErrorDialog(mContext, 0, false, result, errorCause, !receiveTanByEmail);
                    }
                }

                retrieveTanView.setVisibility(View.GONE);
                if (!Config.VIDEO_IDENT_PLUS) {
                    insertTanView.setVisibility(View.VISIBLE);
                }
                setPaintFlagsOnInsertTanTextView();
                insertTanHintTextView.setVisibility(View.GONE);
                insertTanHintTextViewCode.setVisibility(View.GONE);
            }

            @Override
            public void onSuccess() {
                retrieveTanButton.setEnabled(true);
                if (Config.VIDEO_IDENT_PLUS && !E_SIGNING) {
                    Util_Log.i(LOGTAG, "http to enter setEnterCodeScreenVisible");
                    setEnterCodeScreenVisible();
                } else {
                    if (takePictureButton != null) {
                        takePictureButton.setVisibility(View.GONE);
                    }
                    retrieveTanView.setVisibility(View.GONE);
                    insertTanView.setVisibility(View.VISIBLE);
                    setPaintFlagsOnInsertTanTextView();
                    insertTanHintTextView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onReceiveByEmail(boolean receiveByEmail) {
                receiveTanByEmail = receiveByEmail;
            }
        };
        updateMobileNumberCallback = new UpdateMobileNumberCallback() {
            @Override
            public void onSuccess(UI_SMSWaitScreen ui_smsWaitScreen) {
                if (Config.WAITING_LIST_NOTIFICATIONS_CHANNEL.equals("SMS")) {
                    videoLiveStreamManager.enrollForWaitingListNotifications(IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken(), ui_smsWaitScreen, enrollWaitingListCallback);
                } else {
                    videoLiveStreamManager.subscribeToForPushNotifications(IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken(), subscribeCallback);
                }
            }

            @Override
            public void onFailure() {
                if (Config.WAITING_LIST_NOTIFICATIONS_CHANNEL.equals("SMS")) {
                    videoLiveStreamManager.enrollForWaitingListNotifications(IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken(), null, enrollWaitingListCallback);
                } else {
                    videoLiveStreamManager.subscribeToForPushNotifications(IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken(), subscribeCallback);
                }
            }
        };
        enrollWaitingListCallback = new EnrollWaitingListCallback() {
            @Override
            public void onSuccess(UI_SMSWaitScreen ui_smsWaitScreen) {
                if (Config.SHOULD_DISPLAY_WAITING_SCREEN && ui_smsWaitScreen != null) {
                    ui_smsWaitScreen.displayConfirmationScreen();
                } else {
                    LinearLayout confirmation_panel = findViewById(R.id.confirmation_panel);
                    confirmation_panel.setVisibility(View.VISIBLE);
                    explanationView.getNotifyViaPushView().setMiddlePanelVisible(false);
                    explanationView.getNotifyViaPushView().setWaitScreenSmsConfirmationDoneOnClickListener(v -> confirmWaitAndReturn());
                }

                if (Config.VIDEO_IDENT_PLUS) {
                    if (video_ident_plus_layout_waiting_list != null) {
                        video_ident_plus_layout_waiting_list.setVisibility(View.GONE);
                        confirmWaitAndReturn();
                    }
                }
            }

            @Override
            public void onFailure() {
                if (Config.VIDEO_IDENT_PLUS) {
                    videoLiveStreamManager.identificationCanceledRESTCall(null, identificationCanceledCallback);
                    returnFromSDK();
                } else {
                    closePushLowerPanel();
                    closePushDialogPanel();
                }
            }
        };
        requestVideoChatCallback = (error, result) -> {
            if (error != null && error.getResponse() != null && isActivityRunning) {
                if (error.getResponse().getStatus() != 400) {
                    Util_UtilUI.showRESTCallErrorDialog(mContext, error.getResponse().getStatus(), true, requestVideoChatRESTCallRunnable, result, true, true, "");
                }
            } else {
                if (isActivityRunning) {
                    Util_UtilUI.showRESTCallErrorDialog(mContext, 0, true, requestVideoChatRESTCallRunnable, result, true, true, "");
                }
            }
        };

        if (Config.INSTANT_SIGN) {
            overlayView.setVisibility(View.VISIBLE);
            overlayView.setESigningPreparationContaoinerVisible(true);
            overlayView.setESigningNativeContainerVisible(false);
            overlayView.setESignWebViewContainerVisible(false);
            progressBarLoading.setVisibility(View.GONE);
            prepareSigningSession();
        } else if ((Config.WALLET_LOGIN) && (!Config.RESTART_VIDEO_IDENT)) {
            if (video_ident_plus_layout != null) {
                video_ident_plus_layout.setVisibility(View.GONE);
            }
            startESigning();
        } else {
            if (!Config.E_SIGNING && !Config.WALLET_REGISTRATION && !WALLET_LOGIN) {
                NORMAL_VIDEO_IDENT = true;
            }

            if (IDnowSDK.isForcedWaitingList() && Config.VIDEO_IDENT_PLUS && !Config.WAITING_LIST_NOTIFICATIONS_ENROLLED && !Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE) {
                progressBarLoading.setVisibility(View.GONE);
                openPushDialogPanel();
                openPushLowerPanel();
            } else if (Config.VIDEO_IDENT_PLUS && Config.WAITING_LIST_NOTIFICATIONS_ENROLLED) {
                progressBarLoading.setVisibility(View.GONE);
                openPushSuccessPanel();
            } else if ((Config.VIDEO_IDENT_PLUS && NORMAL_VIDEO_IDENT) || (Config.VIDEO_IDENT_PLUS && Config.RESTART_VIDEO_IDENT) || (Config.VIDEO_IDENT_PLUS && Config.WALLET_REGISTRATION) || (Config.VIDEO_IDENT_PLUS && NORMAL_ESIGN && !WALLET_LOGIN)) {
                agentSide = findViewById(R.id.subscriberView);
                frameLayoutDescription = findViewById(R.id.frameLayoutDescription);
                mainlayout = findViewById(R.id.mainlayoutFrame);
                agentSide.setVisibility(View.GONE);
                frameLayoutDescription.setVisibility(View.GONE);
                mainlayout.setVisibility(View.GONE);
                loadInterfaceVideoIdentPlus();

                if (Config.VIDEO_IDENT_PLUS_DOCUMENT_CHECKING) {
                    loadInterfaceListCountries();
                }

            }

            if ((Config.WALLET_LOGIN) && (!Config.RESTART_VIDEO_IDENT)) {

                if (video_ident_plus_layout != null) {
                    video_ident_plus_layout.setVisibility(View.GONE);
                }
                startESigning();
            }
        }
    }

    public static String getLinkFromJson(String jsonResponse) {
        try {
            // Parse the JSON response
            JSONObject jsonObject = new JSONObject(jsonResponse);

            // Check for the action
            String action = jsonObject.optString("action", "");

            // If action is DOWNLOAD_SIGNATURE_CONTRACT, return null
            if ("DOWNLOAD_SIGNATURE_CONTRACT".equals(action)) {
                return null;
            }

            // Retrieve the link
            return jsonObject.optString("link", null);
        } catch (Exception e) {
            // Handle JSON parsing errors
            e.printStackTrace();
            return null;
        }
    }

    /****** Video Ident Plus ******/

    public void loadInterfaceListCountries() {
        ImageView countrySearch = findViewById(R.id.country_search);
        searchCountryEdt = findViewById(R.id.search_text);
        list_country = findViewById(R.id.list_country);
        listFragment = findViewById(R.id.listFragment);
        id_selection_continue = findViewById(R.id.id_selection_continue);
        id_selection_document_title = findViewById(R.id.id_selection_document_title);
        id_selection_title = findViewById(R.id.id_selection_title);
        list_country.setLayoutManager(new CustomLinearLayoutManager(this));
        image_error_layout = findViewById(R.id.image_error_layout);
        title_error_layout = findViewById(R.id.title_error_layout);
        description_error_layout = findViewById(R.id.description_error_layout);
        button_error_layout = findViewById(R.id.button_error_layout);
        search_bar_country = findViewById(R.id.search_bar_country);
        layout_countries_search = findViewById(R.id.layout_countries_search);
        id_selection_user_feedback = findViewById(R.id.id_selection_user_feedback);
        used_logo_country_documents = findViewById(R.id.used_logo_country_documents);
        id_selection_user_feedback.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_TITLE));
        id_selection_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_IDSELECTION, LOCAL_KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_IDSELECTION));
        searchCountryEdt.setHint(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_SEARCH_TEXT, LOCAL_KEY_VIDEO_IDENT_SEARCH_TEXT));
        id_selection_document_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_DOCUMENT, LOCAL_KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_DOCUMENT));
        id_selection_continue.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_NOT_LISTED, LOCAL_KEY_VIDEO_IDENT_PLUS_CLASSIFICATION_NOT_LISTED));

        used_logo_country_documents.setAnimation("static_logo.json");

        if (IDnowSDK.getShowIDnowLogo()) {
            used_logo_country_documents.setVisibility(View.VISIBLE);
            ViewCompat.setOnApplyWindowInsetsListener(used_logo_country_documents, (v, insets) -> {
                Insets bars = insets.getInsets(
                        WindowInsetsCompat.Type.statusBars()
                                | WindowInsetsCompat.Type.displayCutout()
                );
                v.setPadding(bars.left, bars.top + 10, bars.right, bars.bottom);
                return WindowInsetsCompat.CONSUMED;
            });
        } else {
            used_logo_country_documents.setVisibility(View.GONE);
        }


        if (Config.DARK_MODE) {
            Util_UtilUI.setColorLottieAnimation(Color.WHITE, used_logo_country_documents, "SecondaryVariant");

        } else {
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, used_logo_country_documents, "SecondaryVariant");
        }


        searchCountryEdt.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return false;
            }
        });

        if (IDnowSDK.getNewBrand()) {
            button_error_layout.setBackgroundResource(R.drawable.rounded_background_orange);
        } else {
            button_error_layout.setBackgroundResource(R.drawable.rounded_background_orange_old);
        }

        button_error_layout.setOnClickListener(v -> {
            IDnowSDK.getInstance().setStartCallIssued(false);
            if (contextVIP instanceof Interface_VideoLiveStream) {
                ((Interface_VideoLiveStream) contextVIP).identificationCanceled();
            }
        });

        layout_countries_search.setBackgroundColor(0x00000000);
        search_bar_country.setBackground(contextVIP.getDrawable(R.drawable.vip_search_country_background));

        DividerItemDecoration verticalDecoration = new DividerItemDecoration(list_country.getContext(), DividerItemDecoration.VERTICAL);
        Drawable verticalDivider = ContextCompat.getDrawable(contextVIP, R.drawable.vertical_divider);
        verticalDecoration.setDrawable(verticalDivider);
        list_country.addItemDecoration(verticalDecoration);

        countrySearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(searchCountryEdt.getText().length() == 0)) {
                    if (listCountryAdapter.getSelectedPosition() != -1) {
                        clearData();
                    }

                    searchCountryEdt.setSelection(searchCountryEdt.getText().length());
                    listCountryAdapter.getFilter().filter(searchCountryEdt.getText());
                    listCountryAdapter.notifyDataSetChanged();
                }
            }
        });

        list_country.setVisibility(View.GONE);
        listCountryAdapter = new IDnowListCountryAdapterVIP(this, (ArrayList<String>) Util_PhotoDataHolder.getCountryList(this));
        listCountryAdapter.setCountryItemClickListener((IDnowListCountryAdapterVIP.CountryItemClickListener) contextVIP);
        list_country.setAdapter(listCountryAdapter);
        id_selection_continue.setOnClickListener(v -> {
            selectdocumentLayout.setVisibility(View.GONE);
            document_not_supported_layout.setVisibility(View.VISIBLE);
            updateErrorScreen(false);
        });

        searchCountryEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                list_country.setVisibility(View.VISIBLE);
                layout_countries_search.setBackground(contextVIP.getDrawable(R.drawable.vip_background_layout));
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (listCountryAdapter.getSelectedPosition() != -1) {
                    clearData();
                }

                searchCountryEdt.setSelection(searchCountryEdt.getText().length());
                listCountryAdapter.getFilter().filter(s);
                listCountryAdapter.notifyDataSetChanged();
            }
        });

        searchCountryEdt.setOnEditorActionListener((v, actionId, event) -> {
            //  Context context = getContext();
            if (contextVIP != null && (actionId == EditorInfo.IME_ACTION_DONE || actionId == KeyEvent.KEYCODE_ENTER)) {
                Util_Util.hideKeyBoard(contextVIP, v);
                return true;
            }

            return false;
        });

        listFragment.setVisibility(View.GONE);
        id_selection_document_title.setVisibility(View.GONE);
    }

    public void showIntroFragment(Fragment fragment) {
        if (fragment instanceof Fragment_IDDocument_list) {
            Fragment_IDDocument_list.showMe(this);
        }
    }

    public void hideIntroFragment(Fragment fragment) {
        if (fragment instanceof Fragment_IDDocument_list) {
            Fragment_IDDocument_list.hideMe(this);
        }
    }

    private void clearData() {
        listCountryAdapter.clearSelection();
    }

    public void dismissProgressDialog() {
        if (takingImageDialog != null && takingImageDialog.isShowing()) {
            takingImageDialog.dismiss();
        }
    }

    public void updateErrorScreen(boolean captureID) {
        if (Activities_VideoLiveStreamActivity_Super.this.isDestroyed()) {
            return;
        }
        dismissProgressDialog();
        video_ident_plus_layout.setVisibility(View.GONE);
        video_select_document_layout.setVisibility(View.VISIBLE);
        selectdocumentLayout.setVisibility(View.GONE);
        document_not_supported_layout.setVisibility(View.VISIBLE);

        if (captureID) {
            title_error_layout.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_TITLE));
            description_error_layout.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_DESC, LOCAL_KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_DESC));
            image_error_layout.setAnimation("static_front_back_id_alert.json");
            image_error_layout.playAnimation();
            button_error_layout.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_BUTTON, LOCAL_KEY_VIDEO_IDENT_PLUS_SOMETHING_WRONG_BUTTON));

            button_error_layout.setOnClickListener(v -> {
                imageViewPhoto.setImageBitmap(null);
                try {
                    camera.open();
                } catch (Error error) {
                    Util_Log.e(LOGTAG, "Start camera preview failed", error);
                }
                setRightScreen(DOCUMENT_IMAGES, false);
            });
        } else {
            title_error_layout.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_LISTED_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_LISTED_TITLE));
            description_error_layout.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_LISTED_DESC, LOCAL_KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_LISTED_DESC));

            image_error_layout.setAnimation("static_step_id_scan.json");
            image_error_layout.playAnimation();

            button_error_layout.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_BUTTON, LOCAL_KEY_VIDEO_IDENT_PLUS_COUNTRY_NOT_BUTTON));
            button_error_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    IDnowSDK.getInstance().setStartCallIssued(false);
                    if (contextVIP instanceof Interface_VideoLiveStream) {
                        ((Interface_VideoLiveStream) contextVIP).identificationCanceled();
                    }
                }
            });
        }

    }

    public Boolean deletefilesbydate(File file, long updatedTime) {
        Date today = new Date();
        int diffInDays = (int) ((today.getTime() - updatedTime) / (1000 * 60 * 60 * 24));
        return diffInDays > 7;
    }

    private static byte[] inputToByte(InputStream inputStream) throws IOException {
        ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
        byte[] buff = new byte[1024];
        int rc;
        while ((rc = inputStream.read(buff, 0, 1024)) > 0) {
            swapStream.write(buff, 0, rc);
        }
        byte[] in2b = swapStream.toByteArray();
        return in2b;
    }

    @SuppressLint({"ResourceAsColor", "WrongViewCast", "ResourceType"})
    public void loadInterfaceVideoIdentPlus() {
        contextVIP = this;

        View bottomSheetContentView = getLayoutInflater().inflate(R.layout.view_rerouting, null);
        bottomSheetDialog = new BottomSheetDialog(contextVIP, R.style.bottomSheetDialog);
        bottomSheetDialog.setContentView(bottomSheetContentView);

        cancelRerouting = bottomSheetContentView.findViewById(R.id.cancelRerouting);
        titleRerouting = bottomSheetContentView.findViewById(R.id.titleRerouting);
        descRerouting = bottomSheetContentView.findViewById(R.id.descRerouting);
        continueRerouting = bottomSheetContentView.findViewById(R.id.continueRerouting);
        tryRerouting = bottomSheetContentView.findViewById(R.id.tryRerouting);
        titleRerouting.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REROUTING_TITLE, LOCAL_KEY_VIDEO_IDENT_REROUTING_TITLE));
        descRerouting.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REROUTING_DESC, LOCAL_KEY_VIDEO_IDENT_REROUTING_DESC));
        continueRerouting.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REROUTING_CONTINUE, LOCAL_KEY_VIDEO_IDENT_REROUTING_CONTINUE));
        tryRerouting.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REROUTING_EID, LOCAL_KEY_VIDEO_IDENT_REROUTING_EID));
        tryRerouting.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Util_Util.checkNFCenabled(contextVIP)) {
                    bottomSheetDialog.dismiss();
                    Model_eIDData model_eIDData = new Model_eIDData();
                    model_eIDData.endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
                    model_eIDData.companyID = IDnowSDK.getCompanyId();
                    model_eIDData.transactionToken = IDnowSDK.getTransactionToken();

                    try {
                        eIDSdk.setDarkModeEnabled(DARK_MODE);
                        eIDSdk.getInstance().initialize(Activities_VideoLiveStreamActivity_Super.this);
                        eIDSdk.setIDnowSDKEndpoint(model_eIDData.getEndPoint());
                        eIDSdk.setCompanyId(model_eIDData.getCompanyID());
                        eIDSdk.setTransactionToken(model_eIDData.getTransactionToken());
                        eIDSdk.setAppkey(Config.CUSTOM_LOG_APPKEY);
                        eIDSdk.setAppURL(Config.CUSTOM_LOG_URL);
                        eIDSdk.setEnableEIDQES(Config.ENABLE_QES_EID);
                        eIDSdk.setPhoneNumber(Config.USER_PHONE_NO);
                        eIDSdk.setModels_clientInfoLanguage(Util_Util.getClientInfoLanguage());
                        eIDSdk.setShowTermsConditionsEID(IDnowSDK.isShowTermsConditionsEID(), mContext);
                        eIDSdk.setShowPoweredBy(SHOW_POWERED_BY_KEY);
                        eIDSdk.setShowIDnowLogo(SHOW_IDNOW_LOGO);
                        eIDSdk.setAuthadaStagingUrl(Config.AUTHADA_STAGING_URL);
                        eIDSdk.setAuthadaProductionUrl(Config.AUTHADA_PRODUCTION_URL);
                        eIDSdk.setShowDialogsWithIcon(IDnowSDK.showDialogsWithIcon());
                        if (Config.ENABLE_ID_CAPTURE_EID) {
                            eIDSdk.setEnableIDCaptureEID(true);
                        }
                        if (Config.ENABLE_PIN_CHANGE) {
                            eIDSdk.setChangePinEID(true);
                        }

                        eIDSdk.setStandaloneEID(Config.ENABLE_EID_STANDALONE);

                        if (IDnowSDK.getNewBrand()) {
                            eIDSdk.setNewBrand(true);
                        }
                        eIDSdk.setMessagesfromBackend(Config.MESSAGES);
                    } catch (NoClassDefFoundError error) {
                        Util_Log.e(LOGTAG, "Setup and run eID failed", error);
                        Util_UtilUI.showEIDDialog(contextVIP, "You are trying to perform an identification using the Electronic ID option please contact our support under support@mail.idnow.de");
                    }
                } else {
                    Util_UtilUI.showNoConnectionDialog(contextVIP, false);
                }
            }
        });

        continueRerouting.setOnClickListener(v -> {
            bottomSheetDialog.dismiss();
            setRightScreen(Util_PhotoDataHolder.DocumentImages.idbackside, false);
        });

        cancelRerouting.setOnClickListener(v -> {
            bottomSheetDialog.dismiss();
            setRightScreen(Util_PhotoDataHolder.DocumentImages.idbackside, false);
        });
        video_ident_plus_layout = findViewById(R.id.video_ident_plus_layout);
        Guideline videoIdentPlusLayoutInnerGuideline = video_ident_plus_layout.findViewById(R.id.percent_35_guideline);
        float videoIdentPlusLayoutInnerGuidelinePercent = new ResourceHelper(this).getFloatDimen(R.dimen.conference_screen_steps_container_guide_percent);
        videoIdentPlusLayoutInnerGuideline.setGuidelinePercent(videoIdentPlusLayoutInnerGuidelinePercent);

        video_select_document_layout = findViewById(R.id.video_select_document_layout);
        video_ident_plus_layout_waiting_list = findViewById(R.id.video_ident_plus_layout_waiting_list);
        selectdocumentLayout = findViewById(R.id.selectdocumentLayout);
        document_not_supported_layout = findViewById(R.id.document_not_supported_layout);
        video_ident_steps_layout = findViewById(R.id.video_ident_steps_layout);
        agent_card_normal = findViewById(R.id.agent_card_normal);
        card_vip = findViewById(R.id.card_vip);
        idcard_text_normal = findViewById(R.id.idcard_text_normal);
        idcard_text_normal.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE));

        idcard_text_normal_steps = findViewById(R.id.idcard_text_normal_steps);
        idcard_text_normal_steps.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE));
        video_ident_plus_layout_retry_flow = findViewById(R.id.video_ident_plus_layout_retry_flow);
        agent_steps = findViewById(R.id.agent_steps);
        agent_normal_steps = findViewById(R.id.agent_normal_steps);

        poweredByViewVIP = findViewById(R.id.poweredByViewVIP);
        takePictureLayout = findViewById(R.id.takePictureLayout);
        textDescription = findViewById(R.id.textDescription);
        textSMSCode = findViewById(R.id.textSMSCode);
        retake = findViewById(R.id.retakeImage);

        poweredByViewVIP.setAnimation("static_powered_by_idnow.json");
        poweredByViewVIP.playAnimation();

        retake.setAnimation("static_camera_retake.json");
        retake.playAnimation();

        retakeAction = findViewById(R.id.retakeAction);
        document_front = findViewById(R.id.document_front);
        document_back = findViewById(R.id.document_back);
        document_selfie = findViewById(R.id.document_selfie);
        vip_save_button = findViewById(R.id.vip_save_button);
        retakePhoto_retry = findViewById(R.id.retakePhoto_retry);
        logo_retry_flow = findViewById(R.id.logo_retry_flow);

        check_1 = findViewById(R.id.check_1);
        check_1.setAnimation("static_loading_round.json");
        check_1.playAnimation();
        check_2 = findViewById(R.id.check_2);
        check_2.setAnimation("static_loading_round.json");
        check_2.playAnimation();
        check_3 = findViewById(R.id.check_3);
        check_3.setAnimation("static_loading_round.json");
        check_3.playAnimation();

        vip_document_text_1 = findViewById(R.id.vip_document_text_1);
        vip_document_text_2 = findViewById(R.id.vip_document_text_2);
        vip_document_text_3 = findViewById(R.id.vip_document_text_3);
        vip_document_front = findViewById(R.id.vip_document_front);
        vip_document_back = findViewById(R.id.vip_document_back);
        vip_document_selfie = findViewById(R.id.vip_document_selfie);

//		document_front.setAnimation("static_id_front.json");
        document_front.setAnimation("animate_id_front_hand_zoom.json");
        document_front.playAnimation();

//		document_back.setAnimation("static_id_back.json");
        document_back.setAnimation("animate_id_back_hand_zoom.json");
        document_back.playAnimation();

//		document_selfie.setAnimation("static_selfie_frame.json");
        document_selfie.setAnimation("animate_selfie_blink.json");
        document_selfie.playAnimation();

        reuse_title = findViewById(R.id.reuse_title);
        reuse_desc = findViewById(R.id.reuse_desc);

        vip_document_front.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_FRONTID, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_FRONTID));
        vip_document_back.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_BACKID, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_BACKID));
        vip_document_selfie.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_SELFIE, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_SELFIE));
        retakePhoto_retry.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_TAKE_PHOTOS, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_TAKE_PHOTOS));
        reuse_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_TITLE));
        reuse_desc.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_DESC, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_DESC));
        vip_save_button.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_USE_SAVED_IMAGES, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_USE_SAVED_IMAGES));
        vip_document_text_1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_CHECKING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_CHECKING));
        vip_document_text_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_CHECKING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_CHECKING));
        vip_document_text_3.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_CHECKING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_CHECKING));

        retakeAction.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_IMAGE_RETAKE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_IMAGE_RETAKE));
        requestIdentCodeButton = findViewById(R.id.requestIdentCodeButton);

        if (IDnowSDK.getNewBrand()) {
            requestIdentCodeButton.setBackgroundResource(R.drawable.rounded_background_orange);
            vip_save_button.setBackgroundResource(R.drawable.rounded_background_orange);
        } else {
            requestIdentCodeButton.setBackgroundResource(R.drawable.rounded_background_orange_old);
            vip_save_button.setBackgroundResource(R.drawable.rounded_background_orange_old);
        }
        logo_retry_flow.setAnimation("static_logo.json");

        if (Config.DARK_MODE) {
            Util_UtilUI.setColorLottieAnimation(Color.WHITE, logo_retry_flow, "SecondaryVariant");

        } else {
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, logo_retry_flow, "SecondaryVariant");
        }

        if (IDnowSDK.getShowIDnowLogo()) {
            logo_retry_flow.setVisibility(View.VISIBLE);
        } else {
            logo_retry_flow.setVisibility(View.GONE);
        }

        status_layout = findViewById(R.id.status_layout);

        if (VIDEO_IDENT_PLUS_REUSE_IMAGES) {
            prefs = getApplicationContext().getSharedPreferences("notifications", MODE_PRIVATE);
            Config.RETRY = prefs.getBoolean("receiveNotifications", false);
            Config.SAVED_TOKEN = prefs.getString("receiveToken", "nothing");

            vip_save_button.setVisibility(View.GONE);

            if (filesExist() && Config.RETRY && (IDnowSDK.getTransactionToken().equals(Config.SAVED_TOKEN))) {
                Config.RETRY_UPLOAD = true;
                video_ident_plus_layout.setVisibility(View.GONE);
                video_ident_plus_layout_retry_flow.setVisibility(View.VISIBLE);

                String path;
                File folder;
                if (VIDEO_IDENT_PLUS_REUSE_IMAGES) {
                    path = getFilesDir().toString() + "/IDnow";
                    folder = new File(getFilesDir() + "/IDnow");
                } else {
                    path = getCacheDir().toString() + "/IDnow";
                    folder = new File(getCacheDir() + "/IDnow");
                }
                File[] files = folder.listFiles();
                if (files != null) {
                    for (int i = 0; i < files.length; i++) {
                        if (files[i].getName().contains(Util_PhotoDataHolder.DocumentImages.idfrontside.toString())) {
                            if (deletefilesbydate(files[i], files[i].lastModified())) {
                                deleteFile(files[i].getName());
                                frontfile = null;
                                frontfilename = "";
                            } else {
                                frontfile = new File(path, files[i].getName());
                                frontfilename = files[i].getName();
                            }
                        } else if (files[i].getName().contains(Util_PhotoDataHolder.DocumentImages.idbackside.toString())) {
                            if (deletefilesbydate(files[i], files[i].lastModified())) {
                                deleteFile(files[i].getName());

                                backfile = null;
                                backfilename = "";
                            } else {
                                backfile = new File(path, files[i].getName());
                                backfilename = files[i].getName();
                            }
                        } else if (files[i].getName().contains(Util_PhotoDataHolder.DocumentImages.face.toString())) {
                            if (deletefilesbydate(files[i], files[i].lastModified())) {
                                deleteFile(files[i].getName());

                                selfiefile = null;
                                selfiefilename = "";
                            } else {
                                selfiefile = new File(path, files[i].getName());
                                selfiefilename = files[i].getName();
                            }
                        }

                        if (frontfile != null) {

                            showID(frontfile, idfrontside);
                        } else {
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                public void run() {
                                    check_1.setAnimation("static_error.json");
                                    check_2.setAnimation("static_error.json");
                                    check_3.setAnimation("static_error.json");

                                    check_1.playAnimation();
                                    check_2.playAnimation();
                                    check_3.playAnimation();

                                    vip_document_text_1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_MISSING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_MISSING));
                                    vip_document_text_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_MISSING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_MISSING));
                                    vip_document_text_3.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_MISSING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_MISSING));

                                    backfilename = null;
                                    selfiefile = null;

                                    if (backfilename == null) {
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                check_2.setAnimation("static_error.json");
                                                check_2.playAnimation();
                                                vip_document_text_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_MISSING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_MISSING));
                                                if (selfiefilename == null) {
                                                    Handler handler2 = new Handler();
                                                    handler2.postDelayed(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            check_3.setAnimation("static_error.json");
                                                            check_3.playAnimation();
                                                            vip_document_text_3.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_MISSING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_MISSING));
                                                            vip_save_button.setVisibility(View.GONE);
                                                            retakePhoto_retry.setTextColor(getResources().getColor(R.color.primary));
                                                        }
                                                    }, 2000);
                                                } else {
                                                    //showID(selfiefile,face);
                                                }
                                            }
                                        }, 2000);
                                    } else {
                                        //showID(backfile,face);
                                    }

                                }
                            }, 2000);
                        }
                    }
                } else {
                    video_ident_plus_layout.setVisibility(View.VISIBLE);
                    video_ident_plus_layout_retry_flow.setVisibility(View.GONE);
                }

                if ((frontfile == null) && (backfile == null) && (selfiefile == null)) {
                    vip_save_button.setVisibility(View.GONE);
                }

                vip_save_button.setOnClickListener(view -> {
                    if ((frontfile != null) && (backfile != null) && (selfiefile != null)) {
                        reuseflowAction();
                    } else {
                        Util_UtilUI.showRetryRequest(contextVIP);
                    }
                });

                retakePhoto_retry.setOnClickListener(view -> {
                    Config.RETRY_UPLOAD = false;
                    Config.ONLY_BACK_SIDE_NULL = false;
                    Util_Util.deleteCache(contextVIP);
                    video_ident_plus_layout.setVisibility(View.VISIBLE);
                    video_ident_plus_layout_retry_flow.setVisibility(View.GONE);
                });

            } else {
                Config.RETRY_UPLOAD = false;
                Util_Util.deleteCache(this);
            }
        }

        video_ident_plus_layout.setVisibility(View.VISIBLE);

        if (IDnowSDK.getShowPoweredBy()) {
            poweredByViewVIP.setVisibility(View.VISIBLE);
        } else {
            poweredByViewVIP.setVisibility(View.GONE);
        }

        if (video_ident_plus_layout.getVisibility() == View.VISIBLE) {

            video_ident_plus = findViewById(R.id.video_ident_plus);
            cameraCutoutOverlay = findViewById(R.id.cameraCutout);
            imageViewPhoto = findViewById(R.id.imageViewPhoto);
            relativeLayoutScreen = findViewById(R.id.takePhotoLayoutScreen);
            cameraPreview = findViewById(R.id.cameraPreview);
            cameraPreview.setFocusable(true);
            cameraPreview.setFocusableInTouchMode(true);
            camera = new IDnowCamera(this, this, cameraPreview);
            circleCheck1 = findViewById(R.id.circleCheck1);
            circleCheck2 = findViewById(R.id.circleCheck2);
            circleCheck3 = findViewById(R.id.circleCheck3);
            circleCheck1_steps = findViewById(R.id.circleCheck1_steps);
            circleCheck2_steps = findViewById(R.id.circleCheck2_steps);
            circleCheck3_steps = findViewById(R.id.circleCheck3_steps);

            circleCheck1.setAnimation("static_checkbox_round.json");
            Util_UtilUI.setColorLottieAnimation(Color.parseColor("#00B140"), circleCheck1, "Success");
            circleCheck1.playAnimation();
            circleCheck2.setAnimation("static_checkbox_round.json");
            Util_UtilUI.setColorLottieAnimation(Color.parseColor("#00B140"), circleCheck2, "Success");

            circleCheck2.playAnimation();
            circleCheck3.setAnimation("static_checkbox_round.json");
            Util_UtilUI.setColorLottieAnimation(Color.parseColor("#00B140"), circleCheck3, "Success");

            circleCheck3.playAnimation();
            circleCheck1_steps.setAnimation("static_checkbox_round.json");
            Util_UtilUI.setColorLottieAnimation(Color.parseColor("#00B140"), circleCheck1_steps, "Success");

            circleCheck1_steps.playAnimation();
            circleCheck2_steps.setAnimation("static_checkbox_round.json");
            Util_UtilUI.setColorLottieAnimation(Color.parseColor("#00B140"), circleCheck2_steps, "Success");

            circleCheck2_steps.playAnimation();
            circleCheck3_steps.setAnimation("static_checkbox_round.json");
            Util_UtilUI.setColorLottieAnimation(Color.parseColor("#00B140"), circleCheck3_steps, "Success");

            circleCheck3_steps.playAnimation();

            num_text = findViewById(R.id.num_text);
            idcard_text = findViewById(R.id.idcard_text);
            mainTextDescription = findViewById(R.id.mainTextDescription);
            num_text_steps = findViewById(R.id.num_text_steps);
            idcard_text_steps = findViewById(R.id.idcard_text_steps);

            idcard_text_steps.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE));
            num_text.setText("1");

            circle1 = findViewById(R.id.circle1);
            circle2 = findViewById(R.id.circle2);
            circle3 = findViewById(R.id.circle3);
            circle4 = findViewById(R.id.circle4);

            if (!Config.VIDEO_IDENT_PLUS_SELFIE_IMAGE) {
                circle4.setVisibility(View.GONE);

                if (Config.DOCUMENT_TYPES == Util_PhotoDataHolder.DocumentTypes.passport) {
                    num_text.setText("2");
                } else {
                    num_text.setText("3");
                }
                circleCheck3_steps.setVisibility(View.GONE);
            }

            layoutAction_1 = findViewById(R.id.layoutAction_1);
            layoutAction_2 = findViewById(R.id.layoutAction_2);

            continueButton = findViewById(R.id.continueButton);
            continueButton.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_IMAGE_CONTINUE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_IMAGE_CONTINUE));

            if (IDnowSDK.getNewBrand()) {
                continueButton.setBackgroundResource(R.drawable.rounded_background_orange);
            } else {
                continueButton.setBackgroundResource(R.drawable.vip_button_steps_enable);
            }

            takePictureButton = findViewById(R.id.takePictureButton);
            retakeButton = findViewById(R.id.retakeButton);
            takePictureButton.setAnimation("static_camera_button.json");
            Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.primaryColor)), takePictureButton, "Primary");
            takePictureButton.setAlpha(0.8f);
            if (IDnowSDK.getNewBrand()) {
                retakeButton.setBackgroundResource(R.drawable.rounded_background_white);
            } else {
                retakeButton.setBackgroundResource(R.drawable.vip_button_steps_disable);
            }

            if (Config.VIDEO_IDENT_PLUS && Config.VIDEO_IDENT_PLUS_IDImage) {
                DOCUMENT_IMAGES = Util_PhotoDataHolder.DocumentImages.idfrontside;
                setRightScreen(Util_PhotoDataHolder.DocumentImages.idfrontside, TAKE_PICTURE_LAYOUT);
            } else if ((Config.VIDEO_IDENT_PLUS) && (Config.VIDEO_IDENT_PLUS_UI)) {
                DOCUMENT_IMAGES = Util_PhotoDataHolder.DocumentImages.agent;
                if (!(contextVIP instanceof Activities_AgentFeedbackActivity && Config.ENABLE_AGENT_FEEDBACK)) {
                    setRightScreen(Util_PhotoDataHolder.DocumentImages.agent, TAKE_PICTURE_LAYOUT);
                }
            }
        } else if (selectdocumentLayout.getVisibility() == View.VISIBLE) {

        }

    }

    public void reuseflowAction() {
        Config.CHECK_UPLOAP = true;
        Config.ALL_PHOTO_USED = true;
        takingImageDialog = setProgressDialog(takingImageDialog);

        if (Config.CHECK_UPLOAP) {

            if (frontfile != null && backfile != null && selfiefile != null) {
                Config.MISSING_IMAGES = 0;
            } else if (frontfile != null && backfile == null && selfiefile == null) {
                Config.MISSING_IMAGES = 2;
            } else if ((frontfile != null) && (backfile != null || selfiefile != null)) {
                Config.MISSING_IMAGES = 1;
            }
            byte[] imageStringToPush = ImageHelper.INSTANCE.readAsBase64(frontfilename, 90 );
            videoLiveStreamManager.sendUploadPhotoRESTCall(this, Activities_VideoLiveStreamActivity_Super.this, imageStringToPush, idfrontside, classificationCallback);
        }
    }

    private void showID(File file, Util_PhotoDataHolder.DocumentImages documentImages) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                Bitmap b = null;
                try {
                    b = BitmapFactory.decodeStream(new FileInputStream(file));
                } catch (FileNotFoundException e) {
                    Util_Log.e(LOGTAG, "Show ID failed", e);
                }

                if (documentImages.equals(idfrontside)) {
                    scaleImage(b, document_front);
                    document_front.playAnimation();
                    check_1.setAnimation("static_checkbox_round.json");
                    check_1.playAnimation();
                    vip_document_text_1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_DONE, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_DONE));
                    if (backfile != null) {
                        showID(backfile, idbackside);
                    } else {
                        if (selfiefile != null) {
                            check_2.setAnimation("static_error.json");
                            check_2.playAnimation();
                            vip_document_text_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_MISSING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_MISSING));

                            showID(selfiefile, face);
                            Config.ONLY_BACK_SIDE_NULL = true;
                        } else {
                            vip_document_text_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_MISSING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_MISSING));
                            vip_document_text_3.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_MISSING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_MISSING));
                            check_2.setAnimation("static_error.json");
                            check_2.playAnimation();
                            check_3.setAnimation("static_error.json");
                            check_3.playAnimation();
                            vip_save_button.setVisibility(View.VISIBLE);
                            retakePhoto_retry.setTextColor(getResources().getColor(R.color.primaryColor));
                        }
                    }
                } else if (documentImages.equals(idbackside)) {
                    scaleImage(b, document_back);
                    document_back.playAnimation();
                    check_2.setAnimation("static_checkbox_round.json");
                    check_2.playAnimation();

                    vip_document_text_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_DONE, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_DONE));
                    if (selfiefile != null) {
                        showID(selfiefile, face);
                    } else {
                        vip_document_text_3.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_MISSING, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_MISSING));
                        check_3.setAnimation("static_error.json");
                        check_3.playAnimation();
                        vip_save_button.setVisibility(View.VISIBLE);
                        retakePhoto_retry.setTextColor(getResources().getColor(R.color.primaryColor));
                    }
                } else if (documentImages.equals(face)) {
                    scaleImage(b, document_selfie);
                    document_selfie.playAnimation();
                    check_3.setAnimation("static_checkbox_round.json");
                    check_3.playAnimation();
                    vip_document_text_3.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_REUSE_DONE, LOCAL_KEY_VIDEO_IDENT_PLUS_REUSE_DONE));
                    vip_save_button.setVisibility(View.VISIBLE);
                    retakePhoto_retry.setTextColor(getResources().getColor(R.color.primaryColor));
                }
            }
        }, 2000);
    }

    private void scaleImage(Bitmap bitmap, ImageView view) throws NoSuchElementException {

        int viewWidth = view.getWidth();
        int viewHeight = view.getHeight();

        // Get current dimensions AND the desired bounding box
        int width = 0;
        try {
            width = bitmap.getWidth();
        } catch (NullPointerException e) {
            throw new NoSuchElementException("Can't find bitmap on given view/drawable");
        }

        int height = bitmap.getHeight();
        int bounding = dpToPx(250);
        Util_Log.i("Test", "original width = " + width);
        Util_Log.i("Test", "original height = " + height);
        Util_Log.i("Test", "bounding = " + bounding);

        // Determine how much to scale: the dimension requiring less scaling is
        // closer to the its side. This way the image always stays inside your
        // bounding box AND either x/y axis touches it.
        float xScale = ((float) bounding) / width;
        float yScale = ((float) bounding) / height;
        float scale = (xScale <= yScale) ? xScale : yScale;
        Util_Log.i("Test", "xScale = " + xScale);
        Util_Log.i("Test", "yScale = " + yScale);
        Util_Log.i("Test", "scale = " + scale);

        // Create a matrix for the scaling and add the scaling data
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);

        // Create a new bitmap and convert it to a format understood by the ImageView
        Bitmap scaledBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
        width = scaledBitmap.getWidth(); // re-use
        height = scaledBitmap.getHeight(); // re-use
        BitmapDrawable result = new BitmapDrawable(scaledBitmap);
        Util_Log.i("Test", "scaled width = " + width);
        Util_Log.i("Test", "scaled height = " + height);

        // Apply the scaled bitmap
        //view.setBackground(result);
        view.setImageDrawable(result);
        view.setScaleType(ImageView.ScaleType.FIT_XY);

        view.setAdjustViewBounds(true);

        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) view.getLayoutParams();
        params.width = viewWidth;
        params.height = viewHeight;
        view.setLayoutParams(params);

        Util_Log.i("Test", "done");
    }

    private int dpToPx(int dp) {
        float density = getApplicationContext().getResources().getDisplayMetrics().density;
        return Math.round((float) dp * density);
    }

    public void loadWaitingScreenVideoIdentPlus() {
        isAgentView = true;
        if (Config.VIDEO_IDENT_PLUS_UI) {
            card_vip.setVisibility(View.GONE);
            agent_card_normal.setVisibility(View.VISIBLE);
            textDescription.setVisibility(View.GONE);
        } else {
            card_vip.setVisibility(View.VISIBLE);
            agent_card_normal.setVisibility(View.GONE);
        }

        vip_ok_waiting_list = findViewById(R.id.vip_ok_waiting_list);
        vip_cancel_waiting_list = findViewById(R.id.vip_witinglist_text_cancel);
        waiting_time_layout = findViewById(R.id.waiting_time_layout);
        animationWL = findViewById(R.id.animationWL);
        animationWL.playAnimation();
        animationWL.setAnimation("static_step_id_scan.json");

        waiting_list_vip_title = findViewById(R.id.waiting_list_vip_title);
        vip_witinglist_text_1 = findViewById(R.id.vip_witinglist_text_1);
        vip_witinglist_text_2 = findViewById(R.id.vip_witinglist_text_2);
        vip_witinglist_time = findViewById(R.id.vip_witinglist_time);
        vip_witinglist_text_3 = findViewById(R.id.vip_witinglist_text_3);
        vip_witinglist_text_4 = findViewById(R.id.vip_witinglist_text_4);
        vip_witinglist_text_cancel = findViewById(R.id.vip_witinglist_text_cancel);

        if (IDnowSDK.getNewBrand()) {
            vip_ok_waiting_list.setBackgroundResource(R.drawable.rounded_background_orange);
        } else {
            vip_ok_waiting_list.setBackgroundResource(R.drawable.rounded_button_orange);
        }

        waiting_list_vip_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_TITLE));
        vip_witinglist_text_1.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC1, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC1));
        vip_witinglist_text_2.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC2, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC2));
        vip_witinglist_text_3.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC3, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC3));
        vip_witinglist_text_4.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC4, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC4));
        vip_witinglist_text_cancel.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_CANCEL, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_CANCEL));
        vip_ok_waiting_list.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_BUTTON, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_BUTTON));
        mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC2, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC2));
        layoutAction_1.setVisibility(View.VISIBLE);
        layoutAction_2.setVisibility(View.GONE);
        retake.setVisibility(View.GONE);
        retakeAction.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_NO, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_NO));
        retakeButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Util_CustomLogData.setEventData(EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_CROSS_BTN, "EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_CROSS_BTN", "Waiting list (Push notification)", "Button click events", null);
                Util_Log.d("COUNTLY LOG", "EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_CROSS_BTN");

                mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC3, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC3));

                layoutAction_1.setVisibility(View.GONE);
                layoutAction_2.setVisibility(View.GONE);
            }
        });

        continueButton.setOnClickListener(v -> {
            Util_CustomLogData.setEventData(Util_CustomLogData.EVENT_WAITING_LIST_PUSH_SUCCESS_SCREEN_SHOWN, "EVENT_WAITING_LIST_PUSH_SUCCESS_SCREEN_SHOWN", "Waiting list (Push notification)", "Screen", null);
            Util_Log.d("COUNTLY LOG", "EVENT_WAITING_LIST_PUSH_SUCCESS_SCREEN_SHOWN");

            video_ident_plus_layout.setVisibility(View.GONE);
            video_select_document_layout.setVisibility(View.GONE);
            video_ident_plus_layout_waiting_list.setVisibility(View.VISIBLE);

            if (Config.IDENT_ESTIMATED_WAITING_TIME < 0) {
                waiting_time_layout.setVisibility(View.GONE);
            } else {
                vip_witinglist_time.setText(Integer.toString(Config.IDENT_ESTIMATED_WAITING_TIME));
            }

            vip_ok_waiting_list.setOnClickListener(v1 -> {
                prefs = getApplicationContext().getSharedPreferences("waiting", MODE_PRIVATE);
                editor = prefs.edit();
                Config.WAITING_DONE = true;
                Config.SAVED_TOKEN = IDnowSDK.getTransactionToken();
                editor.putBoolean("receiveWaiting", Config.WAITING_DONE).apply();
                editor.putString("receiveToken", Config.SAVED_TOKEN).apply();

                videoLiveStreamManager.enrollForWaitingListNotifications(IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken(), null, enrollWaitingListCallback);
            });

            vip_witinglist_text_cancel.setOnClickListener(v12 -> {
                Util_CustomLogData.setEventData(EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_CROSS_BTN, "EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_CROSS_BTN", "Waiting list (Push notification)", "Button click events", null);
                Util_Log.d("COUNTLY LOG", "EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_CROSS_BTN");

                video_ident_plus_layout_waiting_list.setVisibility(View.GONE);
                video_ident_plus_layout.setVisibility(View.VISIBLE);
                video_select_document_layout.setVisibility(View.GONE);
                mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC3, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC3));
                layoutAction_1.setVisibility(View.GONE);
                layoutAction_2.setVisibility(View.GONE);
            });
        });
    }

    protected void setTakePictureLayoutVisibility(int visibility, boolean requestRestore) {
        takePictureLayout.setVisibility(visibility);
        shouldRestoreTakePictureLayout = requestRestore;
    }

    protected void setVideoIdentStepsLayoutVisibility(int visibility, boolean requestRestore) {
        video_ident_steps_layout.setVisibility(visibility);
        shouldRestoreVideoIdentStepsLayout = requestRestore;
    }

    public void setRequestScreenVisible(Boolean visible) {

        if (visible) {
            setVideoIdentStepsLayoutVisibility(View.GONE, false);
            if (isInPictureInPictureMode()) {
                setTakePictureLayoutVisibility(View.GONE, true);
            } else {
                setTakePictureLayoutVisibility(View.VISIBLE, false);
            }

            textDescription.setVisibility(View.GONE);
            textSMSCode.setVisibility(View.VISIBLE);
            layoutAction_1.setVisibility(View.GONE);
            layoutAction_2.setVisibility(View.GONE);
            requestIdentCodeButton.setVisibility(View.VISIBLE);
            retake.setVisibility(View.GONE);

            if (!Config.IDENT_CODE_BY_SMS && Config.IDENT_CODE_BY_EMAIL) {
                textSMSCode.setHint(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_TITLE, LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_EMAIL_TITLE));
                textSMSCode.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);

                mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC4_EMAIL, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC4_EMAIL));

                if (Config.HIDE_USERS_PII_DATA && Config.MASKED_EMAIL_ADDRESS != null) {
                    manageEditText(textSMSCode, "EMAIL");
                } else {
                    textSMSCode.setText(Config.EMAIL_ADDRESS);
                }

                textSMSCode.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
            } else {

                textSMSCode.setInputType(InputType.TYPE_CLASS_PHONE);
                textSMSCode.setHint(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_TITLE, LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_TITLE));

                mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC4, LOCAL_KEY_VIDEO_IDENT_MOBILE_CONSENT_CHECK_PHONE_NUMBER_TITLE));

                if (Config.HIDE_USERS_PII_DATA && !Config.MASKED_USER_PHONE_NO.equals("")) {
                    textSMSCode.clearFocus();
                    manageEditText(textSMSCode, "PHONE");
                } else {
                    textSMSCode.setText(Config.USER_PHONE_NO);
                }
                setTextSMSCodeEditable(!Config.MOBILE_NUMBER_CHANGE_DISABLED);
            }

            textSMSCode.setBackgroundResource(R.drawable.background_rounded_border);


            requestIdentCodeButton.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_BUTTON_REQUEST, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_BUTTON_REQUEST));

            requestIdentCodeButton.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (textSMSCode != null && !textSMSCode.getText().toString().contains("***")) {
                        Config.USER_PHONE_NO = textSMSCode.getText().toString();
                    }

                    if (textSMSCode != null && !textSMSCode.getText().toString().contains("***") && textSMSCode.getText().toString().contains("@")) {
                        Config.EMAIL_ADDRESS = textSMSCode.getText().toString();
                    }

                    insertEmailEditText.setText(Config.EMAIL_ADDRESS);

                    if (Config.IDENT_CODE_BY_EMAIL) {
                        receiveTanByEmail = true;
                    }

                    if (!receiveTanByEmail && Config.IDENT_CODE_BY_SMS &&
                            Util_UtilUI.isEditTextEmpty(textSMSCode, true,
                                    Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REQUIRED_FIELD, LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD))) {
                    } else if (receiveTanByEmail && Config.IDENT_CODE_BY_EMAIL &&
                            Util_UtilUI.isEditTextEmpty(textSMSCode, true,
                                    Util_Strings.getStringWithDefault(getApplicationContext(), KEY_EMAIL_FORMAT, LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD))) {
                    } else {
                        if (SystemClock.elapsedRealtime() - lastClickTime < 2000) {
                            Util_Log.i(LOGTAG, "clicked too fast");
                        } else {
                            Util_Util.hideSoftKeyboard(Activities_VideoLiveStreamActivity_Super.this);
                            sendIdentCodeToPhoneRESTCall();
                        }

                        lastClickTime = SystemClock.elapsedRealtime();
                    }
                }
            });

        } else {


            if (!Config.VIDEO_IDENT_PLUS_UI) {

                video_ident_steps_layout.setVisibility(View.VISIBLE);
                circle1.setVisibility(View.VISIBLE);
                circle2.setVisibility(View.VISIBLE);

                if (!Config.VIDEO_IDENT_PLUS_SELFIE_IMAGE) {
                    circleCheck3_steps.setVisibility(View.GONE);
                    if (Config.DOCUMENT_TYPES == Util_PhotoDataHolder.DocumentTypes.passport) {
                        num_text.setText("2");
                    } else {
                        num_text.setText("3");
                    }
                }

                takePictureLayout.setVisibility(View.GONE);

            } else {

                video_ident_steps_layout.setVisibility(View.GONE);

                takePictureLayout.setVisibility(View.VISIBLE);

                mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_IDENT_COMPELTED, LOCAL_KEY_VIDEO_IDENT_PLUS_IDENT_COMPELTED));
                textDescription.setVisibility(View.VISIBLE);
                mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_IDENT_BEING_WAIT, LOCAL_KEY_VIDEO_IDENT_PLUS_IDENT_BEING_WAIT));


            }

        }
    }

    private void setTextSMSCodeEditable(boolean state){
        textSMSCode.setFocusable(state);
        textSMSCode.setFocusableInTouchMode(state);
        textSMSCode.setClickable(state);
        textSMSCode.setLongClickable(state);
    }

    private void manageEditText(EditText editTextField, String s) {
        if (Config.HIDE_USERS_PII_DATA && !Config.MASKED_USER_PHONE_NO.equals("") && s.equals("PHONE")) {
            editTextField.setText(Config.MASKED_USER_PHONE_NO);
        }

        if (Config.HIDE_USERS_PII_DATA && !Config.MASKED_EMAIL_ADDRESS.equals("") && s.equals("EMAIL")) {
            editTextField.setText(Config.MASKED_EMAIL_ADDRESS);
        }


		/*editTextField.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View view, MotionEvent motionEvent) {
				if(s.equals("EMAIL")){
					codeByEmailContainer.performClick();
					receiveTanByEmail = true;
				}
				else if(s.equals("PHONE")){
					codeByEmailContainer.performClick();
					receiveTanByEmail = false;
				}
				return false;
			}
		});*/

        editTextField.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextField.setEnabled(true);

            }
        });

        editTextField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (Config.HIDE_USERS_PII_DATA) {
                    if (editTextField.getText().toString().contains("***") && b) {
                        editTextField.setText("");
                    } else if (!b && editTextField.getText().toString().equals("")) {
                        if (s.equals("EMAIL")) {
                            editTextField.setText((Config.MASKED_EMAIL_ADDRESS));
                            Config.EMAIL_ADDRESS_WALLET = Config.EMAIL_ADDRESS;
                        } else if (s.equals("PHONE")) {
                            editTextField.setText((Config.MASKED_USER_PHONE_NO));
                            Config.USER_PHONE_NO_WALLET = Config.USER_PHONE_NO;
                        }
                    }
                }


				/*	if(b&&editTextField.getText().toString().contains("***")&&(s.equals("PHONE")||s.equals("EMAIL"))){
						editTextField.getText().clear();
					}
					else {
						if(!b&&editTextField.getText().toString().equals("")&&s.equals("PHONE")) {

							if(Config.MASKED_USER_PHONE_NO!=null){
								editTextField.setText(Config.MASKED_USER_PHONE_NO);
							}

							Config.USER_PHONE_NO_WALLET = Config.USER_PHONE_NO;

						}
					if(!b&&editTextField.getText().toString().equals("")&&s.equals("EMAIL")) {

						editTextField.setText(Config.EMAIL_ADDRESS);

						Config.EMAIL_ADDRESS_WALLET = Config.EMAIL_ADDRESS;

					}
					}*/
            }
        });

        editTextField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }

    private void setCameraCutoutOverlayType(CameraCutoutOverlayType type) {
        cameraCutoutOverlay.setType(type);
        if (type == CameraCutoutOverlayType.Document) {
            cameraCutoutOverlay.updateMargins(0.1F, 0.3F, 0.04F, 0.04F);
        } else {
            cameraCutoutOverlay.updateMargins(0.115F, 0.45F, 0.1F, 0.1F);
        }
        cameraCutoutOverlay.setVisibility(View.VISIBLE);
    }

    public void setRightScreen(Util_PhotoDataHolder.DocumentImages rightScreen, boolean b) {

        if (Activities_VideoLiveStreamActivity_Super.this.isDestroyed()) {
            return;
        }
        dismissProgressDialog();

        video_ident_plus_layout.setVisibility(View.VISIBLE);
//		video_ident_plus.setBackgroundResource(R.drawable.vip_bg_card);
        video_select_document_layout.setVisibility(View.GONE);

        if (rightScreen.equals(Util_PhotoDataHolder.DocumentImages.idfrontside)) {
            num_text.setText("1");
            circleCheck1.setVisibility(View.GONE);
            circleCheck2.setVisibility(View.GONE);
            circleCheck3.setVisibility(View.GONE);
            circle1.setVisibility(View.GONE);
            circle2.setVisibility(View.VISIBLE);
            circle3.setVisibility(View.VISIBLE);
            if (!Config.VIDEO_IDENT_PLUS_SELFIE_IMAGE) {
                circle4.setVisibility(View.GONE);
            } else {
                circle4.setVisibility(View.VISIBLE);
            }

//			video_ident_plus.setBackgroundResource(R.drawable.frame_53);
            idcard_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_TITLE));
            mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_DESC, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_DESC));
            takePictureButton.setEnabled(false);

            Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.primaryVariantColor)), takePictureButton, "Primary");
            takePictureButton.setAlpha(0.5f);

            setCameraCutoutOverlayType(CameraCutoutOverlayType.Document);
            cameraCutoutOverlay.setAnimation("animate_id_front_hand_zoom.json", 1.085F);
            cameraCutoutOverlay.playAnimation(() -> {
                Util_Log.d("Animation:", "end");
//					video_ident_plus.setBackgroundResource(R.drawable.vip_bg_card);
                takePictureButton.setEnabled(true);

                // TODO change color
                Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.primaryColor)), takePictureButton, "Primary");
                takePictureButton.setAlpha(1f);
                return null;
            });
            setRightLayout(rightScreen, b);
        } else if (rightScreen.equals(Util_PhotoDataHolder.DocumentImages.idbackside)) {
            imageViewPhoto.setImageBitmap(null);

            try {
                camera.open(CameraType.BACK);
            } catch (Error error) {
                Util_Log.e(LOGTAG, "Start camera preview failed", error);
            }

            circleCheck1.setVisibility(View.VISIBLE);
            circleCheck2.setVisibility(View.GONE);
            circleCheck3.setVisibility(View.GONE);

            circle1.setVisibility(View.GONE);
            circle2.setVisibility(View.GONE);
            circle3.setVisibility(View.VISIBLE);
            if (!Config.VIDEO_IDENT_PLUS_SELFIE_IMAGE) {
                circle4.setVisibility(View.GONE);
            } else {
                circle4.setVisibility(View.VISIBLE);
            }

            num_text.setText("2");
//			video_ident_plus.setBackgroundResource(R.drawable.frame_54);

            idcard_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_BACK_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_BACK_TITLE));
            mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_BACK_DESC, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_BACK_DESC));
            takePictureButton.setEnabled(false);

            Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.primaryVariantColor)), takePictureButton, "Primary");
            takePictureButton.setAlpha(0.5f);

            setCameraCutoutOverlayType(CameraCutoutOverlayType.Document);
            cameraCutoutOverlay.setAnimation("animate_id_back_hand_zoom.json", 1.085F);
            cameraCutoutOverlay.playAnimation(() -> {
                Util_Log.d("Animation:", "end");
//					video_ident_plus.setBackgroundResource(R.drawable.vip_bg_card);
                takePictureButton.setEnabled(true);

                // TODO change color
                Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.primaryColor)), takePictureButton, "Primary");
                takePictureButton.setAlpha(1f);
                return null;
            });
            setRightLayout(rightScreen, b);
        } else if (rightScreen.equals(Util_PhotoDataHolder.DocumentImages.face)) {
            imageViewPhoto.setImageBitmap(null);
            circleCheck1.setVisibility(View.VISIBLE);
            circleCheck2.setVisibility(View.VISIBLE);
            circleCheck3.setVisibility(View.GONE);

            circle1.setVisibility(View.GONE);
            circle2.setVisibility(View.GONE);
            circle3.setVisibility(View.GONE);
            circle4.setVisibility(View.VISIBLE);

            num_text.setText("3");
//			video_ident_plus.setBackgroundResource(R.drawable.bg_selfie_pre);

            idcard_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_TITLE));
            mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_DESC1, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_DESC1));
            takePictureButton.setEnabled(false);

            Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.primaryVariantColor)), takePictureButton, "Primary");
            takePictureButton.setAlpha(0.5f);

            setCameraCutoutOverlayType(CameraCutoutOverlayType.Selfie);
            float selfieBlinkScale = new ResourceHelper(this).getFloatDimen(R.dimen.conference_screen_selfie_animation_scale);
            cameraCutoutOverlay.setAnimation("animate_selfie_blink.json", selfieBlinkScale);
            cameraCutoutOverlay.playAnimation(() -> {
                Util_Log.d("Animation:", "end");
//					video_ident_plus.setBackgroundResource(R.drawable.bg_selfie);
                takePictureButton.setEnabled(true);

                // TODO change color
                Util_UtilUI.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.primaryColor)), takePictureButton, "Primary");
                takePictureButton.setAlpha(1f);
                return null;
            });

            setRightLayout(rightScreen, b);
        } else if (rightScreen.equals(Util_PhotoDataHolder.DocumentImages.agent)) {
            isAgentView = true;
            Util_CustomLogData.setEventData(EVENT_WAITING_FOR_AN_AGENT_SCREEN_SHOWN, "EVENT_WAITING_FOR_AN_AGENT_SCREEN_SHOWN", "Waiting for an agent", "Screen", null);
            if (Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED) {
                loadWaitingAnimation();
                if (!(contextVIP instanceof Activities_AgentFeedbackActivity || mContext instanceof Activities_AgentFeedbackActivity)) {
                    waitingSheetDialog.show();
                }
            }
            takePictureButton.setVisibility(View.GONE);
            VIDEO_IDENT_AGENT_FLOW = true;

            if (Config.VIDEO_IDENT_PLUS_UI) {
                camera.close();
//				video_ident_plus.setBackgroundColor(0x00000000);
                cameraCutoutOverlay.setVisibility(View.GONE);
                mainlayout.setBackgroundColor(0x00000000);

                mainlayout.setVisibility(View.VISIBLE);
                mPublisherViewContainer.setVisibility(View.VISIBLE);
                progressBarLoading.setVisibility(View.GONE);
                poweredByView.setVisibility(View.GONE);
                agentSide.setVisibility(View.VISIBLE);

                if (contextVIP instanceof Activities_VideoLiveStreamActivity_LIVESWITCH) {
                    ((Activities_VideoLiveStreamActivity_LIVESWITCH) contextVIP).LiveswitchCalled();
                }
                agent_card_normal.setVisibility(View.VISIBLE);
                card_vip.setVisibility(View.GONE);
                layoutAction_1.setVisibility(View.GONE);
                textDescription.setVisibility(View.GONE);

                idcard_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE));
                idcard_text_normal_steps.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE));
                mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC1, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC1));
                textDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_LABEL_WAITING_FOR_AGENT, LOCAL_LABEL_WAITING_FOR_AGENT));

                prefs = getApplicationContext().getSharedPreferences("waiting", MODE_PRIVATE);
                Config.WAITING_DONE = prefs.getBoolean("receiveWaiting", false);
                Config.SAVED_TOKEN = prefs.getString("receiveToken", "nothing");

                if (Config.WAITING_LIST_NOTIFICATIONS_ENABLED && (!Config.WAITING_DONE || !(IDnowSDK.getTransactionToken().equals(Config.SAVED_TOKEN)))) {
                    mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC1, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC1));
                    boolean timerElapsed = (System.currentTimeMillis() - (1000 * Config.WAITING_LIST_NOTIFICATIONS_TIMEOUT)) >= timer;

                    if (Config.WAITING_LIST_NOTIFICATIONS_ENABLED &&
                            !Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE &&
                            (Config.FIREBASE_NOTIFICATION_TOKEN != null || Config.WAITING_LIST_NOTIFICATIONS_CHANNEL.equals("SMS")) &&
                            !conferenceStarted || IDnowSDK.isForcedWaitingList()) {

                        if (timerElapsed || (Config.IDENT_POSITION_IN_QUEUE >= Config.WAITING_LIST_NOTIFICATIONS_TRESHOLD) || IDnowSDK.isForcedWaitingList()) {
                            Util_Log.i(LOGTAG, "Push notification panel opened.");
                            Config.SCREEN = "WAITING SCREEN";
                            Util_Log.d("COUNTLY LOG", "EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_SHOWN");

                            isAgentView = true;
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    loadWaitingScreenVideoIdentPlus();
                                    Util_CustomLogData.setEventData(EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_SHOWN, "EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_SHOWN", "Waiting list (Push notification)", "Screen", null);
                                }
                            }, Config.WAITING_LIST_NOTIFICATIONS_TIMEOUT * 1000);
                        }
                    }
                } else {
                    String mainText = Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC3, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC3);
                    mainTextDescription.setText(mainText);
                }
            } else {
                camera.close();
//				video_ident_plus.setBackgroundColor(0x00000000);
                cameraCutoutOverlay.setVisibility(View.GONE);
                mainlayout.setBackgroundColor(0x00000000);

                mainlayout.setVisibility(View.VISIBLE);
                mPublisherViewContainer.setVisibility(View.VISIBLE);
                progressBarLoading.setVisibility(View.GONE);
                poweredByView.setVisibility(View.GONE);
                agentSide.setVisibility(View.VISIBLE);
                //subscriberContainer.setBackgroundResource(R.drawable.bg_agent);

                if (contextVIP instanceof Activities_VideoLiveStreamActivity_LIVESWITCH) {
                    ((Activities_VideoLiveStreamActivity_LIVESWITCH) contextVIP).LiveswitchCalled();
                }
                circleCheck1.setVisibility(View.VISIBLE);
                circleCheck2.setVisibility(View.VISIBLE);
                if (!Config.VIDEO_IDENT_PLUS_SELFIE_IMAGE) {
                    circleCheck3.setVisibility(View.GONE);
                } else {
                    circleCheck3.setVisibility(View.VISIBLE);
                }

                circle1.setVisibility(View.GONE);
                circle2.setVisibility(View.GONE);
                circle3.setVisibility(View.GONE);
                circle4.setVisibility(View.GONE);

                if (!Config.VIDEO_IDENT_PLUS_SELFIE_IMAGE) {
                    if (Config.DOCUMENT_TYPES == Util_PhotoDataHolder.DocumentTypes.passport) {
                        num_text.setText("2");
                        num_text_steps.setText("2");
                    } else {
                        num_text.setText("3");
                        num_text_steps.setText("3");
                    }
                } else {
                    if ((Config.DOCUMENT_TYPES == Util_PhotoDataHolder.DocumentTypes.passport)) {
                        num_text.setText("3");
                        num_text_steps.setText("3");
                    } else {
                        num_text.setText("4");
                        num_text_steps.setText("4");
                    }
                }

                idcard_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_TITLE));
                prefs = getApplicationContext().getSharedPreferences("waiting", MODE_PRIVATE);
                Config.WAITING_DONE = prefs.getBoolean("receiveWaiting", false);
                Config.SAVED_TOKEN = prefs.getString("receiveToken", "nothing");

                if (Config.WAITING_LIST_NOTIFICATIONS_ENABLED && (!Config.WAITING_DONE || !(IDnowSDK.getTransactionToken().equals(Config.SAVED_TOKEN)))) {
                    mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC1, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC1));
                    boolean timerElapsed = (System.currentTimeMillis() - (1000 * Config.WAITING_LIST_NOTIFICATIONS_TIMEOUT)) >= timer;

                    if (Config.WAITING_LIST_NOTIFICATIONS_ENABLED &&
                            !Config.SHOULD_DISPLAY_WAITING_SCREEN &&
                            !Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE &&
                            (Config.FIREBASE_NOTIFICATION_TOKEN != null || Config.WAITING_LIST_NOTIFICATIONS_CHANNEL.equals("SMS")) &&
                            !conferenceStarted || IDnowSDK.isForcedWaitingList()) {

                        if (timerElapsed || (Config.IDENT_POSITION_IN_QUEUE >= Config.WAITING_LIST_NOTIFICATIONS_TRESHOLD) || IDnowSDK.isForcedWaitingList()) {
                            Util_Log.i(LOGTAG, "Push notification panel opened.");

                            Config.SCREEN = "WAITING SCREEN";
                            isAgentView = true;

                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {

                                    loadWaitingScreenVideoIdentPlus();
                                    Util_CustomLogData.setEventData(EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_SHOWN, "EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_SHOWN", "Waiting list (Push notification)", "Screen", null);
                                }
                            }, Config.WAITING_LIST_NOTIFICATIONS_TIMEOUT * 1000);

                        }
                    }

                } else {
                    mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC3, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC3));
                }

                layoutAction_1.setVisibility(View.GONE);
                layoutAction_2.setVisibility(View.GONE);
            }
        }
    }

    public void setRightLayout(final Util_PhotoDataHolder.DocumentImages rightScreen, Boolean rightLayout) {
        if (Activities_VideoLiveStreamActivity_Super.this.isDestroyed()) {
            return;
        }
        dismissProgressDialog();
        if (!rightLayout) {
            imageViewPhoto.setImageBitmap(null);
            layoutAction_1.setVisibility(View.GONE);
            layoutAction_2.setVisibility(View.VISIBLE);
            takePictureButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ID_DOCUMENT = rightScreen;
                    takePicture();
                }
            });
            setupImageCaptureCallback(rightScreen);
            if (rightScreen == face || rightScreen == facefrontside){
                camera.open(CameraType.FRONT);
            }else{
                camera.open(CameraType.BACK);
            }
        } else {
            camera.close();
            relativeLayoutScreen.setVisibility(View.VISIBLE);
            if (rightScreen.equals(Util_PhotoDataHolder.DocumentImages.face)) {
                mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_DESC2, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_SELFIE_DESC2));
            } else {
                mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_IMAGE_DESC, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_FRONT_IMAGE_DESC));
            }

            layoutAction_1.setVisibility(View.VISIBLE);
            layoutAction_2.setVisibility(View.GONE);

            retakeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imageViewPhoto.setImageBitmap(null);
                    setRightScreen(rightScreen, false);
                }
            });

            continueButton.setOnClickListener(v -> {
                ID_DOCUMENT = rightScreen;
                callUploadPhoto();
            });
        }
    }

    public void takePicture() {
        takingImageDialog = setProgressDialog(takingImageDialog);
        captureImage();
    }

    public Boolean filesExist() {
        File folder = new File(getFilesDir() + "/IDnow");
        File[] files = folder.listFiles();
        return files != null;
    }

    private void setupImageCaptureCallback(final Util_PhotoDataHolder.DocumentImages rightScreen) {
        imageCapturedCallback = new ImageCapture.OnImageCapturedCallback() {
            @Override
            public void onCaptureSuccess(@NonNull ImageProxy image) {
                super.onCaptureSuccess(image);
                try {
                    int rotationDegrees = image.getImageInfo().getRotationDegrees();
                    Bitmap rotatedBitmap = ImageHelper.INSTANCE.rotateBitmap(image.toBitmap(), rotationDegrees);
                    if (rightScreen == face || rightScreen == facefrontside) {
                        rotatedBitmap = ImageHelper.INSTANCE.mirrorBitmap(rotatedBitmap);
                    }
                    Bitmap croppedBitmap = ImageHelper.INSTANCE.cropBitmapToPreviewAspect(rotatedBitmap, imageViewPhoto.getMeasuredWidth(), imageViewPhoto.getMeasuredHeight());
                    imageViewPhoto.setImageBitmap(croppedBitmap);
                    File folder = new File(VIDEO_IDENT_PLUS_REUSE_IMAGES ? getFilesDir() : getCacheDir(), "IDnow");
                    folder.mkdir();

                    File[] files = folder.listFiles();
                    if (files != null) {
                        for (File file : files) {
                            if (file.getName().contains(rightScreen.toString()))
                                file.delete();
                        }
                    }

                    String filePath = new File(folder, "IDnow" + rightScreen + System.currentTimeMillis() + ".jpeg").getAbsolutePath();

                    OutputStream outStream;
                    outStream = new FileOutputStream(filePath);
                    rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
                    outStream.close();
                    capturedImageFilePath = filePath;
                    Util_Log.d(LOGTAG, "Path: " + (filePath));

                } catch (Exception e) {
                    Util_Log.e(LOGTAG, "Handling taken picture failed", e);
                    capturedImageFilePath = "";
                }

                dismissProgressDialog();
                callPhotoCheckActivity();
            }

            @Override
            public void onError(@NonNull ImageCaptureException exception) {
                super.onError(exception);
                Util_Log.e(LOGTAG, "CameraX capture failed", exception);
                capturedImageFilePath = "";
                dismissProgressDialog();
                callPhotoCheckActivity();
            }
        };
    }

    private void callPhotoCheckActivity() {
        dismissProgressDialog();
        setRightLayout(ID_DOCUMENT, true);
    }

    private void captureImage() {
        try {
            camera.takePicture(imageCapturedCallback);
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Capture image failed", e);
            Toast.makeText(contextVIP, getString(R.string.photo_ident_failure_saving_picture), Toast.LENGTH_LONG).show();
        }
    }

    private void callUploadPhoto() {
        takingImageDialog = setProgressDialog(takingImageDialog);

        Util_PhotoDataHolder.updateHashMap(ID_DOCUMENT, true, contextVIP);
        Util_PhotoDataHolder.DocumentImages imageType = ID_DOCUMENT;

        if (imageType != null) {
            isFaceImage = imageType.equals(face);
            byte[] imageStringToPush = ImageHelper.INSTANCE.readAsBase64(capturedImageFilePath, 90);
            videoLiveStreamManager.sendUploadPhotoRESTCall(this, Activities_VideoLiveStreamActivity_Super.this, imageStringToPush, imageType, classificationCallback);
        } else {
            Util_Log.e(LOGTAG, "Unknown image type. Check the code");
        }
    }

    public void sendUploadPhoto(byte[] imageStringToPush, @NonNull final Util_PhotoDataHolder.DocumentImages imageType) {
        videoLiveStreamManager.sendUploadPhotoRESTCall(contextVIP, Activities_VideoLiveStreamActivity_Super.this, imageStringToPush, imageType, classificationCallback);
    }

    /**************************/

    @Override
    public void onAnimationCompleted(int currentPage) {

        boolean timerElapsed = (System.currentTimeMillis() - (1000 * Config.WAITING_LIST_NOTIFICATIONS_TIMEOUT)) >= timer;

        prefs = getApplicationContext().getSharedPreferences("waiting", MODE_PRIVATE);
        Config.WAITING_DONE = prefs.getBoolean("receiveWaiting", false);
        Config.SAVED_TOKEN = prefs.getString("receiveToken", "nothing");

        if (Config.WAITING_LIST_NOTIFICATIONS_ENABLED) {
            if (!timerElapsed) {
                if (waitScreen != null) {
                    waitScreen.displayNextPage(currentPage + 1);
                }
            } else {
                if (!Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE && !Config.WAITING_LIST_NOTIFICATIONS_ENROLLED) {
                    Util_CustomLogData.setEventData(EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_SHOWN, "EVENT_WAITING_LIST_PUSH_NOTIFICATION_SCREEN_SHOWN", "Waiting list (Push notification)", "Screen", null);
                    smsWaitScreen = new UI_SMSWaitScreen(this);
                    ViewGroup rootView = findViewById(R.id.mainlayoutFrame);
                    waitScreen.removeView();
                    smsWaitScreen.inflateView(rootView);

                }
            }
        } else {
            waitScreen.displayNextPage(currentPage + 1);
        }
    }

    @Override
    public void onUpdateMobilePhoneNumber(CharSequence phoneNo, UI_SMSWaitScreen ui_smsWaitScreen) {
        videoLiveStreamManager.updateMobilePhoneNumber(IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken(), phoneNo, ui_smsWaitScreen, updateMobileNumberCallback);
    }

    @Override
    public void onSMSFlowCompleted() {
        if (smsWaitScreen != null) {
            smsWaitScreen.removeView();

            explanationView.setNotifyViaPushViewVisibility(false);
            bottomLayout.setVisibility(View.VISIBLE);
            explanationView.setVisibility(View.VISIBLE);
        }
    }

    public void startIdentification() {
        // set the actionbar title and the first explanation
        if (identificationIsAtStep1) {
            setCurrentStep(1);
            explanationView.setTextViewExplanationContentText(Util_Strings.getVideoIdentStepText(this, 1));
            explanationView.setTextViewExplanationTitleText((Util_Strings.getVideoIdentStepTitle(this, 1)));
        }

        waitingForSubscriberThreadIsRunning = false;
    }

    public Runnable updateTimerThread = new Runnable() {

        @Override
        public void run() {
            if (threadIsRunning) {
                timeInMilliseconds = SystemClock.uptimeMillis() - startTime;
                updatedTime = timeSwapBuff + timeInMilliseconds;
                secs = (int) (updatedTime / 1000);
                secs = secs % 60;
                Util_Log.i(LOGTAG, "secs: " + secs);

                if (Config.SOCKET_ENABLED) {
                    if ((secs - (SOCKET_RECONNECT_INTERVAL * Config.SOCKET_TRIES)) >= SOCKET_RECONNECT_INTERVAL) {
                        Config.SOCKET_TRIES = Config.SOCKET_TRIES + 1;
                        timeSwapBuff = secs;
                        secs = 0;
                    }
                    if (Config.SOCKET_TRIES == Config.SOCKET_RECONNECT_ATTEMPTS) {
                        Util_Log.e(LOGTAG, "WebSocket reconnect attempts exceeded limit");
                        Config.SOCKET_TRIES = 0;
                        if (isActivityRunning) {
                            Util_UtilUI.showVideoErrorDialog(mContext, true, restartSessionRunnable);
                            uiHandler.removeCallbacks(updateTimerThread);
                            threadIsRunning = false;
                        }
                    }
                } else {
                    if (secs >= RECONNECTION_TIMEOUT && threadIsRunning) {
                        // only open dialog, if the activity is currently running
                        if (isActivityRunning) {
                            Util_UtilUI.showVideoErrorDialog(mContext, true, restartSessionRunnable);
                            uiHandler.removeCallbacks(updateTimerThread);
                            threadIsRunning = false;
                        }
                    }
                }
                // call every 3 seconds
                uiHandler.postDelayed(this, 5000);
            }
        }
    };

    public Runnable restartWaitingForSubscriberRunnable = new Runnable() {
        @Override
        public void run() {
            if (getSubscriber() == null && isActivityRunning) {
                startTimeWaitingForSubscriber = SystemClock.uptimeMillis();
                uiHandler.postDelayed(waitingForSubscriberThread, 0);
                mLoadingSub.setVisibility(View.VISIBLE);
                waitingForSubscriberThreadIsRunning = true;
            }
        }
    };


    /**
     * agent sent a message. display the message in  a toast, coloring the fab and displaying an indicator with the number of unread messages
     */
    public void showNewAgentMessage(Models_ChatMessage chatMessage) {
        textMessages.add(chatMessage);

        // if the user has already opened the chatview -> just update the list
        if (chatLayout != null && chatLayout.getVisibility() == View.VISIBLE) {
            if (chatListView != null && textChatAdapter != null) {
                textChatAdapter.notifyDataSetChanged();
                scrollListToBottom();
            }
        }

        // chatview is not opened -> show toast and update indicator
        else {
            Toast chatMessageToast = Toast.makeText(this, chatMessage.getText(), Toast.LENGTH_LONG);
            chatMessageToast.setGravity(Gravity.CENTER, 0, 0);
            chatMessageToast.show();

            unreadAgentMessages++;
            indicatorTextView.setText("" + unreadAgentMessages);
            chatIndicatorLayout.setVisibility(View.VISIBLE);
            coloringIcon(chatButton, true, R.drawable.ic_chat_black);
        }
    }

    /**
     * clear the state new message received by deleting the indicator and clear the coloring of the fab button
     */
    public void clearNewMessageState() {
        unreadAgentMessages = 0;
        chatIndicatorLayout.setVisibility(View.GONE);
        coloringIcon(chatButton, false, R.drawable.ic_chat_black);
    }

    public void coloringIcon(ImageView imageView, boolean setActive, int drawableID) {
        Drawable checkedIcon = getResources().getDrawable(drawableID);

        if (setActive) {
            checkedIcon.setColorFilter(getResources().getColor(R.color.primary), Mode.SRC_IN);
        } else {
            checkedIcon.clearColorFilter();
            checkedIcon.setColorFilter(null);
        }

        imageView.setImageDrawable(checkedIcon);
    }

    /**
     * The chatButton can be either docked above the explanationView or aligned top right.
     * Because the button has to be shown on different layers, we need 2 containers
     * in which the button has to be added, according to the current setting.
     *
     * @param aboveBottomView if set to true, the chatButton is docked above the explanation view. if set to false, its aligned to the top right.
     */
    public void locateChatButton(boolean aboveBottomView) {

        // check if chat is enabled
        if (IDnowSDK.enableChat && chatButtonHolder != null) {
            // first of all, remove the button from its container, to be able to add it afterwards.
            try {
                buttonHolderTop.removeView(chatButtonHolder);
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Remove chat button failed", e);
                logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.ERROR.get());
                logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.INFO.get());


            }

            try {
                buttonHolderBottom.removeView(chatButtonHolder);
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Remove chat button failed", e);
                logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.ERROR.get());
                logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.INFO.get());

            }

            // dock the button above the explanation layout and remove it from the top layout.
            if (aboveBottomView) {
                try {
                    buttonHolderTop.removeView(chatButtonHolder);
                } catch (Exception e) {
                    Util_Log.e(LOGTAG, "Remove chat button failed", e);
                    logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.ERROR.get());
                    logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.INFO.get());

                }

                buttonHolderBottom.addView(chatButtonHolder);

            }

            // remove the button from the bottom layout and add it to the top layout.
            else {
                // a handler has to be used, to slow down adding the view, because otherwise the button will be overlapped by an overlay.
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // if the button in the meantime was added to the bottom layout, remove it.
                        try {
                            buttonHolderBottom.removeView(chatButtonHolder);
                        } catch (Exception e) {
                            Util_Log.e(LOGTAG, "Remove chat button failed", e);
                            logExternally(getApplicationContext(), "error : " + e.getMessage(), LogEventTypeEnum.ERROR.get());
                            logExternally(getApplicationContext(), "error : " + e.getMessage(), LogEventTypeEnum.INFO.get());

                        }

                        buttonHolderTop.addView(chatButtonHolder);
                    }
                }, 500);
            }
        }
    }

    public void initChatLayout() {
        if (IDnowSDK.enableChat) {
            chatLayout = findViewById(R.id.chatLayout);
            closeChatButton = findViewById(R.id.closeChatButton);
            closeChatButton.setImageDrawable(getResources().getDrawable(R.drawable.ic_close));
            coloringIcon(closeChatButton, true, R.drawable.ic_close);

            closeButtonFrameLayout = findViewById(R.id.closeButtonFrameLayout);
            closeButtonFrameLayout.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {
                    hideChatLayout();
                }
            });

            if (buttonHolderBottom == null) {
                buttonHolderBottom = findViewById(R.id.buttonHolderBottom);
            }
            if (buttonHolderTop == null) {
                buttonHolderTop = findViewById(R.id.buttonHolderTop);
            }

            if (chatButtonHolder == null) {
                chatButtonHolder = findViewById(R.id.chatButtonHolder);
            }

            chatListView = findViewById(R.id.chatListView);
            chatIndicatorLayout = findViewById(R.id.chatIndicatorLayout);
            chatEditText = findViewById(R.id.chatEditText);
            chatEditText.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CHAT_ENTER_MSG, LOCAL_KEY_VIDEO_IDENT_CHAT_ENTER_MSG));

            SendChatMessageCallback sendChatCallback = new SendChatMessageCallback() {
                @Override
                public void onSuccess() {
                    createMessageEntryForChat();

                    if (progressBarLoading != null) {
                        progressBarLoading.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onFailure() {
                    if (progressBarLoading != null) {
                        progressBarLoading.setVisibility(View.GONE);
                    }

                    Util_UtilUI.showMessageOK(Activities_VideoLiveStreamActivity_Super.this, Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CHAT_SEND_MSG_FAILURE, LOCAL_KEY_VIDEO_IDENT_CHAT_SEND_MSG_FAILURE), (dialog, which) -> {
                    });
                }
            };

            chatEditText.setOnEditorActionListener(new OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEND) {
                        // Close the keyboard
                        View view = Activities_VideoLiveStreamActivity_Super.this.getCurrentFocus();
                        if (view != null) {
                            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                        }

                        progressBarLoading.setVisibility(View.VISIBLE);
                        videoLiveStreamManager.sendChatMessageRESTCall(chatEditText.getText().toString(), sendChatCallback);
                    }
                    return true;
                }
            });
            indicatorTextView = findViewById(R.id.indicatorTextView);

            // dynamically set color of the send icon (active if a valid text has been entered, inactive if no text has been entered).
            chatEditText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (chatEditText.getText().toString().length() > 0) {
                        sendMessageImageView.setImageDrawable(getResources().getDrawable(R.drawable.ic_chat_send_active));
                        coloringIcon(sendMessageImageView, true, R.drawable.ic_chat_send_active);
                    } else {
                        sendMessageImageView.setImageDrawable(getResources().getDrawable(R.drawable.ic_chat_send));
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {
                    scrollListToBottom();
                }
            });

            if (!Config.VIDEO_IDENT_PLUS) {
                chatButtonHolder.setVisibility(View.VISIBLE);
            }

            sendMessageImageView = findViewById(R.id.sendMessageImageView);

            // sending the message by creating a new chatMessage and update the listview
            sendMessageImageView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    progressBarLoading.setVisibility(View.VISIBLE);
                    videoLiveStreamManager.sendChatMessageRESTCall(chatEditText.getText().toString(), sendChatCallback);
                }
            });


            textChatAdapter = new Adapter_TextChat(this, textMessages);
            chatListView.setAdapter(textChatAdapter);

            chatButton = findViewById(R.id.chatButton);
            coloringIcon(chatButton, false, R.drawable.ic_chat_black);

            // handle the
            chatButton.setOnClickListener(v -> openChatScreen());
        }
    }

    private void createMessageEntryForChat() {
        Date date = Calendar.getInstance().getTime();
        textMessages.add(new Models_ChatMessage(chatEditText.getText().toString(), date, "USER", Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_CHAT_TEXT_USER, LOCAL_KEY_VIDEO_IDENT_CHAT_TEXT_USER)));
        textChatAdapter.notifyDataSetChanged();
        chatEditText.setText("");
        sendMessageImageView.setImageDrawable(getResources().getDrawable(R.drawable.ic_chat_send));
        scrollListToBottom();
    }

    private void openChatScreen() {
        clearNewMessageState();
        chatLayout.setVisibility(View.VISIBLE);
        scrollListToBottom();
        chatButtonHolder.setVisibility(View.GONE);
    }

    /**
     * Select the last row so it will scroll into view
     */
    void scrollListToBottom() {
        chatListView.post(new Runnable() {
            @Override
            public void run() {
                chatListView.setSelection(textChatAdapter.getCount() - 1);
                chatListView.invalidate();
            }
        });
    }

    /**
     * just an empty method. has to be overwritten by tokbox and liveswitch activities
     */
    public Object getSubscriber() {
        return null;
    }

    /**
     * this runnable is called when the agent looses his connection or the stream is dropped. It informs the user about the current state
     * and offers him the opportunity to retry to connect.
     */
    public Runnable waitingForSubscriberThread = new Runnable() {

        @Override
        public void run() {
            if (waitingForSubscriberThreadIsRunning) {
                timeInMillisecondsWaitingForSubscriber = SystemClock.uptimeMillis() - startTimeWaitingForSubscriber;

                updatedTimeWaitingForSubscriber = timeSwapBuffWaitingForSubscriber + timeInMillisecondsWaitingForSubscriber;

                int secs = (int) (updatedTimeWaitingForSubscriber / 1000);
                secs = secs % 60;
                Util_Log.i(LOGTAG, "secs in waiting: " + secs);

                if (secs >= RECONNECTION_TIMEOUT && waitingForSubscriberThreadIsRunning) {
                    // only open dialog, if the activity is currently running
                    if (isActivityRunning) {
                        Util_UtilUI.showVideoErrorDialog(mContext, true, restartWaitingForSubscriberRunnable);
                    }
                    uiHandler.removeCallbacks(waitingForSubscriberThread);

                    waitingForSubscriberThreadIsRunning = false;
                }

                // call every 3 seconds
                uiHandler.postDelayed(this, 3000);
            }
        }
    };

    public Runnable restartSessionRunnable = new Runnable() {
        @Override
        public void run() {

            if (Config.SOCKET_ENABLED) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            startWebsocket(true);
                        } catch (Exception e) {
                            Util_Log.e(LOGTAG, "Start websocket failed", e);
                        }
                    }
                });

                thread.start();
            } else {
                if (isActivityRunning) {
                    sessionConnect();
                    startTime = SystemClock.uptimeMillis();
                    uiHandler.postDelayed(updateTimerThread, 0);
                    mLoadingSub.setVisibility(View.VISIBLE);
                    threadIsRunning = true;
                }
            }
        }
    };

    // just a empty superclass method, behavior implemented in subclasses
    public void sessionConnect() {
    }

    /**
     * a "powered-by-idnow" watermark is placed on top of the view if the calling app is not the idnow-host-app
     */
    public void handleWatermarkVisibility(View poweredByView) {

        if (!IDnowSDK.getShowPoweredBy()) {
            poweredByView.setVisibility(View.GONE);
        } else {
            poweredByView.setVisibility(View.VISIBLE);
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        isActivityRunning = false;
        if (!isInPictureInPictureMode()) {
            videoLiveStreamManager.appEnteredBackgroundRESTCall(false);
        }
    }

    public AlertDialog setProgressDialog(AlertDialog takingImageDialog) {

        int llPadding = 30;
        LinearLayout ll = new LinearLayout(this);
        ll.setFitsSystemWindows(true);
        ll.setOrientation(LinearLayout.HORIZONTAL);
        ll.setPadding(llPadding, llPadding, llPadding, llPadding);
        ll.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams llParam = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        llParam.gravity = Gravity.CENTER;
        ll.setLayoutParams(llParam);

        ProgressBar progressBar = new ProgressBar(this);
        progressBar.setIndeterminate(true);
        progressBar.setPadding(0, 0, llPadding, 0);
        progressBar.setLayoutParams(llParam);
        progressBar.getIndeterminateDrawable().setColorFilter(getResources().getColor(R.color.primaryColor), Mode.MULTIPLY);

        llParam = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        llParam.gravity = Gravity.CENTER;
        TextView tvText = new TextView(this);
        tvText.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_IMAGE_PROCESSING, LOCAL_KEY_VIDEO_IDENT_IMAGE_PROCESSING));
        tvText.setTextColor(getResources().getColor(R.color.primarytextColor));
        tvText.setTextSize(14);
        tvText.setLayoutParams(llParam);

        ll.addView(progressBar);
        ll.addView(tvText);

        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.IDnowAlertDialogStyle));

        builder.setCancelable(true);
        builder.setView(ll);


        takingImageDialog = builder.create();
        takingImageDialog.show();
        Window window = takingImageDialog.getWindow();
        if (window != null) {
            WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
            layoutParams.copyFrom(takingImageDialog.getWindow().getAttributes());
            layoutParams.width = LinearLayout.LayoutParams.WRAP_CONTENT;
            layoutParams.height = LinearLayout.LayoutParams.WRAP_CONTENT;
            takingImageDialog.getWindow().setAttributes(layoutParams);
        }

        if (takingImageDialog != null) {
        }
        return takingImageDialog;
    }

    @Override
    public void onResume() {
        super.onResume();

        isActivityRunning = true;
        activityIsFinishing = false;
        videoLiveStreamManager.appEnteredForegroundRESTCall(Activities_VideoLiveStreamActivity_Super.this);

        mNotificationManager.cancel(Config.NOTIFICATION_ID);

        // make sure the waiting information gets fetched again
        setupWaitingQueueInformation();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    /**
     * called when the websocket call "finished" is received
     */
    public void onEndCall(int resultCode) {
        manuallyClosedActivity = true;
        if (IDnowSDK.getShowErrorSuccessScreen(mContext)) {
            if (!userInitiatedCancellation) {
                if (Config.CALL_ABORT_REASON_SCREEN) {
                    runOnUiThread(() -> {
                        if (user_abort_feedback_view != null) {
                            user_abort_feedback_view.setVisibility(View.GONE);
                        }
                    });
                }
                showResultActivity(resultCode);
            }

        } else {
            AudioManager am = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);
            am.setMode(AudioManager.MODE_NORMAL);

            Intent onEndCallIntent = new Intent();
            if (resultCode == IDnowSDK.RESULT_CODE_SUCCESS) {
                onEndCallIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
            } else if (resultCode == IDnowSDK.RESULT_CODE_FAILED) {
                onEndCallIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, getString(IDnowSDK.MESSAGE_ID_FAILED));
            }
            if (!userInitiatedCancellation) {
                if (!IDnowSDK.getOverrideEntryActivity()) {
                    Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity.class;
                }
                Intent intent = new Intent(this, Config.HOST_APP_START_ACTIVITY);
                intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                IDnowSDK.updateResultCode(resultCode);
                IDnowSDK.getInstance().deliverResult(resultCode, getIntent());
                setResult(resultCode, getIntent());
                finish();
                startActivity(intent);
            }
        }
    }

    public void startWebsocket(final boolean triggerRequestVideoChatRESTCall) {
        Network_WebSocketService.getInstance().create(this, new Runnable() {
            @Override
            public void run() {
                if (triggerRequestVideoChatRESTCall &&
                        (!Config.AUTHENTICATED_POSSIBLE || Config.RESTART_VIDEO_IDENT)) {
                    videoLiveStreamManager.requestVideoChatRESTCall(requestVideoChatCallback);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (Config.SOCKET_ENABLED) {
                            Util_UtilUI.showVideoErrorDialog(Activities_VideoLiveStreamActivity_Super.this, true, restartSessionRunnable);
                        } else {
                            Util_UtilUI.showVideoErrorDialog(Activities_VideoLiveStreamActivity_Super.this, false, null);
                        }
                    }
                });
            }
        }, IDnowSDK.getConnectionType(mContext) == IDnowSDK.ConnectionType.LONG_POLLING);

        try {
            Network_WebSocketService.getInstance().run();


        } catch (RuntimeException e) {
            Util_Log.e(LOGTAG, "Start websocket failed", e);
            logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.ERROR.get());
            logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.INFO.get());

            throw new RuntimeException(e); //Propagate error for now, should be replaced with server side logging
        }
    }

    private boolean mIsBound = false;

    @Override
    public void onStop() {

        super.onStop();
        Util_CustomLogData.onStop();
        Util_Log.i(LOGTAG, "http Stopped");

        try {
            stopService();
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Stop service failed", e);
        }

        if (isFinishing()) {
            Util_Log.i(LOGTAG, "Stopped");

            mNotificationManager.cancel(Config.NOTIFICATION_ID);
        }

        isActivityRunning = false;

        // unbind service, if activity is destroyed
        if (mIsBound) {
            try {
                unbindService(mConnection);
                Util_Log.i(LOGTAG, "service was destroyed");
                mIsBound = false;
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Unbind service failed", e);
                logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.ERROR.get());
                logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.INFO.get());

            }
        }
    }

    private void UserAbortRestCall(String reason_to_cancel) {
        Config.ABORT_IDENT = true;
        videoLiveStreamManager.identificationCanceledRESTCall(reason_to_cancel, identificationCanceledCallback);
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    public void loadWaitingAnimation() {
        View bottomSheetContentView = getLayoutInflater().inflate(R.layout.view_waiting_bottom_layout, null);
        waitingSheetDialog = new BottomSheetDialog(mContext, R.style.bottomSheetDialog);
        waitingSheetDialog.setContentView(bottomSheetContentView);

        BottomSheetBehavior mBehavior = BottomSheetBehavior.from((View) bottomSheetContentView.getParent());
        mBehavior.setPeekHeight(2700);

        animationWaitingL = waitingSheetDialog.findViewById(R.id.animationWaitingL);
        animationWLtitle = waitingSheetDialog.findViewById(R.id.animationWLtitle);
        waiting_estimated_text = waitingSheetDialog.findViewById(R.id.waiting_estimated_text);
        countDownText = waitingSheetDialog.findViewById(R.id.countdowntimertext);
        estimation_layout = waitingSheetDialog.findViewById(R.id.estimation_layout);
        dontleave_text = waitingSheetDialog.findViewById(R.id.dontleave_text);
        waiting_screen_desc = waitingSheetDialog.findViewById(R.id.waiting_screen_desc);
        waiting_screen_no = waitingSheetDialog.findViewById(R.id.waiting_screen_no);
        waiting_screen_yes = waitingSheetDialog.findViewById(R.id.waiting_screen_yes);
        delayedTextView = waitingSheetDialog.findViewById(R.id.delayedMessage);

        String animation = Config.REMOTE_ANIMATIONS.find("animation_wl.json");
        if (animation != null) {
            animationWaitingL.setAnimationFromJson(animation, null);
        } else {
            String localName = IDnowSDK.getWaitingListAnimationName(mContext);
            animationWaitingL.setAnimation(localName != null ? localName : "animate_waiting_screen_animation.json");
        }
        animationWaitingL.playAnimation();
        animationWaitingL.loop(true);

        animationWLtitle.setText(Util_Strings.getStringWithDefault(mContext, Util_Strings.KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION1, Util_Strings.LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION1));

        waiting_estimated_text.setText(Util_Strings.getStringWithDefault(mContext, Util_Strings.KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC3, Util_Strings.LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_DESC3));
        dontleave_text.setText(Util_Strings.getStringWithDefault(mContext, Util_Strings.KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION3, Util_Strings.LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION3));
        delayedTextView.setText(Util_Strings.getStringWithDefault(mContext, KEY_CUSTOMISED_WAITING_SCREEN_APOLOGIES, LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_APOLOGIES));
        waiting_screen_desc.setText(Util_Strings.getStringWithDefault(mContext, Util_Strings.KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION2, Util_Strings.LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION2));
        waiting_screen_no.setText(Util_Strings.getStringWithDefault(mContext, Util_Strings.KEY_CUSTOMISED_WAITING_SCREEN_ACTION2, Util_Strings.LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_ACTION2));
        waiting_screen_yes.setText(Util_Strings.getStringWithDefault(mContext, Util_Strings.KEY_CUSTOMISED_WAITING_SCREEN_ACTION1, Util_Strings.LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_ACTION1));

        waiting_screen_yes.setOnClickListener(v -> {
            estimation_layout.setBackgroundResource(R.color.transparent);

            if (isTimerFinished) {
                dontleave_text.setVisibility(View.GONE);
                delayedTextView.setVisibility(View.VISIBLE);
            } else {
                dontleave_text.setVisibility(View.VISIBLE);
                delayedTextView.setVisibility(View.GONE);
            }
            waiting_screen_yes.setVisibility(View.GONE);

            waiting_screen_desc.setVisibility(View.GONE);

        });

        waiting_screen_no.setOnClickListener(v -> Util_UtilUI.showWaitingScreenDialog(mContext));
        startCountDown();

        waitingSheetDialog.setCancelable(false);

    }

    public void startCountDown() {
        startTimer();
    }

    public void startTimer() {

        countDownTimer = new CountDownTimer(timerinMilliSeconds
                , 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timerinMilliSeconds = millisUntilFinished;
                updateTimer();
            }

            @Override
            public void onFinish() {
                estimation_layout.setVisibility(View.GONE);
                delayedTextView.setVisibility(View.VISIBLE);
                waiting_screen_desc.setVisibility(View.GONE);
                dontleave_text.setVisibility(View.GONE);
                isTimerFinished = true;
            }
        }.start();

        timeRunning = true;
    }

    public void stopTimer() {
        countDownTimer.cancel();
        timerinMilliSeconds = DISPLAY_WAITING_SCREEN_CUSTOMISED_TIMER;
        timeRunning = false;
    }

    public void updateTimer() {
        long minutes = timerinMilliSeconds / 60000;
        long seconds = timerinMilliSeconds % 60000 / 1000;
        String timeLeftText;
        timeLeftText = "" + minutes;
        timeLeftText += ":";
        if (seconds < 10) timeLeftText += "0";
        timeLeftText += seconds;
        countDownText.setText(": " + timeLeftText);
    }


    public String getHiddenPhoneNumber() {
        String hiddenPhoneNum = Util_Util.hidePhoneNum(Config.USER_PHONE_NO);
        if (hiddenPhoneNum == null) {
            hiddenPhoneNum = "";
        }
        return hiddenPhoneNum;
    }

    public String getHiddenEmail() {
        String hiddenEmail = Util_Util.hideEmail(Config.EMAIL_ADDRESS);
        if (hiddenEmail == null) {
            hiddenEmail = "";
        }
        return hiddenEmail;
    }

    @SuppressLint("CutPasteId")
    public void loadInterface() {
        // secures against manual screenshots and automatic screenshots
//		getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.view_live_stream);
        completeIdentificationView = findViewById(R.id.completeIdentificationView);
        overlayView = findViewById(R.id.eSignatureOverlayView);
        feedback_title = findViewById(R.id.feedback_title);
        feedback_description = findViewById(R.id.feedback_desc);
        userAbort_radio = findViewById(R.id.userAbort_radio);
        feedback_cancel = findViewById(R.id.feedback_cancel);
        feedback_button = findViewById(R.id.feedback_button);
        rateAgent_view = findViewById(R.id.rateAgent_view);
        userAbort_view = findViewById(R.id.userAbort_view);
        rateAgent_view.setVisibility(View.VISIBLE);
        userAbort_view.setVisibility(View.GONE);
        user_abort_feedback_view = findViewById(R.id.user_abort_feedback_view);
        logo_screen_feedback = findViewById(R.id.logo_screen_feedback);
        // view that appears later in the process (where user has to enter his ident-code)
        insertTanHintTextView = findViewById(R.id.textViewInsertTanHint);
        insertTanHintTextViewCode = findViewById(R.id.textViewInsertTanHintCode);
        retrieveTanInfoTextView = findViewById(R.id.textViewRetrieveTanInfo);
        retrieveTanInfoTextViewModal = findViewById(R.id.textViewRetrieveTanInfoModal);

        mLoadingSub = findViewById(R.id.loadingSpinner);
        mLoadingSub.getIndeterminateDrawable().setColorFilter(getResources().getColor(R.color.primaryColor), Mode.MULTIPLY);
        mLoadingSub.setVisibility(View.VISIBLE);
        progressBarLoading = findViewById(R.id.progressBarLoading);
        bottomLayout = findViewById(R.id.explanationContainer);
        signatureMask = findViewById(R.id.video_signing_mask);
        buttonHolderBottom = findViewById(R.id.buttonHolderBottom);
        buttonHolderTop = findViewById(R.id.buttonHolderTop);
        chatButtonHolder = findViewById(R.id.chatButtonHolder);

        if (!VIDEO_IDENT_PLUS) {
            if (Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED) {
                loadWaitingAnimation();
                if (!(mContext instanceof Activities_AgentFeedbackActivity)) {
                    waitingSheetDialog.show();
                }
            }
        }

        // use the primary color to tint signatureMask
        Resources res = mContext.getResources();
        final int newColor = res.getColor(R.color.primary);
        signatureMask.setColorFilter(newColor, Mode.SRC_ATOP);

        // IDNOW-4091
        notifyViaPushLowerPanel = findViewById(R.id.notifyViaPushLowerPanel);
        notifyViaPushOKButton = findViewById(R.id.notifyViaPushOKButton);
        notifyViaPushOKButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                openPushLowerPanel();
            }
        });

        textEnterIdentCode = findViewById(R.id.textEnterIdentCode);
        textRequestIdentCode = findViewById(R.id.textRequestIdentCode);

        if (!Config.FULL_SIZE_MODAL_SMS_WINDOW) {
            insertTanView = findViewById(R.id.view_insert_tan_half_size);
            retrieveTanView = findViewById(R.id.view_retrieve_tan_half_size);
            resizeActivity(retrieveTanView, 0.5);
            resizeActivity(insertTanView, 0.7);
            removeIncludedViewFromFrameLayoutForGivenId(R.id.view_insert_tan);
            removeIncludedViewFromFrameLayoutForGivenId(R.id.view_retrieve_tan);
            if (Config.HEADER_BOLDED) {
                textRequestIdentCode.setTypeface(null, Typeface.BOLD);
                textEnterIdentCode.setTypeface(null, Typeface.BOLD);
            }

        } else {
            insertTanView = findViewById(R.id.view_insert_tan);
            retrieveTanView = findViewById(R.id.view_retrieve_tan);
            removeIncludedViewFromFrameLayoutForGivenId(R.id.view_insert_tan_half_size);
            removeIncludedViewFromFrameLayoutForGivenId(R.id.view_retrieve_tan_half_size);
        }

        if (Config.TRANSPARENT_BACKGROUND_MODAL_SMS_WINDOW) {
            retrieveTanView.getBackground().setAlpha(Config.TRANSPARENT_ALPHA_VALUE);
        }
        notReceivedTanTextView = findViewById(R.id.textViewForgotTan);
        retrieveTanButton = findViewById(R.id.buttonRetrieveTan);
        retrieveTanButton.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_RETRIEVE_TAN_BUTTON, LOCAL_KEY_VIDEO_IDENT_RETRIEVE_TAN_BUTTON));
        if (IDnowSDK.getNewBrand()) {
            retrieveTanButton.setBackgroundResource(R.drawable.rounded_background_grey);
        }
        Util_UtilUI.setProceedButtonBackgroundSelector(retrieveTanButton);
        retrieveTanButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveTanButton.setEnabled(false);

                // replace the placeholder with the phone number the user has entered

                if (Config.HIDE_USERS_PII_DATA) {
                    if (insertEmailEditText != null) {
                        if (!insertEmailEditText.getText().toString().contains("***")) {
                            Config.EMAIL_ADDRESS = insertEmailEditText.getText().toString();
                        } else {
                            insertEmailEditText.setText(Config.MASKED_EMAIL_ADDRESS);
                        }
                    }

                    if (insertPhoneNrEditText != null) {
                        if (!insertPhoneNrEditText.getText().toString().contains("***")) {
                            USER_PHONE_NO = insertPhoneNrEditText.getText().toString();
                        } else {
                            insertPhoneNrEditText.setText(Config.MASKED_USER_PHONE_NO);
                        }
                    }
                } else {
                    if (!insertEmailEditText.getText().toString().equals(EMAIL_ADDRESS)) {
                        EMAIL_ADDRESS = insertEmailEditText.getText().toString();
                    } else if (!insertPhoneNrEditText.getText().toString().equals(USER_PHONE_NO)) {
                        USER_PHONE_NO = insertPhoneNrEditText.getText().toString();
                    }
                }


                if (Config.IDENT_CODE_BY_EMAIL && !Config.IDENT_CODE_BY_SMS) {
                    retrieveTanInfoTextView.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_TEXT_EMAIL, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_EMAIL).replace("xxx", Config.EMAIL_ADDRESS));
                    retrieveTanInfoTextViewModal.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_TEXT_EMAIL, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_EMAIL).replace("xxx", Config.EMAIL_ADDRESS));
                    notReceivedTanTextView.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_IDENT_CODE_REQUEST_AGAIN_EMAIL_MESSAGE, LOCAL_KEY_VIDEO_IDENT_IDENT_CODE_REQUEST_AGAIN_EMAIL_MESSAGE));
                } else if (Config.IDENT_CODE_BY_SMS && Config.IDENT_CODE_BY_EMAIL && receiveTanByEmail) {
                    retrieveTanInfoTextView.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_TEXT_EMAIL, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_EMAIL).replace("xxx", Config.EMAIL_ADDRESS));
                    retrieveTanInfoTextViewModal.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_TEXT_EMAIL, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_EMAIL).replace("xxx", Config.EMAIL_ADDRESS));
                    notReceivedTanTextView.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_IDENT_CODE_REQUEST_AGAIN_EMAIL_MESSAGE, LOCAL_KEY_VIDEO_IDENT_IDENT_CODE_REQUEST_AGAIN_EMAIL_MESSAGE));
                } else {
                    String boldedPhonenb = "<b>" + Config.USER_PHONE_NO + "</b>";
                    retrieveTanInfoTextView.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS).replace("xxx", Config.USER_PHONE_NO));
                    retrieveTanInfoTextViewModal.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS).replace("xxx", USER_PHONE_NO));
                    notReceivedTanTextView.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_IDENT_CODE_REQUEST_AGAIN_SMS_MESSAGE, LOCAL_KEY_VIDEO_IDENT_IDENT_CODE_REQUEST_AGAIN_SMS_MESSAGE));
                }

                if (Config.IDENT_CODE_BY_EMAIL) {
                    if ((boolean) checkViewCodeByEmail.getTag()) {
                        receiveTanByEmail = true;
                    }
                }

                if (!receiveTanByEmail && Util_UtilUI.isEditTextEmpty(insertPhoneNrEditText, true,
                        Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_REQUIRED_FIELD, LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD))) {
                    retrieveTanButton.setEnabled(true);
                } else if (receiveTanByEmail && Util_UtilUI.isEditTextEmpty(insertEmailEditText, true,
                        Util_Strings.getStringWithDefault(getApplicationContext(), KEY_EMAIL_FORMAT, LOCAL_KEY_EMAIL_FORMAT))) {
                    retrieveTanButton.setEnabled(true);
                } else {
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) {
                        Util_Log.i(LOGTAG, "clicked too fast");
                    } else {
                        Util_Util.hideSoftKeyboard(Activities_VideoLiveStreamActivity_Super.this);
                        sendIdentCodeToPhoneRESTCall();
                    }

                    lastClickTime = SystemClock.elapsedRealtime();
                }
            }
        });

        insertTanButton = findViewById(R.id.buttonAccept);

        if (IDnowSDK.getNewBrand()) {
            insertTanButton.setBackgroundResource(R.drawable.rounded_background_grey);
        }
        insertTanButton.setEnabled(false);
        Util_UtilUI.setProceedButtonBackgroundSelector(insertTanButton);
        insertTanButton.setText(Util_Strings.getStringWithDefault(mContext, KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_BUTTON_CONFIRM, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_BUTTON_CONFIRM));
        insertTanButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // only trigger REST call, if the edittext isn't empty
                        if (!Util_UtilUI.isEditTextEmpty(insertTanEditText, true, Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_ENTER_CODE, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_ENTER_CODE))) {
                            // prevent double click by checking if the last click has been performed more than 2 seconds ago
                            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) {
                                Util_Log.i(LOGTAG, "clicked too fast");

                            } else {
                                // if the user enters very fast the code and presses the button, a delay between the entered code and button click is
                                // possible. this means that not the whole code is used, but only a part of it. so add a delay for calling the button
                                // click.
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        Util_Util.hideSoftKeyboard(Activities_VideoLiveStreamActivity_Super.this);
                                        videoLiveStreamManager.sendConfirmationCodeRESTCall(insertTanEditText.getText().toString(), sendConfirmationCodeCallback);
                                    }
                                }, 500);
                            }
                            lastClickTime = SystemClock.elapsedRealtime();
                        }
                    }
                });
            }
        });

        insertTanEditText = findViewById(R.id.editTextInsertTan);

        insertTanEditText.setHint(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_ENTER_CODE, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_ENTER_CODE));

        if (IDnowSDK.getNewBrand()) {
            insertTanEditText.setBackgroundResource(R.drawable.rounded_background_grey);
        }
        insertTanEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                Util_Util.hideKeyBoard(this, v);
                v.clearFocus();
                if (insertTanButton.isEnabled())
                    insertTanButton.performClick();
                return true;
            }
            return false;
        });
        insertTanEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                insertTanButton.setEnabled(s.length() != 0);
                Util_UtilUI.setProceedButtonBackgroundSelector(insertTanButton);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        text_request_ident_code = findViewById(R.id.textRequestIdentCode);
        text_request_ident_code.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_RETRIEVE_TAN_TITLE, LOCAL_KEY_VIDEO_IDENT_RETRIEVE_TAN_TITLE));

        mobile_number_textview = findViewById(R.id.mobile_number_textview);
        mobile_number_textview.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_IDENTCODE_PHONE_NUMBER_TITLE, LOCAL_KEY_VIDEO_IDENT_IDENTCODE_PHONE_NUMBER_TITLE));
        insertPhoneNrEditText = findViewById(R.id.editTextInsertMobileNr);

        if (insertEmailEditText != null) {
            insertEmailEditText.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PHONE_NUMBER_PLACEHOLDER, LOCAL_KEY_VIDEO_IDENT_PHONE_NUMBER_PLACEHOLDER));
        }

        if (IDnowSDK.getNewBrand()) {
            insertPhoneNrEditText.setBackgroundResource(R.drawable.rounded_background_grey);
        }

        if (Config.HIDE_USERS_PII_DATA && !Config.USER_PHONE_NO.equals("")) {
            insertPhoneNrEditText.setText(Util_Util.hidePhoneNum(Config.USER_PHONE_NO));
        } else {
            insertPhoneNrEditText.setText(Config.USER_PHONE_NO);
        }

        if (Config.MOBILE_NUMBER_CHANGE_DISABLED) {
            insertPhoneNrEditText.setEnabled(false);

        } else {
            insertPhoneNrEditText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    insertTanButton.setEnabled(s.length() != 0);
                    Util_UtilUI.setProceedButtonBackgroundSelector(insertTanButton);
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });
        }

        TextView retrieve_tan_content_text = findViewById(R.id.retrieve_tan_content);
        TextView ident_code_via_email_title = findViewById(R.id.verify_info_textview);
        retrieve_tan_content_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_IDENTCODE_REQUEST_MESSAGE, LOCAL_KEY_VIDEO_IDENT_IDENTCODE_REQUEST_MESSAGE));
        ident_code_via_email_title.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_IDENTCODE_REQUEST_EMAIL_TITILE, LOCAL_KEY_VIDEO_IDENT_IDENTCODE_REQUEST_EMAIL_TITILE));

        insertEmailEditText = findViewById(R.id.editTextInsertEmail);
        if (IDnowSDK.getNewBrand()) {
            insertEmailEditText.setBackgroundResource(R.drawable.rounded_background_grey);
        }

        if (Config.HIDE_USERS_PII_DATA) {
            insertEmailEditText.setText(hideEmail(Config.EMAIL_ADDRESS));
            manageEditText(insertEmailEditText, "EMAIL");
        } else {
            insertEmailEditText.setText(Config.EMAIL_ADDRESS);
        }

        poweredByView = findViewById(R.id.poweredByView);
        icon_powered_by = findViewById(R.id.icon_powered_by);

        icon_powered_by.setAnimation("static_logo.json");

        if (IDnowSDK.getShowIDnowLogo()) {
            icon_powered_by.setVisibility(View.VISIBLE);
        } else {
            icon_powered_by.setVisibility(View.GONE);
        }

        if (Config.DARK_MODE) {
            Util_UtilUI.setColorLottieAnimation(Color.WHITE, icon_powered_by, "SecondaryVariant");

        } else {
            Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, icon_powered_by, "SecondaryVariant");
        }

        explanationView = findViewById(R.id.explanationView);
        helperImageContainer = findViewById(R.id.helperImageContainer);
        helperImageContainer.setVisibility(View.GONE);
        subscriberContainer = findViewById(R.id.subscriberContainer);
        subscriberLayout = findViewById(R.id.subscriberLayout);
        connecting_with_agent_text = findViewById(R.id.connecting_with_agent_text);
        connecting_with_agent_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), Util_Strings.KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION, LOCAL_KEY_CUSTOMISED_WAITING_SCREEN_INSTRUCTION));
        spinnerWL = findViewById(R.id.spinnerWA);
        spinnerWL.setAnimation("loading.json");
        spinnerWL.setRepeatCount(ValueAnimator.INFINITE);
        spinnerWL.playAnimation();

        ViewCompat.setOnApplyWindowInsetsListener(connecting_with_agent_text, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.statusBars()
                            | WindowInsetsCompat.Type.displayCutout()
            );
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });


        if (Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED && !Config.AGENT_CONNECTED) {
            connecting_with_agent_text.setVisibility(View.VISIBLE);
            spinnerWL.setVisibility(View.VISIBLE);
            subscriberContainer.setVisibility(View.GONE);
        }

        if (Config.WHITE_AGENT_THUMBNAIL_BACKGROUND) {
            subscriberContainer.setBackgroundResource(R.color.light_gray);
        }

        if (Config.HIDE_USERS_PII_DATA && !Config.USER_PHONE_NO.equals("")) {
            retrieveTanInfoTextView.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS).replace("xxx", getHiddenPhoneNumber()));
            retrieveTanInfoTextViewModal.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS).replace("xxx", Util_Util.hidePhoneNum(Config.USER_PHONE_NO)));
        } else {
            retrieveTanInfoTextView.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS).replace("xxx", Config.USER_PHONE_NO));
            retrieveTanInfoTextViewModal.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_TEXT_SMS).replace("xxx", Config.USER_PHONE_NO));
        }

        textEnterIdentCode.setText(Util_Strings.getStringWithDefault(getApplicationContext(), Util_Strings.KEY_VIDEO_IDENT_IDENT_CODE_ENTER_CODE, LOCAL_KEY_VIDEO_IDENT_IDENT_CODE_ENTER_CODE));

        View.OnClickListener insertTanOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // replace the phone number the user has entered with the placeholder "xxx". this is necessary because the user maybe wants to change
                // the number he has entered.


                if (!Config.IDENT_CODE_BY_SMS && Config.IDENT_CODE_BY_EMAIL) {
                    if (Config.HIDE_USERS_PII_DATA && !Config.EMAIL_ADDRESS.equals("")) {
                        retrieveTanInfoTextView.setText(retrieveTanInfoTextView.getText().toString().replace(getHiddenEmail(), "xxx"));
                        retrieveTanInfoTextViewModal.setText(retrieveTanInfoTextView.getText().toString().replace(hideEmail(Config.EMAIL_ADDRESS), "xxx"));
                    } else {
                        retrieveTanInfoTextView.setText(retrieveTanInfoTextView.getText().toString().replace(Config.EMAIL_ADDRESS, "xxx"));
                        retrieveTanInfoTextViewModal.setText(retrieveTanInfoTextView.getText().toString().replace(Config.EMAIL_ADDRESS, "xxx"));
                    }
                }

                if (Config.IDENT_CODE_BY_SMS && Config.IDENT_CODE_BY_EMAIL && receiveTanByEmail) {
                    if (Config.HIDE_USERS_PII_DATA && !Config.EMAIL_ADDRESS.equals("")) {
                        retrieveTanInfoTextView.setText(retrieveTanInfoTextView.getText().toString().replace(getHiddenEmail(), "xxx"));
                        retrieveTanInfoTextViewModal.setText(retrieveTanInfoTextView.getText().toString().replace(hideEmail(Config.EMAIL_ADDRESS), "xxx"));
                    } else {
                        retrieveTanInfoTextView.setText(retrieveTanInfoTextView.getText().toString().replace(Config.EMAIL_ADDRESS, "xxx"));
                        retrieveTanInfoTextViewModal.setText(retrieveTanInfoTextView.getText().toString().replace(Config.EMAIL_ADDRESS, "xxx"));
                    }
                } else {

                    if (Config.HIDE_USERS_PII_DATA && !getHiddenPhoneNumber().equals("")) {
                        retrieveTanInfoTextView.setText(retrieveTanInfoTextView.getText().toString().replace(getHiddenPhoneNumber(), "xxx"));
                        retrieveTanInfoTextViewModal.setText(retrieveTanInfoTextView.getText().toString().replace(Util_Util.hidePhoneNum(Config.USER_PHONE_NO), "xxx"));
                    } else {
                        retrieveTanInfoTextView.setText(retrieveTanInfoTextView.getText().toString().replace(Config.USER_PHONE_NO, "xxx"));
                        retrieveTanInfoTextViewModal.setText(retrieveTanInfoTextView.getText().toString().replace(Config.USER_PHONE_NO, "xxx"));
                    }

                }
                retrieveTanView.setVisibility(View.VISIBLE);
                insertTanView.setVisibility(View.GONE);
                insertTanHintTextViewCode.setVisibility(View.GONE);
                insertTanHintTextView.setVisibility(View.GONE);
            }
        };
        if (!Config.FULL_SIZE_MODAL_SMS_WINDOW) {
            noReceivedTanButton = findViewById(R.id.buttonForgotTan);

            if (IDnowSDK.getNewBrand()) {
                noReceivedTanButton.setBackgroundResource(R.drawable.rounded_background_white);
            } else {
                noReceivedTanButton.setBackgroundResource(R.drawable.button_border);
            }

            noReceivedTanButton.setOnClickListener(insertTanOnClickListener);
        } else {
            insertTanTextView = findViewById(R.id.textViewInsertTan);
            insertTanTextView.setText(Util_Strings.getStringWithDefault(mContext, Util_Strings.KEY_VIDEO_IDENT_REQUEST_CODE_AGAIN, Util_Strings.LOCAL_KEY_VIDEO_IDENT_REQUEST_CODE_AGAIN));
            insertTanTextView.setOnClickListener(insertTanOnClickListener);
        }

        mPublisherViewContainer = findViewById(R.id.publisherView);
        mSubscriberViewContainer = findViewById(R.id.subscriberView);
        mSubscriberAudioOnlyView = findViewById(R.id.audioOnlyView);

        // E-Signature Views
        // collect the touch events, so the user cannot scroll the pdf-webview if the overlay is shown
        overlayView.setContentViewOnTouchListener((view, motionEvent) -> true);
        overlayView.getPdfWebView().allowFileAccess(false);
        overlayView.getButtonNext().setOnClickListener(v -> eSignatureNextStep(null));
        overlayView.showContractOnClickListener(v -> showContract(null));
        initEsignatureNativeViews();
        initCheckEntries();
        overlayView.setDeclineOnClickListener(v -> declineContract());
        overlayView.getSignContractView().setTextViewResignOnClickListener(v -> resignDocumentClick());
        handleWatermarkVisibility(poweredByView);

        // init tan views
        initIdentCodeViews();

        if (Config.SHOULD_DISPLAY_WAITING_SCREEN) {
            bottomLayout.setVisibility(View.GONE);
            poweredByView.setVisibility(View.GONE);
            waitScreen = new UI_WaitScreen(this);

            ViewGroup rootView = findViewById(R.id.mainlayoutFrame);
            waitScreen.inflateView(rootView);
        }

        ViewCompat.setOnApplyWindowInsetsListener(subscriberLayout, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.statusBars()
                            | WindowInsetsCompat.Type.displayCutout()
            );
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        runOnUiThread(() -> overlayView.initButtonStyles());
    }

    public void hideWaitingScreenCustomisationUI() {
        connecting_with_agent_text.setVisibility(View.GONE);
        spinnerWL.setVisibility(View.GONE);
        subscriberContainer.setVisibility(View.VISIBLE);
    }

    public void displayAbortUser() {
        if (Config.AGENT_CONNECTED && Config.CALL_ABORT_REASON_SCREEN) {
            ((Activities_VideoLiveStreamActivity_Super) mContext).feedback_title.setText(Util_Strings.getStringWithDefault(mContext, Util_Strings.KEY_USER_ABORT_FEEDBACK_TITLE, Util_Strings.LOCAL_KEY_USER_ABORT_FEEDBACK_TITLE));
            ((Activities_VideoLiveStreamActivity_Super) mContext).feedback_description.setText(Util_Strings.getStringWithDefault(mContext, Util_Strings.KEY_USER_ABORT_FEEDBACK_DESC, Util_Strings.LOCAL_KEY_USER_ABORT_FEEDBACK_DESC));

            ((Activities_VideoLiveStreamActivity_Super) mContext).feedback_cancel.setText(Util_Strings.getStringWithDefault(mContext, Util_Strings.KEY_USER_ABORT_CONTINUE_IDENTIFICATION, Util_Strings.LOCAL_KEY_USER_ABORT_CONTINUE_IDENTIFICATION));
            ((Activities_VideoLiveStreamActivity_Super) mContext).feedback_button.setText(Util_Strings.getStringWithDefault(mContext, Util_Strings.KEY_USER_ABORT_LEAVE_IDENTIFICATION, Util_Strings.LOCAL_KEY_USER_ABORT_LEAVE_IDENTIFICATION));

            RadioGroup.LayoutParams params_soiled = new RadioGroup.LayoutParams(getBaseContext(), null);
            params_soiled.setMargins(10, 10, 10, 10);

            if (USER_CANCELLATION_ENUM != null) {
                for (int i = 0; i < USER_CANCELLATION_ENUM.length; i++) {
                    RadioButton rb = new RadioButton(this); // dynamically creating RadioButton and adding to RadioGroup.
                    rb.setText(IDnowSDK.getInstance().getStringWithDefault(mContext, USER_ABORT_REASON + "." + USER_CANCELLATION_ENUM[i], null));
                    rb.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
                    rb.setTextColor(getColor(R.color.primarytextColor));
                    rb.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    rb.setButtonDrawable(R.drawable.radio_button_customised);
                    rb.setLayoutParams(params_soiled);
                    rb.setPadding(10, 10, 10, 10);
                    userAbort_radio.addView(rb);
                    View view = new View(this);
                    LinearLayout.LayoutParams lpView = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1);
                    view.setLayoutParams(lpView);
                    view.setBackgroundColor(Color.parseColor("#C9C6C4"));
                    userAbort_radio.addView(view);
                }
            }

            if (IDnowSDK.getNewBrand()) {
                feedback_button.setBackground(getResources().getDrawable(R.drawable.rounded_background_orange));
            } else {
                feedback_button.setBackground(getResources().getDrawable(R.drawable.rounded_button_orange));
            }

            if (Config.VIDEO_IDENT_PLUS) {
                ((Activities_VideoLiveStreamActivity_Super) mContext).logo_screen_feedback.setVisibility(View.VISIBLE);
                ((Activities_VideoLiveStreamActivity_Super) mContext).logo_screen_feedback.setAnimation("static_logo.json");

                if (Config.DARK_MODE) {
                    Util_UtilUI.setColorLottieAnimation(Color.WHITE, ((Activities_VideoLiveStreamActivity_Super) mContext).logo_screen_feedback, "SecondaryVariant");
                } else {
                    Util_UtilUI.setColorLottieAnimation(R.color.logo_fill, ((Activities_VideoLiveStreamActivity_Super) mContext).logo_screen_feedback, "SecondaryVariant");
                }

            } else {
                ((Activities_VideoLiveStreamActivity_Super) mContext).logo_screen_feedback.setVisibility(View.INVISIBLE);
            }

            if (IDnowSDK.getShowIDnowLogo()) {
                logo_screen_feedback.setVisibility(View.VISIBLE);
            } else {
                logo_screen_feedback.setVisibility(View.GONE);
            }

            if (Config.CALL_ABORT_REASON_SCREEN) {
                ((Activities_VideoLiveStreamActivity_Super) mContext).rateAgent_view.setVisibility(View.GONE);
                ((Activities_VideoLiveStreamActivity_Super) mContext).userAbort_view.setVisibility(View.VISIBLE);
            }
            ((Activities_VideoLiveStreamActivity_Super) mContext).feedback_button.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedId = userAbort_radio.getCheckedRadioButtonId() % USER_CANCELLATION_ENUM.length;
                    if (!(selectedId > 0 && selectedId <= USER_CANCELLATION_ENUM.length)) {
                        if (selectedId != -1) {
                            selectedId = USER_CANCELLATION_ENUM.length;
                        }
                    }

                    if (selectedId > 0) {
                        reason_to_cancel = USER_CANCELLATION_ENUM[selectedId - 1];

                        userAbort_radio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(RadioGroup group, int checkedId) {
                            }
                        });
                    } else {
                        reason_to_cancel = null;
                    }
                    UserAbortRestCall(reason_to_cancel);
                }

            });

            ((Activities_VideoLiveStreamActivity_Super) mContext).feedback_cancel.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    user_abort_feedback_view.setVisibility(View.GONE);
                    userAbort_radio.removeAllViews();
                    userAbort_radio.clearCheck();
                    selectedId = 0;

                    if (Config.WALLET_REGISTRATION) {
                        if (Config.ALERT_DIALOG_TO_SHOW.equals(KEY_ACCOUNT_REGISTER)) {
                            Util_UtilUI.showEsignDialog(mContext, Util_Strings.KEY_ACCOUNT_REGISTER, null, openTrustWebView);
                        } else if (Config.ALERT_DIALOG_TO_SHOW.equals(KEY_ACCOUNT_PASSWORD)) {
                            Util_UtilUI.showEsignDialog(mContext, Util_Strings.KEY_ACCOUNT_PASSWORD, null, openTrustWebView);
                        } else if (Config.ALERT_DIALOG_TO_SHOW.equals(KEY_ACCOUNT_UPDATE)) {
                            Util_UtilUI.showEsignDialog(mContext, Util_Strings.KEY_ACCOUNT_UPDATE, null, openTrustWebView);
                        } else if (Config.ALERT_DIALOG_TO_SHOW.equals(KEY_ACCOUNT_NOT_REM_PASSWORD)) {
                            Util_UtilUI.showEsignDialog(mContext, Util_Strings.KEY_ACCOUNT_NOT_REM_PASSWORD, null, openTrustWebView);
                        }
                    }

                    if (!Config.START_ESIGNING) {
                        if (VIDEO_IDENT_PLUS) {
                            video_ident_steps_layout.setVisibility(View.GONE);
                            video_ident_plus_layout.setVisibility(View.VISIBLE);
                        } else if (VIDEO_IDENT_PLUS_UI) {
                            video_ident_steps_layout.setVisibility(View.VISIBLE);
                            video_ident_plus_layout.setVisibility(View.GONE);
                        }
                    }
                }
            });
        }
    }

    public void hideWaitingScreeenCustomised() {
        if (waitingSheetDialog != null) {
            waitingSheetDialog.dismiss();
        }
    }

    public void hideWaitingScreen() {
        if (waitScreen != null) {
            waitScreen.removeView();
        }
        if (smsWaitScreen != null) {
            smsWaitScreen.removeView();
        }
    }

    /**
     * @param toResize
     * @param visibilitySizeFactor 0.1 - margin is 10% of view
     *                             0.5 - margin is 50% of view
     */
    private void resizeActivity(View toResize, double visibilitySizeFactor) {
        ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) toResize.getLayoutParams();
        layoutParams.height = (int) (getResources().getDisplayMetrics().heightPixels * visibilitySizeFactor);
        toResize.setLayoutParams(layoutParams);
    }

    private void removeIncludedViewFromFrameLayoutForGivenId(int viewId) {
        View retrieveTanUnused = findViewById(viewId);
        ((FrameLayout) retrieveTanUnused.getParent()).removeView(retrieveTanUnused);
    }

    private void initEsignatureNativeViews() {
        overlayView.setESignatureNextButtonEnabled(false);
        overlayView.setESignatureNextButtonListener(v -> {

            if(Config.OTP_DISPLAY_SIGNING){
                ViewGroup retrieveTanViewParent = (ViewGroup) retrieveTanView.getParent();
                if (retrieveTanViewParent != null) {
                    retrieveTanViewParent.removeView(retrieveTanView);
                }
                ViewGroup insertTanViewParent = (ViewGroup) insertTanView.getParent();
                if (insertTanViewParent != null) {
                    insertTanViewParent.removeView(insertTanView);
                }

                retrieveTanView.setBackgroundColor(mContext.getResources().getColor(R.color.bgPrimaryColor));
                insertTanView.setBackgroundColor(mContext.getResources().getColor(R.color.bgPrimaryColor));
                overlayView.addViewToESigningNativeContainer(retrieveTanView);
                overlayView.addViewToESigningNativeContainer(insertTanView);
                retrieveTanView.setVisibility(View.VISIBLE);
            }
            else {
                videoLiveStreamManager.sendConfirmationCodeRESTCall("", sendConfirmationCodeCallback);
            }
        });
        overlayView.setESignatureCancelListener(v -> Util_UtilUI.showCancelNativeESigningDialog(mContext, false));
    }

    private void initCheckEntries() {
        checkEntries = new ArrayList<>();
        checkEntries.add(
                new SpannableString("\"Ich, PETER MÜLLER, beautrage xxx hiermit, in meinem Namen ein Zertifikat auszustellen, um dieses Dokument zu unterschreiben. Es gelten die AGBs von xxx"));
        checkEntries.add(
                new SpannableString("Hiermit bestätige ich die Richtigkeit meiner persönlichen Daten, wie diese oben angezeigt werden. Ich erkläre mich damit einverstanden, dass diese Daten als Teil des Zertifikates, welches zum Signieren verwendet wird, übermittelt werden. Darüber hinaus bestätige ich die Nutzungsbedingungen zum Signierungsprozess gelese zu haben."));
    }

    private void updateCheckEntries() {
        checkEntriesImageViews = new ArrayList<>();
        for (SpannableString s : checkEntries) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            View view = inflater.inflate(R.layout.view_checkbox_element, null);
            ImageView checkMark = view.findViewById(R.id.eSigningCheckMark);
            Util_UtilUI.setCheckMark(checkMark, false);
            checkMark.setTag(false);

            TextView textView = view.findViewById(R.id.eSigningCheckTextView);
            textView.setClickable(true);
            textView.setText(s);
            textView.setMovementMethod(LinkMovementMethod.getInstance());
            textView.setLinkTextColor(getResources().getColor(R.color.link));

            view.setOnClickListener(new UI_CustomOnClickListenerCheckMark());
            view.setPadding(Util_UtilUI.getPxFromDp(mContext, 8), Util_UtilUI.getPxFromDp(mContext, 8), Util_UtilUI.getPxFromDp(mContext, 8), Util_UtilUI.getPxFromDp(mContext, 8));

            overlayView.addViewToESigningCheckboxContainer(view);
        }
    }

    public void openPushDialogPanel() {
        boolean timerElapsed = (System.currentTimeMillis() - (1000 * Config.WAITING_LIST_NOTIFICATIONS_TIMEOUT)) >= timer;

        if (Config.WAITING_LIST_NOTIFICATIONS_ENABLED &&
                !Config.SHOULD_DISPLAY_WAITING_SCREEN &&
                !Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE &&
                (Config.FIREBASE_NOTIFICATION_TOKEN != null || Config.WAITING_LIST_NOTIFICATIONS_CHANNEL.equals("SMS")) &&
                !conferenceStarted || IDnowSDK.isForcedWaitingList()) {

            if (timerElapsed || (Config.IDENT_POSITION_IN_QUEUE >= Config.WAITING_LIST_NOTIFICATIONS_TRESHOLD) || IDnowSDK.isForcedWaitingList()) {
                Util_Log.i(LOGTAG, "Push notification panel opened.");
                explanationView.setNotifyViaPushViewVisibility(true);
                explanationView.setDividerTopVisibility(false);
            }
        }
    }

    protected void closePushDialogPanel() {
        Util_Log.i(LOGTAG, "Push notification panel closed.");
        explanationView.setNotifyViaPushViewVisibility(false);
        explanationView.setDividerTopVisibility(true);
    }

    public void openPushLowerPanel() {
        if (Config.SHOULD_DISPLAY_WAITING_SCREEN) {
            bottomLayout.setVisibility(View.VISIBLE);
        }

        Util_Log.i(LOGTAG, "Open notification input panel");
        explanationView.getNotifyViaPushView().setPanelsVisibility(false, false, true);

        videoLiveStreamManager.prepareCustomMessagesViaRestFromJSON("js.waitingList.enforced", message -> explanationView.getNotifyViaPushView().setNotifyViaPushDetailsText(message));

        EditText waitScreenEditText = explanationView.getNotifyViaPushView().getWaitScreenEditText();
        waitScreenEditText.setText("");
        waitScreenEditText.setVisibility(View.INVISIBLE);

        connecting_with_agent_text.setVisibility(View.GONE);
        spinnerWL.setVisibility(View.GONE);

        explanationView.getNotifyViaPushView().setWaitScreenSmsNotifyButtonOnClickListener(v -> {
            prefs = getApplicationContext().getSharedPreferences("waiting", MODE_PRIVATE);
            editor = prefs.edit();
            Config.WAITING_DONE = true;
            Config.SAVED_TOKEN = IDnowSDK.getTransactionToken();
            editor.putBoolean("receiveWaiting", Config.WAITING_DONE).apply();
            editor.putString("receiveToken", Config.SAVED_TOKEN).apply();

            Config.USER_PHONE_NO = waitScreenEditText.getText().toString();

            if (Config.WAITING_LIST_NOTIFICATIONS_CHANNEL.equals("SMS")) {
                videoLiveStreamManager.updateMobilePhoneNumber(IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken(), Config.USER_PHONE_NO, null, updateMobileNumberCallback);
            } else {
                videoLiveStreamManager.subscribeToForPushNotifications(IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken(), subscribeCallback);
            }
        });
    }

    public ClickableSpan clickLink(String link) {
        ClickableSpan clickableSpan = new ClickableSpan() {
            public void onClick(View textView) {
                Util_Log.i(LOGTAG, "Approval phrases link or file path : " + link);
                if (link != null) {
                    if (link.contains("https")) {
                        Intent browserIntent = new Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse(link));
                        startActivity(browserIntent);
                    } else if (!link.contains("pdf") && !link.equals("")) {
                        Util_UtilWebsocket.openUrlInNewBrowserTask(mContext, Config.CURRENT_SERVER.getWebHost(IDnowSDK.getTransactionToken()) + link);
                    } else {
                        if (link.equals("")) {
                            Toast.makeText(mContext, "currently the PDF document is not possible to load", Toast.LENGTH_LONG).show();
                        } else {
                            Intent intent = new Intent(mContext, Activities_PDFViewer.class);
                            startActivity(intent);
                        }
                    }
                }
            }
        };

        return clickableSpan;
    }

    public void openPushSuccessPanel() {
        Util_Log.i(LOGTAG, "Open notification success panel");

        logExternally(getApplicationContext(), "Open notification success panel", LogEventTypeEnum.INFO.get());

        View explanationView = findViewById(R.id.explanationContainer);
        explanationView.setVisibility(View.GONE);
        View aboveExplanationView = findViewById(R.id.subscriberLayout);
        aboveExplanationView.setVisibility(View.GONE);

        if (Config.SHOULD_DISPLAY_WAITING_SCREEN_CUSTOMISED && !Config.AGENT_CONNECTED) {
            explanationView.setVisibility(View.GONE);
        }

        View successPanel = findViewById(R.id.notifyViaPushSuccessLayout);
        successPanel.setVisibility(View.VISIBLE);
        TextView textView = findViewById(R.id.notifyViaPushSuccessText);
        textView.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_WAITING_LIST_SUCCESS_SMS_MSG, LOCAL_KEY_VIDEO_IDENT_WAITING_LIST_SUCCESS_SMS_MSG));

        String jsonKey;
        if (Config.WAITING_LIST_NOTIFICATIONS_ENROLLED) {
            jsonKey = "js.waitingList.enforcedEnrolled";
        } else {
            jsonKey = "js.waitingList.enforcedSuccess";
        }
        videoLiveStreamManager.prepareCustomMessagesViaRestFromJSON(jsonKey, message -> textView.setText(message));

        Button sendButton = findViewById(R.id.notifyViaPushSuccessBackButton);
        sendButton.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_SUCCESS_HOME_BUTTON, LOCAL_KEY_VIDEO_IDENT_SUCCESS_HOME_BUTTON));
        sendButton.setOnClickListener(v -> confirmWaitAndReturn());
    }

    public void confirmWaitAndReturn() {
        if (!IDnowSDK.getOverrideEntryActivity()) {
            Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity.class;
        }
        Intent intent = new Intent(mContext, Config.HOST_APP_START_ACTIVITY);
        intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        IDnowSDK.updateResultCode(3);
        finishAndRemoveTask();
        IDnowSDK.getInstance().deliverResult(3, getIntent());
        setResult(3, getIntent());
        finishAndRemoveTask();
        if ((!Config.BACK_TO_VID) || IDnowSDK.getOverrideEntryActivity()) {
            startActivity(intent);
        }
    }

    public void returnFromSDK() {
        int resultCode = IDnowSDK.RESULT_USER_IN_QUEUE;
        Intent onBackPressedIntent = new Intent();
        IDnowSDK.getInstance().deliverResult(resultCode, onBackPressedIntent);
        setResult(resultCode, onBackPressedIntent);
        finishAndRemoveTask();
    }

    protected void closePushLowerPanel() {
        IDnowSDK.setForcedWaitingList(false);
        Util_Log.i(LOGTAG, "Close notification input panel");

        logExternally(getApplicationContext(), "Close notification input pane;", LogEventTypeEnum.INFO.get());

        View upperPanel = findViewById(R.id.notifyViaPushUpperPanel);
        upperPanel.setVisibility(View.VISIBLE);
        View lowerPanel = findViewById(R.id.notifyViaPushLowerPanel);
        lowerPanel.setVisibility(View.GONE);
    }

    /**
     * initializes the views of the overlay of the request and insert tan step.
     * checks if requesting the ident code by email is available.
     */
    private void initIdentCodeViews() {
        checkViewCodeBySMS = findViewById(R.id.phoneCheckBox);
        checkViewCodeByEmail = findViewById(R.id.emailCheckBox);

        codeBySmsContainer = findViewById(R.id.identCodeBySMSContainer);
        codeByEmailContainer = findViewById(R.id.identCodeByEmailContainer);

        insertEmailEditText.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                view.onTouchEvent(motionEvent);
                codeByEmailContainer.performClick();
                receiveTanByEmail = true;

                manageEditText(insertEmailEditText, "EMAIL");

                return false;
            }
        });

        insertPhoneNrEditText.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                view.onTouchEvent(motionEvent);
                codeBySmsContainer.performClick();
                receiveTanByEmail = false;

                manageEditText(insertPhoneNrEditText, "PHONE");

                return false;
            }
        });

        if (Config.IDENT_CODE_BY_EMAIL && !Config.IDENT_CODE_BY_SMS) {
            codeByEmailContainer.setVisibility(View.VISIBLE);
            codeBySmsContainer.setVisibility(View.GONE);
            checkViewCodeByEmail.setVisibility(View.GONE);
            setupIdentCodeByEmail();
        } else if (Config.IDENT_CODE_BY_EMAIL && Config.IDENT_CODE_BY_SMS) {
            codeByEmailContainer.setVisibility(View.VISIBLE);
            codeBySmsContainer.setVisibility(View.VISIBLE);
            checkViewCodeByEmail.setVisibility(View.VISIBLE);
            checkViewCodeBySMS.setVisibility(View.VISIBLE);
            setupIdentCodeByEmail();
        } else {
            checkViewCodeBySMS.setVisibility(View.GONE);
            codeByEmailContainer.setVisibility(View.GONE);
        }
    }

    /**
     * initializes the views for requesting the tan by email.
     */
    private void setupIdentCodeByEmail() {
        // preselect the check button for requesting the tan by sms.
        checkViewCodeBySMS.setTag(true);
        checkViewCodeByEmail.setTag(false);

        Util_UtilUI.setCheckMark(checkViewCodeBySMS, true);
        Util_UtilUI.setCheckMark(checkViewCodeByEmail, false);

        codeBySmsContainer.setOnClickListener(new UI_CustomLinearLayoutRadioGroupOnClickListener(codeByEmailContainer));
        codeByEmailContainer.setOnClickListener(new UI_CustomLinearLayoutRadioGroupOnClickListener(codeBySmsContainer));

        codeBySmsContainer.setTag(checkViewCodeBySMS);
        codeByEmailContainer.setTag(checkViewCodeByEmail);
    }

    /**
     * initializes the notification, that appears when user puts the app to the background. one single code is used, so every time a notification is created, it replaces the old one
     */
    public void updateNotification() {
        // only trigger the notification, when the process isn't about to end (because user or agent canceled the call)
        if (!activityIsFinishing) {
            mConnection = new ServiceConnection() {
                @TargetApi(VERSION_CODES.JELLY_BEAN)
                @Override
                public void onServiceConnected(ComponentName className, IBinder binder) {
                    ((KillBinder) binder).service.startService(new Intent(mContext, Util_KillNotificationService.class));

                    mNotifyBuilder = new Notification.Builder(mContext)
                            .setContentTitle(explanationView.getExplanationTitleText())
                            .setContentText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_NOTIF_CONTENT, LOCAL_KEY_VIDEO_IDENT_NOTIF_CONTENT))
                            .setSmallIcon(R.drawable.action_activate_flash)
                            .setOngoing(true);

                    Intent notificationIntent = new Intent(mContext, Util_VideoStreamService.getClassForVideoLiveStreaming());
                    notificationIntent.setFlags(FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    PendingIntent intent = PendingIntent.getActivity(mContext, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);

                    Util_Util.getNotificationPendingIntent(mContext).cancel();

                    mNotifyBuilder.setContentIntent(intent);
                    mNotificationManager.notify(Config.NOTIFICATION_ID, mNotifyBuilder.build());
                }

                @Override
                public void onServiceDisconnected(ComponentName className) {
                }

            };

            try {
                bindService(new Intent(Activities_VideoLiveStreamActivity_Super.this, Util_KillNotificationService.class), mConnection, Context.BIND_AUTO_CREATE);
                mIsBound = true;
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Bind service failed", e);

                logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.ERROR.get());
                logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.INFO.get());


            }
        }
    }


    /**
     * sets the text and title of the explanation view according to the current step
     * <p/>
     * Flow:
     * 1. "Warten auf freien Mitarbeiter"
     * 2. "Name und Foto"
     * 3. "Ausweis Vorderseite"
     * 4. "Ausweis Vorderseite" - Sicherheitsmerkmale
     * 5. "Ausweis Vorderseite" - Ausweisnummer
     * 6. "Ausweis Rückseite"
     * 7. "Ausweis Rückseite" - Sicherheitsmerkmale
     * 8. "Ident-Code eingeben"
     * 9. "Identifizierung beendet"
     *
     * @param websocketResponse
     */

    public void updateExplanationView(final String websocketResponse) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                int stepCounter = Config.EXPLANATION_STEP_PER_SOCKET_RESPONSES.get(websocketResponse);

                if (Config.VIDEO_IDENT_PLUS_UI) {
                    mainTextDescription.setText(Util_Strings.getVideoIdentStepTitle(contextVIP, stepCounter));
                    textDescription.setText(Util_Strings.getVideoIdentStepText(contextVIP, stepCounter));

                    if (stepCounter == 2) {
                        Util_Log.d("COUNTLY LOG", "EVENT_CQC_SCREEN_SHOWN");
                    }
                }

                signatureMask.setVisibility(View.GONE);

                if (websocketResponse.equals(Config.COMMAND_FINISHED_FACE)) {

                    if (Config.VIDEO_IDENT_PLUS) {
//						video_ident_plus.setBackgroundDrawable(ContextCompat.getDrawable(contextVIP,R.drawable.bg_card_middle));
                        setCameraCutoutOverlayType(CameraCutoutOverlayType.Document);
                    } else {
                        helperImageContainer.setVisibility(View.VISIBLE);
                    }
                    Util_CustomLogData.setEventData(Util_CustomLogData.EVENT_SECURITY_STEPS_FRONT_OF_ID_SCREEN_SHOWN, "EVENT_SECURITY_STEPS_FRONT_OF_ID_SCREEN_SHOWN", "FRONT SIDE ID", "Screen", null);

                } else if (websocketResponse.equals(Config.COMMAND_FINISHED_ID_FRONTSIDE)) {
                    if (Config.VIDEO_IDENT_PLUS) {
                        cameraCutoutOverlay.setVisibility(View.GONE);
                    } else {
                        helperImageContainer.setVisibility(View.GONE);
                    }
                } else if (websocketResponse.equals(Config.COMMAND_WIGGLE_DONE)) {
                    if (Config.VIDEO_IDENT_PLUS) {
                        setCameraCutoutOverlayType(CameraCutoutOverlayType.Document);
                    } else {
                        helperImageContainer.setVisibility(View.VISIBLE);
                    }
                } else if (websocketResponse.equals(Config.COMMAND_FINISHED_ID_BACKSIDE)) {
                    if (Config.VIDEO_IDENT_PLUS) {
                        cameraCutoutOverlay.setVisibility(View.GONE);
                    } else {
                        helperImageContainer.setVisibility(View.GONE);
                    }
                } else if (websocketResponse.equals(Config.COMMAND_FINISHED)) {

                }

                // idNumberDone -> show loading text for esigning
                if (stepCounter == 7 && Config.E_SIGNING) {
                    explanationView.setTextViewExplanationContentText(Util_Strings.getVideoIdentStepText(getApplicationContext(), 99));
                    explanationView.setTextViewExplanationTitleText(Util_Strings.getVideoIdentStepTitle(getApplicationContext(), 99));
                    Util_Log.i(LOGTAG, "step: " + stepCounter);
                    locateChatButton(true);
                }

                // tanDone -> hide esigning overlay
                else if (stepCounter == 8 && Config.E_SIGNING) {
                    overlayView.setVisibility(View.GONE);
                    subscriberContainer.setVisibility(View.VISIBLE);

                    explanationView.setTextViewExplanationTitleText(Util_Strings.getStringWithDefault(mContext, KEY_VIDEO_IDENT_ESIGN_BEING_COMPLETED_TITLE, LOCAL_KEY_VIDEO_IDENT_ESIGN_BEING_COMPLETED_TITLE));
                    explanationView.setTextViewExplanationTitleText(Util_Strings.getStringWithDefault(mContext, KEY_VIDEO_IDENT_COMPLETE_ESIGN, LOCAL_KEY_VIDEO_IDENT_COMPLETE_ESIGN));
                    explanationView.setTextViewExplanationContentText("");

                    locateChatButton(true);

                    if (Config.VIDEO_IDENT_PLUS) {

                        if (Config.VIDEO_IDENT_PLUS_UI) {
                            if(!isInPictureInPictureMode()) {
                                takePictureLayout.setVisibility(View.VISIBLE);
                            }
                            agent_card_normal.setVisibility(View.VISIBLE);
                            card_vip.setVisibility(View.GONE);
                            mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC6, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC6));
                            textDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_IDENT_FINISHED, LOCAL_KEY_VIDEO_IDENT_PLUS_IDENT_FINISEDH));
                            circle1.setVisibility(View.GONE);
                            circle2.setVisibility(View.GONE);
                            circle3.setVisibility(View.GONE);
                            circle4.setVisibility(View.GONE);

                        } else {

                        }

                    }
                }
                // SIGNATURE
                else if (stepCounter == 25) {
                    explanationView.setTextViewExplanationContentText(Config.SIGNATURE_EXPLANATION_CONTENT);
                    explanationView.setTextViewExplanationTitleText(Config.SIGNATURE_EXPLANATION_TITLE);
                    signatureMask.setVisibility(View.GONE);
                    locateChatButton(false);
                } else {
                    if (stepCounter == 7 && Config.SIGNATURE_EXPLANATION_TITLE.equals("")) {
                        explanationView.setExplanationTitleVisibility(View.INVISIBLE);
                    } else {
                        explanationView.setExplanationTitleVisibility(View.VISIBLE);
                    }

                    explanationView.setTextViewExplanationContentText(Util_Strings.getVideoIdentStepText(getApplicationContext(), stepCounter));
                    explanationView.setTextViewExplanationTitleText(Util_Strings.getVideoIdentStepTitle(getApplicationContext(), stepCounter));
                    Util_Log.i(LOGTAG, "step: " + stepCounter);
                    locateChatButton(true);

                    identificationIsAtStep1 = false;
                    //   }
                }

                setSubscriberViewToInitialPosition();
            }
        });
    }


    public class CustomComparator implements Comparator<Camera.Size> {
        @Override
        public int compare(Camera.Size size1, Camera.Size size2) {
            return size1.width > size2.width ? 1 : (size1.width < size2.width ? -1 : compareHeight(size1, size2));
        }

        private int compareHeight(Camera.Size size1, Camera.Size size2) {
            return size1.height > size2.height ? 1 : (size1.height < size2.height ? -1 : 0);
        }
    }

    public void setcompleteScreenVisible() {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {

                if (!Config.WALLET_VIP) {
                    if (Config.VIDEO_IDENT_PLUS && !Config.VIDEO_IDENT_PLUS_UI) {
                        if (status_layout != null) {
                            status_layout.setBackgroundDrawable(ContextCompat.getDrawable(contextVIP, R.drawable.rounded_bg_complete));
                        }
                        num_text.setTextColor(contextVIP.getResources().getColor(R.color.num_text_color));
                        idcard_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_AGENT_COMPLETE, LOCAL_KEY_VIDEO_IDENT_AGENT_COMPLETE));
                        idcard_text.setTextColor(contextVIP.getResources().getColor(R.color.num_text_color));

                    } else {

                        if (Config.VIDEO_IDENT_PLUS) {
                            card_vip.setVisibility(View.GONE);
                            agent_card_normal.setVisibility(View.VISIBLE);
                        }
                    }

                    if (Config.VIDEO_IDENT_PLUS) {
                        idcard_text.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_AGENT_COMPLETE, LOCAL_KEY_VIDEO_IDENT_AGENT_COMPLETE));
                        mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC6, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC6));
                        circle1.setVisibility(View.GONE);
                        circle2.setVisibility(View.GONE);
                        circle3.setVisibility(View.GONE);
                        circle4.setVisibility(View.GONE);
                        if (!Config.VIDEO_IDENT_PLUS_UI) {
                            textDescription.setVisibility(View.GONE);
                        }
                    }
                }
            }
        });
    }

    /**
     * on some devices the subscriber view slides off the screen. this is a probable fix for this issue.
     * the subscriberView is set to it's origin position after each step.
     */
    private void setSubscriberViewToInitialPosition() {
        if(isInPictureInPictureMode()) {
            return;
        }
        try {
            if (subscriberLayout != null) {
                // initial fetching of the position. once set, it doesn't have to be read anymore.
                if (subscriberLayoutX == 0) {
                    int[] coordinates = new int[2];
                    subscriberLayout.getLocationOnScreen(coordinates);
                    subscriberLayoutX = coordinates[0];

                    // the height of the status bar has to be removed from the y-position.
                    subscriberLayoutY = coordinates[1] - Util_Util.getStatusBarHeight(Activities_VideoLiveStreamActivity_Super.this);
                }

                // for each userstep, reset the position of the subscriberLayout, so if it wants to slide off the screen, it immediately gets resetted to its origin position.
                subscriberLayout.setX(subscriberLayoutX);
                subscriberLayout.setY(subscriberLayoutY);
                Util_Log.i(LOGTAG, "resetting the position of the subscriberLayout");
            }

        } catch (Exception e) {
            logExternally(this, "Resetting the position was not possible: ", LogEventTypeEnum.ERROR.get());
            logExternally(this, "Resetting the position was not possible: ", LogEventTypeEnum.INFO.get());
            Util_Log.e(LOGTAG, "Resetting the position for subscriber layout failed", e);
        }
    }


    public void initESignature() {
        overlayView.getPdfWebView().initDocumentsSpinner();
        initDrawingView();
    }

    /**
     * handles the visibility of views like the insert-phone-no or insert-ident-code view
     *
     * @param step
     */
    public void setCurrentStep(final int step) {
        runOnUiThread(new Runnable() {
                          @Override
                          public void run() {
                              if (step == currentUserStep || (step == 4 && currentUserStep == 5)) {
                                  currentUserStep = step;
                                  return;
                              }

                              // start the e_signing process/the sending of the tan
                              if (step == 4 && !Config.E_SIGNING) {
                                  if (Config.IDENT_CODE_REQUIRED) {
                                      if (Config.VIDEO_IDENT_PLUS) {
                                          setRequestScreenVisible(Boolean.TRUE);
                                      } else {
                                          if (Config.SHOULD_DISPLAY_WAITING_SCREEN) {
                                              hideWaitingScreen();
                                          }
                                          retrieveTanView.setVisibility(View.VISIBLE);

                                      }
                                      explanationView.setVisibility(View.GONE);
                                      bottomLayout.setVisibility(View.GONE);
                                      locateChatButton(false);
                                  } else {
                                      completeIdentificationView.setVisibility(View.VISIBLE);
                                      locateChatButton(true);
                                      explanationView.setVisibility(View.GONE);
                                  }
                              }
                              // user has send the token he got per sms, hide all the overlays and return to the "default" view
                              else if (step == 5 && (!Config.E_SIGNING || !Config.IDENT_CODE_REQUIRED)) {
                                  completeIdentificationView.setVisibility(View.GONE);
                                  bottomLayout.setVisibility(View.VISIBLE);
                                  explanationView.setVisibility(View.VISIBLE);
                                  locateChatButton(true);
                              } else {
                                  completeIdentificationView.setVisibility(View.GONE);
                                  retrieveTanView.setVisibility(View.GONE);
                                  explanationView.setVisibility(View.VISIBLE);
                                  bottomLayout.setVisibility(View.VISIBLE);
                                  locateChatButton(true);
                              }

                              currentUserStep = step;
                          }
                      }
        );
    }

    public Runnable requestVideoChatRESTCallRunnable = () -> videoLiveStreamManager.requestVideoChatRESTCall(requestVideoChatCallback);

    public void prepareSigningSession() {
        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Models_EmptyJson> callback = new Callback<Models_EmptyJson>() {
            @Override
            public void success(Models_EmptyJson resultObject, Response response) {
                loadNamirialSigning();
            }

            @Override
            public void failure(RetrofitError error) {
                progressBarLoading.setVisibility(View.INVISIBLE);
                String result = "";

                result = Util_UtilRetrofit.printRetrofitError(error);

                logExternally(mContext, "error : " + result, LogEventTypeEnum.ERROR.get());

                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                }

                if (error != null && error.getResponse() != null) {
                    Util_UtilUI.showRESTCallErrorDialog(mContext, 500, false, null, result, true, false, "");
                } else {
                    Util_UtilUI.showRESTCallErrorDialog(mContext, 0, true, null, result, false, false, "");
                }
            }
        };

        retrofit2.Call<Models_EmptyJson> result = service
                .prepareSigningSession(
                        new Models_EmptyJson(),
                        IDnowSDK.getCompanyId(),
                        IDnowSDK.getTransactionToken(), null);
        result.enqueue(callback);
    }

    public void sendIdentCodeToPhoneRESTCall() {

        String endPoint = Config.CURRENT_SERVER.getApiHost(IDnowSDK.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, IDnowSDK.getInstance().getAppContext());

        Callback<Object> callback = new Callback<Object>() {

            @Override
            public void failure(RetrofitError error) {

                Util_Log.i(LOGTAG, "http sendIdentCode REST Call was failed");


                retrieveTanButton.setEnabled(true);
                String result, errorCause;
                result = Util_UtilRetrofit.printRetrofitError(error);
                errorCause = Util_UtilRetrofit.getErrorCauseRetrofit(result);
                logExternally(getApplicationContext(), "error : " + result, LogEventTypeEnum.ERROR.get());
                logExternally(getApplicationContext(), "error : " + result, LogEventTypeEnum.INFO.get());


                if (!result.equals("")) {
                    result = Util_UtilRetrofit.getErrorIdRetrofit(result);
                }

                if (error != null && error.getResponse() != null && isActivityRunning) {
                    Util_UtilUI.showSendingTanErrorDialog(mContext, error.getResponse().getStatus(), false, result, errorCause, !receiveTanByEmail);

                } else {
                    if (isActivityRunning) {
                        Util_UtilUI.showSendingTanErrorDialog(mContext, 0, false, result, errorCause, !receiveTanByEmail);
                    }
                }

                retrieveTanView.setVisibility(View.GONE);
                if (!Config.VIDEO_IDENT_PLUS) {
                    insertTanView.setVisibility(View.VISIBLE);
                }
                setPaintFlagsOnInsertTanTextView();
                insertTanHintTextView.setVisibility(View.GONE);
                insertTanHintTextViewCode.setVisibility(View.GONE);
            }

            @Override
            public void success(Object resultObject, Response response) {
                retrieveTanButton.setEnabled(true);
                Util_Log.i(LOGTAG, "http sendIdentCode REST Call was successful : " + resultObject.toString() + " " + response.isSuccessful());

                if (Config.HIDE_USERS_PII_DATA) {
                    Util_Util.updateMaskedData(this);
                }

                if (Config.VIDEO_IDENT_PLUS && !E_SIGNING) {
                    Util_Log.i(LOGTAG, "http to enter setEnterCodeScreenVisible");
                    setEnterCodeScreenVisible();
                } else {

                    if (takePictureButton != null) {
                        takePictureButton.setVisibility(View.GONE);
                    }
                    retrieveTanView.setVisibility(View.GONE);
                    insertTanView.setVisibility(View.VISIBLE);
                    setPaintFlagsOnInsertTanTextView();
                    insertTanHintTextView.setVisibility(View.GONE);
                }

            }

        };

        if (Config.IDENT_CODE_BY_EMAIL && !Config.IDENT_CODE_BY_SMS) {
            Util_Log.i(LOGTAG, "http send code by email");

            receiveTanByEmail = true;
            retrofit2.Call<Object> result = service
                    .requestConfirmationTokenByEmail(
                            new Models_Email(Config.EMAIL_ADDRESS),
                            IDnowSDK.getCompanyId(),
                            IDnowSDK.getTransactionToken()
                    );
            result.enqueue(callback);
        } else if (Config.IDENT_CODE_BY_EMAIL && Config.IDENT_CODE_BY_SMS) {
            boolean smsChecked = (boolean) checkViewCodeBySMS.getTag();
            if (Config.VIDEO_IDENT_PLUS) {
                Util_Log.i(LOGTAG, "http send code by phone");

                retrofit2.Call<Object> result = service.requestConfirmationToken(new Models_MobileNumber(Config.USER_PHONE_NO), IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken());
                result.enqueue(callback);
            } else if (smsChecked) {
                Util_Log.i(LOGTAG, "http send code by phone");

                receiveTanByEmail = false;
                retrofit2.Call<Object> result = service.requestConfirmationToken(new Models_MobileNumber(Config.USER_PHONE_NO), IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken());
                result.enqueue(callback);

            } else {
                Util_Log.i(LOGTAG, "http send code by email");

                receiveTanByEmail = true;
                retrofit2.Call<Object> result = service
                        .requestConfirmationTokenByEmail(
                                new Models_Email(Config.EMAIL_ADDRESS),
                                IDnowSDK.getCompanyId(),
                                IDnowSDK.getTransactionToken()
                        );
                result.enqueue(callback);
            }
        } else {
            Util_Log.i(LOGTAG, "http send code by phone");
            retrofit2.Call<Object> result = service.requestConfirmationToken(new Models_MobileNumber(Config.USER_PHONE_NO), IDnowSDK.getCompanyId(), IDnowSDK.getTransactionToken());
            result.enqueue(callback);
        }

    }

    public void setEnterCodeScreenVisible() {
        retrieveTanView.setVisibility(View.GONE);
        insertTanView.setVisibility(View.GONE);
        if (requestIdentCodeButton != null) {
            requestIdentCodeButton.setVisibility(View.GONE);
        }
        layoutAction_1.setVisibility(View.VISIBLE);

        if (Config.IDENT_CODE_BY_EMAIL && !IDENT_CODE_BY_SMS) {
            mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC5_EMAIL, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC5_EMAIL));
        } else {
            mainTextDescription.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC5, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_DESC5));
        }
        textSMSCode.setInputType(InputType.TYPE_CLASS_PHONE);
        textSMSCode.setText("");
        textSMSCode.setHint(R.string.sms_code);
        setTextSMSCodeEditable(true);

        retakeAction.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_BUTTON_RESEND, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_WAITING_BUTTON_RESEND));
        continueButton.setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_BUTTON_CONFIRM, LOCAL_KEY_VIDEO_IDENT_PLUS_TAKE_AGENT_BUTTON_CONFIRM));

        retakeButton.setOnClickListener(v -> {
            // replace the phone number the user has entered with the placeholder "xxx". this is necessary because the user maybe wants to change
            // the number he has entered.
            setRequestScreenVisible(Boolean.TRUE);
        });

        continueButton.setOnClickListener(v -> runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // only trigger REST call, if the edittext isn't empty
                if (!Util_UtilUI.isEditTextEmpty(textSMSCode, true, Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_TAN_HINT_ENTER_CODE, LOCAL_KEY_VIDEO_IDENT_TAN_HINT_ENTER_CODE))) {
                    // prevent double click by checking if the last click has been performed more than 2 seconds ago
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) {
                        Util_Log.i(LOGTAG, "clicked too fast");

                    } else {
                        // if the user enters very fast the code and presses the button, a delay between the entered code and button click is
                        // possible. this means that not the whole code is used, but only a part of it. so add a delay for calling the button
                        // click.
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {

                            @Override
                            public void run() {
                                Util_Util.hideSoftKeyboard(Activities_VideoLiveStreamActivity_Super.this);

                                if (textSMSCode != null) {
                                    textSMSCodeResult = textSMSCode.getText().toString();
                                }

                                videoLiveStreamManager.sendConfirmationCodeRESTCall(textSMSCodeResult, sendConfirmationCodeCallback);
                            }
                        }, 500);
                    }

                    lastClickTime = SystemClock.elapsedRealtime();
                }
            }
        }));
    }

    private void setPaintFlagsOnInsertTanTextView() {
        if (Config.FULL_SIZE_MODAL_SMS_WINDOW) {
            insertTanTextView.setPaintFlags(insertTanTextView.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        }
    }

    /**
     * gets called when the identification is closed by an error (not by the user)
     */
    public void identificationFailedRESTCall() {
        userCanceledIdentification();
        progressBarLoading.setVisibility(View.VISIBLE);
        IdentificationFailedCallback callback = () -> triggerOnBackPressed(IDnowSDK.RESULT_CODE_FAILED);
        videoLiveStreamManager.identificationFailedRESTCall(callback);
    }

    public void userCanceledIdentification() {
        Config.E_SIGNING_IN_PROGRESS = false;
        manuallyClosedActivity = true;
        activityIsFinishing = true;
    }

    /**
     * gets called when the user cancels the identification
     */

    public void identificationCanceled() {
        userInitiatedCancellation = true;
        progressBarLoading.setVisibility(View.VISIBLE);
        userCanceledIdentification();
        triggerOnBackPressed(IDnowSDK.RESULT_CODE_CANCEL);
        videoLiveStreamManager.identificationCanceledRESTCall(null, identificationCanceledCallback);
    }

    public void signingCanceledRESTCall() {
        progressBarLoading.setVisibility(View.VISIBLE);
        userCanceledIdentification();
        videoLiveStreamManager.signingCanceledRESTCall(() -> triggerOnBackPressed(IDnowSDK.RESULT_CODE_CANCEL));
    }

    public void setupImageStreamPush(byte[] imageString, String imageType) {
        imageStringToPush = imageString;

        imageTypeToPush = imageType;

        // if another picture is currently uploaded, don't trigger a new upload but write a log
        synchronized (currentlyUploadingPicture) {
            if (currentlyUploadingPicture) {
                Util_Log.i(LOGTAG, "upload image request will be ignored, because another upload is still running!");
            } else {
                currentlyUploadingPicture = true;

                try {
                    new ImageUploader().execute("");
                } catch (Exception e) {
                    logExternally(this, "Unable to upload image : " + e.getMessage(), LogEventTypeEnum.ERROR.get());
                    Util_Log.e(LOGTAG, "Unable to upload image", e);
                    currentlyUploadingPicture = false;
                }
            }
        }
    }

    public void handleCheckMarkClicked(ImageView view) {
        if (checkEntries != null && checkEntriesImageViews != null) {
            if (checkEntriesImageViews.contains(view)) {
                checkEntriesImageViews.remove(view);
            } else {
                checkEntriesImageViews.add(view);
            }
        }
        overlayView.setESignatureNextButtonEnabled(checkEntriesImageViews.size() == checkEntries.size());
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onCountryItemClick(int position) {

    }

    public class ImageUploader extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            Util_Log.i(LOGTAG, "started upload");
        }

        @Override
        protected String doInBackground(String... params) {
            videoLiveStreamManager.uploadScreenshotRESTCall(imageStringToPush, imageTypeToPush, () -> currentlyUploadingPicture = false);
            return "executed";
        }

        @Override
        protected void onPostExecute(String result) {
            Util_Log.i(LOGTAG, "finished upload");
        }

    }


    private void initDocumentsSpinner(Spinner spinner) {
        // Create an ArrayAdapter using the string array and a default spinner layout
        Adapters_DocumentSpinnerAdapter adapter = new Adapters_DocumentSpinnerAdapter(mContext, android.R.layout.simple_spinner_item, Config.PDF_DOCUMENTS);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (Config.PDF_DOCUMENTS != null && Config.PDF_DOCUMENTS.length > position && Config.PDF_DOCUMENTS[position].getDocumentDefinition() != null) {
                    getPDFToDocument(Config.PDF_DOCUMENTS[position].getDocumentDefinition().getIdentifier());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    // example: http://go.dev.idnow.de/pdf/esigning-demo/DEV-HDJTU/doc3
    private void getPDFToDocument(String document) {
        overlayView.getPdfWebView().initPDF(Config.CURRENT_SERVER.getWebHost(IDnowSDK.getTransactionToken()) + "/assets/web/viewer.html?file=/api/v1/" + IDnowSDK.getCompanyId() + "/identifications/" + IDnowSDK.getTransactionToken() + "/documents/" + document + "/data");
    }

    public void declineContract() {
        Util_UtilUI.showCancelIdentificationDialog(mContext, false);
    }

    private void initDrawingView() {
        drawingView = new Util_Drawing_View(this);
        drawingView.setDrawingCacheEnabled(true);
        drawingView.setBackground(getResources().getDrawable(R.drawable.signature_background));
        overlayView.getSignContractView().getDrawingViewPlaceholder().addView(drawingView);
        drawingView.setOnTouchListener((v, event) -> {
            signed = true;
            overlayView.handlingNextButtonActiveness(signed);
            return false;
        });
    }

    public void eSignatureNextStep(String kind) {
        // the pdf view is active and the "sign contract" button is clicked -> current view needs to be shown again
        if (eSignatureStep == 1 && overlayView.getSignContractView().getVisibility() == View.GONE) {
            overlayView.setContentViewVisible(true);
            overlayView.getSignContractView().setVisibility(View.VISIBLE);
            mSubscriberViewContainer.setVisibility(View.VISIBLE);
            overlayView.setShowContractTextViewVisible(true);
            overlayView.setBufferViewVisible(true);
            overlayView.addMarginBottomToButtonView();
            overlayView.getButtonNext().setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_ESIGN_ACCEPT_BUTTON, LOCAL_KEY_VIDEO_IDENT_ESIGN_ACCEPT_BUTTON));
            overlayView.handlingNextButtonActiveness(signed);
        }
        // opentrust view has to be shown again
        else if (eSignatureStep == 2) {
            overlayView.setButtonViewVisible(true);
            overlayView.addMarginBottomToButtonView();
            overlayView.setContentViewVisible(true);
            openTrustWebView.setVisibility(View.VISIBLE);
            subscriberContainer.setVisibility(View.INVISIBLE);
            if (!Config.DTMAndPSM) {
                overlayView.setShowContractTextViewVisible(true);
                overlayView.setBufferViewVisible(true);
            }

            if ((Config.AUTHENTICATED_SIGNED) && (!Config.RESTART_VIDEO_IDENT) && (!Config.SHOW_CONTRACT_AGAIN)) {
                overlayView.setShowContractTextViewVisible(false);
                overlayView.setBufferViewVisible(false);

                if (kind.equals(KEY_ACCOUNT_REGISTER)) {
                    Util_UtilUI.showEsignDialog(mContext, Util_Strings.KEY_ACCOUNT_REGISTER, null, openTrustWebView);
                } else if (kind.equals(KEY_ACCOUNT_LOGIN)) {
                    Util_UtilUI.showEsignDialog(mContext, Util_Strings.KEY_ACCOUNT_LOGIN, null, openTrustWebView);
                } else if (kind.equals(KEY_ACCOUNT_PASSWORD)) {
                    Util_UtilUI.showEsignDialog(mContext, Util_Strings.KEY_ACCOUNT_PASSWORD, null, openTrustWebView);
                } else if (kind.equals(KEY_ACCOUNT_UPDATE)) {
                    Util_UtilUI.showEsignDialog(mContext, Util_Strings.KEY_ACCOUNT_UPDATE, null, openTrustWebView);
                }
            }
        }

        // the native signing overlay is shown and the next button was clicked
        else {
            eSignatureStep++;
            handleEsignatureNextButtonClicked();
        }

        // show chatButton again.
        if (IDnowSDK.enableChat && chatButtonHolder != null) {
            if (!Config.VIDEO_IDENT_PLUS) {
                chatButtonHolder.setVisibility(View.VISIBLE);
            }
        }
    }

    /**
     * init layout for displaying opentrust process
     */
    @SuppressLint("SetJavaScriptEnabled")
    private void initOpentrustWebview() {
        eSignatureStep = 2;
        overlayView.getSignContractView().setVisibility(View.GONE);
        overlayView.setButtonViewVisible(false);

        subscriberContainer.setVisibility(View.INVISIBLE);

        openTrustWebView.setVisibility(View.VISIBLE);
        openTrustWebView.setWebViewClient(new Util_Custom_WebViewClient(mContext));

        openTrustWebView.getSettings().setJavaScriptEnabled(true);
        openTrustWebView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        openTrustWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        openTrustWebView.clearCache(true);

        openTrustWebView.setWebViewClient(new IDNowWebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                overlayView.injectCSS();
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                // Inject CSS on PageFinished
                overlayView.injectCSS();
                super.onPageFinished(view, url);
            }

        });

        openTrustWebView.setWebChromeClient(new WebChromeClient() {

            @RequiresApi(api = VERSION_CODES.M)
            @SuppressLint("ResourceType")
            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                if (DARK_MODE) {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(view.getContext(), R.style.IDnowAlertDialogStyle);
                    alertDialogBuilder.setTitle(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_ESIGN_DIALOG_TITLE, LOCAL_KEY_VIDEO_IDENT_ESIGN_DIALOG_TITLE));
                    alertDialogBuilder.setMessage(message);

                    alertDialogBuilder.setPositiveButton(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK),
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    result.confirm();
                                }
                            });

                    alertDialogBuilder.setNegativeButton(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_COMMON_CANCEL, LOCAL_KEY_VIDEO_IDENT_COMMON_CANCEL),
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    result.cancel();
                                }
                            });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.setOnShowListener(arg0 -> {
                        alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.primarytextColor));
                        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.primarytextColor));
                        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setBackgroundColor(getResources().getColor(R.color.primaryColor));
                        alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setBackgroundColor(getResources().getColor(R.color.primaryColor));
                        alertDialog.getWindow().setBackgroundDrawableResource(R.color.bgPrimaryColor);

                    });

                    alertDialog.show();

                    return true;

                } else {
                    return super.onJsConfirm(view, url, message, result);
                }
            }
        });


        // TODO show failure url if invalid url or empty url is given
        // just a fallback

        if ((Config.AUTHENTICATED_SIGNED)) {
            overlayView.setShowContractTextViewVisible(false);
            overlayView.setBufferViewVisible(false);

            if (Config.AUTHENTICATED_POSSIBLE && !Config.RESTART_VIDEO_IDENT) {
                Util_UtilUI.showEsignDialog(mContext, Util_Strings.KEY_ACCOUNT_LOGIN, null, openTrustWebView);
            } else {
                Util_UtilUI.showEsignDialog(mContext, Util_Strings.KEY_ACCOUNT_REGISTER, null, openTrustWebView);
                Config.RESTART_VIDEO_IDENT = false;
            }
        } else {
            overlayView.setBackgroundViewVisibility(false);
            overlayView.setProgressBarLoadingContractVisible(false);
            overlayView.setProgressBarHeadlineVisible(false);
            overlayView.setProgressBarDescriptionVisible(false);
            openTrustWebView.loadUrl(Config.OPENTRUST_URL);
            handleTCWebviewClick(openTrustWebView);
        }
    }

    private void handleTCWebviewClick(WebView webView) {
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Util_Log.d(LOGTAG, "command it's here :" + request.getUrl().toString());
                openTrustWebView.setVisibility(View.GONE);
                openTrustWebViewTC.setVisibility(View.VISIBLE);
                openTrustWebViewTC.setWebViewClient(new Util_Custom_WebViewClient(mContext));
                openTrustWebViewTC.getSettings().setJavaScriptEnabled(true);
                openTrustWebViewTC.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                openTrustWebViewTC.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
                openTrustWebViewTC.clearCache(true);
                openTrustWebViewTC.loadUrl(request.getUrl().toString());
                return false;
            }
        });
    }

    private void sendSigningBitmapToServer() {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        drawingView.getDrawingCache().compress(Bitmap.CompressFormat.JPEG, 100, os);
        Util_UtilWebsocket.sendImageToServer(Util_PhotoStrings.SIGNATURE, os.toByteArray(), (Interface_VideoLiveStream) this);
    }

    /**
     * called when user clicks the "next" button of the native esignature view.
     * sends the handwriting bitmap to the server and initializes the opentrust webview
     */
    private void handleEsignatureNextButtonClicked() {
        sendSigningBitmapToServer();
        initOpentrustWebview();
    }


    /**
     * triggered when user presses the "resign" button at the native esigning overlay
     */
    public void resignDocumentClick() {
        drawingView.mCanvas.drawColor(0, Mode.CLEAR);
        drawingView.invalidate();
        signed = false;

        overlayView.handlingNextButtonActiveness(signed);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        if (resultCode == RESULT_CODE_CANCEL) {
            triggerOnBackPressed(RESULT_CODE_CANCEL);
        } else if (resultCode == RESULT_CODE_FALLBACK_VID) {

            Config.BACK_TO_VID = true;
            try {
                IDnowSDK.getInstance().start(getTransactionToken());
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Start identification failed", e);
            }
            setResult(resultCode);
            IDnowSDK.getInstance().deliverResult(resultCode, getIntent());
            finishAndRemoveTask();

        } else if (resultCode == CHOOSER_SCREEN) {
            Config.BACK_TO_VID = false;

            try {
                IDnowSDK.getInstance().start(getTransactionToken());
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Start identification failed", e);
            }
            setResult(resultCode);
            IDnowSDK.getInstance().deliverResult(resultCode, getIntent());

            finishAndRemoveTask();
        } else {
            if (!IDnowSDK.getOverrideEntryActivity()) {
                Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity.class;
            }
            Intent intentActivity = new Intent(this, Config.HOST_APP_START_ACTIVITY);
            intentActivity.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            IDnowSDK.updateResultCode(resultCode);
            IDnowSDK.getInstance().deliverResult(resultCode, getIntent());
            setResult(resultCode, getIntent());
            finishAndRemoveTask();
            if ((!Config.BACK_TO_VID) || IDnowSDK.getOverrideEntryActivity()) {
                startActivity(intentActivity);
            }
        }
    }

    /**
     * when the user presses the backButton a dialog is shown asking him if he really wants to quit the identification. if he selects "ok" this
     * function gets called
     */
    public void triggerOnBackPressed(int resultCode) {
        Config.USER_CANCEL = true;
        progressBarLoading.setVisibility(View.GONE);
        openResultActivity(resultCode);
    }

    public void openResultActivity(int resultCode) {
        manuallyClosedActivity = true;
        IDnowSDK.RETRY_RESULT_CODE = IDnowSDK.RESULT_CODE_CANCEL;
        Intent onBackPressedIntent = getIntentWithResultDescription(resultCode);

        // only finish the activity if the host app is not the idnow host app, because in this host app, back pressing should be allowed and therefore the backstack shouldn't be overwritten
        if (!Config.IS_IDNOW_HOST_APP) {
            IDnowSDK.getInstance().deliverResult(resultCode, onBackPressedIntent);
            setResult(resultCode, onBackPressedIntent);

        }

        closeSocket();

        if (IDnowSDK.getShowErrorSuccessScreen(this)) {
            showResultActivity(resultCode);
        } else {
            if (!IDnowSDK.getOverrideEntryActivity()) {
                Config.HOST_APP_START_ACTIVITY = Activities_EntryActivity.class;
            }
            Intent intent = new Intent(this, Config.HOST_APP_START_ACTIVITY);
            intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            IDnowSDK.updateResultCode(resultCode);
            IDnowSDK.getInstance().deliverResult(resultCode, getIntent());
            setResult(resultCode, getIntent());
            Util_Util.clearApplicationData(contextVIP);
            finishAndRemoveTask();
            if (!Config.BACK_TO_VID || IDnowSDK.getOverrideEntryActivity()) {
                if (IDnowSDK.isShowVideoOverviewCheck(this)) {
                    startActivity(intent);
                }
            }
            Config.BACK_TO_VID = false;
            return;
        }

        IDnowSDK.updateResultCode(resultCode);
    }

    @NonNull
    private Intent getIntentWithResultDescription(int resultCode) {
        Intent onBackPressedIntent = new Intent();
        switch (resultCode) {
            case IDnowSDK.RESULT_CODE_CANCEL: {
                onBackPressedIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, getString(IDnowSDK.MESSAGE_USER_CANCELED));
                onBackPressedIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                break;
            }
            case IDnowSDK.RESULT_CODE_FAILED: {
                onBackPressedIntent.putExtra(IDnowSDK.RESULT_DATA_ERROR, getString(IDnowSDK.MESSAGE_ID_FAILED));
                onBackPressedIntent.putExtra(IDnowSDK.RESULT_DATA_TRANSACTION_TOKEN, IDnowSDK.getTransactionToken());
                break;
            }
            default:
                break;
        }
        return onBackPressedIntent;
    }

    public void showResultActivity(int resultCode) {
        if(Config.STORED_IDENTITY_SCREEN && !showedConsent && resultCode == IDnowSDK.RESULT_CODE_SUCCESS && !Config.INSTANT_SIGN) {
            showedConsent = true;
            Intent intent = new Intent(this, StoredIdentityActivity.class);
            if (Config.IS_IDNOW_HOST_APP) {
                intent.setFlags(FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            }
            intent.putExtra(Config.EXTRA_IDENTIFICATION_SUCCESSFUL, true);
            intent.putExtra(Config.EXTRA_RESPONSE_CODE, resultCode);
            startActivity(intent);
            finishAndRemoveTask();
            return;
        }
        Intent intent = new Intent(this, Activities_ResultActivity.class);
        intent.putExtra(Config.EXTRA_IDENTIFICATION_SUCCESSFUL, resultCode == IDnowSDK.RESULT_CODE_SUCCESS);
        intent.putExtra(Config.EXTRA_RESPONSE_CODE, resultCode);
        intent.putExtra("userCanceled", userInitiatedCancellation);

        if (Config.IS_IDNOW_HOST_APP) {
            intent.setFlags(FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        }

        IDnowSDK.getInstance().deliverResult(REQUEST_ID_NOW_SDK, getIntent());
        setResult(IDnowSDK.REQUEST_ID_NOW_SDK, getIntent());
        finishAndRemoveTask();
        startActivity(intent);
    }


    // ==============================================
    // E-SIGNATURE
    // ==============================================
    public void startESigning() {
        if (Config.E_SIGNING) {
            Util_CustomLogData.setEventData(EVENT_ESIGN_CONTRACT_SIGN_SCREEN_SHOWN, "EVENT_ESIGN_CONTRACT_SIGN_SCREEN_SHOWN", "eSign Contract signing Screen", "Screen", null);
            Util_Log.d("COUNTLY LOG", "EVENT_ESIGN_CONTRACT_SIGN_SCREEN_SHOWN");

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Config.VIDEO_IDENT_PLUS) {
                        if (takePictureLayout != null && video_ident_steps_layout != null) {
                            takePictureLayout.setVisibility(View.GONE);
                            video_ident_steps_layout.setVisibility(View.GONE);
                        }
                    }
                }
            });
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openTrustWebView = overlayView.getOpenTrustWebView();
                    openTrustWebViewTC = overlayView.getOpenTrustWebView();
                    openTrustWebView.getSettings().setAllowUniversalAccessFromFileURLs(false);
                    overlayView.setVisibility(View.VISIBLE);

                    if (Config.USE_NATIVE_ESIGNING) {
                        if (Config.INSTANT_SIGN) {
                            overlayView.setESigningPreparationContaoinerVisible(false);
                        }
                        if (!Util_Util.isEmptyString(IDENTIFICATION_SIGNATURE) || Config.INSTANT_SIGN) {
                            approvalPhrasesCallback.implementView();
                        }
                        if (overlayView != null) {
                            String jsonKey;
                            if (Config.PDF_DOCUMENTS.length > 1) {
                                jsonKey = "js.signing.native.consentProtocol.documentsPhrase.plural";
                            } else {
                                jsonKey = "js.signing.native.consentProtocol.documentsPhrase.one";
                            }
                            videoLiveStreamManager.prepareCustomMessagesViaRestFromJSON(jsonKey, overlayView::setSigningTextViewHeaderMessage);
                        }

                        overlayView.getPdfWebView().setSpinnerVisible(true);
                        overlayView.getPdfWebView().initDocumentsSpinner();

                        subscriberContainer.setVisibility(View.INVISIBLE);
                        progressBarLoading.setVisibility(View.GONE);
                        overlayView.setESigningNativeContainerVisible(true);

                        overlayView.setESignWebViewContainerVisible(false);
                        chatLayout = findViewById(R.id.chatLayout);
                        chatLayout.setVisibility(View.GONE);
                        chatButtonHolder = findViewById(R.id.chatButtonHolder);
                        chatButtonHolder.setVisibility(View.GONE);
                        Config.E_SIGNING_IN_PROGRESS = true;
                    } else {
                        if (Config.E_SIGNING_ASK_FOR_USER_CONSENT) {
                            AssetsLoader.INSTANCE.loadMessagesAsync(false);

                            chatButtonHolder = findViewById(R.id.chatButtonHolder);
                            chatButtonHolder.setVisibility(View.GONE);
                            overlayView.getESignConsentView().setVisibility(View.VISIBLE);
                            overlayView.getESignConsentView().confirmOnclickListener(v -> {
                                overlayView.getESignConsentView().setVisibility(View.GONE);
                                chatButtonHolder.setVisibility(View.VISIBLE);
                            });
                        }

                        overlayView.setContentViewVisible(true);
                        overlayView.getSignContractView().setVisibility(View.VISIBLE);

                        overlayView.setESigningNativeContainerVisible(false);
                        overlayView.setESignWebViewContainerVisible(true);

                        overlayView.handlingNextButtonActiveness(signed);
                        initESignature();

                        initOpentrustWebview();
                    }

                    locateChatButton(false);
                }
            });
        }
    }

    private void hideChatLayout() {
        chatLayout.setVisibility(View.GONE);

        if (chatButtonHolder != null) {
            if (!Config.VIDEO_IDENT_PLUS) {
                chatButtonHolder.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    public void onBackPressed() {

        if (chatLayout != null && chatLayout.getVisibility() == View.VISIBLE) {
            hideChatLayout();
        } else if (notifyViaPushLowerPanel.getVisibility() == View.VISIBLE) {
            closePushLowerPanel();
        }

        // TODO send the user closed chat REST call.
        else {
            // when user is at goodbye-step (tan_done) and wants to close the identification process, handle it as success rather than failure
            if (currentUserStep == 5) {
                IDnowSDK.RETRY_RESULT_CODE = IDnowSDK.RESULT_CODE_SUCCESS;
                Config.E_SIGNING_IN_PROGRESS = false;
                closeSocket();
                openReportVideoLiveStream(true);
            } else {

                if (Config.CALL_ABORT_REASON_SCREEN && Config.AGENT_CONNECTED && user_abort_feedback_view.getVisibility() != View.VISIBLE) {
                    if (VIDEO_IDENT_PLUS) {
                        video_ident_steps_layout.setVisibility(View.GONE);
                    } else if (VIDEO_IDENT_PLUS_UI) {
                        video_ident_plus_layout.setVisibility(View.GONE);
                    }
                    if (Config.E_SIGNING) {
                        // eSignatureLayout.setVisibility(View.GONE);
                    }
                    displayAbortUser();
                    if (user_abort_feedback_view != null) {
                        user_abort_feedback_view.setVisibility(View.VISIBLE);
                    }
                } else {
                    if (user_abort_feedback_view.getVisibility() != View.VISIBLE) {
                        Util_UtilUI.showCancelIdentificationDialog(mContext, false);
                    }
                }
            }
        }

        AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_NORMAL);

        Config.CALL_QUALITY_CHECK_PASSED = false;
    }

    public void openReportVideoLiveStream(Boolean aBoolean) {
        openReportActivity(
                (Interface_VideoLiveStream) this, /* this is a huge hack as a compromise */
                /* here base class uses code which requires reference to this child class (!!) */
                mContext,
                aBoolean);
    }

    public void closeSocket() {
        Network_WebSocketService.getInstance().close();
    }

    @Override
    public void onDestroy() {
        Util_Log.i(LOGTAG, "http onDestroy");
        if (!VIDEO_IDENT_PLUS_REUSE_IMAGES) {
            Util_Util.deleteCache(this);
        }

        if (camera != null){
            camera.destroy();
        }

        closeSocket();

        // resetting the Waiting Queue information, so the user doesn't get stuck in his old information, when he restarts the call.
        Config.IDENT_ESTIMATED_WAITING_TIME = -1;
        Config.IDENT_POSITION_IN_QUEUE = -1;
        // For good measure
        Config.E_SIGNING_IN_PROGRESS = false;

        manuallyClosedActivity = true;

        try {
            mNotificationManager.cancel(Config.NOTIFICATION_ID);
        } catch (Exception e) {
            logExternally(this, "error : " + e.getMessage(), LogEventTypeEnum.ERROR.get());
            Util_Log.e(LOGTAG, "Cancel notification failed", e);
        }

        // Util_Util.deleteCache(this);
        AudioManager am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_NORMAL);

        try {
            stopService();
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Stop service failed", e);
        }

        super.onDestroy();
    }

    /**
     * performed when user clicks on the "showContract" Button at the opentrust-webview or native signing overlay
     */
    public void showContract(final String kind) {
        // the chatButton has to be hidden, when the contract is shown, because of the dropdown, which isn't clickable if the chatButton is shown.
        // the chatButton has to be shown again, when user presses the buttonNext to return to the openTrustView.

        ((Activities_VideoLiveStreamActivity_Super) mContext).overlayView.setBackgroundViewColor(0);


        if (IDnowSDK.enableChat && chatButtonHolder != null) {
            chatButtonHolder.setVisibility(View.GONE);
        }

        if (Config.OVERRIDE_BRANDING_COLOR && Config.overridableColorsMap.containsKey(IDnowSDK.OverridableUIElement.E_SIGNING_DOCUSIGN_BACK_BUTTON)) {
            Util_UtilUI.overrideBrandingColor(overlayView.getButtonNext(), Config.overridableColorsMap.get(IDnowSDK.OverridableUIElement.E_SIGNING_DOCUSIGN_BACK_BUTTON).get(Config.OverridableColorType.BACKGROUND),
                    Config.overridableColorsMap.get(IDnowSDK.OverridableUIElement.E_SIGNING_DOCUSIGN_BACK_BUTTON).get(Config.OverridableColorType.TEXT));
        }

        overlayView.setContentViewVisible(false);
        mSubscriberViewContainer.setVisibility(View.GONE);
        overlayView.setShowContractTextViewVisible(false);
        overlayView.setBufferViewVisible(false);
        overlayView.getButtonNext().setPressed(false);

        overlayView.addMarginsToButtonView();
        overlayView.getPdfWebView().setMarginBottom(72);
        overlayView.getButtonNext().setEnabled(true);
        overlayView.getButtonNext().setText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_VIDEO_IDENT_ESIGN_BACK_SIGNING, LOCAL_KEY_VIDEO_IDENT_ESIGN_BACK_SIGNING));
        overlayView.setSignatureButtonViewVisible(false);

        if (eSignatureStep == 1) {
            overlayView.getSignContractView().setVisibility(View.GONE);
        } else if (eSignatureStep > 1) {
            overlayView.setESigningNativeContainerVisible(false);
            openTrustWebView.setVisibility(View.GONE);
            overlayView.setButtonViewVisible(true);
            subscriberContainer.setVisibility(View.VISIBLE);
        }

        overlayView.getButtonNext().setOnClickListener(view -> {
            ((Activities_VideoLiveStreamActivity_Super) mContext).overlayView.setBackgroundViewColor((getResources().getColor(R.color.bgPrimaryColor)));
            eSignatureNextStep(kind);
        });
    }


    /**
     * initializes showing information about the waiting queue and the remaining waiting time to the user.
     * Starting the handler, that fetches these information every {@link #refreshPeriod} milliseconds.
     */
    private void setupWaitingQueueInformation() {
        if (setupCompleteCallAlreadyTriggered) {
            return;
        }

        // check if the default values are still in use. If that't the case, show the default text.
        if ((Config.IDENT_ESTIMATED_WAITING_TIME == -1 && Config.IDENT_POSITION_IN_QUEUE == -1) ||
                (Config.IDENT_ESTIMATED_WAITING_TIME == 0 && Config.IDENT_POSITION_IN_QUEUE == 0)) {
            // set default value, when server responded with invalid / no data
            Util_Log.i(LOGTAG, "setupWaitingQueueInformation - Showing default waiting position as it seems that the information has not been fetched yet");
            explanationView.setTextViewExplanationContentText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_LABEL_WAITING_FOR_AGENT, LOCAL_LABEL_WAITING_FOR_AGENT));

            if (IDnowSDK.isForcedWaitingList()) {
                explanationView.setExplanationTitleVisibility(View.GONE);
                explanationView.setTextViewExplanationContentVisibility(false);
            }
        } else {
            // setting the text according to the info values from the server.
            Util_Log.i(LOGTAG, "setupWaitingQueueInformation - Showing values as they are different from 0 and -1");
            explanationView.setTextViewExplanationContentText(Util_Util.getHumanReadableWaitingInformation(Activities_VideoLiveStreamActivity_Super.this, Config.IDENT_POSITION_IN_QUEUE, Config.IDENT_ESTIMATED_WAITING_TIME));
        }

        // setting the title of the explanation view
        explanationView.setTextViewExplanationTitleText(Util_Strings.getVideoIdentStepTitle(this, 0));

        // starting the handler to fetch the waiting info
        Util_Log.i(LOGTAG, "setupWaitingQueueInformation - starting poller");
        handlerFetchWaitingInformation();
    }

    public Runnable startRESTCallRunnable = new Runnable() {
        @Override
        public void run() {
            videoLiveStreamManager.makeStartRESTCall(mContext, () -> hideHelpertextAndConnect());
        }
    };

    public void setExplanationTitleText(String text) {
        explanationView.setTextViewExplanationTitleText(text);
    }

    public void setExplanationContentText(String text) {
        explanationView.setTextViewExplanationContentText(text);
    }


    /**
     * update the text and trigger a new call after 2 seconds as long as agent hasn't taken the call.
     *
     * @param resultObject
     */
    private void updateWaitingInformation(final Models_Customer resultObject) {
        if (resultObject != null) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // only set the text, if the user is still at the first step (waiting for connection step).
                    if (currentUserStep == 0) {
                        if (resultObject.getRequest() != null) {
                            Util_Log.i(LOGTAG, String.format("positionInQueue: %d - waitingTime: %d - isPositionInitializedByResponse: %b",
                                    resultObject.getRequest().getPositionInQueue(),
                                    resultObject.getRequest().getEstimatedWaitingTime(),
                                    resultObject.getRequest().isPositionInitializedByResponse()
                            ));

                            Util_Log.d(LOGTAG, "Waitingpos - updateWaitingInformation - update based on resultObject");
                            if (resultObject.getRequest().isPositionInitializedByResponse()) {
                                // update the values
                                if (Config.IDENT_ESTIMATED_WAITING_TIME == -1) {
                                    // the value was not properly initialized, so let's do this now
                                    Config.IDENT_ESTIMATED_WAITING_TIME = resultObject.getRequest().getEstimatedWaitingTime();
                                }

                                // only update the values shown to the user, if they haven't increased.
                                if (Config.IDENT_POSITION_IN_QUEUE == -1 || resultObject.getRequest().getPositionInQueue() < Config.IDENT_POSITION_IN_QUEUE) {
                                    Config.IDENT_POSITION_IN_QUEUE = resultObject.getRequest().getPositionInQueue();
                                }

                                if (Config.IDENT_ESTIMATED_WAITING_TIME != -1 && Config.IDENT_POSITION_IN_QUEUE != -1) {
                                    explanationView.setTextViewExplanationContentText(Util_Util.getHumanReadableWaitingInformation(Activities_VideoLiveStreamActivity_Super.this, Config.IDENT_POSITION_IN_QUEUE, Config.IDENT_ESTIMATED_WAITING_TIME));
                                }
                            } else {
                                Util_Log.d(LOGTAG, "Waitingpos - updateWaitingInformation - skipping update as the response was not yet having proper value");
                            }
                        }
                        // something went wrong, show default text.
                        else {
                            Util_Log.d(LOGTAG, "Waitingpos - updateWaitingInformation - resultObject null");
                            explanationView.setTextViewExplanationContentText(Util_Strings.getStringWithDefault(getApplicationContext(), KEY_LABEL_WAITING_FOR_AGENT, LOCAL_LABEL_WAITING_FOR_AGENT));
                        }
                    }
                }
            });
        }
    }

    /**
     * fetch waiting information every {@link #refreshPeriod} milliseconds.
     */
    private void handlerFetchWaitingInformation() {
        final Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                // do your stuff - don't create a new runnable here!
                fetchWaitingInformation(null, null, false);
                // check if the activity still is running and if the user is currently still at the first step.
                if (isActivityRunning && currentUserStep == 0) {
                    handler.postDelayed(this, refreshPeriod);
                }
            }
        };

        handler.post(runnable);
    }

    /**
     * fetches every {@link #refreshPeriod} milliseconds the current waiting information as long as the agent hasn't taken the call.
     */
    public void fetchWaitingInformation(@NonNull Interface_VideoLiveStream sink, final Context context, boolean successful) {
        FetchWaitingInformationCallback fetchCallback = new FetchWaitingInformationCallback() {
            @Override
            public void updateInfo(Models_Customer info) {
                updateWaitingInformation(info);
            }

            @Override
            public void onSuccess(Models_Customer result) {
                if (!Config.WAITING_LIST_NOTIFICATIONS_FROM_QUEUE && !Config.WAITING_LIST_NOTIFICATIONS_ENROLLED) {
                    openPushDialogPanel();
                }

                if (result.getRequest() != null && "REQUESTED_CHAT".equals(result.getRequest().getStatus())) {
                    if (result.isPreEstablishVideoConnection()) {
                        if (getCurrentRetryCount() >= Config.VIDEO_CONFIG_PRE_ESTABLISH_RETRY_COUNT && Config.VIDEO_CONFIG_PRE_ESTABLISH_RETRY_COUNT > -1) {
                            identificationFailedRESTCall();
                            return;
                        }
                        establishVideoConnection();
                    } else {
                        disconnectVideoConnection();
                    }
                }
            }
        };
        videoLiveStreamManager.fetchWaitingInformation(sink, context, successful, fetchCallback);
    }


    protected abstract int getCurrentRetryCount();

    protected abstract void disconnectVideoConnection();

    protected abstract void establishVideoConnection();

    private void hideHelpertextAndConnect() {
        helperImageContainer.setVisibility(View.GONE);
        sessionConnect();
    }

    // INTERFACE DEFINITIONS
    public Handler getHandler() {
        return uiHandler;
    }

    public static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." +
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        return pat.matcher(email).matches();
    }

    public boolean isValidPassword(String password) {
        boolean valid = true;
        if (password.length() < 8) {
            valid = false;
        }
        String upperCaseChars = "(.*[A-Z].*)";
        if (!password.matches(upperCaseChars)) {
            valid = false;
        }
        String lowerCaseChars = "(.*[a-z].*)";
        if (!password.matches(lowerCaseChars)) {
            valid = false;
        }
        String numbers = "(.*[0-9].*)";
        if (!password.matches(numbers)) {
            valid = false;
        }
        return valid;
    }

    public void loadCreateAccountLayout(final Dialog dialog, final Context context, final WebView webView) {
        Config.EMAIL_ADDRESS_WALLET = Config.EMAIL_ADDRESS;
        Config.USER_PHONE_NO_WALLET = Config.USER_PHONE_NO;

        headlineAccount = dialog.findViewById(R.id.headlineReg);
        instructionAccount = dialog.findViewById(R.id.instructionReg);
        noRegistrationReg = dialog.findViewById(R.id.noRegistrationReg);

        if (Config.AUTHENTICATED_SIGNING_HIDE_OPTION_TO_CONTINUE_WITHOUT_WALLET) {
            noRegistrationReg.setVisibility(View.INVISIBLE);
        } else {
            noRegistrationReg.setVisibility(View.VISIBLE);
        }

        hintAccount = dialog.findViewById(R.id.hintReg);
        emailAccount = dialog.findViewById(R.id.emailReg);
        mobilePhoneAccount = dialog.findViewById(R.id.mobilePhoneReg);
        confirmAccount = dialog.findViewById(R.id.confirmReg);
        abortAccount = dialog.findViewById(R.id.abortReg);
        showContractTextViewRegister = dialog.findViewById(R.id.showContractTextViewRegister);
        showContractTextViewRegister.setText(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ESIGN_CHECK_CONTRACT, LOCAL_KEY_VIDEO_IDENT_ESIGN_CHECK_CONTRACT));

        if (IDnowSDK.getNewBrand()) {
            emailAccount.setBackgroundResource(R.drawable.background_rounded_grey);
            mobilePhoneAccount.setBackgroundResource(R.drawable.background_rounded_grey);
            confirmAccount.setBackgroundResource(R.drawable.rounded_background_orange);
            abortAccount.setBackgroundResource(R.drawable.rounded_background_grey);
        } else {

            emailAccount.setBackgroundResource(R.drawable.rounded_border_edittext);
            mobilePhoneAccount.setBackgroundResource(R.drawable.rounded_border_edittext);
            confirmAccount.setBackgroundResource(R.drawable.rounded_button_orange);
            abortAccount.setBackgroundResource(R.drawable.rounded_cornor_gray);
        }

        headlineAccount.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNTINFO_HEADLINE, null));
        instructionAccount.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNTINFO_INSTRCUTION, null));
        hintAccount.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNTINFO_HINT, null));
        noRegistrationReg.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNTINFO_NO_REGISTRATION_LINK, null));
        confirmAccount.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_SIGNIN_CONTINUE, null));
        abortAccount.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_SIGNING_ABORT, null));

        if (Config.HIDE_USERS_PII_DATA && Config.MASKED_EMAIL_ADDRESS != null) {
            manageEditText(emailAccount, "EMAIL");
        } else {
            emailAccount.setText(Config.EMAIL_ADDRESS);
        }

        if (Config.HIDE_USERS_PII_DATA && !Config.MASKED_USER_PHONE_NO.equals("")) {
            manageEditText(mobilePhoneAccount, "PHONE");
        } else {
            mobilePhoneAccount.setText(Config.USER_PHONE_NO);
        }

        emailAccount.setHint(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNTINFO_HELP_EMAIL, null));
        mobilePhoneAccount.setHint(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNTINFO_HELP_PHONE, null));

        if (Config.DTMAndPSM) {
            showContractTextViewRegister.setVisibility(View.GONE);
        }

        showContractTextViewRegister.setOnClickListener(view -> {
            dialog.dismiss();
            Config.SHOW_CONTRACT_AGAIN = false;
            Config.RESTART_VIDEO_IDENT = false;
            ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewColor(0);
            ((Activities_VideoLiveStreamActivity_Super) context).showContract(Util_Strings.KEY_ACCOUNT_REGISTER);
        });

        noRegistrationReg.setOnClickListener(view -> {
            Config.ESIGN_UPDATE_PHONE_NUMBER = true;
            dialog.cancel();
            Util_UtilUI.showEsignDialog(context, Util_Strings.KEY_ACCOUNT_UPDATE, dialog, webView);
        });

        confirmAccount.setOnClickListener(view -> {
            int invalidCases = 0;

            if (!mobilePhoneAccount.getText().toString().contains("***")) {
                Config.USER_PHONE_NO_WALLET = mobilePhoneAccount.getText().toString();
            }

            if (!emailAccount.getText().toString().contains("***")) {
                Config.EMAIL_ADDRESS_WALLET = emailAccount.getText().toString();
            }

            if (!mobilePhoneAccount.getText().toString().contains("***")) {
                Config.USER_PHONE_NO_WALLET = mobilePhoneAccount.getText().toString();

            }

            if (Config.EMAIL_ADDRESS_WALLET.equals("")) {
                Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_EMAIL_PRESENCE);
                invalidCases++;
            } else if (Config.USER_PHONE_NO_WALLET.equals("")) {
                Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_MOBILENUMBER_PRESENCE);
                invalidCases++;
            } else if (!isValidEmail(Config.EMAIL_ADDRESS_WALLET.toString())) {
                Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_EMAIL_FORMAT);
                invalidCases++;
            } else if (!Config.USER_PHONE_NO_WALLET.startsWith("+") || !Config.USER_PHONE_NO_WALLET.substring(1).matches("[0-9]+")) {
                Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_MOBILENUMBER_FORMAT);
                invalidCases++;
            }
            if (invalidCases == 0) {
                Models_RegistrationeSign models_registrationeSign = new Models_RegistrationeSign(Config.EMAIL_ADDRESS_WALLET, Config.USER_PHONE_NO_WALLET);
                if ((Config.START_ESIGNING) && (!Config.OPENTRUST_URL.equals(""))) {
                    videoLiveStreamManager.updateOpenTrustUrl(context, mobilePhoneAccount.getText().toString(), isActivityRunning, webView, models_registrationeSign, dialog);
                } else {
                    if (videoLiveStreamManager == null) {
                        Context applicationContext = ((Activities_VideoLiveStreamActivity_Super) context).getApplicationContext();
                        videoLiveStreamManager = new VideoLiveStreamManager(applicationContext);
                    }

                    videoLiveStreamManager.createAccountRESTCall(context, models_registrationeSign, dialog, webView, isActivityRunning);
                }
            }
        });

        abortAccount.setOnClickListener(view -> {
            Config.ALERT_DIALOG_TO_SHOW = Util_Strings.KEY_ACCOUNT_REGISTER;
            Util_UtilUI.showDeclineeSigning(context, dialog);
        });
    }

    public void loadSavePasswordLayout(final Dialog dialog, final Context context, final WebView webView) {
        String passwordInstruction = IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_SELECTPASSWORD_HINT_HTML, null);

        passwordInstruction = passwordInstruction.replace("<br/>", "\n");

        headlinePassword = dialog.findViewById(R.id.headlinePassword);
        instructionPassword = dialog.findViewById(R.id.instructionPassword);
        hintPassword = dialog.findViewById(R.id.hintPassword);
        passwordPassword = dialog.findViewById(R.id.passowrd);
        reconfirmPassword = dialog.findViewById(R.id.confirmpassword);
        abortPassword = dialog.findViewById(R.id.abortPassword);
        confirmPassword = dialog.findViewById(R.id.confirmPassword);
        showContractTextViewPassword = dialog.findViewById(R.id.showContractTextViewPassword);
        showContractTextViewPassword.setText(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ESIGN_CHECK_CONTRACT, LOCAL_KEY_VIDEO_IDENT_ESIGN_CHECK_CONTRACT));

        if (IDnowSDK.getNewBrand()) {
            passwordPassword.setBackgroundResource(R.drawable.background_rounded_grey);
            reconfirmPassword.setBackgroundResource(R.drawable.background_rounded_grey);
            abortPassword.setBackgroundResource(R.drawable.rounded_background_grey);
            confirmPassword.setBackgroundResource(R.drawable.rounded_background_orange);
        } else {

            passwordPassword.setBackgroundResource(R.drawable.rounded_border_edittext);
            reconfirmPassword.setBackgroundResource(R.drawable.rounded_border_edittext);
            abortPassword.setBackgroundResource(R.drawable.rounded_cornor_gray);
            confirmPassword.setBackgroundResource(R.drawable.rounded_button_orange);
        }

        headlinePassword.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_SELECTPASSWORD_HEADLINE, null));
        instructionPassword.setText(IDnowSDK.getInstance().getStringWithDefault(this, Util_Strings.KEY_SELECTPASSWORD_VALIDATION_SELECT_PASSWORD_INSTRUCTION, null));
        confirmPassword.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_SIGNIN_CONTINUE, null));
        abortPassword.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_SIGNING_ABORT, null));
        hintPassword.setText(passwordInstruction);
        passwordPassword.setHint(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_SELECTPASSWORD_HELP_PASSWORD, null));
        reconfirmPassword.setHint(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_SELECTPASSWORD_HELP_PASSWORD_CONF, null));

        if (Config.DTMAndPSM) {
            showContractTextViewPassword.setVisibility(View.GONE);
        }

        showContractTextViewPassword.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Config.SHOW_CONTRACT_AGAIN = false;
                Config.RESTART_VIDEO_IDENT = false;
                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewColor(0);
                ((Activities_VideoLiveStreamActivity_Super) context).showContract(KEY_ACCOUNT_PASSWORD);
            }
        });

        confirmPassword.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                int invalidCases = 0;

                if (passwordPassword.getText().toString().equals("")) {
                    Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_PASSWORD_PRESENCE);
                    invalidCases++;
                } else if (!isValidPassword(passwordPassword.getText().toString())) {
                    Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_PASSWORD_VALIDATION);
                    invalidCases++;
                } else if (!passwordPassword.getText().toString().equals(reconfirmPassword.getText().toString())) {
                    Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_CONFIRMED_PASSWORD);
                    invalidCases++;
                }
                if (invalidCases == 0) {
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewVisibility(true);
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarLoadingContractVisible(true);
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarHeadlineVisible(true);
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarDescriptionVisible(true);
                    Models_Password models_password = new Models_Password(passwordPassword.getText().toString(), reconfirmPassword.getText().toString());

                    SaveAccountPasswordCallback callback = () -> webView.post(() -> {
                        Config.SHOW_CONTRACT_AGAIN = true;

                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewVisibility(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarLoadingContractVisible(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarHeadlineVisible(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarDescriptionVisible(false);

                        if (!Config.DTMAndPSM) {
                            ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setShowContractTextViewVisible(true);
                            ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBufferViewVisible(true);
                        }
                        webView.loadUrl(Config.OPENTRUST_URL);
                        handleTCWebviewClick(webView);
                    });

                    if (videoLiveStreamManager == null) {
                        Context applicationContext = context.getApplicationContext();
                        videoLiveStreamManager = new VideoLiveStreamManager(applicationContext);
                    }
                    videoLiveStreamManager.saveAccountPasswordRESTCall(context, models_password, dialog, callback);
                }
            }
        });

        abortPassword.setOnClickListener(view -> Util_UtilUI.showDeclineeSigning(context, dialog));
    }

    public void loadLoginAccountLayout(final Dialog dialog, final Context context, final WebView webView) {
        if (videoLiveStreamManager == null) {
            Context applicationContext = ((Activities_VideoLiveStreamActivity_Super) context).getApplicationContext();
            videoLiveStreamManager = new VideoLiveStreamManager(applicationContext);
        }

        if (Config.VIDEO_IDENT_PLUS) {
            if (video_ident_plus_layout != null) {
                video_ident_plus_layout.setVisibility(View.GONE);
            }
        }

        headlineLogin = dialog.findViewById(R.id.headlineAccount);
        instructionLogin = dialog.findViewById(R.id.instructionAccount);
        hintLogin = dialog.findViewById(R.id.hintAccount);
        rememberPasswordLogin = dialog.findViewById(R.id.cantRemember);
        emailLogin = dialog.findViewById(R.id.emailAccount);
        passwordLogin = dialog.findViewById(R.id.passwordAccount);
        abortLogin = dialog.findViewById(R.id.abortAccount);
        confirmLogin = dialog.findViewById(R.id.confirmAccount);

        showContractTextViewLogin = dialog.findViewById(R.id.showContractTextViewLogin);

        showContractTextViewLogin.setText(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ESIGN_CHECK_CONTRACT, LOCAL_KEY_VIDEO_IDENT_ESIGN_CHECK_CONTRACT));

        if (IDnowSDK.getNewBrand()) {
            emailLogin.setBackgroundResource(R.drawable.background_rounded_grey);
            passwordLogin.setBackgroundResource(R.drawable.background_rounded_grey);
            abortLogin.setBackgroundResource(R.drawable.rounded_background_grey);
            confirmLogin.setBackgroundResource(R.drawable.rounded_background_orange);
        } else {

            emailLogin.setBackgroundResource(R.drawable.rounded_border_edittext);
            passwordLogin.setBackgroundResource(R.drawable.rounded_border_edittext);
            abortLogin.setBackgroundResource(R.drawable.rounded_cornor_gray);
            confirmLogin.setBackgroundResource(R.drawable.rounded_button_orange);
        }

        headlineLogin.setText(IDnowSDK.getInstance().getStringWithDefault(mContext, Util_Strings.KEY_ACCOUNT_LOGIN_HEADLINE, LOCAL_LABEL_TERMS));
        instructionLogin.setText(IDnowSDK.getInstance().getStringWithDefault(mContext, Util_Strings.KEY_ACCOUNT_LOGIN_INSTRUCTION, LOCAL_LABEL_TERMS));
        hintLogin.setText(IDnowSDK.getInstance().getStringWithDefault(mContext, Util_Strings.KEY_ACCOUNT_LOGIN_HINT, LOCAL_LABEL_TERMS));
        rememberPasswordLogin.setText(IDnowSDK.getInstance().getStringWithDefault(mContext, Util_Strings.KEY_ACCOUNT_LOGIN_CANTREM_LINK, LOCAL_LABEL_TERMS));
        confirmLogin.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_SIGNIN_CONTINUE, null));
        abortLogin.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_SIGNING_ABORT, null));

        if (Config.HIDE_USERS_PII_DATA && Config.MASKED_EMAIL_ADDRESS != null) {
            manageEditText(emailLogin, "EMAIL");
        } else {
            emailLogin.setText(Config.EMAIL_ADDRESS);
        }

        emailLogin.setHint(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNT_LOGIN_HELP_EMAIL, null));
        emailLogin.setEnabled(false);
        passwordLogin.setHint(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNT_LOGIN_HELP_PASSWORD, null));
        passwordLogin.setEnabled(true);


        if (Config.DTMAndPSM) {
            showContractTextViewLogin.setVisibility(View.GONE);
        }

        showContractTextViewLogin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Config.SHOW_CONTRACT_AGAIN = false;
                Config.RESTART_VIDEO_IDENT = false;
                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewColor(0);
                ((Activities_VideoLiveStreamActivity_Super) context).showContract(KEY_ACCOUNT_LOGIN);
            }
        });

        rememberPasswordLogin.setOnClickListener(view -> Util_UtilUI.showEsignDialog(context, Util_Strings.KEY_ACCOUNT_NOT_REM_PASSWORD, null, null));

        confirmLogin.setOnClickListener(view -> {
            if (!emailLogin.getText().toString().contains("***")) {
                Config.EMAIL_ADDRESS_WALLET = emailLogin.getText().toString();
            }

            int invalidCases = 0;
            if (passwordLogin.getText().toString().equals("")) {
                Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_ACCOUNT_LOGIN_FAILED);
                invalidCases++;
            }
            if (invalidCases == 0) {
                Config.SHOW_CONTRACT_AGAIN = true;

                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewVisibility(true);
                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarLoadingContractVisible(true);
                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarHeadlineVisible(true);
                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarDescriptionVisible(true);

                LoginAccountCallback callback = responseCode -> new Thread() {
                    public void run() {
                        runOnUiThread(() -> {
                            if (responseCode == 412 || responseCode == 400) {

                                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewVisibility(true);
                                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarLoadingContractVisible(false);
                                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarHeadlineVisible(false);
                                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarDescriptionVisible(false);

                                Config.ERROR_LOGIN = true;
                                Config.SUCCESS_LOGIN = false;
                                dialog.show();
                                Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_ACCOUNT_LOGIN_FAILED);
                            } else if (responseCode == 200) {

                                Config.ERROR_LOGIN = false;
                                Config.SUCCESS_LOGIN = true;
                                dialog.dismiss();

                                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewVisibility(true);
                                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarLoadingContractVisible(true);
                                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarHeadlineVisible(true);
                                ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarDescriptionVisible(true);

                                Config.LOAD_URL = true;

                            }
                        });
                    }
                }.start();

                videoLiveStreamManager.loginAccountRESTCall(context, passwordLogin.getText().toString(), dialog, callback);
                if (Config.ERROR_LOGIN && !Config.SUCCESS_LOGIN) {
                    passwordLogin.setEnabled(true);
                    Config.ERROR_LOGIN = false;
                    Config.SUCCESS_LOGIN = false;
                    Config.SHOW_CONTRACT_AGAIN = false;
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewVisibility(false);
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setShowContractTextViewVisible(false);
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBufferViewVisible(false);
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarLoadingContractVisible(false);
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarHeadlineVisible(false);
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarDescriptionVisible(false);

                    Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_ACCOUNT_LOGIN_FAILED);
                }
            }
        });

        abortLogin.setOnClickListener(view -> Util_UtilUI.showDeclineeSigning(context, dialog));
    }

    public void loadContinueSignLayout(final Dialog dialog, final Context context, final Dialog firstDialog, final WebView webView) {
        TextView headlineUpdate = dialog.findViewById(R.id.headlineUpdate);
        TextView instructionUpdate = dialog.findViewById(R.id.instructionUpdate);
        final EditText phoneUpdate = dialog.findViewById(R.id.phoneUpdate);
        Button confirmUpdate = dialog.findViewById(R.id.confirmUpdate);
        Button abortUpdate = dialog.findViewById(R.id.abortUpdate);
        Button showContractTextViewUpdate = dialog.findViewById(R.id.showContractTextViewUpdate);
        showContractTextViewUpdate.setText(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_ESIGN_CHECK_CONTRACT, LOCAL_KEY_VIDEO_IDENT_ESIGN_CHECK_CONTRACT));
        TextView continueIDnowAccount = dialog.findViewById(R.id.continueIDnowAccount);

        if (IDnowSDK.getNewBrand()) {
            phoneUpdate.setBackgroundResource(R.drawable.background_rounded_grey);
            confirmUpdate.setBackgroundResource(R.drawable.rounded_background_orange);
            abortUpdate.setBackgroundResource(R.drawable.rounded_background_grey);
        } else {
            phoneUpdate.setBackgroundResource(R.drawable.rounded_border_edittext);
            confirmUpdate.setBackgroundResource(R.drawable.rounded_button_orange);
            abortUpdate.setBackgroundResource(R.drawable.rounded_cornor_gray);
        }

        headlineUpdate.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNTFORGOT_HEADLINE, null));
        instructionUpdate.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNTINFO_HINT_NO_REGISTRATION, null));
        confirmUpdate.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_SIGNIN_CONTINUE, null));
        abortUpdate.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_SIGNING_ABORT, null));

        if (Config.HIDE_USERS_PII_DATA && !Config.MASKED_USER_PHONE_NO.equals("")) {
            manageEditText(phoneUpdate, "PHONE");
        } else {
            phoneUpdate.setText(Config.USER_PHONE_NO);
        }

        phoneUpdate.setHint(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNTINFO_HELP_PHONE, null));
        continueIDnowAccount.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_ACCOUNTINFO_CREATE_ACCOUNT_LINK, null));

        if (Config.DTMAndPSM) {
            showContractTextViewUpdate.setVisibility(View.GONE);
        }

        showContractTextViewUpdate.setOnClickListener(view -> {
            dialog.dismiss();
            Config.SHOW_CONTRACT_AGAIN = false;
            Config.RESTART_VIDEO_IDENT = false;
            ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewColor(0);
            ((Activities_VideoLiveStreamActivity_Super) context).showContract(KEY_ACCOUNT_UPDATE);
        });

        continueIDnowAccount.setOnClickListener(view -> {
            dialog.dismiss();
            Util_UtilUI.showEsignDialog(context, KEY_ACCOUNT_REGISTER, dialog, webView);
        });

        confirmUpdate.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                int invalidCases = 0;

                if (!phoneUpdate.getText().toString().contains("***")) {
                    Config.USER_PHONE_NO_WALLET = phoneUpdate.getText().toString();
                }

                String phoneNumber = Config.USER_PHONE_NO_WALLET;
                String subPhoneNumber = (phoneNumber == null || phoneNumber.isEmpty()) ? "" : phoneNumber.substring(1);

                if (phoneNumber.equals("")) {
                    Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_MOBILENUMBER_PRESENCE);
                    invalidCases++;
                } else if (!phoneNumber.startsWith("+") || !subPhoneNumber.matches("[0-9]+")) {
                    Util_UtilUI.showErrorFieldEsignAuth(context, Util_Strings.KEY_ERROR_MOBILENUMBER_FORMAT);
                    invalidCases++;
                }

                if (invalidCases == 0) {
                    Config.SHOW_CONTRACT_AGAIN = true;

                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewVisibility(true);
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarLoadingContractVisible(true);
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarHeadlineVisible(true);
                    ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarDescriptionVisible(true);

                    ContinueSignCallback callback = () -> webView.post(() -> {
                        Config.SHOW_CONTRACT_AGAIN = true;
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewVisibility(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarLoadingContractVisible(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarHeadlineVisible(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarDescriptionVisible(false);

                        if (!Config.DTMAndPSM) {
                            ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setShowContractTextViewVisible(true);
                            ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBufferViewVisible(true);
                        }
                        webView.loadUrl(Config.OPENTRUST_URL);
                        handleTCWebviewClick(webView);

                    });

                    if (videoLiveStreamManager == null) {
                        Context applicationContext = context.getApplicationContext();
                        videoLiveStreamManager = new VideoLiveStreamManager(applicationContext);
                    }
                    videoLiveStreamManager.continueSignRESTCall(context, phoneNumber, dialog, callback);

                    if (Config.ERROR_LOGIN) {
                        Config.SHOW_CONTRACT_AGAIN = false;
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBackgroundViewVisibility(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setShowContractTextViewVisible(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setBufferViewVisible(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarLoadingContractVisible(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarHeadlineVisible(false);
                        ((Activities_VideoLiveStreamActivity_Super) context).overlayView.setProgressBarDescriptionVisible(false);


                    }
                }

            }
        });
        abortUpdate.setOnClickListener(view -> Util_UtilUI.showDeclineeSigning(context, dialog));
    }

    public void loadAccountForgotPassword(final Dialog dialog, final Context context) {
        headlineForgotPassword = dialog.findViewById(R.id.headlineForgotPassword);
        instructionForgotPassword = dialog.findViewById(R.id.instructionForgotPassword);
        continueVideoIdent = dialog.findViewById(R.id.confirmForgotPassword);
        abortForgotPassword = dialog.findViewById(R.id.abortForgotPassword);

        if (IDnowSDK.getNewBrand()) {
            continueVideoIdent.setBackgroundResource(R.drawable.rounded_background_orange);
            abortForgotPassword.setBackgroundResource(R.drawable.rounded_background_grey);
        } else {
            continueVideoIdent.setBackgroundResource(R.drawable.rounded_button_orange);
            abortForgotPassword.setBackgroundResource(R.drawable.rounded_cornor_gray);
        }

        headlineForgotPassword.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_FORGOT_PASSWORD_HEADLINE, null));
        instructionForgotPassword.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_FORGOT_PASSWORD_INSTRUCTION, null));
        continueVideoIdent.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_FORGOT_PASSWORD_CONT_IDENT, null));
        abortForgotPassword.setText(Util_Strings.getStringWithDefault(this, Util_Strings.KEY_SIGNING_ABORT, null));
        continueVideoIdent.setOnClickListener(view -> {
            dialog.dismiss();
            Config.RESTART_VIDEO_IDENT = true;
            Intent intent;

            if (IDnowSDK.isShowVideoOverviewCheck(context)) {
                intent = new Intent(context, IDnowSDK.getCheckScreenActivity());
            } else {
                intent = new Intent(context, Activities_EntryActivity.class);
            }

            intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP);
            IDnowSDK.updateResultCode(IDnowSDK.RESULT_CODE_CANCEL);
            IDnowSDK.getInstance().deliverResult(RESULT_CODE_CANCEL, getIntent());
            setResult(IDnowSDK.RESULT_CODE_CANCEL, getIntent());
            closeSocket();
            finishAndRemoveTask();
            if (!Config.BACK_TO_VID || IDnowSDK.getOverrideEntryActivity()) {
                context.startActivity(intent);
            }
            Config.BACK_TO_VID = false;
        });
        abortForgotPassword.setOnClickListener(view -> dialog.dismiss());
    }

    public void loadNamirialSigning() {
        videoLiveStreamManager.getApprovalPhrasesViaREST(approvalPhrasesCallback);
    }

    public void loadWebView(WebView webView, Activities_VideoLiveStreamActivity_Super context) {
        webView.post(() -> {
            webView.loadUrl(Config.OPENTRUST_URL);
            handleTCWebviewClick(webView);
            if (!Config.DTMAndPSM) {
                overlayView.setShowContractTextViewVisible(true);
                overlayView.setBufferViewVisible(true);

            }
            context.overlayView.setBackgroundViewVisibility(false);
            context.overlayView.setProgressBarLoadingContractVisible(false);
            context.overlayView.setProgressBarHeadlineVisible(false);
            context.overlayView.setProgressBarDescriptionVisible(false);
        });
    }

    private boolean isNotAgentFlowAndNotWallet() {
        return !VIDEO_IDENT_AGENT_FLOW && !(WALLET_LOGIN && !RESTART_VIDEO_IDENT);
    }

    @RequiresApi(api = VERSION_CODES.O)
    public void startService() {
        Intent intent = new Intent(this, IDnowForegroundService.class);

        int cameraPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int audioPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO);

        if (cameraPermission == PackageManager.PERMISSION_GRANTED && audioPermission == PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= VERSION_CODES.O) {

                final Context applicationContext = mContext.getApplicationContext();
                applicationContext.bindService(intent, new ServiceConnection() {
                    @Override
                    public void onServiceConnected(ComponentName name, IBinder binder) {
                        if (binder instanceof IDnowForegroundBinder) {
                            IDnowForegroundBinder iDnowForegroundBinder = (IDnowForegroundBinder) binder;
                            IDnowForegroundService service = iDnowForegroundBinder.getService();
                            if (service != null) {
                                try {
                                    startForegroundService(intent);
                                } catch (Exception e) {
                                    Util_Log.e(LOGTAG, "Start service failed", e);
                                    return;
                                }
                            }
                        }
                        applicationContext.unbindService(this);
                    }

                    @Override
                    public void onServiceDisconnected(ComponentName name) {
                    }
                }, Context.BIND_AUTO_CREATE);
            }
        } else {
            Util_Log.e(LOGTAG, "No permissions Microphone and/or Camera!");
        }
    }

    private void stopService() {
        Intent intent = new Intent(this, IDnowForegroundService.class);
        stopService(intent);
    }

    @Override
    protected void onStart() {
        Util_CustomLogData.onStart(this);
        super.onStart();
    }
}
