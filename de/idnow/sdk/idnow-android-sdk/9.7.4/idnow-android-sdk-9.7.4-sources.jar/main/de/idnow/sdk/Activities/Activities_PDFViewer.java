package de.idnow.sdk.Activities;

import static de.idnow.sdk.Config.URL_DOCUMENT_NAMIRIAL;

import android.content.Context;
import android.os.Bundle;
import android.webkit.WebSettings;
import java.io.File;

import de.idnow.sdk.BuildConfig;
import de.idnow.sdk.Config;
import de.idnow.sdk.R;
import de.idnow.sdk.util.Util_CustomWebView;

public class Activities_PDFViewer extends BaseActivity {

    public Util_CustomWebView pdfView;
    File file;

    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pdf_viewer);

        pdfView= findViewById(R.id.pdfView);

        context = this;

        pdfView.getSettings().setLoadsImagesAutomatically(true);
        pdfView.getSettings().setJavaScriptEnabled(true);
        pdfView.clearHistory();
        WebSettings settings = pdfView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(true);
        pdfView.loadUrl("file:///android_asset/pdfviewer.html?"+URL_DOCUMENT_NAMIRIAL);

    }
}