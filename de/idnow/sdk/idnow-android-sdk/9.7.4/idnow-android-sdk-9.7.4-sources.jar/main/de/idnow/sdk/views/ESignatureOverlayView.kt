package de.idnow.sdk.views

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.webkit.WebView
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.core.view.isVisible
import de.idnow.sdk.Config
import de.idnow.sdk.IDnowSDK
import de.idnow.sdk.R
import de.idnow.sdk.databinding.ViewOverlayBinding
import de.idnow.sdk.util.Util_Strings
import de.idnow.sdk.util.Util_UtilUI

class ESignatureOverlayView @JvmOverloads constructor(
    context: Context,
    attributeSet: AttributeSet? = null,
    defStyle: Int = 0
) : RelativeLayout(context, attributeSet, defStyle) {

    private var binding: ViewOverlayBinding
    var pdfWebView: PDFWebView
    var signContractView: SignContractView
    var eSignConsentView: ESignConsentView
    var buttonNext: Button
    var openTrustWebView: WebView
    var openTrustWebViewTC : WebView
    var prepareTitle : TextView
    var prepareDesc : TextView
    var progressBarPrepareSigningLoading: ProgressBar

    init {
        binding = ViewOverlayBinding.inflate(LayoutInflater.from(context), this, true)
        pdfWebView = binding.pdfWebView
        signContractView = binding.signContractView
        eSignConsentView = binding.eSignConsentView
        buttonNext = binding.buttonNext
        openTrustWebView = binding.openTrustWebView
        openTrustWebViewTC = binding.openTrustWebViewTC
        prepareTitle = binding.prepareTitle
        prepareDesc = binding.prepareDesc
        progressBarPrepareSigningLoading = binding.progressBarPrepareSigningLoading


        binding.prepareTitle.text = Util_Strings.getStringWithDefault(context,Util_Strings.KEY_ESIGN_PREPARATION_TITLE,Util_Strings.LOCAL_KEY_ESIGN_PREPARATION_TITLE)
        binding.prepareDesc.text = Util_Strings.getStringWithDefault(context.getApplicationContext(),Util_Strings.KEY_ESIGN_PREPARATION_DESC,Util_Strings.LOCAL_KEY_ESIGN_PREPARATION_DESC)
        setVisiblePrepareSigningProgressLoading()
        binding.buttonNext.text = Util_Strings.getStringWithDefault(
            context,
            Util_Strings.KEY_VIDEO_IDENT_ESIGN_ACCEPT_BUTTON,
            Util_Strings.LOCAL_KEY_VIDEO_IDENT_ESIGN_ACCEPT_BUTTON
        )

        binding.progressBarHeadline.text = Util_Strings.getStringWithDefault(
            context,
            Util_Strings.KEY_SIGNING_PREPARING_HEADLINE,
            null
        )

        binding.progressBarDescription.text = Util_Strings.getStringWithDefault(
            context,
            Util_Strings.KEY_SIGNING_PREPARING_DESCRIPTION,
            null
        )

        if (!Config.OTP_DISPLAY_SIGNING){
            binding.eSigningButtonNext.text = Util_Strings.getStringWithDefault(
                context,
                Util_Strings.KEY_SIGNING_BUTTON_DUCPLICATED,
                Util_Strings.LOCAL_KEY_VIDEO_IDENT_ESIGN_BACK_SIGNING
            )
        }
        else{
            binding.eSigningButtonNext.text = Util_Strings.getStringWithDefault(
                context,
                Util_Strings.KEY_VIDEO_IDENT_ESIGN_BACK_SIGNING,
                Util_Strings.LOCAL_KEY_VIDEO_IDENT_ESIGN_BACK_SIGNING
            )
        }

        binding.eSigningButtonCancel.text = Util_Strings.getStringWithDefault(
            context,
            Util_Strings.KEY_VIDEO_IDENT_COMMON_CANCEL,
            Util_Strings.LOCAL_KEY_VIDEO_IDENT_COMMON_CANCEL
        )

        initButtonStyles()

        setSigningButtonCheckDocumentListener()
        setESigningButtonHideDocumentListener()

        if (IDnowSDK.getNewBrand()) {
            binding.eSigningButtonNext.setBackgroundResource(R.drawable.rounded_background_grey)
            binding.eSigningButtonCancel.setBackgroundResource(R.drawable.rounded_background_grey)
        }
    }

    fun initButtonStyles() {
        Util_UtilUI.setProceedButtonBackgroundSelector(binding.eSigningButtonCancel)
        Util_UtilUI.setProceedButtonBackgroundSelector(binding.eSigningButtonNext)
        Util_UtilUI.setProceedButtonBackgroundSelector(binding.buttonNext)
        Util_UtilUI.setESignatureTextColorSelector(binding.declineContractTextView)
        Util_UtilUI.setESignatureTextColorSelector(binding.showContractTextView)
    }

    fun setESignWebViewContainerVisible(isVisible: Boolean) {
        binding.eSigningWebViewContainer.isVisible = isVisible
    }

    fun setButtonViewVisible(isVisible: Boolean) {
        binding.buttonView.isVisible = isVisible
    }

    fun setSignatureButtonViewVisible(isVisible: Boolean) {
        binding.linearLayoutSignatureButtons.isVisible = isVisible
    }

    fun setBufferViewVisible(isVisible: Boolean) {
        binding.bufferView.isVisible = isVisible
    }

    fun setShowContractTextViewVisible(isVisible: Boolean) {
        binding.showContractTextView.isVisible = isVisible
    }

    fun setBackgroundViewVisibility(isVisible: Boolean) {
        binding.viewBackgroundProgress.isVisible = isVisible
    }

    fun setProgressBarHeadlineVisible(isVisible: Boolean) {
        binding.progressBarHeadline.isVisible = isVisible
    }

    fun setProgressBarDescriptionVisible(isVisible: Boolean) {
        binding.progressBarDescription.isVisible = isVisible
    }

    fun setContentViewVisible(isVisible: Boolean) {
        binding.contentView.isVisible = isVisible
    }

    fun setProgressBarLoadingContractVisible(isVisible: Boolean) {
        binding.progressBarLoadingContract.isVisible = isVisible
    }

    fun setESigningNativeContainerVisible(isVisible: Boolean) {
        binding.eSigningNativeContainer.isVisible = isVisible
    }

    fun setESigningPreparationContaoinerVisible(isVisible: Boolean) {
        binding.preapreeSigningViewContainer.isVisible = isVisible
    }

    fun setESigningProgressContainerVisible(isVisible: Boolean) {
        binding.eSigningProgressContainer.isVisible = isVisible
    }

    fun setESigningNativeContentVisible(isVisible: Boolean) {
        binding.eSigningNativeContent.isVisible = isVisible
    }

    fun setESigningSuccessContainerVisible(isVisible: Boolean) {
        binding.eSigningSuccessContainer.isVisible = isVisible
    }

    fun setESigningExpandViewContainerVisible(isVisible: Boolean) {
        binding.eSigningExpandViewContainer.isVisible = isVisible
    }

    fun setESignatureNextButtonEnabled(isEnabled: Boolean) {
        binding.eSigningButtonNext.isEnabled = isEnabled
    }

    fun addViewToESigningNativeContainer(view: View) {
        val params = view.layoutParams as? MarginLayoutParams
        params?.setMargins(
            0,
            Util_UtilUI.getPxFromDp(context, 16),
            0,
            0
        )

        binding.eSigningNativeContainer.addView(view)
    }

    fun addESigningPreparationContaoinerVisible(view: View) {
        binding.preapreeSigningViewContainer.addView(view)
    }

    fun setVisiblePrepareSigningProgressLoading() {
        binding.progressBarPrepareSigningLoading.visibility = View.VISIBLE
    }



    fun addViewToESigningCheckboxContainer(view: View) {
        binding.eSignatureCheckBoxContainer.addView(view)
    }

    fun setBackgroundViewColor(color: Int) {
        binding.viewBackgroundProgress.setBackgroundColor(color)
    }

    fun addMarginsToButtonView() {
        val params = binding.buttonView.layoutParams as LayoutParams
        params.setMargins(
            Util_UtilUI.getPxFromDp(context, 8),
            0,
            Util_UtilUI.getPxFromDp(context, 8),
            0
        )
        binding.buttonView.layoutParams = params
    }

    fun addMarginBottomToButtonView() {
        val params = binding.buttonView.layoutParams as LayoutParams
        params.setMargins(
            Util_UtilUI.getPxFromDp(context, 8),
            0,
            Util_UtilUI.getPxFromDp(context, 8),
            Util_UtilUI.getPxFromDp(context, 8)
        ) //left, top, right, bottom
        binding.buttonView.layoutParams = params
        pdfWebView.removeMargins()
        binding.linearLayoutSignatureButtons.visibility = VISIBLE
    }

    fun handlingNextButtonActiveness(signed: Boolean) {
        buttonNext.isEnabled = signed
        buttonNext.isPressed = false
    }

    fun setDeclineOnClickListener(listener: OnClickListener) {
        binding.declineContractTextView.setOnClickListener(listener)
        binding.declineContractTextView.isPressed = false
    }

    fun showContractOnClickListener(listener: OnClickListener) {
        binding.showContractTextView.isPressed = false
        binding.showContractTextView.setOnClickListener(listener)
    }

    @SuppressLint("ClickableViewAccessibility")
    fun setContentViewOnTouchListener(listener: OnTouchListener) {
        binding.contentView.setOnTouchListener(listener)
    }

    fun setESignatureNextButtonListener(listener: OnClickListener) {
        binding.eSigningButtonNext.setOnClickListener(listener)
    }

    fun setESignatureCancelListener(listener: OnClickListener) {
        binding.eSigningButtonCancel.setOnClickListener(listener)
    }

    private fun setSigningButtonCheckDocumentListener() {
        binding.eSigningButtonCheckDocument.setOnClickListener {
            setESigningNativeContainerVisible(false)
            setESigningExpandViewContainerVisible(true)
        }
    }

    private fun setESigningButtonHideDocumentListener() {
        binding.eSigningButtonHideDocument.setOnClickListener {
            setESigningNativeContainerVisible(true)
            setESigningExpandViewContainerVisible(false)
        }
    }

    fun setSigningTextViewHeaderMessage(message: String) {
        binding.eSigningTextViewHeader.text = message
    }

    fun injectCSS() {
        if (Config.DARK_MODE) {
            binding.openTrustWebView.loadUrl(
                "javascript:document.body.style.setProperty(\"color\", \"white\");"
            )
            binding.openTrustWebView.loadUrl(
                "javascript:document.body.style.setProperty(\"background-color\", \"#32343F\");"
            )
            binding.openTrustWebView.loadUrl(
                "javascript:document.getElementById(\"continueButton\").style.setProperty(\"background-color\", \"#FF6B40\");"
            )
            binding.openTrustWebView.loadUrl(
                "javascript:document.getElementById(\"psm_otp_code\").style.setProperty(\"background-color\", \"#39414A\");"
            )
            binding.openTrustWebView.loadUrl(
                "javascript:document.getElementById(\"signButton\").style.setProperty(\"background-color\", \"#FF6B40\");"
            )
            binding.openTrustWebView.loadUrl(
                "javascript:document.getElementById(\"resendOtpButton\").style.setProperty(\"color\", \"#FF6B40\");"
            )
        }
    }
}