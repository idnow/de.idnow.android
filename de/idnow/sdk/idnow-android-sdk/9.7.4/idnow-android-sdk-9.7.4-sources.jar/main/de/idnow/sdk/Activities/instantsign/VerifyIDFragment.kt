package de.idnow.sdk.Activities.instantsign

class VerifyIDFragment {
}