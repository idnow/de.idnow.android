package de.idnow.android.eid.AusweisApp2SDK.util

import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import de.idnow.android.eid.AusweisApp2SDK.core.IdentificationCallback
import de.idnow.android.eid.AusweisApp2SDK.core.IdentificationManager

abstract class NfcInterceptorActivity : AppCompatActivity() {
    var nfcDispatcher: ForegroundDispatcher? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        nfcDispatcher = ForegroundDispatcher(this)
        IdentificationManager.bind(applicationContext, provideIdentificationCallback())
    }

    override fun onResume() {
        super.onResume()  // IMPORTANT: Call super first!
        // Pass the callback for Reader Mode (Android 15+)
        nfcDispatcher?.enable(::handleNfcTag)
    }

    override fun onPause() {
        nfcDispatcher?.disable()
        super.onPause()  // IMPORTANT: Call super after disable!
    }

    override fun onDestroy() {
        IdentificationManager.unbind()
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Android 14 and below: Foreground Dispatch flow
        val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
        tag?.let(IdentificationManager::dispatchNfcTag)
    }

    /**
     * Android 15+: Reader Mode flow
     * Called when an NFC tag is detected via Reader Mode (Android 15+).
     */
    protected fun handleNfcTag(tag: Tag) =
        IdentificationManager.dispatchNfcTag(tag)

    protected abstract fun provideIdentificationCallback(): IdentificationCallback
}
