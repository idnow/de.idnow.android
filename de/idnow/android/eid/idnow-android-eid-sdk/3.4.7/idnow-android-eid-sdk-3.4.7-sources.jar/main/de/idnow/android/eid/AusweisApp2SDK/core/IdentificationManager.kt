@file:Suppress("unused")

package de.idnow.android.eid.AusweisApp2SDK.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.nfc.Tag
import android.os.IBinder
import com.governikus.ausweisapp2.IAusweisApp2Sdk
import com.governikus.ausweisapp2.IAusweisApp2SdkCallback
import de.idnow.android.eid.Config
import de.idnow.android.eid.Config.ISSUER_URL
import de.idnow.android.eid.Config.VALIDITY_DATE
import de.idnow.android.eid.fragments.Fragment_HoldIDBack
import de.idnow.android.eid.util.Util_Log
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Collections
import kotlin.concurrent.Volatile
import kotlin.time.Duration.Companion.seconds

object IdentificationManager {
    private const val LOGTAG = "IDNOW_IdentificationManager"
    private const val START_SERVICE_INTENT_ACTION = "com.governikus.ausweisapp2.START_SERVICE"
    private val coroutineScope = MainScope()

    private lateinit var appContext: Context

    @Volatile
    private var service: IAusweisApp2Sdk? = null
    private val serviceConnection: ServiceConnection by lazy(::resolveServiceConnection)

    @Volatile
    private var isServiceUnbinding = false

    private var allowExecPendingActionsJob: Job? = null
    private var allowExecPendingActions = false
    private val pendingActions: MutableList<() -> Unit> =
        Collections.synchronizedList(mutableListOf())

    private var callback: IdentificationCallback? = null
    private val serviceCallback: IAusweisApp2SdkCallback by lazy(::provideServiceCallback)

    @Volatile
    private var serviceCallbackAttached = false

    fun bind(context: Context, callback: IdentificationCallback) {
        appContext = context.applicationContext
        if (service != null) {
            Util_Log.w(LOGTAG, "Service already bound")
            return
        }
        Util_Log.i(LOGTAG, "Binding service...")
        this.callback = callback
        isServiceUnbinding = false
        allowExecPendingActionsJob?.cancel()
        allowExecPendingActions = false
        pendingActions.clear()
        serviceCallbackAttached = false
        val serviceIntent = Intent(START_SERVICE_INTENT_ACTION)
        serviceIntent.setPackage(context.packageName)
        context.bindService(
            serviceIntent,
            serviceConnection,
            Context.BIND_AUTO_CREATE
        )
    }

    fun unbind() {
        isServiceUnbinding = true
        Util_Log.i(LOGTAG, "Unbinding service... ")
        callback = null
        appContext.unbindService(serviceConnection)
        reset()
    }

    fun startIdent(tokenURL: String) {
        send(
            IdentificationUtil.buildCmdString(
                IdentificationUtil.CMD_RUN_AUTH,
                Pair(IdentificationUtil.PARAM_TCTOKEN, tokenURL),
                Pair(IdentificationUtil.PARAM_STATUS, true)
            )
        )
    }

    fun setNewPin(pin: String) {
        send(
            IdentificationUtil.buildCmdString(
                IdentificationUtil.CMD_SET_NEW_PIN, Pair(
                    IdentificationUtil.PARAM_VALUE, pin
                )
            )
        )
    }

    fun setPin(pin: String) {
        //TODO callback required
        Config.PIN_IS_SET = true
        send(
            IdentificationUtil.buildCmdString(
                IdentificationUtil.CMD_SET_PIN, Pair(
                    IdentificationUtil.PARAM_VALUE, pin
                )
            )
        )
    }

    fun setPuk(puk: String) {
        send(
            IdentificationUtil.buildCmdString(
                IdentificationUtil.CMD_SET_PUK, Pair(
                    IdentificationUtil.PARAM_VALUE, puk
                )
            )
        )
    }

    fun setCan(can: String) {
        Config.PIN_IS_SET = true
        send(
            IdentificationUtil.buildCmdString(
                IdentificationUtil.CMD_SET_CAN, Pair(
                    IdentificationUtil.PARAM_VALUE, can
                )
            )
        )
    }

    fun changePin() {
        send(
            IdentificationUtil.buildCmdString(
                IdentificationUtil.CMD_RUN_CHANGE_PIN,
                null,
                Pair(IdentificationUtil.PARAM_STATUS, true)
            )
        )
    }

    fun requestInterruption() {
        send(IdentificationUtil.buildCmdString(IdentificationUtil.CMD_INTERRUPT))
    }

    fun requestContinue() {
        send(IdentificationUtil.buildCmdString(IdentificationUtil.CMD_CONTINUE))
    }

    fun requestAcceptRights() {
        send(IdentificationUtil.buildCmdString(IdentificationUtil.CMD_ACCEPT))
    }

    fun requestCancel() {
        send(IdentificationUtil.buildCmdString(IdentificationUtil.CMD_CANCEL))
    }

    fun requestGetCertificate() {
        send(IdentificationUtil.buildCmdString(IdentificationUtil.CMD_GET_CERTIFICATE))
    }

    private fun send(cmd: String) = safeExecAction {
        Util_Log.d(LOGTAG, "SessionID: ${Config.SessionID}")
        Util_Log.d(LOGTAG, "Sending command: $cmd")
        try {
            if (service?.send(Config.SessionID, cmd) == false)
                throw Exception("Send command failed")
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Could not send command to SDK", e)
            callback?.onIdentificationError()
        }
    }

    private fun onMessageReceived(messageJson: String) {
        Util_Log.d(LOGTAG, "handleMessage: $messageJson")
        val message = IdentificationUtil.parseJson(messageJson)
        Util_Log.d(LOGTAG, message.toString())

        if (message == null) {
            Util_Log.e(LOGTAG, "Message to handle is null")
            return
        }

        schedulePendingActionExec()
        when (message.msg) {
            IdentificationUtil.MSG_STATUS -> {
                if (Fragment_HoldIDBack.getInstance() != null && Fragment_HoldIDBack.getInstance().isAdded) {
                    when (message.progress) {
                        "20" -> {
                            Util_Log.i(LOGTAG, "Card reading - success establish connection")
                            callback?.onCardConnectionEstablished()
                        }

                        "40" -> {
                            Util_Log.i(LOGTAG, "Card reading - pin verified")
                            callback?.onCardPinVerified()
                        }

                        "60" -> {
                            Util_Log.i(LOGTAG, "Card reading - certification verified")
                            callback?.onCardCertificationVerified()
                        }

                        "80" -> {
                            Util_Log.i(LOGTAG, "Card reading - encrypted data transferred")
                            callback?.onCardEncryptedDataTransferred()
                        }
                    }
                }
            }

            IdentificationUtil.MSG_AUTH -> {
                println("IdentSDK MSG_AUTH Config.USER_RESTART_FLOW :" + Config.USER_RESTART_FLOW)


                if (message.result?.reason.equals("User_Cancelled") && Config.USER_RESTART_FLOW) {
                    Util_Log.i(LOGTAG, "Flow restart requested")
                    callback?.onFlowRestartRequested()
                } else
                    if (message.url?.contains(
                            "eid/error?message=NAME_MISMATCH&ResultMajor=ok",
                            true
                        ) == true
                    ) {
                        Util_Log.i(LOGTAG, "Identification failed. Reason: name mismatch")
                        callback?.onNameMismatchError()
                        return
                    } else
                        if (message.url?.contains("eid/error?message=ResultMajor=ok") == true) {
                            Util_Log.e(LOGTAG, "Identification failed. Reason: unknown")
                            callback?.onUnknownError()
                            return
                        } else
                            if (message.url?.contains("eid/success?ResultMajor=ok") == true) {
                                Util_Log.i(LOGTAG, "eid/success")
                                callback?.onIdentificationCompleted()
                                return
                            } else {
                                Util_Log.e(LOGTAG, "Identification failed. Reason: unknown")
                                callback?.onUnknownError()
                            }
            }

            IdentificationUtil.MSG_ACCESS_RIGHTS -> {
                Util_Log.i(LOGTAG, "Access rights required")
                Util_Log.d(LOGTAG, message.chat!!.effective!!.toString())
                callback?.onAccessRightsRequired(message.chat.required)
            }

            IdentificationUtil.MSG_READER -> {
                Util_Log.i(LOGTAG, "Read card started")
                message.card ?: run {
                    Util_Log.e(LOGTAG, "Read card failed. Card is null")
                    return
                }
                callback?.onCardReadingStarted()
            }

            IdentificationUtil.MSG_INSERT_CARD -> {
                Util_Log.i(LOGTAG, "Card recognized")
                callback?.onCardRecognized()
            }

            IdentificationUtil.MSG_ENTER_PIN -> {
                Util_Log.i(LOGTAG, "Wrong pin entered")
                val card = message.reader?.card ?: run {
                    Util_Log.e(LOGTAG, "Wrong pin entered. Reader or card is null")
                    return
                }
                var retryCount = 0

                if (card.retryCounter > -1 && card.retryCounter < 3) {
                    if (card.retryCounter == 2) {
                        retryCount = 2
                    } else if (card.retryCounter == 1) {
                        retryCount = 1
                    }
                } else if (card.retryCounter == 3) {
                    retryCount = 3
                }

                callback?.onPinEntryFailed(retryCount)
            }

            IdentificationUtil.MSG_ENTER_PUK -> {
                Util_Log.i(LOGTAG, "Wrong puk entered")
                callback?.onPukEntryFailed()
            }

            IdentificationUtil.MSG_ENTER_CAN -> {
                Util_Log.i(LOGTAG, "Request enter can")
                val card = message.reader?.card ?: run {
                    Util_Log.e(LOGTAG, "Request enter can failed. Reason: card is null")
                    return
                }

                if (card.retryCounter > -1 && card.retryCounter < 3) {
                    if (card.retryCounter == 2) {
                        Util_Log.i(LOGTAG, "Wrong pin entered. Remaining tries: 2")
                        callback?.onPinEntryFailed(2)
                    } else if (card.retryCounter == 1) {
                        Util_Log.i(LOGTAG, "Wrong pin entered. Remaining tries before can: 1")
                        callback?.onPinEntryLastAttemptBeforeCan()
                    }
                }
            }

            IdentificationUtil.MSG_ENTER_NEW_PIN -> {
                Util_Log.i(LOGTAG, "Request enter new pin")
                callback?.onNewPinEntryRequested()
            }

            IdentificationUtil.MSG_CHANGE_PIN -> {
                val result = message.success.equals("true", ignoreCase = true)
                Util_Log.i(LOGTAG, "Change pin result: $result")
                callback?.onPinChanged(result)
            }

            IdentificationUtil.MSG_INSERT_CERTIFICATE -> {
                Util_Log.i(LOGTAG, "Certificate inserted")
                VALIDITY_DATE =
                    message.validity!!.expirationDate + " - " + message.validity.effectiveDate
                ISSUER_URL = message.description!!.issuerUrl

                callback?.onCertificateInserted()
            }

            IdentificationUtil.MSG_BAD_STATE ->
                Util_Log.e(LOGTAG, "Bad state: ${message.msg}")

            IdentificationUtil.MSG_INTERNAL_ERROR ->
                Util_Log.e(LOGTAG, "Internal error: ${message.msg}")

            IdentificationUtil.MSG_INVALID ->
                Util_Log.e(LOGTAG, "Invalid command: ${message.msg}")

            IdentificationUtil.MSG_UNKNOWN_COMMAND ->
                Util_Log.e(LOGTAG, "Unknown command: ${message.msg}")

            IdentificationUtil.MSG_PAUSE -> {
                Util_Log.i(LOGTAG, "Process paused")
                callback?.onProcessPaused()
                requestContinue()
            }
        }
    }

    private fun attachServiceCallback() {
        Util_Log.i(LOGTAG, "Attaching service callback...")
        try {
            if (service?.connectSdk(serviceCallback) == true) {
                Util_Log.i(LOGTAG, "Service callback attached")
                serviceCallbackAttached = true
                schedulePendingActionExec()
            } else {
                throw Exception("Failed attaching service callback")
            }
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Sdk binding failed", e)
            callback?.onSdkConnectionError()
            unbind()
        }
    }

    fun dispatchNfcTag(tag: Tag) = safeExecAction {
        try {
            service?.updateNfcTag(Config.SessionID, tag)
        } catch (e: Exception) {
            callback?.onNfcTagDispatchError()
            Util_Log.e(
                LOGTAG,
                "An error occurred updating/dispatching a NFC Tag",
                e
            )
        }
    }

    private fun reset() {
        service = null
        serviceCallbackAttached = false
        callback = null
        resetPendingActions()
    }

    private fun resetPendingActions() {
        allowExecPendingActionsJob?.cancel()
        allowExecPendingActionsJob = null
        allowExecPendingActions = false
        pendingActions.clear()
    }

    private fun safeExecAction(action: () -> Unit) {
        if (serviceCallbackAttached) {
            action.invoke()
        } else {
            pendingActions.add(action)
        }
    }

    @Synchronized
    private fun schedulePendingActionExec() {
        cancelPendingActionExecTimer()
        if (serviceCallbackAttached) {
            allowExecPendingActionsJob = coroutineScope.launch {
                delay(2.seconds)
                allowExecPendingActions = true
                execPendingAction()
            }
        } else {
            allowExecPendingActions = false
        }
    }

    @Synchronized
    private fun cancelPendingActionExecTimer() {
        allowExecPendingActionsJob?.cancel()
        allowExecPendingActionsJob = null
    }

    @Synchronized
    private fun execPendingAction() {
        if (allowExecPendingActions.not() || pendingActions.isEmpty())
            return

        allowExecPendingActions = false
        pendingActions.removeFirstOrNull()?.invoke()
    }

    private fun resolveServiceConnection() = object : ServiceConnection {
        override fun onServiceConnected(
            name: ComponentName?,
            service: IBinder?
        ) {
            try {
                Util_Log.i(LOGTAG, "Service connected")
                this@IdentificationManager.service =
                    IAusweisApp2Sdk.Stub.asInterface(service)
                attachServiceCallback()
            } catch (e: Exception) {
                Util_Log.e(LOGTAG, "Save service instance failed", e)
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            Util_Log.i(LOGTAG, "Service Disconnected")
            if (isServiceUnbinding) {
                isServiceUnbinding = false
            } else {
                Util_Log.e(LOGTAG, "Sdk connection error")
                callback?.onSdkConnectionError()
            }
            reset()
        }
    }

    private fun provideServiceCallback() = object : IAusweisApp2SdkCallback.Stub() {
        override fun sessionIdGenerated(pSessionId: String) {
            Util_Log.i(LOGTAG, "Sdk callback attached. Session created")
            Config.SessionID = pSessionId
        }

        override fun receive(pJson: String) {
            Util_Log.i(LOGTAG, "Message received")
            onMessageReceived(pJson)
        }

        override fun sdkDisconnected() {
            Util_Log.i(LOGTAG, "SDK Disconnected")
            serviceCallbackAttached = false
            resetPendingActions()
        }
    }
}
