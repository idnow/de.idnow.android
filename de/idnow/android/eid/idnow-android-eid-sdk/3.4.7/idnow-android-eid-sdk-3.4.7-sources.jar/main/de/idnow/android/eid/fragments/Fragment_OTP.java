package de.idnow.android.eid.fragments;

import static de.idnow.android.eid.Config.URL_DOCUMENT_NAMIRIAL;
import static de.idnow.android.eid.util.Util_Strings.KEY_EID_BUTTON_VERIFIYING;
import static de.idnow.android.eid.util.Util_Strings.KEY_LABEL_PHONE_VALIDATION_CORRECTED;
import static de.idnow.android.eid.util.Util_Strings.KEY_LABEL_PHONE_VALIDATION_ERROR;
import static de.idnow.android.eid.util.Util_Strings.KEY_VIDEO_IDENT_COMMON_ERROR;
import static de.idnow.android.eid.util.Util_Strings.KEY_VIDEO_IDENT_NOTIF_TITLE;
import static de.idnow.android.eid.util.Util_Strings.KEY_VIDEO_IDENT_REQUIRED_FIELD;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_COMMON_ERROR;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_LABEL_PHONE_VALIDATION_CORRECTED;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_LABEL_PHONE_VALIDATION_ERROR;

import android.Manifest;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

import de.idnow.android.eid.Adapters.CustomAdapter;
import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.UI.HeaderView;
import de.idnow.android.eid.UI.SubtitleView;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.models.Models_ApprovalPhrase;
import de.idnow.android.eid.models.Models_ConfirmationToken;
import de.idnow.android.eid.models.Models_EmptyJson;
import de.idnow.android.eid.models.Models_MobileNumber;
import de.idnow.android.eid.network.EidCallback;
import de.idnow.android.eid.network.EidError;
import de.idnow.android.eid.network.IDnowRestClient;
import de.idnow.android.eid.network.Network_RESTCalls;
import de.idnow.android.eid.util.Util;
import de.idnow.android.eid.util.Util_Log;
import de.idnow.android.eid.util.Util_Status;
import de.idnow.android.eid.util.Util_Strings;
import kotlin.Unit;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Response;

public class Fragment_OTP extends BaseFragment {
    private static final String LOGTAG = "IDNOW_Fragment_OTP";

    Button continue_button;
    Context context;
    EditText verify_code_textfield, editTextPhoneNr;
    TextView resendCodeText, incorrect_code;
    Spinner countryspinner;
    LinearLayout mobileLayout, codeLayout;
    ConstraintLayout layout_verification;
    LottieAnimationView verify_animation;

    ArrayList<JSONObject> countStrings = new ArrayList<JSONObject>();
    ArrayList<String> dial_code_list = new ArrayList<String>();
    String dial_code_country;
    String code_country;
    ImageView imageview_error;
    private HeaderView header;
    private SubtitleView subtitle;

    View view;

    public Fragment_OTP() {
        // Required empty public constructor
    }

    @SuppressLint({"CutPasteId", "SetTextI18n"})
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_otp, container, false);

        header = view.findViewById(R.id.header);
        subtitle = view.findViewById(R.id.subtitle);
        imageview_error = view.findViewById(R.id.imageview_error);

        header.setCancelAction(() -> {
            if (Config.OTP_SCREEN.equals(Util_Status.SCREEN_PHONE_NUMBER_CONFIRM_UPDATE)) {
                eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_CROSS);
                Config.CANCEL_REASON = "EID_USER_CANCELLATION_PHONE_CONFIRMATION";
            } else if (Config.OTP_SCREEN.equals(Util_Status.SCREEN_PHONE_NUMBER_OTP)) {
                eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_OTP_SCREEN_CROSS);
                Config.CANCEL_REASON = "EID_USER_CANCELLATION_VERIFICATION_CODE";
            }
            ((eIDActivity) context).getVisibleFragment();
            return Unit.INSTANCE;
        });

        continue_button = view.findViewById(R.id.continue_button);

        mobileLayout = view.findViewById(R.id.mobileLayout);
        codeLayout = view.findViewById(R.id.codeLayout);
        incorrect_code = view.findViewById(R.id.incorrect_code);
        incorrect_code.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_ESIGN_OTP_CODE_INCORRECT, Util_Strings.LOCAL_KEY_EID_ESIGN_OTP_CODE_INCORRECT));
        verify_code_textfield = view.findViewById(R.id.verify_code_textfield);
        verify_code_textfield.setHint(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_ESIGN_OTP_CODE_ENTER, Util_Strings.LOCAL_KEY_EID_ESIGN_OTP_CODE_ENTER));
        resendCodeText = view.findViewById(R.id.resendCodeText);

        editTextPhoneNr = view.findViewById(R.id.editTextPhoneNr);
        countryspinner = view.findViewById(R.id.countryspinner);

        context = getContext();

        layout_verification = view.findViewById(R.id.layout_verification);
        verify_animation = view.findViewById(R.id.verify_animation);

        resendCodeText.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_OTP_CODE_RESEND, Util_Strings.LOCAL_KEY_EID_ESIGN_OTP_CODE_RESEND));

        continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BUTTON_CONTINUE, Util_Strings.LOCAL_EID_BUTTON_CONTINUE));
        continue_button.setEnabled(false);
        Util.setProceedButtonBackgroundSelector(continue_button);

        verify_animation.setAnimation("loading.json");
        verify_animation.setRepeatCount(ValueAnimator.INFINITE);
        verify_animation.playAnimation();
        context = getActivity();

        if (Config.OTP_SCREEN.equals(Util_Status.SCREEN_PHONE_NUMBER_CONFIRM_UPDATE)) {

            eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_OTP_SCREEN_SHOWN);
            eIDSdk.startEvent(eIDSdk.EVENT_EID_QES_OTP_SCREEN_TIME_SPENT);


            try {
                JSONObject obj = new JSONObject(loadJSONFromAsset());
                JSONArray m_jArry = obj.getJSONArray("countries");
                ArrayList<HashMap<String, String>> formList = new ArrayList<HashMap<String, String>>();
                HashMap<String, String> m_li;

                for (int i = 0; i < m_jArry.length(); i++) {
                    JSONObject jo_inside = m_jArry.getJSONObject(i);
                    Util_Log.d("Details-->", jo_inside.getString("name"));
                    String name = jo_inside.getString("name");
                    String dial_code = jo_inside.getString("dial_code");
                    String code = jo_inside.getString("code");

                    //Add your values in your `ArrayList` as below:
                    m_li = new HashMap<String, String>();
                    m_li.put("name", name);

                    countStrings.add(i, jo_inside);

                    dial_code_list.add(i, dial_code);

                    m_li.put("dial_code", dial_code);

                    formList.add(m_li);

                }
            } catch (JSONException e) {
                Util_Log.e(LOGTAG, "Parse countries json failed", e);
            }

            CustomAdapter customAdapter = new CustomAdapter(getActivity().getApplicationContext(), countStrings);

            countryspinner.setAdapter(customAdapter);

            String phoneNumber = editTextPhoneNr.getText().toString();

            int pos = -1;

            code_country = getPhoneRegionCode(phoneNumber) != null ? getPhoneRegionCode(phoneNumber) : "";
            dial_code_country = "+" + getPhoneCountryCode(Config.USER_PHONE_NO);

            editTextPhoneNr.setText("+" + getPhoneCountryCode(Config.USER_PHONE_NO));


            if (pos >= 0) {
                countryspinner.setSelection(pos);
            } else {
                countryspinner.setSelection(dial_code_list.indexOf(dial_code_country));
            }

            continue_button.setEnabled(false);
            Util.setProceedButtonBackgroundSelector(continue_button);

            countryspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_FLAG_TAPPED);


                    editTextPhoneNr.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            return false;
                        }
                    });

                    countryspinner.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {

                            Config.PHONE_NUMBER_MAN_CHANGED = false;

                            return false;
                        }
                    });

                    if (!Config.PHONE_NUMBER_MAN_CHANGED) {

                        String dial_code_frm_list = null;
                        try {
                            dial_code_frm_list = countStrings.get(position).getString("dial_code");
                            dial_code_country = "+" + getPhoneCountryCode(editTextPhoneNr.getText().toString());
                            Config.USER_PHONE_NO = editTextPhoneNr.getText().toString().replace(dial_code_country, dial_code_frm_list);
                            editTextPhoneNr.setText(Config.USER_PHONE_NO);

                        } catch (JSONException e) {
                            Util_Log.e(LOGTAG, "Read phone number from json failed", e);
                        }

                        Config.PHONE_NUMBER_MAN_CHANGED = true;

                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });

            editTextPhoneNr.clearFocus();

            editTextPhoneNr.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View view, boolean hasFocus) {
                    if (!hasFocus) {
                        String number = editTextPhoneNr.getText().toString();
                        if (number != null && Util.isPhoneValid(number)) {
                            // Number is valid, should convert into e164
                            String finalNumber = Util.formatValidE164(number, Locale.getDefault());
                            if (finalNumber == null) {
                                displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getContext().getApplicationContext(), KEY_VIDEO_IDENT_REQUIRED_FIELD, LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD), Util_Strings.getStringWithDefault(getContext().getApplicationContext(), KEY_LABEL_PHONE_VALIDATION_ERROR, LOCAL_LABEL_PHONE_VALIDATION_ERROR));
                            } else {
                                if (!editTextPhoneNr.getText().toString().equals(finalNumber)) {
                                    displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getContext().getApplicationContext(), KEY_VIDEO_IDENT_NOTIF_TITLE, LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE), Util_Strings.getStringWithDefault(getContext().getApplicationContext(), KEY_LABEL_PHONE_VALIDATION_CORRECTED, LOCAL_LABEL_PHONE_VALIDATION_CORRECTED));
                                }
                                editTextPhoneNr.setText(finalNumber);
                                Config.USER_PHONE_NO = finalNumber;
                                return;
                            }
                        }
                    }
                }
            });

            editTextPhoneNr.addTextChangedListener(new TextWatcher() {
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_TEXTFIELD_TAPPED);

                    String partialPhone = s + "";

                    code_country = getPhoneRegionCode(partialPhone) != null ? getPhoneRegionCode(partialPhone) : "";
                    dial_code_country = "+" + getPhoneCountryCode(partialPhone);

                    int pos = -1;

                    for (int i = 0; i < countStrings.size(); i++) {
                        try {
                            if (code_country.equals(countStrings.get(i).getString("code"))) {
                                pos = i;
                                break;
                            }
                        } catch (JSONException e) {
                            Util_Log.e(LOGTAG, "Find country by code failed", e);
                        }
                    }

                    if (pos >= 0) {
                        countryspinner.setSelection(pos);
                    } else {
                        countryspinner.setSelection(dial_code_list.indexOf(dial_code_country));
                    }

                    if (Util.isPhoneValid(String.valueOf(s))) {
                        continue_button.setEnabled(true);
                        Util.setProceedButtonBackgroundSelector(continue_button);

                    } else {
                        continue_button.setEnabled(false);
                    }
                }

                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_TEXTFIELD_TAPPED);

                }

                @Override
                public void afterTextChanged(Editable s) {

                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_TEXTFIELD_FILLED);


                    if (Util.isPhoneValid(String.valueOf(s))) {

                        editTextPhoneNr.setError(null);

                    } else {

                        continue_button.setEnabled(false);

                    }
                }
            });

            mobileLayout.setVisibility(View.VISIBLE);
            codeLayout.setVisibility(View.GONE);
            header.setTitle(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_OTP_MOBILE_TITLE, Util_Strings.LOCAL_KEY_EID_ESIGN_OTP_MOBILE_TITLE));
            subtitle.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_OTP_MOBILE_DESC, Util_Strings.LOCAL_KEY_EID_ESIGN_OTP_MOBILE_DESC));

        } else if (Config.OTP_SCREEN.equals(Util_Status.SCREEN_PHONE_NUMBER_OTP)) {

            eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_SHOWN);
            eIDSdk.startEvent(eIDSdk.EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_TIME_SPENT);


            verify_code_textfield.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_OTP_SCREEN_TEXTFIELD_TAPPED);
                    verify_code_textfield.setBackgroundResource(R.drawable.background_textfield);
                    incorrect_code.setVisibility(View.GONE);
                    imageview_error.setVisibility(View.GONE);
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    verify_code_textfield.setBackgroundResource(R.drawable.background_textfield);
                    incorrect_code.setVisibility(View.GONE);
                    imageview_error.setVisibility(View.GONE);
                }

                @Override
                public void afterTextChanged(Editable s) {
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_OTP_SCREEN_TEXTFIELD_FILLED);
                    if (verify_code_textfield.length() == 6) {
                        continue_button.setEnabled(true);
                        Util.setProceedButtonBackgroundSelector(continue_button);
                    } else {
                        continue_button.setEnabled(false);
                        Util.setProceedButtonBackgroundSelector(continue_button);
                    }
                }
            });

            mobileLayout.setVisibility(View.GONE);
            codeLayout.setVisibility(View.VISIBLE);

            header.setTitle(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_OTP_CODE_TITLE, Util_Strings.LOCAL_KEY_EID_ESIGN_OTP_CODE_TITLE));

            String otp_descString = Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_OTP_CODE_DESC, Util_Strings.LOCAL_KEY_EID_ESIGN_OTP_CODE_DESC);
            otp_descString = otp_descString.replace("xxx", Config.USER_PHONE_NO);
            subtitle.setText(otp_descString);
        }

        resendCodeText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                incorrect_code.setVisibility(View.GONE);
                imageview_error.setVisibility(View.GONE);
                verify_code_textfield.setBackgroundResource(R.drawable.background_textfield);
                Toast.makeText(context, R.string.toast_digit_code_to_send, Toast.LENGTH_SHORT).show();
                eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_OTP_SCREEN_RESEND_BUTTON);
                resendConfirmationTokenRestCall();
            }
        });

        continue_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                hideSoftKeyboard(view);

                if (Config.OTP_SCREEN.equals(Util_Status.SCREEN_PHONE_NUMBER_OTP)) {
                    continue_button.setText(Util_Strings.getStringWithDefault(context, KEY_EID_BUTTON_VERIFIYING, Util_Strings.LOCAL_EID_BUTTON_VERIFIYING));
                    continue_button.setEnabled(false);
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_OTP_SCREEN_CONTINUE);
                    sendConfirmationTokenRestCall(verify_code_textfield.getText().toString(), Fragment_OTP.this, getActivity());
                } else if (Config.OTP_SCREEN.equals(Util_Status.SCREEN_PHONE_NUMBER_CONFIRM_UPDATE)) {
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_CONTINUE);
                    Config.USER_PHONE_NO = editTextPhoneNr.getText().toString();
                    updatePhoneNumberRestCall(Config.USER_PHONE_NO);

                }
            }
        });

        return view;
    }

    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = getActivity().getApplicationContext().getAssets().open("countrylist.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            Util_Log.e(LOGTAG, "Load country list json from assets failed", ex);
            return null;
        }
        return json;
    }

    public static String getPhoneRegionCode(String phoneNo) {
        String country = Locale.getDefault().getCountry();
        String regionCode = "";
        PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
        try {
            Phonenumber.PhoneNumber phonenumber = phoneNumberUtil.parse(phoneNo, country);
            regionCode = phoneNumberUtil.getRegionCodeForNumber(phonenumber);
        } catch (NumberParseException e) {
            Util_Log.e(LOGTAG, "Extract phone region code failed", e);
        }

        return regionCode;
    }

    public static int getPhoneCountryCode(String phoneNo) {
        String country = Locale.getDefault().getCountry();
        int countrycode = 0;
        PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
        try {
            Phonenumber.PhoneNumber phonenumber = phoneNumberUtil.parse(phoneNo, country);
            countrycode = phonenumber.getCountryCode();
        } catch (NumberParseException e) {
            Util_Log.e(LOGTAG, "Extract phone country code failed", e);
        }

        return countrycode;
    }

    private void verifyMobileNumberFormat() {

        String e164 = Util.formatValidE164(String.valueOf(Config.USER_PHONE_NO), Locale.getDefault());
        editTextPhoneNr.setText(Config.USER_PHONE_NO);

        if (e164 != null && !e164.equals(Config.USER_PHONE_NO)) {
            if (Util.isPhoneValid(e164)) {
                editTextPhoneNr.setText(e164);
                displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getActivity().getApplicationContext(), KEY_VIDEO_IDENT_NOTIF_TITLE, LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE), Util_Strings.getStringWithDefault(getContext(), KEY_LABEL_PHONE_VALIDATION_CORRECTED, LOCAL_LABEL_PHONE_VALIDATION_CORRECTED));
            } else {
                handleInvalidPhoneNumber();
            }

        } else if (e164 == null) {
            handleInvalidPhoneNumber();
        } else {
            // Input OK
            editTextPhoneNr.setText(e164);
            Config.USER_PHONE_NO = e164;
        }

    }

    private void handleInvalidPhoneNumber() {
        displayInvalidNumberDialog(Util_Strings.getStringWithDefault(getActivity().getApplicationContext(), KEY_VIDEO_IDENT_COMMON_ERROR, LOCAL_KEY_VIDEO_IDENT_COMMON_ERROR), Util_Strings.getStringWithDefault(getContext(), KEY_LABEL_PHONE_VALIDATION_ERROR, LOCAL_LABEL_PHONE_VALIDATION_ERROR));
        editTextPhoneNr.requestFocus();
    }

    private void displayInvalidNumberDialog(String title, String message) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle))
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        editTextPhoneNr.requestFocus();
                        editTextPhoneNr.postDelayed(new Runnable() {

                            @Override
                            public void run() {
                                InputMethodManager keyboard = (InputMethodManager)
                                        getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                if (keyboard != null) {
                                    keyboard.showSoftInput(editTextPhoneNr, 0);
                                }
                            }
                        }, 300);
                    }
                });

        alertDialogBuilder.show();


    }

    public void updatePhoneNumberRestCall(String phoneNumber) {

        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, eIDSdk.getInstance().getAppContext());

        EidCallback<Models_EmptyJson> callback = new EidCallback<Models_EmptyJson>() {
            @Override
            public void success(Models_EmptyJson models_mobileNumber, Response response) {
                verify_animation.setVisibility(View.GONE);
                layout_verification.setVisibility(View.VISIBLE);

                verify_animation.setVisibility(View.VISIBLE);
                layout_verification.setVisibility(View.GONE);

              /*  if ((ActivityCompat.checkSelfPermission((eIDActivity)context, PERMISSIONS[0]) != PackageManager.PERMISSION_GRANTED)||((ActivityCompat.checkSelfPermission((eIDActivity)context, PERMISSIONS[1]) != PackageManager.PERMISSION_GRANTED))) {
                    ActivityCompat.requestPermissions((eIDActivity)context, PERMISSIONS, 1);
                }*/
                prepareSigningSessionRestCall(context, Fragment_OTP.this, getActivity());
            }

            @Override
            public void failure(EidError error) {
                verify_animation.setVisibility(View.GONE);
                layout_verification.setVisibility(View.VISIBLE);
                Util.showRESTCallErrorDialog(context, error.getResponse().getStatus(), Fragment_OTP.this);
            }
        };

        retrofit2.Call<Models_EmptyJson> result = service.updateMobileNumber(
                new Models_MobileNumber(phoneNumber),
                eIDSdk.getCompanyId(),
                eIDSdk.getTransactionToken()
        );
        result.enqueue(callback);
    }

    public void getapprovalPhrasesRestCall(Context context, Fragment fragment, FragmentActivity fragmentActivity) {
        String customer = eIDSdk.getCompanyId();
        String token = eIDSdk.getTransactionToken();
        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, eIDSdk.getInstance().getAppContext());

        EidCallback<Models_ApprovalPhrase[]> callback = new EidCallback<Models_ApprovalPhrase[]>() {
            @Override
            public void success(Models_ApprovalPhrase[] approvalPhrases, Response response) {
                Config.MODEL_APPROVAL_PHRASES = approvalPhrases;
                getTSPDocumentRestCall(context, fragment, fragmentActivity);
            }

            @Override
            public void failure(EidError error) {
                Util.showRESTCallErrorDialog(context, error.getResponse().getStatus(), Fragment_OTP.this);
            }
        };

        retrofit2.Call<Models_ApprovalPhrase[]> result = service.getApprovalPhrases(customer, token);
        result.enqueue(callback);
    }

    public void getTSPDocumentRestCall(Context context, Fragment fragment, FragmentActivity fragmentActivity) {

        final String urlDocument = "";

        final OkHttpClient client = new OkHttpClient();

        String url = Config.CURRENT_SERVER.getApiHost(eIDSdk.getTransactionToken()) + "/api/v1/" + eIDSdk.getCompanyId() + "/identifications/" + eIDSdk.getTransactionToken() + "/tspDocument";

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Identification-Signature", Config.EID_SIGNATURE)
                .addHeader("Content-Type", "application/pdf")
                .build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                okhttp3.Response response = null;
                try {
                    response = client.newCall(request).execute();
                    Util.showRESTCallErrorDialog(context, response.code(), Fragment_OTP.this);
                } catch (IOException ioException) {
                    Util_Log.e(LOGTAG, "Fetch TSP document failed", ioException);
                }

             /*   Fragment_Signing fragment_signing = new Fragment_Signing();
                ((eIDActivity)getActivity()).hideIntroFragment(Fragment_OTP.this);
                ((eIDActivity)getActivity()).showIntroFragment(fragment_signing); */

            }

            @SuppressLint("SetJavaScriptEnabled")
            @Override
            public void onResponse(Call call, okhttp3.Response response) throws IOException {
                dataToPDF(response, context, fragment, fragmentActivity);
            }
        });
    }

    private static byte[] inputToByte(InputStream inputStream) throws IOException {
        ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
        byte[] buff = new byte[1024];
        int rc;
        while ((rc = inputStream.read(buff, 0, 1024)) > 0) {
            swapStream.write(buff, 0, rc);
        }
        byte[] in2b = swapStream.toByteArray();
        return in2b;

    }

    public void dataToPDF(okhttp3.Response response, Context context, Fragment fragment, FragmentActivity fragmentActivity) throws IOException {
        //---you need this to prevent the webview from
        // launching another browser when a url
        // redirection occurs---

        InputStream in = response.body().byteStream();

        byte[] bytesArray = inputToByte(in);

        File folder = null;
        String path = "";
        String fileName = "";
        path = context.getFilesDir().toString();
        folder = new File(context.getFilesDir() + "/IDnow");
        folder.mkdir();
        fileName = "/IDnow" + "-File-" + "SignatureContract" + ".pdf";
        path = path + "/IDnow";

        OutputStream outStream;
        outStream = new FileOutputStream(path + fileName);
        outStream.write(bytesArray);
        outStream.close();

        URL_DOCUMENT_NAMIRIAL = path + fileName;

        Fragment_Signing fragment_signing = new Fragment_Signing();
        ((eIDActivity) fragmentActivity).hideIntroFragment(fragment);
        if (fragment_signing != null && fragmentActivity != null) {
            ((eIDActivity) fragmentActivity).showIntroFragment(fragment_signing);
        }


    }


    public void prepareSigningSessionRestCall(Context context, Fragment fragment, FragmentActivity fragmentActivity) {
        String token = eIDSdk.getTransactionToken();
        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, eIDSdk.getInstance().getAppContext());

        EidCallback<Models_EmptyJson> callback = new EidCallback<Models_EmptyJson>() {
            @Override
            public void success(Models_EmptyJson models_emptyJson, Response response) {
                getapprovalPhrasesRestCall(context, fragment, fragmentActivity);
            }

            @Override
            public void failure(EidError error) {
                Util.showRESTCallErrorDialog(context, error.getResponse().getStatus(), Fragment_OTP.this);
            }
        };

        retrofit2.Call<Models_EmptyJson> result = service.prepareSigningSession(
                new Models_EmptyJson(),
                eIDSdk.getCompanyId(),
                eIDSdk.getTransactionToken(),
                Config.EID_SIGNATURE
        );
        result.enqueue(callback);
    }

    public void resendConfirmationTokenRestCall() {

        String customer = eIDSdk.getCompanyId();
        String token = eIDSdk.getTransactionToken();
        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, eIDSdk.getInstance().getAppContext());

        EidCallback<Object> callback = new EidCallback<Object>() {
            @Override
            public void success(Object models_emptyJson, Response response) {
                Toast.makeText(context, R.string.toast_digit_code_sent, Toast.LENGTH_LONG).show();
            }

            @Override
            public void failure(EidError error) {
                Util.showRESTCallErrorDialog(context, error.getResponse().getStatus(), Fragment_OTP.this);

            }
        };

        retrofit2.Call<Object> result = service.resendConfirmationToken(
                new Models_MobileNumber(Config.USER_PHONE_NO),
                customer,
                token,
                Config.EID_SIGNATURE
        );
        result.enqueue(callback);
    }

    public void sendConfirmationTokenRestCall(String confirmationCode, Fragment fragment, FragmentActivity fragmentActivity) {

        String customer = eIDSdk.getCompanyId();
        String token = eIDSdk.getTransactionToken();
        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, eIDSdk.getInstance().getAppContext());

        EidCallback<Object> callback = new EidCallback<Object>() {
            @Override
            public void success(Object models_emptyJson, Response response) {
                Config.SIGNING_SCREEN = Util_Status.SCREEN_DOCUMENTS_SIGNING;
                Config.GENERAL_CALLBACK = Config.CALLBACK_IDENT_SUCCEEDED;
                Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();
                ((eIDActivity) fragmentActivity).hideIntroFragment(fragment);
                ((eIDActivity) fragmentActivity).showIntroFragment(fragment_verificationStatus);
            }

            @Override
            public void failure(EidError error) {
                if (Config.DISPLAY_OTP_SIGNING) {
                    incorrect_code.setVisibility(View.VISIBLE);
                    imageview_error.setVisibility(View.VISIBLE);
                    verify_code_textfield.setBackgroundResource(R.drawable.rounded_background_incorrect);
                    continue_button.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_BUTTON_CONTINUE, Util_Strings.LOCAL_EID_BUTTON_CONTINUE));
                } else {
                    Util.showRESTCallErrorDialog(fragmentActivity, 0, Fragment_OTP.this);
                    ((eIDActivity) fragmentActivity).hideIntroFragment(fragment);

                }

            }
        };

        retrofit2.Call<Object> result = service.sendConfirmationToken(
                new Models_ConfirmationToken(confirmationCode),
                customer,
                token
        );
        result.enqueue(callback);
    }


    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_OTP.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_OTP.class);
    }

    public void hideSoftKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    String[] PERMISSIONS = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
    };

}