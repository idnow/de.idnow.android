package de.idnow.android.eid.fragments;

import static de.idnow.android.eid.Config.CALLBACK_SECOND_ATTEMPT;
import static de.idnow.android.eid.Config.DIGIT_SCREEN_TO_SHOW;
import static de.idnow.android.eid.util.Util.PinScreens.SCREEN_ENTER_5_DIGIT_PIN;
import static de.idnow.android.eid.util.Util.PinScreens.SCREEN_ENTER_CAN_CODE;
import static de.idnow.android.eid.util.Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
import static de.idnow.android.eid.util.Util.PinScreens.SCREEN_RE_ENTER_NEW_6_PIN;
import static de.idnow.android.eid.util.Util.showNoConnectionDialog;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.nfc.NfcAdapter;
import android.nfc.NfcManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.method.PasswordTransformationMethod;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import de.idnow.android.eid.AusweisApp2SDK.core.IdentificationManager;
import de.idnow.android.eid.Authada.ControlAuthadaIntegration;
import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.UI.GenericTextWatcherWrapper;
import de.idnow.android.eid.UI.HeaderView;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.util.Util;
import de.idnow.android.eid.util.Util_Strings;
import kotlin.Unit;

public class Fragment_EnterPin_6_digit extends BaseFragment {

    Button button_continue;

    Context context;

    TextView do_not_have_pin, enter_pin_title, enter_pin_desc, enter_pin_link, pin_error_text;

    public static EditText pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5;

    private static final String LOGTAG = "FRAGMENT ENTER PIN";

    public View view;

    FragmentActivity fragmentActivity;

    public AppCompatImageView show_pin;

    public BottomSheetDialog bottomSheetMoreInfo;

    public LinearLayout verfy_loading_signing;

    public ConstraintLayout pinLayout;

    public LottieAnimationView verify_animation;

    private Util.PinScreens currentScreen = SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;

    private String fiveDigitTransportPIN, newSixDigitPIN, reEnterSixDigitPIN, CANcode;

    private static Fragment_EnterPin_6_digit instance;

    private HeaderView header;

    ControlAuthadaIntegration controlAuthadaIntegration = new ControlAuthadaIntegration();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_enter_pin_6_digit, container, false);

        context = getContext();

        fragmentActivity = getActivity();

        instance = this;

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        header = view.findViewById(R.id.header);

        verfy_loading_signing = view.findViewById(R.id.verfy_loading_signing);
        pinLayout = view.findViewById(R.id.pinLayout);

        verfy_loading_signing.setVisibility(View.GONE);
        pinLayout.setVisibility(View.VISIBLE);

        verify_animation = view.findViewById(R.id.verify_animation);

        verify_animation.setAnimation("loading.json");
        verify_animation.setRepeatCount(ValueAnimator.INFINITE);
        verify_animation.playAnimation();

        button_continue = view.findViewById(R.id.button_continue_pin);
        do_not_have_pin = view.findViewById(R.id.do_not_have_pin);
        enter_pin_title = view.findViewById(R.id.enter_pin_title);
        enter_pin_desc = view.findViewById(R.id.enter_pin_desc);
        enter_pin_link = view.findViewById(R.id.enter_pin_link);
        show_pin = view.findViewById(R.id.show_pin);
        pin_error_text = view.findViewById(R.id.pin_error_text);

        header.setCancelAction(() -> {
            eIDSdk.recordEvent(eIDSdk.EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_CROSS);
            Config.CANCEL_REASON = "EID_USER_CANCELLATION_PIN_ENTRY";
            ((eIDActivity) context).getVisibleFragment();
            return Unit.INSTANCE;
        });

        button_continue.setEnabled(false);

        setProceedButtonBackgroundSelector(button_continue);

        button_continue.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BUTTON_CONTINUE, Util_Strings.LOCAL_EID_BUTTON_CONTINUE));

        pinBox0 = view.findViewById(R.id.pinBox0);

        pinBox1 = view.findViewById(R.id.pinBox1);

        pinBox2 = view.findViewById(R.id.pinBox2);

        pinBox3 = view.findViewById(R.id.pinBox3);

        pinBox4 = view.findViewById(R.id.pinBox4);

        pinBox5 = view.findViewById(R.id.pinBox5);

        pinBox0.requestFocus();

        show_pin.setOnTouchListener((v, event) -> {

            eIDSdk.recordEvent(eIDSdk.EVENT_EID_TRANPORT_PIN_SCREEN_SIX_DIGIT_PIN);

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    showPIN();
                    show_pin.setImageResource(R.drawable.eye_invisible);
                    return true;
                case MotionEvent.ACTION_UP:
                    hidePIN();
                    show_pin.setImageResource(R.drawable.eye);
                    return false;
                default:
                    return false;
            }
        });

        showDigitView(DIGIT_SCREEN_TO_SHOW);

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        if (!eIDSdk.getEIDTSP().equals("Governikus")) {
            setupPinBoxes();
        }

        button_continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                hideSoftKeyboard(view);

                Config.EID_WRONG_PIN_TRIES = "";

                if (eIDSdk.isNetworkConnected(context)) {
                    if (!checkNFCenabled(context)) {
                        dialog_nfc(context);
                    } else {

                        Handler handler = new Handler();

                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {

                                if (isPinComplete()) {

                                    switch (DIGIT_SCREEN_TO_SHOW) {

                                        case SCREEN_ENTER_CAN_CODE:

                                            eIDSdk.recordEvent(eIDSdk.EVENT_EID_CAN_SCREEN_CONTINUE);
                                            storePinFrom(SCREEN_ENTER_CAN_CODE);
                                            if (eIDSdk.getEIDTSP().equals("Governikus")) {
                                                verfy_loading_signing.setVisibility(View.VISIBLE);
                                                verify_animation.setRepeatCount(ValueAnimator.INFINITE);
                                                verify_animation.playAnimation();
                                                pinLayout.setVisibility(View.GONE);
                                                Fragment_HoldIDBack fragmentHoldIDBack = new Fragment_HoldIDBack();
                                                ((eIDActivity) context).hideIntroFragment(Fragment_EnterPin_6_digit.this);
                                                ((eIDActivity) context).showIntroFragment(fragmentHoldIDBack);
                                                IdentificationManager.INSTANCE.setCan(Config.EID_CAN);
                                            } else {
                                                if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                                                    showDigitView(SCREEN_ENTER_PERSONAL_6_DIGIT_PIN);
                                                } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                                                    showDigitView(SCREEN_ENTER_5_DIGIT_PIN);
                                                }
                                            }
                                            clearPinBoxes();
                                            setupPinBoxes();

                                            break;

                                        case SCREEN_ENTER_PERSONAL_6_DIGIT_PIN:

                                            ((eIDActivity) context).changeStepRESTCall("PIN_ENTRY");

                                            eIDSdk.recordEvent(eIDSdk.EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_CONTINUE);

                                            storePinFrom(SCREEN_ENTER_PERSONAL_6_DIGIT_PIN);
                                            clearPinBoxes();
                                            setupPinBoxes();

                                            if (eIDSdk.getEIDTSP().equals("Governikus")) {
                                                verify_animation.setRepeatCount(ValueAnimator.INFINITE);
                                                verify_animation.playAnimation();

                                                pinLayout.setVisibility(View.GONE);

                                                Fragment_HoldIDBack fragmentHoldIDBack1 = new Fragment_HoldIDBack();
                                                ((eIDActivity) context).hideIntroFragment(Fragment_EnterPin_6_digit.this);
                                                ((eIDActivity) context).showIntroFragment(fragmentHoldIDBack1);
                                                Config.CURRENT_FRAGMENT = ((eIDActivity) context).getCurrentFragment();
                                                IdentificationManager.INSTANCE.setPin(Config.PIN_EID);
                                            } else {
                                                verfy_loading_signing.setVisibility(View.VISIBLE);
                                                pinLayout.setVisibility(View.GONE);
                                                controlAuthadaIntegration.Authentication(Config.EID_MOBILE_TOKEN, context, Fragment_EnterPin_6_digit.this);
                                            }

                                            break;

                                        case SCREEN_ENTER_5_DIGIT_PIN:

                                            eIDSdk.recordEvent(eIDSdk.EVENT_EID_TRANPORT_PIN_SCREEN_CONTINUE);
                                            ((eIDActivity) context).changeStepRESTCall("PIN_ENTRY");

                                            storePinFrom(SCREEN_ENTER_5_DIGIT_PIN);
                                            clearPinBoxes();
                                            setupPinBoxes();

                                            if (eIDSdk.getEIDTSP().equals("Governikus")) {

                                                if (Config.PIN_EID.equals("12345")) {
                                                    IdentificationManager.INSTANCE.setPin("123456");
                                                } else {
                                                    IdentificationManager.INSTANCE.setPin(Config.PIN_EID);
                                                }

                                                //  identificationManager.changePin();
                                                Fragment_HoldIDBack fragmentHoldIDBack2 = new Fragment_HoldIDBack();
                                                ((eIDActivity) context).hideIntroFragment(Fragment_EnterPin_6_digit.this);
                                                ((eIDActivity) context).showIntroFragment(fragmentHoldIDBack2);
                                                Config.CURRENT_FRAGMENT = ((eIDActivity) context).getCurrentFragment();
                                            } else {
                                                DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_NEW_6_DIGIT_PIN;
                                                showDigitView(Util.PinScreens.SCREEN_ENTER_NEW_6_DIGIT_PIN);
                                            }

                                            break;

                                        case SCREEN_ENTER_NEW_6_DIGIT_PIN:

                                            storePinFrom(Util.PinScreens.SCREEN_ENTER_NEW_6_DIGIT_PIN);
                                            clearPinBoxes();
                                            setupPinBoxes();


                                            showDigitView(SCREEN_RE_ENTER_NEW_6_PIN);

                                            break;

                                        case SCREEN_RE_ENTER_NEW_6_PIN:

                                            storePinFrom(SCREEN_RE_ENTER_NEW_6_PIN);
                                            clearPinBoxes();
                                            setupPinBoxes();

                                            verfy_loading_signing.setVisibility(View.VISIBLE);
                                            verify_animation.playAnimation();
                                            verify_animation.setRepeatCount(ValueAnimator.INFINITE);

                                            if (reEnterSixDigitPIN.equals(newSixDigitPIN)) {
                                                Config.PIN_EID = newSixDigitPIN;

                                                if (eIDSdk.getEIDTSP().equals("Governikus")) {
                                                    Fragment_HoldIDBack fragmentHoldIDBack4 = new Fragment_HoldIDBack();
                                                    ((eIDActivity) context).hideIntroFragment(Fragment_EnterPin_6_digit.this);
                                                    ((eIDActivity) context).showIntroFragment(fragmentHoldIDBack4);
                                                    IdentificationManager.INSTANCE.setNewPin(Config.PIN_EID);
                                                } else {
                                                    verfy_loading_signing.setVisibility(View.VISIBLE);
                                                    pinLayout.setVisibility(View.GONE);
                                                    controlAuthadaIntegration.Authentication(Config.EID_MOBILE_TOKEN, context, Fragment_EnterPin_6_digit.this);
                                                }
                                            } else {

                                                verify_animation.setVisibility(View.GONE);

                                                pin_error_text.setVisibility(View.VISIBLE);
                                                pin_error_text.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ERROR_LABEL_PINS_DO_NOT_MATCH, Util_Strings.LOCAL_KEY_EID_ERROR_LABEL_PINS_DO_NOT_MATCH));
                                                showDigitView(Util.PinScreens.SCREEN_ENTER_NEW_6_DIGIT_PIN);
                                                clearPinBoxes();
                                            }

                                            break;
                                    }
                                }

                            }
                        }, 1000);

                        button_continue.setEnabled(false);
                    }
                } else {
                    showNoConnectionDialog(context);
                }

            }
        });

        do_not_have_pin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eIDSdk.setChangePinEID(true);
                if (eIDSdk.getEIDTSP().equals("Authada")) {
                    Config.EID_PIN_CHOOSER = Util_Strings.FIVE_DIGIT_PIN;
                    Fragment_Capture_Desc fragment_capture_desc = new Fragment_Capture_Desc();
                    ((eIDActivity) context).hideIntroFragment(Fragment_EnterPin_6_digit.this);
                    ((eIDActivity) context).showIntroFragment(fragment_capture_desc);
                    return;
                }
                do_not_have_pin.setEnabled(false);
                do_not_have_pin.setAlpha(0.5f);


                if (eIDSdk.getEIDTSP().equals("Governikus")) {
                    IdentificationManager.INSTANCE.requestCancel();
                } else {
                    if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                        Config.EID_PIN_CHOOSER = Util_Strings.FIVE_DIGIT_PIN;
                        showDigitView(SCREEN_ENTER_5_DIGIT_PIN);
                    } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                        Config.EID_PIN_CHOOSER = Util_Strings.SIX_DIGIT_PIN;
                        showDigitView(SCREEN_ENTER_PERSONAL_6_DIGIT_PIN);
                    }
                }
                Config.USER_RESTART_FLOW = true;
            }
        });


        return view;
    }

    public void showDigitView(Util.PinScreens digitView) {

        DIGIT_SCREEN_TO_SHOW = digitView;

        clearPinBoxes();
        setupPinBoxes();

        switch (digitView) {

            case SCREEN_ENTER_5_DIGIT_PIN:

                pinBox5.setVisibility(View.GONE);

                if (Config.CURRENT_CALLBACK.equals(CALLBACK_SECOND_ATTEMPT)) {

                    pin_error_text.setVisibility(View.VISIBLE);
                    pin_error_text.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_TWO_ATTEMPTS_LEFT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_TWO_ATTEMPTS_LEFT));

                } else if (Config.CURRENT_CALLBACK.equals(Config.CALLBACK_ONE_ATTEMPT)) {
                    pin_error_text.setVisibility(View.VISIBLE);
                    pin_error_text.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT));
                }

                enter_pin_desc.setVisibility(View.VISIBLE);
                enter_pin_link.setVisibility(View.VISIBLE);
                do_not_have_pin.setVisibility(View.GONE);
                enter_pin_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_STEPS_ENTER_5_DIGIT_TITLE, Util_Strings.LOCAL_KEY_EID_STEPS_ENTER_5_DIGIT_TITLE));
                enter_pin_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_5_DIGIT_DESC, Util_Strings.LOCAL_KEY_EID_PIN_5_DIGIT_DESC));
                enter_pin_link.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_5_DIGIT_LEARN_MORE, Util_Strings.LOCAL_KEY_EID_PIN_5_DIGIT_LEARN_MORE));

                do_not_have_pin.setVisibility(View.VISIBLE);
                do_not_have_pin.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_5_DIGIT_CHOOSE_6_DIGIT, Util_Strings.LOCAL_KEY_EID_PIN_5_DIGIT_CHOOSE_6_DIGIT));

                enter_pin_link.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_CAN_SCREEN_WHERE_DO_I_FIND_CAN);
                        moreInfo(SCREEN_ENTER_5_DIGIT_PIN);
                    }
                });

                break;

            case SCREEN_ENTER_NEW_6_DIGIT_PIN:

                pinBox5.setVisibility(View.VISIBLE);
                enter_pin_link.setVisibility(View.GONE);
                enter_pin_desc.setVisibility(View.VISIBLE);
                do_not_have_pin.setVisibility(View.GONE);

                enter_pin_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_CREATE_6_DIGIT_TITLE, Util_Strings.LOCAL_KEY_EID_PIN_CREATE_6_DIGIT_TITLE));
                enter_pin_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_CREATE_6_DIGIT_DESCRIPTION, Util_Strings.LOCAL_KEY_EID_PIN_CREATE_6_DIGIT_DESCRIPTION));

                break;

            case SCREEN_RE_ENTER_NEW_6_PIN:

                pinBox5.setVisibility(View.VISIBLE);
                pin_error_text.setVisibility(View.GONE);
                enter_pin_link.setVisibility(View.GONE);
                enter_pin_desc.setVisibility(View.GONE);
                do_not_have_pin.setVisibility(View.GONE);


                enter_pin_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_RE_ENTER_6_DIGIT_TITLE, Util_Strings.LOCAL_KEY_EID_PIN_RE_ENTER_6_DIGIT_TITLE));

                break;

            case SCREEN_ENTER_PERSONAL_6_DIGIT_PIN:

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_SHOWN);
                eIDSdk.startEvent(eIDSdk.EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_TIME_SPENT);

                pinBox5.setVisibility(View.VISIBLE);
                pin_error_text.setVisibility(View.GONE);

                if (Config.CURRENT_CALLBACK.equals(CALLBACK_SECOND_ATTEMPT)) {

                    pin_error_text.setVisibility(View.VISIBLE);
                    pin_error_text.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC_6_DIGIT_PIN, Util_Strings.LOCAL_KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC));

                } else if (Config.CURRENT_CALLBACK.equals(Config.CALLBACK_ONE_ATTEMPT)) {
                    pin_error_text.setVisibility(View.VISIBLE);
                    pin_error_text.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT_6_DIGIT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT));
                }

                enter_pin_desc.setVisibility(View.GONE);
                enter_pin_link.setVisibility(View.GONE);
                if (eIDSdk.getChangePinEID()) {
                    do_not_have_pin.setVisibility(View.VISIBLE);
                } else {
                    do_not_have_pin.setVisibility(View.GONE);
                }
                enter_pin_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_PAGE_TITLE, Util_Strings.LOCAL_EID_PIN_PAGE_TITLE));
                do_not_have_pin.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_WHERE_TRANSPORT_PIN, Util_Strings.LOCAL_KEY_EID_CHOOSE_WHERE_TRANSPORT_PIN));

                break;

            case SCREEN_ENTER_CAN_CODE:

                pin_error_text.setVisibility(View.GONE);

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_CAN_SCREEN);
                eIDSdk.startEvent(eIDSdk.EVENT_EID_CAN_SCREEN_TIME_SPENT);

                enter_pin_desc.setVisibility(View.VISIBLE);
                enter_pin_link.setVisibility(View.VISIBLE);
                do_not_have_pin.setVisibility(View.GONE);
                enter_pin_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAN_TITLE, Util_Strings.LOCAL_KEY_EID_CAN_TITLE));
                enter_pin_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAN_DESC, Util_Strings.LOCAL_KEY_EID_CAN_DESC));
                enter_pin_link.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAN_LINK, Util_Strings.LOCAL_KEY_EID_CAN_LINK));

                enter_pin_link.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_CAN_SCREEN_WHERE_DO_I_FIND_CAN);
                        moreInfo(SCREEN_ENTER_CAN_CODE);
                    }
                });

                break;

        }
    }

    public void dialog_nfc(Context context) {

        Dialog dialog = new Dialog(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle));
        dialog.setTitle(R.string.nfc_required_title);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle));
        alertDialogBuilder.setTitle(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_NFC_REQUIRED_TITLE, Util_Strings.LOCAL_EID_NFC_REQUIRED_TITLE));
        alertDialogBuilder.setMessage(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_NFC_REQUIRED_MESSAGE, Util_Strings.LOCAL_EID_NFC_REQUIRED_MESSAGE));
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_NFC_REQUIRED_BUTTON_NEXT, Util_Strings.LOCAL_EID_NFC_REQUIRED_BUTTON_NEXT)
                , new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openNfcSettings();
                    }
                }).create().show();
    }

    public void openNfcSettings() {

        Intent intent = new Intent(Settings.ACTION_NFC_SETTINGS);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    public boolean checkNFCenabled(Context context) {

        NfcManager manager = (NfcManager) context.getSystemService(Context.NFC_SERVICE);
        NfcAdapter adapter = manager.getDefaultAdapter();
        if (adapter != null && adapter.isEnabled()) {
            return true;
        } else {
            return false;
        }
    }

    private void converttoTextPin(String pin_text) {
        Config.PIN_EID = pin_text;
    }

    public static void setProceedButtonBackgroundSelector(View view) {
        Drawable buttonDrawable_activate = view.getResources().getDrawable(R.drawable.rounded_background_orange);
        Drawable buDrawable_desactivated = view.getResources().getDrawable(R.drawable.rounded_background_grey);
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(new int[]{android.R.attr.state_pressed}, buttonDrawable_activate);
        stateListDrawable.addState(new int[]{android.R.attr.state_enabled}, buttonDrawable_activate);
        stateListDrawable.addState(new int[]{}, buDrawable_desactivated);
        view.setBackgroundDrawable(stateListDrawable);
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_EnterPin_6_digit.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_EnterPin_6_digit.class);
    }

    public void clearPinBoxes() {
        if (!(pinBox0 == null && pinBox1 == null && pinBox2 == null && pinBox3 == null && pinBox4 == null && pinBox5 == null)) {
            pinBox0.setText("");
            pinBox1.setText("");
            pinBox2.setText("");
            pinBox3.setText("");
            pinBox4.setText("");
            pinBox5.setText("");
            pinBox0.requestFocus();
        }
    }

    private void setupPinBoxes() {
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher0 = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox0, pinBox1, button_continue, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher1 = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox1, pinBox2, button_continue, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher2 = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox2, pinBox3, button_continue, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher3 = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox3, pinBox4, button_continue, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher4_6digit = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox4, pinBox5, button_continue, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher4_5digit = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox4, null, button_continue, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher5 = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox5, null, button_continue, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);

        pinBox0.addTextChangedListener(pinBoxTextWatcher0);
        pinBox1.addTextChangedListener(pinBoxTextWatcher1);
        pinBox2.addTextChangedListener(pinBoxTextWatcher2);
        pinBox3.addTextChangedListener(pinBoxTextWatcher3);
        pinBox5.addTextChangedListener(pinBoxTextWatcher5);
        if (currentScreen == SCREEN_ENTER_5_DIGIT_PIN) {
            pinBox4.removeTextChangedListener(pinBoxTextWatcher4_6digit);
            pinBox4.addTextChangedListener(pinBoxTextWatcher4_5digit);
        } else {
            pinBox4.removeTextChangedListener(pinBoxTextWatcher4_5digit);
            pinBox4.addTextChangedListener(pinBoxTextWatcher4_6digit);
        }

        pinBox0.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox0, null)
        );
        pinBox1.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox1, pinBox0));
        pinBox2.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox2, pinBox1));
        pinBox3.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox3, pinBox2));
        pinBox4.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox4, pinBox3));
        if (currentScreen != SCREEN_ENTER_5_DIGIT_PIN) {
            pinBox5.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox5, pinBox4));
        }
    }

    public void storePinFrom(Util.PinScreens screen) {

        switch (screen) {
            case SCREEN_ENTER_5_DIGIT_PIN:
                Config.PIN_EID = pinBox0.getText().toString()
                        + pinBox1.getText().toString()
                        + pinBox2.getText().toString()
                        + pinBox3.getText().toString()
                        + pinBox4.getText().toString();
                break;
            case SCREEN_ENTER_NEW_6_DIGIT_PIN:
                newSixDigitPIN = pinBox0.getText().toString()
                        + pinBox1.getText().toString()
                        + pinBox2.getText().toString()
                        + pinBox3.getText().toString()
                        + pinBox4.getText().toString()
                        + pinBox5.getText().toString();
                break;
            case SCREEN_RE_ENTER_NEW_6_PIN:
                reEnterSixDigitPIN = pinBox0.getText().toString()
                        + pinBox1.getText().toString()
                        + pinBox2.getText().toString()
                        + pinBox3.getText().toString()
                        + pinBox4.getText().toString()
                        + pinBox5.getText().toString();
                break;


            case SCREEN_ENTER_PERSONAL_6_DIGIT_PIN:
                Config.PIN_EID = pinBox0.getText().toString()
                        + pinBox1.getText().toString()
                        + pinBox2.getText().toString()
                        + pinBox3.getText().toString()
                        + pinBox4.getText().toString()
                        + pinBox5.getText().toString();
                break;
            case SCREEN_ENTER_CAN_CODE:
                Config.EID_CAN = pinBox0.getText().toString()
                        + pinBox1.getText().toString()
                        + pinBox2.getText().toString()
                        + pinBox3.getText().toString()
                        + pinBox4.getText().toString()
                        + pinBox5.getText().toString();
                break;
            default:
                break;
        }
    }

    public boolean isPinComplete() {
        return !pinBox0.getText().toString().isEmpty() &&
                !pinBox1.getText().toString().isEmpty() &&
                !pinBox2.getText().toString().isEmpty() &&
                !pinBox3.getText().toString().isEmpty() &&
                !pinBox4.getText().toString().isEmpty();
    }

    private void showPIN() {

        eIDSdk.recordEvent(eIDSdk.EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_EYE);

        pinBox0.setTransformationMethod(null);
        pinBox1.setTransformationMethod(null);
        pinBox2.setTransformationMethod(null);
        pinBox3.setTransformationMethod(null);
        pinBox4.setTransformationMethod(null);
        pinBox5.setTransformationMethod(null);
    }

    private void hidePIN() {
        pinBox0.setTransformationMethod(PasswordTransformationMethod.getInstance());
        pinBox1.setTransformationMethod(PasswordTransformationMethod.getInstance());
        pinBox2.setTransformationMethod(PasswordTransformationMethod.getInstance());
        pinBox3.setTransformationMethod(PasswordTransformationMethod.getInstance());
        pinBox4.setTransformationMethod(PasswordTransformationMethod.getInstance());
        pinBox5.setTransformationMethod(PasswordTransformationMethod.getInstance());
    }

    public void moreInfo(Util.PinScreens currentScreen) {

        View bottomSheetContentView = getLayoutInflater().inflate(R.layout.bottom_sheet_more_information, null);
        bottomSheetMoreInfo = new BottomSheetDialog(fragmentActivity, R.style.BottomSheetDialog);
        bottomSheetMoreInfo.setContentView(bottomSheetContentView);

        ImageButton bottom_sheet_more_information_cancel_cross = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_cancel_cross);
        TextView bottom_sheet_more_information_description = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_description);
        AppCompatImageView bottom_sheet_more_information_image = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_image);
        LottieAnimationView bottom_sheet_more_information_nfc_antenna_animation = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_nfc_antenna_animation);
        TextView bottom_sheet_more_information_antenna_location_label = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_antenna_location_label);

        switch (currentScreen) {

            case SCREEN_ENTER_5_DIGIT_PIN:

                bottom_sheet_more_information_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DATA_CONFIRMATION_FIVE_DIGIT_DESC, Util_Strings.LOCAL_KEY_EID_DATA_CONFIRMATION_FIVE_DIGIT_DESC));
                bottom_sheet_more_information_image.setImageResource(R.drawable.transport_pin);
                bottom_sheet_more_information_nfc_antenna_animation.setVisibility(View.GONE);
                bottom_sheet_more_information_antenna_location_label.setVisibility(View.GONE);
                bottomSheetMoreInfo.show();

                break;

            case SCREEN_ENTER_CAN_CODE:

                bottom_sheet_more_information_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_WHERE_DO_I_FIND_CAN_INFO, Util_Strings.LOCAL_KEY_EID_WHERE_DO_I_FIND_CAN_INFO));
                bottom_sheet_more_information_image.setImageResource(R.drawable.can_code);
                bottom_sheet_more_information_nfc_antenna_animation.setVisibility(View.GONE);
                bottom_sheet_more_information_antenna_location_label.setVisibility(View.GONE);
                bottomSheetMoreInfo.show();

                break;


        }

        bottom_sheet_more_information_cancel_cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetMoreInfo.dismiss();
            }
        });
    }

    public void hideSoftKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public void redirectScanning() {
        getActivity().runOnUiThread(new Runnable() {
            public void run() {
                Fragment_HoldIDBack fragmentHoldIDBack = new Fragment_HoldIDBack();
                ((eIDActivity) getActivity()).hideIntroFragment(Fragment_EnterPin_6_digit.this);
                ((eIDActivity) getActivity()).showIntroFragment(fragmentHoldIDBack);
                Config.CURRENT_FRAGMENT = Fragment_HoldIDBack.getInstance();
            }
        });
    }

    public void redirectionUser() {

        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Fragment_Capture_Desc fragmentCaptureDesc = new Fragment_Capture_Desc();
                ((eIDActivity) getActivity()).hideIntroFragment(Fragment_EnterPin_6_digit.this);
                ((eIDActivity) getActivity()).showIntroFragment(fragmentCaptureDesc);
            }
        });
    }

    public static Fragment_EnterPin_6_digit getInstance() {

        return instance;
    }
}

