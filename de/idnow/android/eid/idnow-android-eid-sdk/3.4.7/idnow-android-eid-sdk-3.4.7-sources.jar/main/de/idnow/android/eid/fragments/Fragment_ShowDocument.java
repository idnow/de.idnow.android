package de.idnow.android.eid.fragments;

import static de.idnow.android.eid.Config.URL_DOCUMENT_NAMIRIAL;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.util.Util_Log;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;

public class Fragment_ShowDocument extends BaseFragment {

    ImageButton defaultBackButton, downloadButton;

    TextView document_name;

    private static final String LOGTAG = "IDNOW_Fragment_ShowDocument";

    private static final int MEGABYTE = 1024 * 1024;

    WebView pdfView;

    public Fragment_ShowDocument() {
        super(false);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        View view = inflater.inflate(R.layout.show_document, container, false);

        defaultBackButton = view.findViewById(R.id.defaultBackButton);
        downloadButton = view.findViewById(R.id.downloadButton);
        document_name = view.findViewById(R.id.document_name);
        pdfView = view.findViewById(R.id.pdfView);

        document_name.setText("Document " + (Config.DOCUMENT_POSITION + 1));
        defaultBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        downloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // downloadFile();
            }
        });

        String identifier = Config.MODEL_PDF_DOCUMENTS[Config.DOCUMENT_POSITION].getDocumentDefinition().getIdentifier();

        getDocumentRestCall(identifier);

        return view;
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_ShowDocument.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_ShowDocument.class);
    }

    public void dataToPDF(okhttp3.Response response) throws IOException {

        InputStream in = response.body().byteStream();

        byte[] bytesArray = inputToByte(in);

        File folder = null;
        String path = "";
        String fileName = "";
        path = getActivity().getFilesDir().toString();
        folder = new File(getActivity().getFilesDir() + "/IDnow");
        folder.mkdir();
        fileName = "/IDnow" + "-File-" + System.currentTimeMillis() + ".pdf";
        path = path + "/IDnow";

        OutputStream outStream;
        outStream = new FileOutputStream(path + fileName);
        outStream.write(bytesArray);
        outStream.close();

        pdfView.getSettings().setLoadsImagesAutomatically(true);
        pdfView.getSettings().setJavaScriptEnabled(true);
        pdfView.clearHistory();
        WebSettings settings = pdfView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(true);
        pdfView.loadUrl("file:///android_asset/pdfviewer.html?" + URL_DOCUMENT_NAMIRIAL);
    }

    private static byte[] inputToByte(InputStream inputStream) throws IOException {
        ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
        byte[] buff = new byte[1024];
        int rc;
        while ((rc = inputStream.read(buff, 0, 1024)) > 0) {
            swapStream.write(buff, 0, rc);
        }
        byte[] in2b = swapStream.toByteArray();
        return in2b;

    }


    public static void downloadFile(String fileUrl, File directory) {
        try {
            Util_Log.v(LOGTAG, "downloadFile() invoked ");
            Util_Log.v(LOGTAG, "downloadFile() fileUrl " + fileUrl);
            Util_Log.v(LOGTAG, "downloadFile() directory " + directory);

            URL url = new URL(fileUrl);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();

            InputStream inputStream = urlConnection.getInputStream();
            FileOutputStream fileOutputStream = new FileOutputStream(directory);
            int totalSize = urlConnection.getContentLength();

            byte[] buffer = new byte[MEGABYTE];
            int bufferLength = 0;
            while ((bufferLength = inputStream.read(buffer)) > 0) {
                fileOutputStream.write(buffer, 0, bufferLength);
            }
            fileOutputStream.close();
            Util_Log.v(LOGTAG, "downloadFile() completed ");

        } catch (IOException e) {
            Util_Log.e(LOGTAG, "Download file failed", e);
        }
    }

    public void getDocumentRestCall(String identifier) {

        final OkHttpClient client = new OkHttpClient();

        String url = Config.CURRENT_SERVER.getApiHost(eIDSdk.getTransactionToken()) + "/api/v1/" + eIDSdk.getCompanyId() + "/identifications/" + eIDSdk.getTransactionToken() + "/documents/" + identifier + "/data";

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Content-Type", "application/pdf")
                .build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @SuppressLint("SetJavaScriptEnabled")
            @Override
            public void onResponse(Call call, okhttp3.Response response) throws IOException {

                dataToPDF(response);

            }
        });
    }


}
