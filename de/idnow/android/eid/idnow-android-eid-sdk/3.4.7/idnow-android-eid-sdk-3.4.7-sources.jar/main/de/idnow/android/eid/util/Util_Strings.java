package de.idnow.android.eid.util;

import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.StringRes;

import java.util.Map;

import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;

public class Util_Strings {

    public static final String LOGIN_CONTENT_TYPE = "application/json; charset=utf-8";

    public static final String KEY_EID_VERIFY_PAGE_TITLE = "js.mobile.eid.idverify.page.title";
    public static final String KEY_EID_VERIFY_PAGE_DESC1 = "js.mobile.eid.idverify.page.desc.1";
    public static final String KEY_EID_VERIFY_PAGE_DESC2 = "js.mobile.eid.idverify.page.desc.2";
    public static final String KEY_EID_VERIFY_PAGE_DESC3 = "js.mobile.eid.idverify.page.desc.3";
    public static final String KEY_EID_VERIFY_PAGE_LINK1 = "js.mobile.eid.idverify.page.link.1";
    public static final String KEY_EID_VERIFY_PAGE_LINK2 = "js.mobile.eid.idverify.page.link.2";
    public static final String KEY_EID_VERIFY_PAGE_LINK3 = "js.mobile.eid.idverify.page.link.3";
    public static final String KEY_EID_VERIFY_PAGE_DESC4 = "js.mobile.eid.idverify.page.desc.4";
    public static final String KEY_EID_VERIFY_PAGE_AND = "js.mobile.eid.idverify.page.and";
    public static final String KEY_EID_LINK_PRIVACY_POLICY = "js.link.privacy.mobile";
    public static final String KEY_EID_LINK_TERMS_OF_USE = "js.link.terms.mobile";
    public static final String KEY_EID_VERIFY_PAGE_TERMS = "js.link.terms.label.mobile";
    public static final String KEY_EID_VERIFY_PAGE_PRIVACY = "js.link.privacy.label.mobile";


    public static final @StringRes int LOCAL_EID_VERIFY_PAGE_TITLE = R.string.title_text_id_verify;
    public static final @StringRes int LOCAL_EID_VERIFY_PAGE_DESC1 = R.string.title_text_id_verify_hdiw;
    public static final @StringRes int LOCAL_EID_VERIFY_PAGE_DESC2 = R.string.desc_text_hdiw;
    public static final @StringRes int LOCAL_EID_VERIFY_PAGE_DESC3 = R.string.desc_text_hdiw_1;
    public static final @StringRes int LOCAL_KEY_EID_VERIFY_PAGE_LINK1 = R.string.have_5digit_pin_eid_verify;
    public static final @StringRes int LOCAL_KEY_EID_VERIFY_PAGE_LINK2 = R.string.online_with_eid_verify;
    public static final @StringRes int LOCAL_KEY_EID_VERIFY_PAGE_LINK3 = R.string.data_more_information;
    public static final @StringRes int LOCAL_EID_VERIFY_PAGE_DESC4 = R.string.desc_text_hdiw_2;
    public static final @StringRes int LOCAL_EID_VERIFY_PAGE_AND = R.string.and_text;
    public static final @StringRes int LOCAL_EID_VERIFY_PAGE_TERMS = R.string.terms_use;
    public static final @StringRes int LOCAL_EID_VERIFY_PAGE_PRIVACY = R.string.privacy_policy;
    public static final @StringRes int LOCAL_EID_LINK_PRIVACY_POLICY = R.string.second_step_privacy_policy_url_eid;
    public static final @StringRes int LOCAL_EID_LINK_TERMS_OF_USE = R.string.second_step_terms_of_use_url_eid;

    public static final String KEY_EID_SECURITY_PAGE_TITLE = "js.mobile.eid.security.page.title";
    public static final String KEY_EID_SECURITY_PAGE_DESC1 = "js.mobile.eid.security.page.desc.1";
    public static final String KEY_EID_SECURITY_PAGE_DESC2 = "js.mobile.eid.security.page.desc.2";
    public static final String KEY_EID_SECURITY_PAGE_DESC3 = "js.mobile.eid.security.page.desc.3";
    public static final String KEY_EID_SECURITY_PAGE_DESC4 = "js.mobile.eid.security.page.desc.4";
    public static final String KEY_EID_SECURITY_PAGE_DESC5 = "js.mobile.eid.security.page.desc.5";

    public static final @StringRes int LOCAL_EID_SECURITY_PAGE_TITLE = R.string.security_title;
    public static final @StringRes int LOCAL_EID_SECURITY_PAGE_DESC1 = R.string.security_desc1;
    public static final @StringRes int LOCAL_EID_SECURITY_PAGE_DESC2 = R.string.security_desc2;
    public static final @StringRes int LOCAL_EID_SECURITY_PAGE_DESC3 = R.string.security_desc3;
    public static final @StringRes int LOCAL_EID_SECURITY_PAGE_DESC4 = R.string.security_desc4;
    public static final @StringRes int LOCAL_EID_SECURITY_PAGE_DESC5 = R.string.security_desc5;

    public static final String KEY_EID_REGISTRATION_PIN_PAGE_TITLE = "js.mobile.eid.registration.pin.page.title";
    public static final String KEY_EID_REGISTRATION_PIN_PAGE_DESC1 = "js.mobile.eid.registration.pin.page.desc.1";

    public static final @StringRes int LOCAL_EID_REGISTRATION_PIN_PAGE_TITLE = R.string.eid_page_registration_title;
    public static final @StringRes int LOCAL_EID_REGISTRATION_PIN_PAGE_DESC1 = R.string.eid_page_registration_desc;

    public static final String KEY_EID_ID_MORE_INFO_PAGE_DISCRIPTION = "js.mobile.eid.more.info.page.desription";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_DOCUMENTTYPE = "js.mobile.eid.more.info.page.documenttype";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_STATE = "js.mobile.eid.more.info.page.state";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_BIRTHNAME = "js.mobile.eid.more.info.page.firstname";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_FAMILYNAME = "js.mobile.eid.more.info.page.familyname";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_DATEOFBIRTH = "js.mobile.eid.more.info.page.dateofbirth";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_PLACEOFBIRTH = "js.mobile.eid.more.info.page.placeofbirth";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_NATIONALITY = "js.mobile.eid.more.info.page.nationality";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_ADDRESS = "js.mobile.eid.more.info.page.address";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_VALIDUNTIL = "js.mobile.eid.more.info.page.validuntil";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_DOCTORALDEGREE = "js.mobile.eid.more.info.page.doctoraldegree";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_ISSUINGCOUNTRY = "js.mobile.eid.more.info.page.issuingcountry";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_PSEUDONYM = "js.mobile.eid.more.info.page.pseudonym";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_GIVENNAMES = "js.mobile.eid.more.info.page.givennames";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_PROVIDER = "js.mobile.eid.more.info.page.provider";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_IDNOW = "js.mobile.eid.more.info.page.idnow";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_PROVIDERURL = "js.mobile.eid.more.info.page.provider.url";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_IDNOWURL = "js.mobile.eid.more.info.page.idnow.url";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_IDNOWVALIDITY = "js.mobile.eid.more.info.page.idnow.validity";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_USAGE = "js.mobile.eid.more.info.page.usage";
    public static final String KEY_EID_ID_MORE_INFO_PAGE_IDNOW_BUSINESS = "js.mobile.eid.more.info.page.idnow.business";
    public static final String KEY_EID_ID_MORE_INFO_BUSINESS_REASON = "js.mobile.eid.more.info.page.business.reason";

    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_DISCRIPTION = R.string.data_nfc_desc_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_DOCUMENTTYPE = R.string.document_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_STATE = R.string.state_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_BIRTHNAME = R.string.first_name_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_FAMILYNAME = R.string.last_name_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_DATEOFBIRTH = R.string.date_birth_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_PLACEOFBIRTH = R.string.place_birth_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_NATIONALITY = R.string.nationality_data_from_card;
    public static final @StringRes int LOCAL_KEY_EID_ID_MORE_INFO_PAGE_VALIDUNTIL = R.string.valid_until_data_from;
    public static final @StringRes int LOCAL_KEY_EID_ID_MORE_INFO_PAGE_DOCTORALDEGREE = R.string.doctoral_degree_data_from_card;
    public static final @StringRes int LOCAL_KEY_EID_ID_MORE_INFO_PAGE_ISSUINGCOUNTRY = R.string.issuing_country_data_from;
    public static final @StringRes int LOCAL_KEY_EID_ID_MORE_INFO_PAGE_PSEUDONYM = R.string.pseudonym_data_from;
    public static final @StringRes int LOCAL_KEY_EID_ID_MORE_INFO_PAGE_GIVENNAMES = R.string.given_names_data_from;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_ADDRESS = R.string.address_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_PROVIDER = R.string.digital_photo_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_IDNOW = R.string.digital_photo_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_PROVIDERURL = R.string.provider_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_IDNOWURL = R.string.provider_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_IDNOWVALIDITY = R.string.validity_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_USAGE = R.string.usage_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_IDNOW_BUSINESS = R.string.usage_data_from_card;
    public static final @StringRes int LOCAL_EID_ID_MORE_INFO_PAGE_BUSINESS_REASON = R.string.usage_data_from_card;

    public static final String KEY_EID_PIN_PAGE_TITLE = "js.mobile.eid.pin.need.six.digits.title";
    public static final String KEY_EID_PIN_PAGE_DESC = "js.eid.choose.where.transport.pin";
    public static final String KEY_EID_PIN_PAGE_TWO_TRIES_LEFT = "js.mobile.eid.pin.page.two.tries.left";
    public static final String KEY_EID_PIN_PAGE_ONE_TRY_LEFT = "js.mobile.eid.pin.page.one.try.left";
    public static final String KEY_EID_PIN_PAGE_CAN_TITLE = "js.mobile.eid.pin.page.can.title";
    public static final String KEY_EID_PIN_PAGE_CAN_DESC = "js.mobile.eid.pin.page.can.description";

    public static final @StringRes int LOCAL_EID_PIN_PAGE_TITLE = R.string.enter_title_pin;
    public static final @StringRes int LOCAL_EID_PIN_PAGE_TWO_TRIES_LEFT = R.string.enter_pin_two_tries_left;
    public static final @StringRes int LOCAL_EID_PIN_PAGE_ONE_TRY_LEFT = R.string.enter_pin_one_try_left;
    public static final @StringRes int LOCAL_EID_PIN_PAGE_CAN_TITLE = R.string.enter_pin_can_title;
    public static final @StringRes int LOCAL_EID_PIN_PAGE_CAN_DESC = R.string.enter_pin_can_desc;


    public static final String KEY_EID_HOLDID_PAGE_TITLE = "js.mobile.eid.holdid.page.title";
    public static final String KEY_EID_HOLDID_PAGE_DESC = "js.mobile.eid.holdid.scan.desc";
    public static final String KEY_EID_HOLDID_PAGE_DETECTING = "js.mobile.eid.holdid.page.not.detecting";


    public static final String KEY_EID_HOLDID_PAGE_DESC1 = "js.mobile.eid.holdid.dialog.desc.1";
    public static final String KEY_EID_HOLDID_PAGE_DESC2 = "js.mobile.eid.holdid.dialog.desc.2";
    public static final String KEY_EID_HOLDID_PAGE_DESC3 = "js.mobile.eid.holdid.dialog.desc.3";
    public static final String KEY_EID_HOLDID_PAGE_DESC4 = "js.mobile.eid.holdid.dialog.desc.4";
    public static final String KEY_EID_HOLDID_PAGE_ERROR = "js.mobile.eid.holdid.dialog.error";
    public static final String KEY_EID_HOLDID_PAGE_ERROR_PLACE = "js.mobile.eid.holdid.dialog.error.place";


    public static final @StringRes int LOCAL_EID_HOLDID_PAGE_TITLE = R.string.hold_back_id_title; // Scan ID using your phone
    public static final @StringRes int LOCAL_EID_HOLDID_PAGE_DESC = R.string.hold_back_id_description; // Scan ID using your phone
    public static final @StringRes int LOCAL_EID_HOLDID_PAGE_DETECTING = R.string.hold_back_id_detecting; // Scan ID using your phone

    public static final @StringRes int LOCAL_EID_HOLDID_PAGE_DESC1 = R.string.dialog_establish; // This will verify your data via eID.
    public static final @StringRes int LOCAL_EID_HOLDID_PAGE_DESC2 = R.string.dialog_sendPIN;
    public static final @StringRes int LOCAL_EID_HOLDID_PAGE_DESC3 = R.string.dialog_transfer_encrypted_data;
    public static final @StringRes int LOCAL_EID_HOLDID_PAGE_DESC4 = R.string.dialog_transfer_encrypted_data;
    public static final @StringRes int LOCAL_EID_HOLDID_PAGE_ERROR = R.string.dialog_error_text;
    public static final @StringRes int LOCAL_EID_HOLDID_PAGE_ERROR_PLACE = R.string.error_card_not_right_place;


    public static final String KEY_EID_VERIFY_RESULTS_TITLE = "js.mobile.eid.verify.results.title";

    public static final @StringRes int LOCAL_EID_VERIFY_RESULTS_TITLE = R.string.verify_result;

    public static final String KEY_EID_VERIFY_COMPLETE_TITLE = "js.mobile.eid.verification.completed.title";
    public static final String KEY_EID_VERIFY_COMPLETE_DESC = "js.mobile.eid.complete.desc";

    public static final @StringRes int LOCAL_EID_VERIFY_COMPLETE_TITLE = R.string.eid_verification_completed;
    public static final @StringRes int LOCAL_EID_VERIFY_COMPLETE_DESC = R.string.esign_successful_desc;

    public static final String KEY_EID_VERIFY_SORRY_TITLE = "js.mobile.eid.sorry.title";
    public static final String KEY_EID_VERIFY_SORRY_DESC = "js.mobile.eid.sorry.desc";

    public static final @StringRes int LOCAL_EID_VERIFY_SORRY_TITLE = R.string.complete_eid_title_1;
    public static final @StringRes int LOCAL_EID_VERIFY_SORRY_DESC = R.string.complete_eid_desc_1;

    public static final String KEY_EID_BUTTON_CONTINUE = "js.mobile.eid.button.continue";
    public static final String KEY_EID_BUTTON_VERIFIYING = "js.mobile.eid.button.verifying";

    public static final String KEY_EID_BUTTON_SWITCH = "js.mobile.eid.button.switch";
    public static final String KEY_EID_BUTTON_FINISH = "js.mobile.eid.button.finish";
    public static final String KEY_EID_BUTTON_SORRY = "js.mobile.eid.button.sorry";
    public static final String KEY_EID_BUTTON_RESTART = "js.mobile.eid.button.restart";

    public static final @StringRes int LOCAL_EID_BUTTON_CONTINUE = R.string.eid_button_continue;
    public static final @StringRes int LOCAL_EID_BUTTON_VERIFIYING = R.string.eid_button_verifying;

    public static final @StringRes int LOCAL_EID_BUTTON_SWITCH = R.string.eid_button_switch;
    public static final @StringRes int LOCAL_EID_BUTTON_FINISH = R.string.eid_button_finish;
    public static final @StringRes int LOCAL_EID_BUTTON_SORRY = R.string.eid_button_sorry;
    public static final @StringRes int LOCAL_EID_BUTTON_RESTART = R.string.eid_button_restart;


    public static final String KEY_EID_NFC_REQUIRED_TITLE = "js.mobile.eid.nfc.required.title";
    public static final String KEY_EID_NFC_REQUIRED_MESSAGE = "js.mobile.eid.nfc.required.message";
    public static final String KEY_EID_NFC_REQUIRED_BUTTON_NEXT = "js.mobile.eid.nfc.required.button.text";

    public static final @StringRes int LOCAL_EID_NFC_REQUIRED_TITLE = R.string.nfc_required_title;
    public static final @StringRes int LOCAL_EID_NFC_REQUIRED_MESSAGE = R.string.nfc_required_message;
    public static final @StringRes int LOCAL_EID_NFC_REQUIRED_BUTTON_NEXT = R.string.nfc_required_button_text;

    public static final String KEY_EID_YES = "js.documents.upload-again.yes";
    public static final String KEY_EID_NO = "js.documents.upload-again.no";

    public static final @StringRes int LOCAL_EID_YES = R.string.yes;
    public static final @StringRes int LOCAL_EID_NO = R.string.No;

    public static final String KEY_EID_CAN_ENTER = "js.mobile.eid.can.enter";
    public static final String KEY_EID_CAN_ENTER_LOOP = "js.mobile.eid.can.enter.loop";
    public static final String KEY_EID_CAN_PIN_NOT_CHECKED = "js.mobile.eid.can.pin.not.checked";
    public static final String KEY_EID_CAN_WRONG_DESCRIPTION_ = "js.mobile.eid.can.wrong.description";
    public static final String KEY_EID_PIN_TWOTRY_PLACED = "js.mobile.eid.pin.twotry_placed";
    public static final String KEY_EID_CAN_ERROR = "js.mobile.eid.can.error";
    public static final String KEY_EID_CAN_REQUIRED = "js.mobile.eid.can.required";

    public static final @StringRes int LOCAL_EID_CAN_ENTER = R.string.please_enter_can;
    public static final @StringRes int LOCAL_EID_CAN_ENTER_LOOP = R.string.please_enter_can_loop;
    public static final @StringRes int LOCAL_EID_CAN_PIN_NOT_CHECKED = R.string.please_enter_can_pin_not_checked;
    public static final @StringRes int LOCAL_EID_CAN_WRONG_DESCRIPTION_ = R.string.can_wrong_description;
    public static final @StringRes int LOCAL_EID_PIN_TWOTRY_PLACED = R.string.card_with_two_pin_tries_placed;
    public static final @StringRes int LOCAL_EID_CAN_ERROR = R.string.error_can;
    public static final @StringRes int LOCAL_EID_CAN_REQUIRED = R.string.can_required;

    public static final String KEY_VIDEO_IDENT_PER_INTRO_END = "js.mobile.ident.per.intro.end"; //
    public static final String KEY_VIDEO_IDENT_PER_AUDIO = "js.mobile.ident.per.audio"; //
    public static final String KEY_VIDEO_IDENT_PER_VIDEO = "js.mobile.ident.per.video"; //
    public static final String KEY_VIDEO_IDENT_PER_CAMERA = "js.mobile.ident.per.camera"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_IMAGE_PROCESSING = R.string.photo_ident_image_processed;
    public static final String KEY_VIDEO_IDENT_IMAGE_PROCESSING = "js.mobile.ident.iamge.processing"; //


    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PER_INTRO_END = R.string.permissions_intro_end;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PER_AUDIO = R.string.permission_audio;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PER_CAMERA = R.string.permission_camera;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PER_FAILED_BREAK = R.string.permission_failed_break;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_PER_FAILED_CONTINUE = R.string.permission_failed_continue;

    public static final String KEY_VIDEO_IDENT_RESULT_FAILED_MSG = "js.mobile.identresult.failed.message"; // result_screen_info_failure
    public static final String KEY_VIDEO_IDENT_COMMON_NO = "js.mobile.common.no"; // dialog_no
    public static final String KEY_VIDEO_IDENT_COMMON_YES = "js.mobile.common.yes"; // dialog_yes
    public static final String KEY_VIDEO_IDENT_COMMON_CONTINUE = "js.mobile.common.continue"; // dialog_no_wifi_continue
    public static final String KEY_VIDEO_IDENT_COMMON_ERROR = "js.mobile.common.error"; // error_dialog_title
    public static final String KEY_VIDEO_IDENT_COMMON_CANCEL = "js.mobile.common.cancel"; // dialog_no_wifi_cancel
    public static final String KEY_VIDEO_IDENT_COMMON_OK = "js.mobile.common.ok"; // vip_ok_waiting_list

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_NO = R.string.dialog_no;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_YES = R.string.dialog_yes;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_CONTINUE = R.string.dialog_no_wifi_continue;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_ERROR = R.string.error_dialog_title;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_CANCEL = R.string.dialog_no_wifi_cancel;
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_COMMON_OK = R.string.vip_ok_waiting_list;

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CAMERA_ERROR = R.string.dialog_error_camera_title;
    public static final String KEY_VIDEO_IDENT_CAMERA_ERROR = "js.mobile.ident.camera.error"; //

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_CAMERA_ERROR_DESC = R.string.dialog_error_camera_content;
    public static final String KEY_VIDEO_IDENT_CAMERA_ERROR_DESC = "js.mobile.ident.camera.error.desc"; //

    private static final String SHOW_DIALOGS_WITH_ICON_KEY = "showDialogsWithIcon";

    public static final String FIVE_DIGIT_PIN = "FIVE DIGIT PIN";
    public static final String SIX_DIGIT_PIN = "SIX DIGIT PIN";

    public static final String KEY_EID_TAKE_FRONT_TITLE = "js.mobile.videoidentplus.take.front.title";
    public static final String KEY_EID_TAKE_FRONT_DESC = "js.mobile.videoidentplus.take.front.desc";
    public static final String KEY_EID_TAKE_BACK_TITLE = "js.mobile.videoidentplus.take.back.title";
    public static final String KEY_EID_TAKE_BACK_DESC = "js.mobile.videoidentplus.take.back.desc";
    public static final String KEY_EID_TAKE_FRONT_IMAGE_DESC = "js.mobile.videoidentplus.take.image.desc";

    public static final @StringRes int LOCAL_KEY_EID_TAKE_BACK_TITLE = R.string.vip_tak_picture_back_side_title;
    public static final @StringRes int LOCAL_KEY_EID_TAKE_BACK_DESC = R.string.vip_tak_picture_back_side_desc;
    public static final @StringRes int LOCAL_KEY_EID_TAKE_FRONT_DESC = R.string.mainTextDescription;
    public static final @StringRes int LOCAL_KEY_EID_TAKE_FRONT_TITLE = R.string.vip_take_picture_front_side_title;
    public static final @StringRes int LOCAL_KEY_EID_TAKE_FRONT_IMAGE_DESC = R.string.vip_tak_picture_desc;


    public static final String KEY_EID_TAKE_IMAGE_CONTINUE = "js.mobile.videoidentplus.take.image.continue";
    public static final @StringRes int LOCAL_KEY_EID_TAKE_IMAGE_CONTINUE = R.string.continueButton;

    public static final String KEY_EID_TAKE_IMAGE_RETAKE = "js.mobile.videoidentplus.take.image.retake.id";
    public static final @StringRes int LOCAL_EID_TAKE_IMAGE_RETAKE = R.string.retakeAction;

    public static final String KEY_EID_CAPTURE_STEP1 = "js.mobile.eid.capture.step1";
    public static final String KEY_EID_CAPTURE_STEP1_TITTLE = "js.mobile.eid.capture.step1.title";
    public static final String KEY_EID_CAPTURE_STEP1_DESC = "js.mobile.eid.capture.step1.desc";

    public static final String KEY_EID_CAPTURE_STEP2 = "js.mobile.eid.capture.step2";
    public static final String KEY_EID_CAPTURE_STEP2_TITTLE = "js.mobile.eid.capture.step2.title";
    public static final String KEY_EID_CAPTURE_STEP2_DESC = "js.mobile.eid.capture.step2.desc";

    public static final String KEY_EID_CAPTURE_STEP3 = "js.mobile.eid.capture.step3";
    public static final String KEY_EID_CAPTURE_STEP3_TITTLE = "js.mobile.eid.capture.step3.title";
    public static final String KEY_EID_CAPTURE_STEP3_DESC = "js.mobile.eid.capture.step3.desc";

    public static final String KEY_EID_CAPTURE_STEP4 = "js.mobile.eid.capture.step4";
    public static final String KEY_EID_CAPTURE_STEP4_TITTLE = "js.mobile.eid.capture.step4.title"; //
    public static final String KEY_EID_CAPTURE_STEP4_DESC = "js.mobile.eid.capture.step4.desc"; //

    public static final String KEY_EID_CAPTURE_STEP4_NOOTP_TITTLE = "js.mobile.eid.capture.step4.nootp.title"; //

    public static final String KEY_EID_CAPTURE_STEP4_NOOTP_DESC = "js.mobile.eid.capture.step4.nootp.desc"; //

    public static final String KEY_EID_SOCKET_CONNECTION_TIMED_OUT = "js.mobile.eid.connection.socket.timed.out";
    public static final @StringRes int LOCAL_KEY_EID_SOCKET_CONNECTION_TIMED_OUT = R.string.eID_econnection_socket_timed_out;


    public static final String KEY_EID_STEPS_VERIFICATION_DESCRIPTION = "js.mobile.eid.pin.need.six.digits.desc";
    public static final @StringRes int LOCAL_KEY_EID_STEPS_VERIFICATION_DESCRIPTION = R.string.eID_process_encrypted;

    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP1 = R.string.eID_capture_step1;
    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP1_TITLE = R.string.eID_capture_title1;
    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP1_DESC = R.string.eID_capture_desc1;

    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP2 = R.string.eID_capture_step2;
    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP2_TITLE = R.string.eID_capture_title2;
    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP2_DESC = R.string.eID_capture_desc2;

    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP3 = R.string.eID_capture_step3;
    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP3_TITLE = R.string.eID_capture_title3;
    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP3_DESC = R.string.eID_capture_desc3;

    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP4 = R.string.eID_capture_step4;
    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP4_TITLE = R.string.eID_capture_title4;
    public static final @StringRes int LOCAL_KEY_EID_CAPTURE_STEP4_DESC = R.string.eID_capture_desc4;


    public static final String KEY_EID_DIALOG_NOT_EID_TITLE = "js.mobile.eid.not.german.alert.title";
    public static final String KEY_EID_DIALOG_NOT_EID_DESC = "js.mobile.eid.not.german.alert.desc";
    public static final String KEY_EID_DIALOG_NOT_EID_CONTINUE = "js.mobile.eid.not.german.alert.continue.button";
    public static final String KEY_EID_DIALOG_NOT_EID_TRY_ANOTHER = "js.mobile.eid.not.german.alert.cancel.button";

    public static final @StringRes int LOCAL_KEY_EID_DIALOG_NOT_EID_TITLE = R.string.dialog_not_eid_title;
    public static final @StringRes int LOCAL_KEY_EID_DIALOG_NOT_EID_DESC = R.string.dialog_not_eid_desc;
    public static final @StringRes int LOCAL_KEY_EID_DIALOG_NOT_EID_CONTINUE = R.string.dialog_not_eid_continue;
    public static final @StringRes int LOCAL_KEY_EID_DIALOG_NOT_EID_TRY_ANOTHER = R.string.dialog_not_eid_try_other;

    public static final String KEY_EID_ESIGN_VERIFY_TITLE = "js.mobile.eid.signing.preparing.title";
    public static final String KEY_EID_ESIGN_VERIFY_DESC = "js.mobile.eid.signing.preparing.desc";

    public static final @StringRes int LOCAL_KEY_EID_ESIGN_VERIFY_TITLE = R.string.verify_title;
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_VERIFY_DESC = R.string.verify_desc;

    public static final String KEY_EID_CAN_TITLE = "js.mobile.eid.pin.page.can.title";
    public static final String KEY_EID_CAN_DESC = "js.mobile.eid.pin.page.can.description";
    public static final String KEY_EID_CAN_LINK = "js.mobile.eid.last.attempt.can.link";

    public static final @StringRes int LOCAL_KEY_EID_CAN_TITLE = R.string.enter_pin_can_title;
    public static final @StringRes int LOCAL_KEY_EID_CAN_DESC = R.string.enter_pin_can_desc;
    public static final @StringRes int LOCAL_KEY_EID_CAN_LINK = R.string.enter_pin_can_link;


    public static final String KEY_EID_ESIGN_DOCUMENTS_TITLE = "js.mobile.eid.not.german.alert.title";
    public static final String KEY_EID_ESIGN_DOCUMENTS_DESC = "js.mobile.eid.not.german.alert.title";

    public static final @StringRes int LOCAL_KEY_EID_ESIGN_DOCUMENTS_TITLE = R.string.documents_title;
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_DOCUMENTS_DESC = R.string.documents_desc;


    public static final String KEY_EID_ESIGN_OTP_CODE_TITLE = "js.mobile.eid.verification.code.title";
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_OTP_CODE_TITLE = R.string.otp_code_title;

    public static final String KEY_EID_ESIGN_OTP_CODE_DESC = "js.mobile.eid.verification.code.desc";
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_OTP_CODE_DESC = R.string.otp_code_desc;

    public static final String KEY_EID_ESIGN_OTP_MOBILE_TITLE = "js.mobile.eid.confirm.mobile.title";
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_OTP_MOBILE_TITLE = R.string.otp_mobile_title;

    public static final String KEY_EID_ESIGN_OTP_MOBILE_DESC = "js.mobile.eid.confirm.mobile.desc";
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_OTP_MOBILE_DESC = R.string.otp_mobile_desc;

    public static final String KEY_EID_ESIGN_OTP_CODE_ENTER = "js.mobile.eid.verification.code.hint";
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_OTP_CODE_ENTER = R.string.otp_enter_code;

    public static final String KEY_EID_ESIGN_OTP_CODE_RESEND = "js.mobile.eid.verification.resend.code";
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_OTP_CODE_RESEND = R.string.otp_resend;

    public static final String KEY_EID_ESIGN_OTP_CODE_INCORRECT = "js.mobile.eid.verification.incorrect.code";
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_OTP_CODE_INCORRECT = R.string.otp_incorrect;

    public static final String KEY_EID_ESIGN_SUCCESSFUL_TITLE = "js.mobile.eid.signing.successful.title";
    public static final String KEY_EID_ESIGN_SUCCESSFUL_DESC = "js.mobile.eid.complete.desc";

    public static final @StringRes int LOCAL_KEY_EID_ESIGN_SUCCESSFUL_TITLE = R.string.esign_successful_title;
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_SUCCESSFUL_DESC = R.string.esign_successful_desc;

    public static final String KEY_EID_ESIGN_UNSUCCESSFUL_TITLE = "js.mobile.eid.signing.unsuccessful.title";
    public static final String KEY_EID_ESIGN_UNSUCCESSFUL_DESC = "js.mobile.eid.signing.unsuccessful.desc";

    public static final String KEY_EID_UNSUCCESSFUL_DESC = "js.mobile.identresult.failed.message";
    public static final @StringRes int LOCAL_KEY_EID_UNSUCCESSFUL_DESC = R.string.identification_failed_desc;

    public static final String KEY_EID_UNSUCCESSFUL_TITLE = "js.mobile.identresult.failed.title";
    public static final @StringRes int LOCAL_KEY_EID_UNSUCCESSFUL_TITLE = R.string.identification_failed_title;


    public static final @StringRes int LOCAL_KEY_EID_ESIGN_UNSUCCESSFUL_TITLE = R.string.esign_unsuccessful_title;
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_UNSUCCESSFUL_DESC = R.string.esign_unsuccessful_desc;

    public static final String KEY_EID_ESIGN_WRONG_TITLE = "js.mobile.eid.signing.something.wrong.title";
    public static final String KEY_EID_ESIGN_WRONG_DESC = "js.mobile.eid.signing.something.wrong.desc";

    public static final @StringRes int LOCAL_KEY_EID_ESIGN_WRONG_TITLE = R.string.esign_wrong_title;
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_WRONG_DESC = R.string.esign_wrong_desc;

    public static final String KEY_EID_ESIGN_TIMEOUT_TITLE = "js.mobile.eid.signing.session.timeout.title";
    public static final String KEY_EID_ESIGN_TIMEOUT_DESC = "js.mobile.eid.signing.session.timeout.desc";

    public static final @StringRes int LOCAL_KEY_EID_ESIGN_TIMEOUT_TITLE = R.string.esign_timeout_title;
    public static final @StringRes int LOCAL_KEY_EID_ESIGN_TIMEOUT_DESC = R.string.esign_timout_desc;

    public static final @StringRes int LOCAL_KEY_EID_TRY_AGAIN = R.string.try_again;
    public static final String KEY_EID_TRY_AGAIN = "js.mobile.eid.try.again";

    public static final @StringRes int LOCAL_KEY_EID_DONE = R.string.done;
    public static final String KEY_EID_DONE = "js.mobile.eid.try.done";


    public static final @StringRes int LOCAL_KEY_EID_DOCUMENT_TITLE = R.string.list_document_title;
    public static final String KEY_EID_DOCUMENT_TITLE = "js.mobile.eid.signing.documents.desc";

    // STEPS BEFORE PIN
    // 5 DIGIT
    public static final String KEY_EID_STEPS_ENTER_5_DIGIT_TITLE = "js.mobile.eid.pin.page.five.digit.title";
    public static final String KEY_EID_STEPS_ENTER_5_DIGIT_DESC = "js.mobile.eid.before.start.step.capture.desc";

    public static final @StringRes int LOCAL_KEY_EID_STEPS_ENTER_5_DIGIT_TITLE = R.string.eID_pin_5_digit_title;
    public static final @StringRes int LOCAL_KEY_EID_STEPS_ENTER_5_DIGIT_DESC = R.string.eID_steps_five_digit_mailed;

    public static final String KEY_EID_STEPS_CREATE_6_DIGIT_TITLE = "js.mobile.eid.before.start.step.create.pin.title";
    public static final String KEY_EID_STEPS_CREATE_6_DIGIT_DESC = "js.mobile.eid.before.start.step.create.pin.desc";

    public static final @StringRes int LOCAL_KEY_EID_STEPS_CREATE_6_DIGIT_TITLE = R.string.eID_steps_create_6_digit_title;
    public static final @StringRes int LOCAL_KEY_EID_STEPS_CREATE_6_DIGIT_DESC = R.string.eID_steps_create_6_digit_desc;

    public static final String KEY_EID_STEPS_SCAN_TITLE = "js.mobile.eid.before.start.step.scan.title";
    public static final String KEY_EID_STEPS_SCAN_DESC = "js.mobile.eid.before.start.step.scan.desc";

    public static final @StringRes int LOCAL_KEY_EID_STEPS_SCAN_TITLE = R.string.eID_capture_title3;
    public static final @StringRes int LOCAL_KEY_EID_STEPS_SCAN_DESC = R.string.eID_steps_scan_desc;
    // 6 DIGIT
    public static final String KEY_EID_VERIFICATION_STEPS_PHOTO_TITLE = "js.mobile.eid.before.start.step.capture.title";
    public static final String KEY_EID_VERIFICATION_STEPS_PHOTO_DESC = "js.mobile.eid.capture.step1.desc";
    public static final String KEY_EID_VERIFICATION_STEPS_6_DIGIT_TITLE = "js.mobile.eid.before.start.step.pin.title";
    public static final String KEY_EID_VERIFICATION_STEPS_6_DIGIT_DESC = "js.mobile.eid.before.start.step.pin.desc";
    public static final String KEY_EID_VERIFICATION_STEPS_SCAN_TITLE = "js.mobile.eid.before.start.step.scan.title";
    public static final String KEY_EID_VERIFICATION_STEPS_SCAN_DESC = "js.mobile.eid.before.start.step.scan.desc";

    public static final @StringRes int LOCAL_KEY_EID_VERIFICATION_STEPS_PHOTO_TITLE = R.string.eID_verification_steps_photos_title;
    public static final @StringRes int LOCAL_KEY_EID_VERIFICATION_STEPS_PHOTO_DESC = R.string.eID_verification_steps_photos_desc;
    public static final @StringRes int LOCAL_KEY_EID_VERIFICATION_STEPS_6_DIGIT_TITLE = R.string.eID_verification_steps_6_digit_title;
    public static final @StringRes int LOCAL_KEY_EID_VERIFICATION_STEPS_6_DIGIT_DESC = R.string.eID_verification_steps_6_digit_desc;
    public static final @StringRes int LOCAL_KEY_EID_VERIFICATION_STEPS_SCAN_TITLE = R.string.eID_verification_steps_scan_title;
    public static final @StringRes int LOCAL_KEY_EID_VERIFICATION_STEPS_SCAN_DESC = R.string.eID_verification_steps_scan_desc;


    // CHOOSE PIN DIGIT SCREEN
    public static final String KEY_EID_IDENTIFICATION_TITLE = "“js.mobile.eid.terms.title";
    public static final String KEY_EID_CHOOSE_DESCRIPTION = "js.link.eid.have.id.ready.mobile";
    public static final String KEY_EID_CHOOSE_FIVE_DIGIT_PIN = "js.mobile.eid.choose.five.digit.pin";
    public static final String KEY_EID_CHOOSE_TRANSPORT_PIN_DESC = "js.mobile.eid.choose.transport.pin.desc";
    public static final String KEY_EID_CHOOSE_WHERE_PIN_LINK = "js.mobile.eid.choose.where.pin.link";
    public static final String KEY_EID_CHOOSE_SIX_DIGIT_PIN = "js.mobile.eid.choose.six.digit.pin";
    public static final String KEY_EID_CHOOSE_WHERE_TRANSPORT_PIN = "js.eid.choose.where.transport.pin";
    public static final String KEY_EID_CHOOSE_TRY_ANOTHER_IDENT_METHOD = "js.mobile.eid.choose.try.another.ident.method";
    public static final String KEY_EID_CHOOSE_CONTINUE_BUTTON = "js.mobile.eid.button.continue";
    public static final String KEY_EID_CHOOSE_TERMS_PART1 = "js.mobile.eid.idverify.page.desc.4";
    public static final String KEY_EID_CHOOSE_TERMS_PART2 = "js.mobile.eid.idverify.page.and";
    public static final String KEY_EID_CHOOSE_TERMS_PART3 = "js.mobile.eid.idverify.page.dot";

    public static final @StringRes int LOCAL_KEY_EID_IDENTIFICATION_TITLE = R.string.eID_identification_title;
    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_DESCRIPTION = R.string.eID_have_id_ready;
    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_FIVE_DIGIT_PIN = R.string.eID_choose_five_digit_pin;
    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_TRANSPORT_PIN_DESC = R.string.eID_choose_transport_pin_desc;
    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_WHERE_PIN_LINK = R.string.eID_choose_transport_link;
    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_SIX_DIGIT_PIN = R.string.eID_choose_six_digit_pin;
    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_WHERE_TRANSPORT_PIN = R.string.eID_choose_where_transport_pin;
    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_TRY_ANOTHER_IDENT_METHOD = R.string.eID_choose_try_another_ident_method;
    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_CONTINUE_BUTTON = R.string.eID_choose_continue_button;
    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_TERMS_PART1 = R.string.eID_choose_terms_part1;
    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_TERMS_PART2 = R.string.eID_choose_terms_part2;
    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_TERMS_PART3 = R.string.eID_choose_terms_part3;


    public static final String KEY_EID_BEFORE_START_STEP_ACTIVATION_TITLE = "js.mobile.eid.before.start.step.activation.title";
    public static final String KEY_EID_BEFORE_START_STEP_VERIFICATION_TITLE = "js.mobile.eid.before.start.step.verification.title";

    public static final @StringRes int LOCAL_KEY_EID_BEFORE_START_STEP_ACTIVATION_TITLE = R.string.eID_before_start_step_activation_title;
    public static final @StringRes int LOCAL_KEY_EID_BEFORE_START_STEP_VERIFICATION_TITLE = R.string.eID_before_start_step_verification_title;


    // ENTER 5 DIGIT PIN SCREEN
    public static final String KEY_EID_PIN_5_DIGIT_TITLE = "js.mobile.eid.pin.page.five.digit.title";
    public static final String KEY_EID_PIN_5_DIGIT_DESC = "js.mobile.eid.pin.page.five.digit.desc";
    public static final String KEY_EID_PIN_5_DIGIT_LEARN_MORE = "js.link.eid.learn.more.mobil";
    public static final String KEY_EID_PIN_5_DIGIT_CHOOSE_6_DIGIT = "js.mobile.eid.choose.six.digit.pin";

    public static final @StringRes int LOCAL_KEY_EID_PIN_5_DIGIT_TITLE = R.string.eID_pin_5_digit_title;
    public static final @StringRes int LOCAL_KEY_EID_PIN_5_DIGIT_DESC = R.string.eID_pin_5_digit_desc;
    public static final @StringRes int LOCAL_KEY_EID_PIN_5_DIGIT_LEARN_MORE = R.string.eID_pin_5_digit_learn_more;
    public static final @StringRes int LOCAL_KEY_EID_PIN_5_DIGIT_CHOOSE_6_DIGIT = R.string.eID_choose_six_digit_pin;


    // CREATE 6 DIGIT PIN SCREEN
    public static final String KEY_EID_PIN_CREATE_6_DIGIT_TITLE = "js.mobile.eid.create.pin.page.title";
    public static final String KEY_EID_PIN_CREATE_6_DIGIT_DESCRIPTION = "js.mobile.eid.create.pin.page.desc";

    public static final @StringRes int LOCAL_KEY_EID_PIN_CREATE_6_DIGIT_TITLE = R.string.eID_pin_create_6_digit_title;
    public static final @StringRes int LOCAL_KEY_EID_PIN_CREATE_6_DIGIT_DESCRIPTION = R.string.eID_pin_create_6_digit_desc;


    // RE-ENTER 6 DIGIT PIN SCREEN
    public static final String KEY_EID_PIN_RE_ENTER_6_DIGIT_TITLE = "js.mobile.eid.pin.page.re.enter.title";

    public static final @StringRes int LOCAL_KEY_EID_PIN_RE_ENTER_6_DIGIT_TITLE = R.string.eID_pin_re_enter_6_digit_pin;


    // SCAN EID CARD SCREEN
    public static final String KEY_EID_SCAN_EID_TITLE = "js.mobile.eid.holdid.page.title.ios";
    public static final String KEY_EID_SCAN_EID_DESC = "js.mobile.eid.holdid.page.desc";
    public static final String KEY_EID_SCAN_EID_NOT_DETECTING = "js.mobile.eid.holdid.page.not.detecting";

    public static final @StringRes int LOCAL_KEY_EID_SCAN_EID_TITLE = R.string.eID_scan_eid_title;
    public static final @StringRes int LOCAL_KEY_EID_SCAN_EID_DESC = R.string.eID_scan_eid_desc;
    public static final @StringRes int LOCAL_KEY_EID_SCAN_EID_NOT_DETECTING = R.string.eID_scan_eid_not_detecting;

    // ENTER CAN CODE SCREEN
    public static final String KEY_EID_ENTER_CAN_CODE_TITLE = "js.mobile.eid.pin.page.can.title";
    public static final String KEY_EID_ENTER_CAN_CODE_DESC = "js.mobile.eid.pin.page.can.description";
    public static final String KEY_EID_ENTER_CAN_CODE_WHERE_IS_IT = "js.mobile.eid.last.attempt.can.link";

    public static final @StringRes int LOCAL_KEY_EID_ENTER_CAN_CODE_TITLE = R.string.eID_enter_can_code_title;
    public static final @StringRes int LOCAL_KEY_EID_ENTER_CAN_CODE_DESC = R.string.eID_enter_can_code_desc;
    public static final @StringRes int LOCAL_KEY_EID_ENTER_CAN_CODE_WHERE_IS_IT = R.string.eID_enter_can_code_where_is_it;


    // RED ERROR LABELS
    public static final String KEY_EID_ERROR_LABEL_PINS_DO_NOT_MATCH = "js.mobile.eid.pin.page.not.match";

    public static final @StringRes int LOCAL_KEY_EID_ERROR_LABEL_PINS_DO_NOT_MATCH = R.string.eID_red_error_pins_do_not_match;


    // WHERE IS PIN INFO
    public static final String KEY_EID_DATA_CONFIRMATION_FIVE_DIGIT_DESC = "js.mobile.eid.more.info.page.five.digits.desription";

    public static final @StringRes int LOCAL_KEY_EID_DATA_CONFIRMATION_FIVE_DIGIT_DESC = R.string.eID_data_confirmation_five_digit_desc;

    // WHERE DO I FIND CAN INFO
    public static final String KEY_EID_WHERE_DO_I_FIND_CAN_INFO = "js.mobile.eid.where.can.desc";

    public static final @StringRes int LOCAL_KEY_EID_WHERE_DO_I_FIND_CAN_INFO = R.string.eID_where_do_i_find_can_info;

    // NFC TROUBLESHOOT INFO
    public static final String KEY_EID_PHONE_NOT_DETECTING_EID_INFO = "js.mobile.eid.phone.not.detecting.eid.info";
    public static final String KEY_EID_PHONE_NOT_DETECTING_EID_ANTENNA_LOCATIONS = "js.mobile.eid.phone.not.detecting.eid.antenna.locations";

    public static final @StringRes int LOCAL_KEY_EID_PHONE_NOT_DETECTING_EID_INFO = R.string.eID_phone_not_detecting_eid_info;
    public static final @StringRes int LOCAL_KEY_EID_PHONE_NOT_DETECTING_EID_ANTENNA_LOCATIONS = R.string.eID_phone_not_detecting_eid_antenna_location;


    // OUTCOME SCREENS
    public static final String KEY_EID_OUTCOME_DEVICE_NOT_COMPATIBLE_TITLE = "js.mobile.eid.device.not.compatible.title";
    public static final String KEY_EID_OUTCOME_DEVICE_NOT_COMPATIBLE_DESC = "js.mobile.eid.device.not.compatible.description";

    public static final String KEY_EID_OUTCOME_CARD_BLOCKED_TITLE = "js.mobile.eid.card.locked.title";
    public static final String KEY_EID_OUTCOME_CARD_BLOCKED_DESC = "js.mobile.eid.card.locked.desc";

    public static final String KEY_EID_OUTCOME_CARD_DEACTIVATED_TITLE = "js.mobile.eid.card.deactivated.title";
    public static final String KEY_EID_OUTCOME_CARD_DEACTIVATED_DESC = "js.mobile.eid.card.deactivated.desc";

    public static final String KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_TITLE = "js.mobile.eid.pin.changed.success.title";
    public static final String KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_DESC = "js.mobile.eid.pin.changed.success.desc";
    public static final String KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_BUTTON = "js.mobile.eid.pin.changed.continue.button.title";

    public static final String KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC = "js.mobile.eid.pin.page.two.tries.left.five.digit.desc";
    public static final String KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC_6_DIGIT_PIN = "js.mobile.eid.wrong.pin.two.attempts.left";

    public static final String KEY_EID_OUTCOME_INCORRECT_PIN_FINAL_ATTEMPT_TITLE = "js.mobile.eid.last.attempt.title";
    public static final String KEY_EID_OUTCOME_INCORRECT_PIN_FINAL_ATTEMPT_DESC = "js.mobile.eid.last.attempt.desc";

    public static final String KEY_EID_OUTCOME_NO_COMPATIBLE_ID_TITLE = "js.mobile.eid.device.not.compatible.title";
    public static final String KEY_EID_OUTCOME_NO_COMPATIBLE_ID_DESC = "js.mobile.eid.no.compatible.id.desc";

    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC_6_DIGIT_PIN = R.string.eID_bottom_sheet_incorrect_pin_two_attempts_left;
    public static final @StringRes int LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT_6_DIGIT = R.string.eID_bottom_sheet_incorrect_pin_one_attempt_left;

    public static final @StringRes int LOCAL_KEY_EID_BOTTOM_SHEET_CHANGE_PIN_SUCCESSFULL = R.string.eID_bottom_sheet_successful_pin_change;

    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_DEVICE_NOT_COMPATIBLE_TITLE = R.string.eID_outcome_device_not_compatible_title;
    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_DEVICE_NOT_COMPATIBLE_DESC = R.string.eID_outcome_device_not_compatible_description;

    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_CARD_BLOCKED_TITLE = R.string.eID_outcome_card_blocked_title;
    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_CARD_BLOCKED_DESC = R.string.eID_outcome_card_blocked_desc;

    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_CARD_DEACTIVATED_TITLE = R.string.eID_outcome_card_deactivated_title;
    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_CARD_DEACTIVATED_DESC = R.string.eID_outcome_card_deactivated_desc;

    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_TITLE = R.string.eID_outcome_pin_change_success_title;
    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_DESC = R.string.eID_outcome_pin_change_success_desc;
    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_BUTTON = R.string.eID_outcome_pin_change_success_continue;

    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC = R.string.eID_bottom_sheet_incorrect_pin_two_attempts_left;

    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_INCORRECT_PIN_FINAL_ATTEMPT_TITLE = R.string.eID_outcome_final_attempt_title;
    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_INCORRECT_PIN_FINAL_ATTEMPT_DESC = R.string.eID_outcome_final_attempt_desc;

    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_NO_COMPATIBLE_ID_TITLE = R.string.eID_outcome_no_compatible_id_title;
    public static final @StringRes int LOCAL_KEY_EID_OUTCOME_NO_COMPATIBLE_ID_DESC = R.string.eID_outcome_no_compatible_id_desc;

    // BOTTOMSHEET SCREENS
    public static final String KEY_EID_BOTTOM_SHEET_CARD_BLOCKED = "js.mobile.eid.transport.pin.card.locked.title";
    public static final String KEY_EID_BOTTOM_SHEET_PIN_CHANGE_SUCCESS = "js.mobile.eid.pin.changed.success.title";
    public static final String KEY_EID_BOTTOM_SHEET_EID_CARD_FOUND = "js.mobile.eid.bottom.sheet.eid.card.found";
    public static final String KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_TWO_ATTEMPTS_LEFT = "js.mobile.eid.pin.page.two.tries.left.five.digit.desc";
    public static final String KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT = "js.mobile.eid.pin.page.one.try.left.five.digit.desc";
    public static final String KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT_6_DIGIT = "js.mobile.eid.wrong.pin.ONE.attemps.left";
    public static final String KEY_EID_BOTTOM_SHEET_CHANGE_PIN_SUCCESSFULL = "js.mobile.eid.change.pin.successful";

    public static final String KEY_EID_BOTTOM_SHEET_INCORRECT_CAN_PIN = "js.mobile.eid.bottom.sheet.incorrect.can.pin";

    public static final @StringRes int LOCAL_KEY_EID_BOTTOM_SHEET_CARD_BLOCKED = R.string.eID_bottom_sheet_card_blocked;
    public static final @StringRes int LOCAL_KEY_EID_BOTTOM_SHEET_PIN_CHANGE_SUCCESS = R.string.eID_outcome_pin_change_success_title;
    public static final @StringRes int LOCAL_KEY_EID_BOTTOM_SHEET_EID_CARD_FOUND = R.string.eID_bottom_sheet_card_found;
    public static final @StringRes int LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_TWO_ATTEMPTS_LEFT = R.string.incorrect_5_digit_pin_second;
    public static final @StringRes int LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT = R.string.incorrect_5_digit_pin_first;
    public static final @StringRes int LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_CAN_PIN = R.string.eID_enter_can_code_incorrect_can;


    // QUIT DIALOG
    public static final String KEY_EID_QUIT_DIALOG_TITLE = "js.mobile.eid.cancel.alert.title";
    public static final String KEY_EID_QUIT_DIALOG_DESCRIPTION = "js.mobile.eid.cancel.alert.desc";
    public static final String KEY_EID_QUIT_DIALOG_QUIT = "js.mobile.eid.cancel.alert.quit.button";
    public static final String KEY_EID_QUIT_DIALOG_CONTINUE = "js.mobile.eid.cancel.alert.continue.button";
    public static final String KEY_EID_QUIT_DIALOG_TRY_ANOTHER_METHOD = "js.mobile.eid.cancel.alert.try.another.button";

    public static final @StringRes int LOCAL_KEY_EID_QUIT_DIALOG_TITLE = R.string.eID_quit_dialog_title;
    public static final @StringRes int LOCAL_KEY_EID_QUIT_DIALOG_DESCRIPTION = R.string.eID_quit_dialog_desription;
    public static final @StringRes int LOCAL_KEY_EID_QUIT_DIALOG_QUIT = R.string.eID_quit_dialog_quit;
    public static final @StringRes int LOCAL_KEY_EID_QUIT_DIALOG_CONTINUE = R.string.eID_quit_dialog_continue;
    public static final @StringRes int LOCAL_KEY_EID_QUIT_DIALOG_TRY_ANOTHER_METHOD = R.string.eID_quit_dialog_try_another_method;


    // BUTTONS
    public static final String KEY_EID_5_DIGIT_CONTINUE = "js.mobile.eid.button.continue";
    public static final @StringRes int LOCAL_KEY_EID_5_DIGIT_CONTINUE = R.string.eID_5_digit_pin_continue;

    public static final String KEY_EID_5_DIGIT_TRY_AGAIN = "js.mobile.eid.finished.error.button";
    public static final @StringRes int LOCAL_KEY_EID_5_DIGIT_TRY_AGAIN = R.string.eID_5_digit_pin_try_again;

    public static final String KEY_EID_5_DIGIT_TRY_ANOTHER_METHOD = "js.mobile.eid.cancel.alert.try.another.button";
    public static final @StringRes int LOCAL_KEY_EID_5_DIGIT_TRY_ANOTHER_METHOD = R.string.eID_5_digit_pin_try_again_other_method;

    public static final String KEY_EID_5_DIGIT_TRY_ANOTHER_IDENT_METHOD = "js.mobile.eid.button.sorry";
    public static final @StringRes int LOCAL_KEY_EID_5_DIGIT_TRY_ANOTHER_IDENT_METHOD = R.string.eID_5_digit_pin_try_another_ident_method;

    public static final String KEY_EID_5_DIGIT_OPEN_AUSWEIS_APP = "js.mobile.eid.card.locked.button";
    public static final @StringRes int LOCAL_KEY_EID_5_DIGIT_OPEN_AUSWEIS_APP = R.string.eID_5_digit_pin_open_ausweiss;

    public static final String KEY_EID_5_DIGIT_AUSWEIS_PLAY_STORE_LINK = "js.mobile.eid.5.digit.open.ausweis.play.store.link";
    public static final @StringRes int LOCAL_KEY_EID_5_DIGIT_AUSWEIS_PLAY_STORE_LINK = R.string.eID_5_digit_ausweis_play_store_link;

    public static final @StringRes int LOCAL_KEY_EID_SCAN_DETECT = R.string.list_scan_detect;
    public static final String KEY_EID_SCAN_DETECT = "js.mobile.cant.detect";

    public static final @StringRes int LOCAL_KEY_EID_SCAN_HOLD = R.string.list_scan_hold;
    public static final String KEY_EID_SCAN_HOLD = "js.mobile.eid.bottom.sheet.eid.card.found";

    public static final @StringRes int LOCAL_KEY_EID_SCAN_COMPATIBLE = R.string.list_scan_compatible;
    public static final String KEY_EID_SCAN_COMPATIBLE = "js.mobile.eid.scan.compatible";

    public static final @StringRes int LOCAL_KEY_EID_SCAN_WRONG_CAN = R.string.list_scan_wrong_can;
    public static final String KEY_EID_SCAN_WRONG_CAN = "js.mobile.eid.bottom.sheet.incorrect.can.pin";

    public static final @StringRes int LOCAL_KEY_EID_SCAN_WRONG_PIN = R.string.list_scan_wrong_pin;
    public static final String KEY_EID_SCAN_WRONG_PIN = "js.mobile.eid.wrong.pin.two.attempts.left";

    public static final @StringRes int LOCAL_KEY_EID_SCAN_WRONG_PIN_BLOCKED = R.string.list_scan_wrong_pin_blocked;
    public static final String KEY_EID_SCAN_WRONG_PIN_BLOCKED = "js.mobile.eid.card.blocked";

    public static final @StringRes int LOCAL_KEY_EID_VERIFICATION_COMPLETED = R.string.eid_verification_completed;
    public static final String KEY_EID_VERIFICATION_COMPLETED = "js.mobile.eid.verification.completed.title";

    public static final @StringRes int LOCAL_KEY_EID_FINAL_ATTEMPT_TITLE = R.string.final_attempt_title;
    public static final String KEY_EID_FINAL_ATTEMPT_TITLE = "js.mobile.eid.last.attempt.title";

    public static final @StringRes int LOCAL_KEY_EID_FINAL_ATTEMPT_DESC = R.string.eID_outcome_final_attempt_6digit_desc;
    public static final String KEY_EID_FINAL_ATTEMPT_DESC = "js.mobile.eid.last.attempt.desc";

    public static final @StringRes int LOCAL_KEY_EID_FINAL_ATTEMPT_LINK = R.string.final_attempt_link;
    public static final String KEY_EID_FINAL_ATTEMPT_LINK = "js.mobile.eid.last.attempt.can.link";

    public static final String KEY_VIDEO_IDENT_NOTIF_TITLE = "js.mobile.ident.notif.title"; //
    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_NOTIF_TITLE = R.string.notification_dialog_title;

    public static final String KEY_LABEL_PHONE_VALIDATION_CORRECTED = "js.mobile.phone.validation.corrected";
    public static final @StringRes int LOCAL_LABEL_PHONE_VALIDATION_CORRECTED = R.string.phone_no_validation_corrected;

    public static final String KEY_LABEL_PHONE_VALIDATION_ERROR = "js.mobile.phone.validation.error";
    public static final @StringRes int LOCAL_LABEL_PHONE_VALIDATION_ERROR = R.string.phone_no_validation_error;

    public static final @StringRes int LOCAL_KEY_VIDEO_IDENT_REQUIRED_FIELD = R.string.required_field;
    public static final String KEY_VIDEO_IDENT_REQUIRED_FIELD = "js.mobile.ident.invalid.phone.number";//

    public static final @StringRes int LOCAL_KEY_SIGNING_TITLE = R.string.signing_title;
    public static final String KEY_SIGNING_TITLE = "js.mobile.eid.signing.title";//

    public static final @StringRes int LOCAL_KEY_SIGNING_DESC = R.string.signing_desc;
    public static final String KEY_SIGNING_DESC = "js.mobile.eid.signing.desc";//

    public static final String KEY_SIGNING_BUTTON_DUCPLICATED = "js.vi.esign.consent.confirmAndSign";

    public static final String KEY_SIGNING_PLURAL_DOC = "js.mobile.eid.signing.pluralDocuments.text";
    public static final String KEY_SIGNING_DOC = "js.mobile.eid.signing.Document.text";
    public static final @StringRes int LOCAL_KEY_SIGNING_PLURAL_DOC = R.string.documents;
    public static final @StringRes int LOCAL_KEY_SIGNING_DOC = R.string.document;

    //signing_title

    /*

        <string name="card_blocked_title">Your card is blocked</string>
    <string name="card_blocked_desc">To unblock your ID, provice PUK(PIN unblocking key) in the Ausweis app.</string>
    <string name="card_blocked_button">Open AusweisApp 2</string>
    <string name="try_another_identification">Try another identification method</string> */


    public static final @StringRes int LOCAL_KEY_EID_CARD_BLOCKED_TITLE = R.string.card_blocked_title;
    public static final String KEY_EID_CARD_BLOCKED_TITLE = "js.mobile.eid.card.locked.title";

    public static final @StringRes int LOCAL_KEY_EID_CARD_BLOCKED_DESC = R.string.card_blocked_desc;
    public static final String KEY_EID_CARD_BLOCKED_DESC = "js.mobile.eid.card.locked.desc";

    public static final @StringRes int LOCAL_KEY_EID_CARD_BLOCKED_BUTTON = R.string.card_blocked_button;
    public static final String KEY_EID_CARD_BLOCKED_BUTTON = "js.mobile.eid.card.locked.button";

    public static final @StringRes int LOCAL_KEY_EID_TRY_ANOTHER_METHOD = R.string.try_another_identification;
    public static final String KEY_EID_TRY_ANOTHER_METHOD = "js.mobile.eid.button.sorry";

    public static final @StringRes int LOCAL_KEY_EID_IDENTIFICATION_NOT_COMPLETED = R.string.try_another_identification;
    public static final String KEY_EID_IDENTIFICATION_NOT_COMPLETED = "js.idnow.platform.abort.title";

    public static final @StringRes int LOCAL_KEY_EID_NAME_MISMATCH = R.string.name_mismatch;
    public static final String KEY_EID_NAME_MISMATCH = "js.mobile.eid.name.mismatch";

    public static final @StringRes int LOCAL_KEY_EID_VALUE_MISMATCH = R.string.value_mismatch;
    public static final String KEY_EID_VALUE_MISMATCH = "js.idnow.platform.abort.message";

    public static final @StringRes int LOCAL_KEY_EID_DONT_HAVE_LISTED = R.string.don_t_have_the_listed_above;
    public static final String KEY_EID_DONT_HAVE_LISTED = "js.mobile.eid.dont.have";

    public static final @StringRes int LOCAL_KEY_EID_CHOOSE_EID_TYPE = R.string.choose_eid_type;
    public static final String KEY_EID_CHOOSE_EID_TYPE = "js.mobile.eid.choose.eid.type";

    public static final @StringRes int LOCAL_KEY_EID_I_HAVE = R.string.i_have_a;
    public static final String KEY_EID_I_HAVE = "js.mobile.eid.i.have.a";

    public static final @StringRes int LOCAL_KEY_EID_GERMAN_ID_CARD = R.string.german_id_card_with_pin;
    public static final String KEY_EID_GERMAN_ID_CARD = "js.mobile.eid.german.id.card";

    public static final @StringRes int LOCAL_KEY_EID_GERMAN_RESIDENCE_CARD = R.string.german_residence_permit_with_pin;
    public static final String KEY_EID_GERMAN_RESIDENCE_CARD = "js.mobile.eid.german.residence";

    public static final @StringRes int LOCAL_KEY_EID_EU_CITIZEN = R.string.eu_citizen_card_with_pin;
    public static final String KEY_EID_EU_CITIZEN = "js.mobile.eid.eu.citizen.card";

    public static final @StringRes int LOCAL_KEY_EID_VERIFY_YOURSELF = R.string.verify_yourself_by_video_call;
    public static final String KEY_EID_VERIFY_YOURSELF = "js.mobile.eid.verify.yourself";

    public static @NonNull
    String getStringWithDefault(@NonNull Context context, @NonNull String serverStringKey, @StringRes Integer fallbackStringResId) {
        Map<String, String> messages = Config.MESSAGES_FROM_BACKEND;
        if (messages != null && !TextUtils.isEmpty(serverStringKey) && !TextUtils.isEmpty(messages.get(serverStringKey))) {
            return messages.get(serverStringKey);
        }

        if (fallbackStringResId != null && !TextUtils.isEmpty(context.getString(fallbackStringResId))) {
            //Util_Log.i(LOGTAG,"Messages key " + serverStringKey + " not found, falling back to default.");
            return context.getString(fallbackStringResId);
        }

        return "";
    }

}
