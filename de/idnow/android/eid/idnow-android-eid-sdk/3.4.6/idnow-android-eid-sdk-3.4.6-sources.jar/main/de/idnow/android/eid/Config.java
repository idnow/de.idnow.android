package de.idnow.android.eid;

import androidx.fragment.app.Fragment;

import java.util.List;
import java.util.Map;

import de.idnow.android.eid.models.Models_ApprovalPhrase;
import de.idnow.android.eid.models.Models_PDFDocument;
import de.idnow.android.eid.util.Util;

public class Config {

    public static boolean FROM_SCRATCH = false;
    public static boolean USER_RESTART_FLOW = false;
    public static boolean STANDALONE_EID;

    public static boolean SHOW_POWERED_BY_KEY = false;
    public static boolean ENABLE_CHOOSE_EID_TYPE = false;
    public static String SessionID = "";
    public static Boolean PIN_IS_SET = false;

    public static String VALIDITY_DATE = "";
    public static String ISSUER_URL = "";

    public static List<String> DOCUMENT_INFO = null;


    public static boolean SHOW_DIALOG_WITH_ICON = true;

    public static String URL_DOCUMENT_NAMIRIAL = "";
    public static Models_ApprovalPhrase[] MODEL_APPROVAL_PHRASES = {};
    public static boolean EID_STATUS = false;

    public static boolean NEW_BRAND = false;

    public static String MODELS_CLIENT_INFO_LANGUAGE = "en";

    public static String RESULT_TOKEN;

    public static String PIN_EID = "";

    public static String MESSAGE_USER_START_EID = "Identification started eid";

    public static final String RESULT_DATA_ERROR = "resultDataError";
    public static final String RESULT_ERROR_CODE = "resultErrorCode";
    public static final String RESULT_DATA_TRANSACTION_TOKEN = "resultDataTransactionToken";

    public static final int MESSAGE_USER_CANCELED = R.string.message_user_canceled_eid;

    public static int RESULT_CODE_CANCEL = 3;
    public static int RESULT_CODE_SUCCESS = 2;
    public static int RESULT_CODE_FAILED = 1;
    public static int RESULT_CODE_FALLBACK_VID = 5;
    public static int RESULT_CODE = 0;
    public static int CHOOSER_SCREEN = 7;

    public static String IDNOW_ENDPOINT = "";

    public static String TRANSACTION_TOKEN = "";

    public static String COMPANY_ID = "";

    public static int USER_START_EID_CODE = 11;

    public static boolean ATTACH_EID = false;

    public static boolean EID_VID_TOKEN_FINISEHD = false;

    public static Map<String, String> MESSAGES_FROM_BACKEND = null;

    public static String EID_MOBILE_TOKEN = "";
    public static String EID_SESSION_TOKEN = "";
    public static String EID_SIGNATURE = "";

    public static String EID_EXPIRATION_DATE = "";
    public static String EID_EFFECTIVE_DATE = "";


    public static String EID_WRONG_PIN_TRIES = "";
    public static boolean EID_CAN_REQUIRED_1 = false;
    public static boolean EID_CAN_REQUIRED_2 = false;

    public static boolean EID_CANCEL_IDENT = false;
    public static String EID_ERROR_CODE = "";
    public static String EID_CAN = "";

    public static boolean CARD_ATTACHED = false;

    public static eIDSdk.Server CURRENT_AUTHADA_SERVER = eIDSdk.Server.DEV;

    public static boolean SHOWING_DIALOG = false;
    public static String APP_KEY = "";
    public static String APP_URL = "";

    public static boolean DARK_MODE_ENABLED_CUSTOMER = true;
    public static boolean ENABLE_ID_CAPTURE_EID = false;
    public static boolean ENABLE_PIN_CHANGE_EID = false;
    public static boolean ENABLE_ESIGN = false;


    public static eIDSdk.Server CURRENT_SERVER = eIDSdk.Server.DEV;
    public static int ORIENTATION_VALUE;
    public static int SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE = 0;
    public static final String DEBUG_TAG = "IDNOW";
    public static final String API_NAMESPACE_SOCKET = "/api/v1/identifications/";
    public static String EID_PIN_CHOOSER = "";
    public static boolean ENABLE_PIN_CHANGE = true;
    public static Fragment CURRENT_FRAGMENT = null;
    public static String USER_PHONE_NO = "";
    public static String CALLBACK_SESSION_TIMEOUT_URL = "sessiontimeout";
    public static String CALLBACK_SOMETHING_WENT_WRONG = "somethingWentWrong";
    public static String CALLBACK_IDENT_SUCCEEDED = "successful ident";
    public static String CALLBACK_IDENT_FAILED = "failure ident";

    public static String GENERAL_CALLBACK = "";
    public static String CANCEL_REASON = "EID_USER_CANCELLATION";
    public static String CALLBACK_FINAL_ATTEMPT = "Final attempt";
    public static String CALLBACK_CHANGE_PIN_SUCCESSFUL = "Change PIN SUCCESSFUL";
    public static String CALLBACK_CARD_BLOCKED = "Card blocked";
    public static String CALLBACK_CARD_UNBLOCK_ATTEMPT = "Card unblock";
    public static String CALLBACK_SECOND_ATTEMPT = "SECOND ATTEMPT";
    public static String CALLBACK_ONE_ATTEMPT = "ONE ATTEMPT";

    public static boolean PREPARE_SIGNING = false;

    public static String OTP_SCREEN = "";
    public static String SIGNING_SCREEN = "";
    public static Util.PinScreens DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
    public static boolean PLAY_ANIMATION_LOOP = false;

    public static String CURRENT_CALLBACK = "";
    public static boolean PHONE_NUMBER_MAN_CHANGED = false;
    public static boolean VERIFY_PHONE_NO = false;
    public static Models_PDFDocument[] MODEL_PDF_DOCUMENTS;
    public static String APP_ID = "";
    public static int DOCUMENT_POSITION = 0;
    public static boolean SHOW_IDNOW_LOGO = false;
    public static String EXTRA_TC_TOKEN_URL = "";
    public static String CARD_TYPE = "";
    public static boolean NAME_MISMATCH = false;
    public static String EIDTSP = "";
    //  public static String EXTRA_TC_TOKEN_URL = "https://test.governikus-eid.de/AusweisAuskunft/WebServiceRequesterServlet";
    public static String CALLBACK_MISMATCH = "mismatch data";

    public static String CURRENT_SDK_VERSION = "";
    public static String CONNECTION_TYPE = "";

    public static boolean DISPLAY_OTP_SIGNING = false;
    public static boolean DISPLAY_OTP_IDENT = false;


}
