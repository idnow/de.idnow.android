package de.idnow.android.eid.network

import android.annotation.SuppressLint
import java.security.GeneralSecurityException
import java.security.KeyStore
import java.security.cert.X509Certificate
import javax.net.ssl.TrustManager
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

class IdnowTrustManagerFactory {
    companion object {
        fun createTrustAllManager(): Array<TrustManager> {
            @SuppressLint("CustomX509TrustManager")
            val manager = object : X509TrustManager {
                override fun getAcceptedIssuers(): Array<X509Certificate> =
                    emptyArray()

                @SuppressLint("TrustAllX509TrustManager")
                override fun checkClientTrusted(certs: Array<X509Certificate>, authType: String) {
                }

                @SuppressLint("TrustAllX509TrustManager")
                override fun checkServerTrusted(certs: Array<X509Certificate>, authType: String) {
                }
            }

            return arrayOf(manager)
        }

        @Throws(GeneralSecurityException::class)
        fun createSystemTrustManager(): X509TrustManager {
            val trustManagerFactory =
                TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
            trustManagerFactory.init(null as KeyStore?)
            val trustManagers = trustManagerFactory.trustManagers

            return trustManagers[0] as X509TrustManager
        }
    }
}