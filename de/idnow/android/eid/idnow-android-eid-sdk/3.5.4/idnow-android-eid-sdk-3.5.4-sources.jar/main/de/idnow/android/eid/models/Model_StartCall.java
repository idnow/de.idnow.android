package de.idnow.android.eid.models;

import com.google.gson.annotations.SerializedName;

public class Model_StartCall {
    String mobileToken;
    String sessionToken;
    public Models_Request request;

    String tcTokenUrl;
    @SerializedName("enableOTP")
    public Model_EnableOTP modelEnableOTP;


    public Model_StartCall(String mobileToken, String sessionToken, Models_Request request, String tcTokenUrl, Model_EnableOTP modelEnableOTP) {
        this.mobileToken = mobileToken;
        this.sessionToken = sessionToken;
        this.request = request;
        this.tcTokenUrl = tcTokenUrl;
        this.modelEnableOTP = modelEnableOTP;
    }

    public Model_StartCall(String mobileToken, String sessionToken, Models_Request request) {
        this.mobileToken = mobileToken;
        this.sessionToken = sessionToken;
        this.request = request;
    }

    public String getMobileToken() {
        return mobileToken;
    }

    public String getSessionToken() {
        return sessionToken;
    }

    public String getTcTokenUrl() {
        return tcTokenUrl;
    }

    public Models_Request getRequest() {
        return request;
    }

    public void setMobileToken(String mobileToken) {
        this.mobileToken = mobileToken;
    }

    public void setSessionToken(String sessionToken) {
        this.sessionToken = sessionToken;
    }

    public void setRequest(Models_Request request) {
        this.request = request;
    }

    public Model_EnableOTP getModelEnableOTP() {
        return modelEnableOTP;
    }

    public void setModelEnableOTP(Model_EnableOTP modelEnableOTP) {
        this.modelEnableOTP = modelEnableOTP;
    }

    @Override
    public String toString() {
        return "Model_StartCall{" +
                "mobileToken='" + mobileToken + '\'' +
                ", sessionToken='" + sessionToken + '\'' +
                ", request=" + request +
                '}';
    }
}
