package de.idnow.android.eid.Authada

import android.app.Activity
import android.content.Context
import androidx.fragment.app.Fragment
import com.google.android.material.bottomsheet.BottomSheetDialog
import de.authada.library.api.Can
import de.authada.library.api.CheckFailedReason
import de.authada.library.api.RequiredData
import de.authada.library.api.SecretWrong
import de.authada.library.api.WrongSecretFormatException
import de.authada.library.api.authentication.AuthenticationCallback
import de.authada.library.api.authentication.Pin
import de.authada.library.api.authentication.PinTerminationReason
import de.authada.library.api.authentication.StartCallback
import de.authada.library.api.authentication.StartTerminationReason
import de.authada.library.api.authentication.document.DocumentBuilder
import de.idnow.android.eid.Authada.keyLocalization.AuthadaCertificateKey
import de.idnow.android.eid.Authada.keyLocalization.AuthadaCertificateKeyLocalization
import de.idnow.android.eid.Config
import de.idnow.android.eid.Config.EID_ERROR_CODE
import de.idnow.android.eid.eIDActivity
import de.idnow.android.eid.eIDSdk
import de.idnow.android.eid.fragments.Fragment_HoldIDBack
import de.idnow.android.eid.fragments.Fragment_PIN_digit_chooser
import de.idnow.android.eid.fragments.Fragment_ProgressPage
import de.idnow.android.eid.models.Models_ResultToken
import de.idnow.android.eid.network.EidCallback
import de.idnow.android.eid.network.EidError
import de.idnow.android.eid.network.IDnowRestClient
import de.idnow.android.eid.util.Util
import de.idnow.android.eid.util.Util_Log
import de.idnow.android.eid.util.Util_Status
import retrofit2.Response
import java.text.SimpleDateFormat

private const val LOGTAG = "IDNOW_ControlAuthadaIntegration"

internal class ControlAuthadaIntegration {

    var RESULT_START = Util.BottomSheetType.ON_CARD_BLOCKED

    var RESULT_PIN = ""

    var SCAN_PROGRESS = 0

    private lateinit var pin: Pin

    var enterTime = 0


    fun Authentication(mobileToken: String, context: Context, fragment: Fragment) {

        AuthadaAuthenticationWrapper.getAuthentication().start(mobileToken, object : StartCallback {
            override fun onConnectionTimeout() {
                Util_Log.e(LOGTAG, "NFC EID onConnectionTimeout")

                (context as eIDActivity).errorEIDscreen(
                    fragment,
                    Config.CALLBACK_IDENT_FAILED
                )
            }


            override fun onProcessTerminated(terminationReason: StartTerminationReason) {
                Util_Log.e(LOGTAG, "NFC EID onProcessTerminated")

                (context as eIDActivity).errorEIDscreen(
                    fragment,
                    Config.CALLBACK_IDENT_FAILED
                )
            }

            override fun onSuccess(
                businessUseCase: String,
                certificateInfo: HashMap<String, String>,
                dataToBeRead: Array<String>
            ) {
                Util_Log.i(LOGTAG, "NFC EID SUCCESS 1ST AUTHENTICATION : ")

                val fragmentHoldIDBack = Fragment_HoldIDBack()
                (context as eIDActivity).hideIntroFragment(fragment)
                context.showIntroFragment(fragmentHoldIDBack)
            }
        })
    }

    fun Authentication(
        mobileToken: String,
        context: Activity,
        fragmentProgressPage: Fragment_ProgressPage
    ) {

        Util_Log.i(LOGTAG, "mobile token : " + mobileToken)

        Util_Log.i(LOGTAG, "NFC EID  START 1ST AUTHENTICATION : ")

        AuthadaAuthenticationWrapper.getAuthentication().start(mobileToken, object : StartCallback {
            override fun onConnectionTimeout() {
                Util_Log.e(LOGTAG, "NFC EID onConnectionTimeout")

                (context as eIDActivity).errorEIDscreen(
                    fragmentProgressPage,
                    Config.CALLBACK_IDENT_FAILED
                )

            }

            override fun onProcessTerminated(terminationReason: StartTerminationReason) {
                Util_Log.e(LOGTAG, "NFC EID onProcessTerminated")

                (context as eIDActivity).errorEIDscreen(
                    fragmentProgressPage,
                    Config.CALLBACK_IDENT_FAILED
                )
            }

            override fun onSuccess(
                businessUseCase: String,
                certificateInfo: HashMap<String, String>,
                dataToBeRead: Array<String>
            ) {

                Util_Log.i(LOGTAG, "NFC EID SUCCESS 1ST AUTHENTICATION : ")
                val effectiveDate = try {
                    val key =
                        context.getCertificateKey(AuthadaCertificateKey.EFFECTIVE_DATE_OF_CERTIFICATE)
                    certificateInfo.getValue(key)
                } catch (e: NoSuchElementException) {
                    Util_Log.e(LOGTAG, "Read effective date failed", e)
                    ""
                }

                val expireDate = try {
                    val key =
                        context.getCertificateKey(AuthadaCertificateKey.EXPIRATION_DATE_OF_CERTIFICATE)
                    certificateInfo.getValue(key)
                } catch (e: NoSuchElementException) {
                    Util_Log.e(LOGTAG, "Read expiration date failed", e)
                    ""
                }

                Config.EID_EFFECTIVE_DATE = effectiveDate
                Config.EID_EXPIRATION_DATE = expireDate
                Config.DOCUMENT_INFO = dataToBeRead.toList()
                Config.ISSUER_URL = certificateInfo.entries
                    .firstOrNull { it.key.contains("url", ignoreCase = true) }
                    ?.value

                Util_Log.i(LOGTAG, "Config.EID_EFFECTIVE_DATE : " + Config.EID_EFFECTIVE_DATE)
                Util_Log.i(LOGTAG, "Config.EID_EXPIRATION_DATE : " + Config.EID_EXPIRATION_DATE)

                val parser = SimpleDateFormat("yyyy-MM-dd")
                val formatter = SimpleDateFormat("dd-MM-yyyy")

                if (effectiveDate.isNotEmpty()) {
                    Config.EID_EFFECTIVE_DATE = formatter.format(parser.parse(effectiveDate))
                }
                if (expireDate.isNotEmpty()) {
                    Config.EID_EXPIRATION_DATE = formatter.format(parser.parse(expireDate))
                }

                val dateRegex = Regex("""\d{4}-\d{2}-\d{2}""")

                val dateValues = certificateInfo.values
                    .filter { it.matches(dateRegex) }
                    .map { parser.parse(it) } // Parse as actual Date objects
                    .sorted() // Sort chronologically

                if (dateValues.size >= 2) {
                    val startDate = dateValues.first()  // Earliest date
                    val expirationDate = dateValues.last()  // Latest date

                    Config.VALIDITY_DATE =
                        formatter.format(startDate) + " - " + formatter.format(expirationDate)
                }

                val fragmentPinDigitChooser = Fragment_PIN_digit_chooser()

                (context as eIDActivity).hideIntroFragment(fragmentProgressPage)

                context.showIntroFragment(fragmentPinDigitChooser)

            }
        })
    }

    fun isAuthenticationInitialized(): Boolean {
        return AuthadaAuthenticationWrapper.isAuthenticationInitialized()
    }

    fun stopAuthada() {
        return AuthadaAuthenticationWrapper.getAuthentication().stop();
    }

    fun startAuthenticationWithPin(
        context: Context,
        pin_eid: String,
        fragment: Fragment,
        bottomSheetDialog: BottomSheetDialog
    ) {
        Util_Log.i(LOGTAG, "NFC EID : SCAN PIN")

        if (!Config.EID_CAN.equals("")) {
            Util_Log.i(LOGTAG, "NFC EID : SET CAN")
            setCAN(Config.EID_CAN)
        }
        pin = Pin(pin_eid.map { it.toString().toInt() }.toIntArray())

        AuthadaAuthenticationWrapper.getAuthentication().pinAuthentication(
            pin,
            object : AuthenticationCallback {

                // DONE
                override fun onAdditionalDataRequired(requiredData: RequiredData) {

                    Util_Log.i(LOGTAG, "NFC EID : onAdditionalDataRequired " + requiredData)

                    Config.ATTACH_EID = true

                    RESULT_PIN = Util_Status.ON_ADDITIONAL_DATA_REQUIRED

                }

                // DONE
                override fun onAuthenticationProgress(percentage: Int) {

                    Util_Log.i(LOGTAG, "NFC EID : onAuthenticationProgress - " + percentage)

                    SCAN_PROGRESS = percentage

                    Config.ATTACH_EID = true

                    if (RESULT_PIN.equals(Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED)) {
                        if (fragment is Fragment_HoldIDBack) run {
                            fragment.displayBottomSheetAuthada(
                                RESULT_START,
                                context,
                                bottomSheetDialog
                            )
                        }
                    } else {
                        RESULT_PIN = Util_Status.ON_AUTHENTIFCATION_PROGRESS
                    }

                }


                // DONE
                override fun onConnectionTimeout() {
                    Util_Log.e(LOGTAG, "NFC EID : onConnectionTimeout")

                    Config.ATTACH_EID = true

                    RESULT_PIN = Util_Status.ON_CONNECTION_TIMEOUT_PIN

                    RESULT_START = Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED

                    if (fragment is Fragment_HoldIDBack) run {
                        (context as eIDActivity).identificationCanceledRESTCall(
                            fragment,
                            "EID_CARD_SCAN_UNSUCCESSFUL"
                        )

                        fragment.displayBottomSheetAuthada(RESULT_START, context, bottomSheetDialog)
                    }

                }

                // DONE
                override fun onEidCardCheckFailed(failedReason: CheckFailedReason) {
                    Util_Log.i(LOGTAG, "NFC EID : onEidCardCheckFailed")

                    enterTime = 0

                    Config.CARD_ATTACHED = true

                    when (failedReason) {
                        CheckFailedReason.ONE_PIN_TRY_LEFT_CAN_PIN_REQUIRED -> {
                            Util_Log.i(LOGTAG, "NFC EID : ONE_PIN_TRY_LEFT_CAN_PIN_REQUIRED")

                            RESULT_START = Util.BottomSheetType.ON_WRONG_PIN_TRIES_1

                        }

                        CheckFailedReason.NO_EID_CARD -> {
                            Util_Log.i(LOGTAG, "NFC EID : NO_EID_CARD")

                            RESULT_START = Util.BottomSheetType.BOTTOM_SHEET_LOST_CONNECTION

                            EID_ERROR_CODE = "NO EID CARD"
                        }
                    }

                    RESULT_PIN = Util_Status.ON_EID_CARD_CHECK_FAILED

                    if (fragment is Fragment_HoldIDBack) run {
                        fragment.displayBottomSheetAuthada(RESULT_START, context, bottomSheetDialog)
                    }

                }

                /**
                 * The callback is called when an eID card is attached to the NFC antenna of the device and it should be
                 * communicated to the user that the card should stay in position
                 */
                // DONE
                override fun onEidCardFound() {
                    Util_Log.i(LOGTAG, "NFC EID : onEidCardFound")

                    Config.CARD_ATTACHED = true

                    enterTime = enterTime + 1

                    Config.ATTACH_EID = true

                    RESULT_START = Util.BottomSheetType.BOTTOM_SHEET_CARD_DETECTION

                    if (fragment is Fragment_HoldIDBack) run {
                        (context as eIDActivity).changeStepRESTCall("CARD_SCAN")
                        fragment.displayBottomSheetAuthada(RESULT_START, context, bottomSheetDialog)
                    }
                }

                /**
                 * The onEidCardLost is called when the connection to the card is lost.
                 * The NFC process can be continued by placing the card in the correct position again if the
                 * cardLost is called
                 */
                // DONE
                override fun onEidCardLost() {

                    Util_Log.i(LOGTAG, "NFC EID : onEidCardLost")

                    Util_Log.i(LOGTAG, "Please reattach eID card to device.")

                    RESULT_PIN = Util_Status.ON_EID_CARD_LOST

                    EID_ERROR_CODE = "EID Card Lost"

                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_CARD_SCAN_SCREEN_PHONE_NOT_DETECTING_EID)

                    RESULT_START = Util.BottomSheetType.BOTTOM_SHEET_LOST_CONNECTION

                    if (fragment is Fragment_HoldIDBack) run {
                        fragment.displayBottomSheetAuthada(RESULT_START, context, bottomSheetDialog)
                    }

                }

                override fun onImagesRequired(documentBuilder: DocumentBuilder) {}

                /**
                 * The callback is called when we need to terminate and create a new authentication object.
                 */
                // DONE
                override fun onProcessTerminated(terminationReason: PinTerminationReason) {

                    RESULT_START = Util.BottomSheetType.ON_PROCESS_TERMINATED

                    Config.CARD_ATTACHED = true

                    Util_Log.i(LOGTAG, "NFC EID : onProcessTerminated")

                    RESULT_START = Util.BottomSheetType.ON_CARD_BLOCKED

                    when (terminationReason) {
                        PinTerminationReason.CARD_BLOCKED -> {
                            Util_Log.i(LOGTAG, "NFC EID : CARD_BLOCKED")

                            RESULT_START = Util.BottomSheetType.ON_CARD_BLOCKED

                            EID_ERROR_CODE = "CARD BLOCKED"

                        }

                        PinTerminationReason.CARD_LOST -> {
                            Util_Log.i(LOGTAG, "NFC EID : CARD_LOST")
                            EID_ERROR_CODE = "CARD LOST"

                            RESULT_START = Util.BottomSheetType.BOTTOM_SHEET_LOST_CONNECTION

                        }

                        PinTerminationReason.CERTIFICATE_PINNING_FAILED -> {
                            Util_Log.i(LOGTAG, "NFC EID : CERTIFICATE_PINNING_FAILED")
                            //  RESULT_START = Util_Status.ON_EID_OTHER
                            EID_ERROR_CODE = "CERTIFICATE PINNING FAILED"

                            RESULT_START = Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED

                        }

                        PinTerminationReason.GENERAL_HTTP_ERROR -> {
                            Util_Log.i(LOGTAG, "NFC EID : GENERAL_HTTP_ERROR")
                            //  RESULT_START = Util_Status.ON_EID_OTHER
                            EID_ERROR_CODE = "GENERAL HTTP ERROR"

                            RESULT_START = Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED

                        }

                        PinTerminationReason.EID_AUTHENTICATE_ERROR -> {
                            Util_Log.i(LOGTAG, "NFC EID : EID_AUTHENTICATE_ERROR")
                            // RESULT_START = Util_Status.ON_EID_OTHER
                            EID_ERROR_CODE = "EID AUTHENTICATE ERROR"

                            RESULT_START = Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED

                        }

                        PinTerminationReason.EID_INVALID -> {
                            Util_Log.i(LOGTAG, "NFC EID : EID_INVALID")
                            //   RESULT_START = Util_Status.ON_EID_OTHER
                            EID_ERROR_CODE = "EID INVALID"

                            RESULT_START = Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED
                        }

                        PinTerminationReason.EID_SESSION_EXPIRED -> {
                            Util_Log.i(LOGTAG, "NFC EID : EID_SESSION_EXPIRED")
                            //   RESULT_START = Util_Status.ON_EID_OTHER
                            EID_ERROR_CODE = "SESSION EXPIRED"

                            RESULT_START = Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED
                        }

                        PinTerminationReason.EXTENDED_LENGTH_UNSUPPORTED -> {
                            Util_Log.i(LOGTAG, "NFC EID : EXTENDED_LENGTH_UNSUPPORTED")
                            //   RESULT_START = Util_Status.ON_EID_OTHER
                            EID_ERROR_CODE = "EXTENDED LENGTH UNSUPPORTED"

                            RESULT_START = Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED

                        }

                        PinTerminationReason.CARD_DEACTIVATED -> {
                            Util_Log.i(LOGTAG, "NFC EID : CARD_DEACTIVATED")
                            //  RESULT_START = Util_Status.ON_EID_OTHER
                            EID_ERROR_CODE = "CARD DEACTIVATED"
                            RESULT_START = Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED


                        }

                        PinTerminationReason.DOCUMENT_NOT_ALLOWED -> {
                            Util_Log.i(LOGTAG, "NFC EID: DOCUMENT_NOT_ALLOWED")
                            EID_ERROR_CODE = "DOCUMMENT NOT ALLOWED"
                            RESULT_START = Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED
                        }
                    }

                    if (fragment is Fragment_HoldIDBack) run {
                        if (!RESULT_START.equals(Util.BottomSheetType.BOTTOM_SHEET_LOST_CONNECTION) &&
                            !RESULT_START.equals(Util.BottomSheetType.ON_CARD_BLOCKED)
                        ) {
                            (context as eIDActivity).identificationCanceledRESTCall(
                                fragment,
                                "EID_CARD_SCAN_UNSUCCESSFUL"
                            )

                        }
                        fragment.displayBottomSheetAuthada(RESULT_START, context, bottomSheetDialog)
                    }

                    Config.ATTACH_EID = true
                    Util_Log.i(LOGTAG, "NFC EID : onProcessTerminated")
                }

                /**
                 * The onSecretWrong is called when the PIN number to identify the user is wrong.
                 * The triesLeft enum provides context on the type of error that happened.
                 * Possible enums:
                 * --> PIN_WRONG_TWO_PIN_TRIES_LEFT_PIN_REQUIRED
                 * --> PIN_WRONG_ONE_PIN_TRY_LEFT_CAN_PIN_REQUIRED
                 * --> CAN_WRONG_CAN_PIN_REQUIRED
                 */
                // DONE
                override fun onSecretWrong(triesLeft: SecretWrong) {
                    Util_Log.i(LOGTAG, "NFC EID : onSecretWrong")

                    Config.ATTACH_EID = true

                    RESULT_PIN = Util_Status.ON_SECRET_WRONG

                    when (triesLeft) {
                        SecretWrong.PIN_WRONG_TWO_PIN_TRIES_LEFT_PIN_REQUIRED -> {
                            Util_Log.i(
                                LOGTAG,
                                "NFC EID : PIN_WRONG_TWO_PIN_TRIES_LEFT_PIN_REQUIRED "
                            )
                            RESULT_START = Util.BottomSheetType.ON_WRONG_PIN_TRIES_2
                        }

                        SecretWrong.PIN_WRONG_ONE_PIN_TRY_LEFT_CAN_PIN_REQUIRED -> {
                            Util_Log.i(
                                LOGTAG,
                                "NFC EID : PIN_WRONG_ONE_PIN_TRY_LEFT_CAN_PIN_REQUIRED "
                            )
                            RESULT_START = Util.BottomSheetType.ON_WRONG_PIN_TRIES_1
                            enterTime = 0
                        }

                        SecretWrong.CAN_WRONG_CAN_PIN_REQUIRED -> {
                            Util_Log.i(LOGTAG, "NFC EID : CAN_WRONG_CAN_PIN_REQUIRED ")
                            RESULT_START = Util.BottomSheetType.ON_CAN_WRONG
                            enterTime = 0
                        }

                    }

                    if (fragment is Fragment_HoldIDBack) run {
                        fragment.displayBottomSheetAuthada(RESULT_START, context, bottomSheetDialog)
                    }
                }

                /**
                 * The onSuccess is called when the user authentication was carried out successfully.
                 * The resultToken that comes out of this process is to be transferred to
                 * the customerBackend to obtain the user details.
                 */
                // DONE
                override fun onSuccess(resultToken: String) {
                    Util_Log.i(LOGTAG, "NFC EID : onSuccess ")

                    enterTime = 0

                    Config.ATTACH_EID = true

                    Util_Log.i(LOGTAG, "NFC EID : RESULT TOKEN " + resultToken)

                    Config.RESULT_TOKEN = resultToken

                    RESULT_PIN = Util_Status.ON_SUCCESS_PIN

                    Util_Log.i(LOGTAG, "NFC EID - RESULT PIN 1 : " + RESULT_PIN)

                    val fragment_holdIDBack = Fragment_HoldIDBack()

                    Util_Log.d(LOGTAG, "NFC SESSIONTOKEN : " + Config.EID_SESSION_TOKEN)
                    Util_Log.d(
                        LOGTAG,
                        "NFC INTERNALTOKEN : " + eIDSdk.getTransactionToken()
                    )

                    if (fragment is Fragment_HoldIDBack) run {
                        fragment_holdIDBack.displayBottomSheetAuthada(
                            Util.BottomSheetType.ON_SUCCESS_PIN,
                            context,
                            bottomSheetDialog
                        )
                    }


                }
            })
    }

    fun setCAN(can_eid: String) {
        try {
            val can = Can(can_eid.map { it.toString().toInt() }.toIntArray())
            AuthadaAuthenticationWrapper.getAuthentication().setCan(can)
        } catch (e: WrongSecretFormatException) {
            Util_Log.e(LOGTAG, "NFC EID Set can failed", e)
        }
    }

    fun sendResultToken(
        context: Context,
        fragment: Fragment,
        bottomSheetDialog: BottomSheetDialog
    ) {
        val endPoint = Config.CURRENT_SERVER.getApiHost(eIDSdk.getTransactionToken())
        val service = IDnowRestClient.getRestClient()
            .getCallsForEndpoint(endPoint, eIDSdk.getInstance().appContext)
        val callback: EidCallback<Void> = object : EidCallback<Void>() {
            override fun success(resultObject: Void?, response: Response<*>?) {
                Util_Log.d(LOGTAG, "NFC Success")
                if (fragment is Fragment_HoldIDBack) run {
                    if (resultObject != null) {
                        Util_Log.d(LOGTAG, "NFC Success check failed : " + resultObject.toString())
                        fragment.displayBottomSheetAuthada(
                            Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED,
                            context,
                            bottomSheetDialog
                        )
                    } else {
                        Util_Log.d(LOGTAG, "NFC Success PIN ")
                        fragment.displayBottomSheetAuthada(
                            Util.BottomSheetType.ON_EID_SUCCESS_SENDING_PIN,
                            context,
                            bottomSheetDialog
                        )
                    }
                }
            }

            override fun failure(error: EidError) {
                Util_Log.d(LOGTAG, "NFC Failure : " + error.message)
                if (fragment is Fragment_HoldIDBack) {
                    if (eIDSdk.getEnableEIDQES() && error.response.status.equals(412)) {
                        Config.NAME_MISMATCH = true
                        Config.GENERAL_CALLBACK = Config.CALLBACK_MISMATCH
                    }

                    fragment.displayBottomSheetAuthada(
                        Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED,
                        context,
                        bottomSheetDialog
                    )
                }
            }
        }

        val result = service.sendResultToken(
            Models_ResultToken(
                Config.RESULT_TOKEN,
                Config.EID_SESSION_TOKEN,
                eIDSdk.getTransactionToken()
            ),
            eIDSdk.getCompanyId()
        )
        result.enqueue(callback)

    }

    private fun Context.getCertificateKey(key: AuthadaCertificateKey): String =
        AuthadaCertificateKeyLocalization(this).getValue(key)
}