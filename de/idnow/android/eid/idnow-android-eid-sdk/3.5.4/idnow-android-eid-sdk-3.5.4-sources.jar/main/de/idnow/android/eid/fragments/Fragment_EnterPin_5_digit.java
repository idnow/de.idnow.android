package de.idnow.android.eid.fragments;

import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.BottomSheetType.BOTTOM_SHEET_1_ATTEMPT_LEFT;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.BottomSheetType.BOTTOM_SHEET_2_ATTEMPTS_LEFT;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.BottomSheetType.BOTTOM_SHEET_CARD_BLOCKED;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.BottomSheetType.BOTTOM_SHEET_CLOSED;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.BottomSheetType.BOTTOM_SHEET_PIN_CHANGED_SUCCESS;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.BottomSheetType.BOTTOM_SHEET_READY_TO_SCAN;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.BottomSheetType.BOTTOM_SHEET_WRONG_CAN;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.ErrorCases.OUTCOME_CARD_UNBLOCK_ATTEMPT;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.ErrorCases.OUTCOME_ERROR_CARD_BLOCKED;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.ErrorCases.OUTCOME_ERROR_CARD_DEACTIVATED;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.ErrorCases.OUTCOME_ERROR_DEVICE_NOT_COMPATIBLE;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.ErrorCases.OUTCOME_NONE;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.ErrorCases.OUTCOME_NO_COMPATIBLE_ID;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.ErrorCases.OUTCOME_SUCCESS_PIN_CHANGED;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.ErrorCases.OUTCOME_WARNING_PIN_LAST_ATTEMPT;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.ErrorCases.OUTCOME_WARNING_TWO_ATTEMPTS_LEFT;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.PinScreens.SCREEN_ENTER_5_DIGIT_PIN;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.PinScreens.SCREEN_ENTER_CAN_CODE;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.PinScreens.SCREEN_ENTER_NEW_6_DIGIT_PIN;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.PinScreens.SCREEN_HOLD_BACK_EID;
import static de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit.PinScreens.SCREEN_RE_ENTER_NEW_6_PIN;
import static de.idnow.android.eid.util.Util.hideKeyBoard;
import static de.idnow.android.eid.util.Util.setProceedButtonBackgroundSelector;
import static de.idnow.android.eid.util.Util.showKeyBoard;
import static de.idnow.android.eid.util.Util.showNoConnectionDialog;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.nfc.NfcAdapter;
import android.nfc.NfcManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.Objects;

import de.authada.library.api.AuthadaAuthenticationLibrary;
import de.authada.library.api.Can;
import de.authada.library.api.CheckFailedReason;
import de.authada.library.api.SecretWrong;
import de.authada.library.api.authentication.Pin;
import de.authada.library.api.pinChanger.PinChanger;
import de.authada.library.api.pinChanger.PinChangerCallback;
import de.authada.library.api.pinChanger.TPin;
import de.authada.library.api.pinChanger.TerminationReason;
import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.UI.GenericTextWatcherWrapper;
import de.idnow.android.eid.UI.HeaderView;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.util.Util;
import de.idnow.android.eid.util.Util_Log;
import de.idnow.android.eid.util.Util_Strings;
import kotlin.Unit;

public class Fragment_EnterPin_5_digit extends BaseFragment {

    // PIN screen case
    public enum PinScreens {
        SCREEN_ENTER_5_DIGIT_PIN,
        SCREEN_ENTER_NEW_6_DIGIT_PIN,
        SCREEN_RE_ENTER_NEW_6_PIN,
        SCREEN_HOLD_BACK_EID,
        SCREEN_ENTER_CAN_CODE
    }

    // Bottom sheet type
    public enum BottomSheetType {
        BOTTOM_SHEET_READY_TO_SCAN,
        BOTTOM_SHEET_PIN_CHANGED_SUCCESS,
        BOTTOM_SHEET_2_ATTEMPTS_LEFT,
        BOTTOM_SHEET_1_ATTEMPT_LEFT,
        BOTTOM_SHEET_CARD_BLOCKED,
        BOTTOM_SHEET_WRONG_CAN,
        BOTTOM_SHEET_NO_COMPATIBLE_ID,
        BOTTOM_SHEET_CLOSED
    }

    // Error-Success cases
    public enum ErrorCases {
        OUTCOME_ERROR_CARD_BLOCKED,
        OUTCOME_CARD_UNBLOCK_ATTEMPT,
        OUTCOME_ERROR_DEVICE_NOT_COMPATIBLE,
        OUTCOME_ERROR_CARD_DEACTIVATED,
        OUTCOME_NO_COMPATIBLE_ID,
        OUTCOME_WARNING_PIN_LAST_ATTEMPT,
        OUTCOME_WARNING_TWO_ATTEMPTS_LEFT,
        OUTCOME_SUCCESS_PIN_CHANGED,
        OUTCOME_NONE
    }

    // Visibility flags
    private final int
            VIEW_VISIBLE = View.VISIBLE,
            VIEW_GONE = View.GONE,
            VIEW_INVISIBLE = View.INVISIBLE;

    public enum ClickableTextType {
        WHERE_IS_CAN,
        IDNOW_HOME_PAGE,
    }

    public static final boolean IS_VISIBLE = true, IS_GONE = false;
    private boolean thirdTimePinTyped = false;

    public static final long DELAY_MILLIS = 2000;

    private Context context;

    private PinScreens currentScreen = SCREEN_ENTER_5_DIGIT_PIN;
    private BottomSheetType currentBottomSheet = BOTTOM_SHEET_CLOSED;
    private ErrorCases currentOutcome = OUTCOME_NONE;

    private Button main_continue_button, bottom_sheet_continue_button, outcome_continue_button;
    private TextView pin_title;
    private TextView pin_description;
    private TextView pin_error;
    private TextView bottom_sheet_title;
    private TextView bottom_sheet_description;
    private TextView outcome_title;
    private TextView outcome_description;
    private TextView outcome_continue_button_secondary;
    private TextView quit_pin_change_title;
    private TextView quit_pin_change_description;
    private TextView quit_pin_change_quit_button;
    private TextView quit_pin_change_continue_button;
    private TextView quit_pin_change_try_another_method_button;
    private TextView go_to_6_digit_pin_button;
    private TextView more_info_button;

    private EditText pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5;

    private LinearLayout pin_box_layout;

    private String fiveDigitTransportPIN, newSixDigitPIN, reEnterSixDigitPIN, CANcode;

    private ImageButton bottom_sheet_cancel_cross;

    private AppCompatImageView show_pin;
    private LottieAnimationView outcome_imageview;
    private LottieAnimationView sf_gif;
    private LottieAnimationView bottom_sheet_image_sign;
    private HeaderView header;

    private BottomSheetDialog bottomSheetDialog, bottomSheetMoreInfo;
    private LinearLayout outcome_layout;
    private Dialog quitDialog;

    private static final String LOGTAG = "IDNOW_Fragment_EnterPin_5_digit";

    private FragmentActivity fragmentActivity;

    private PinChanger pinChanger;

    PinChangerCallback pinChangerCallback = new PinChangerCallback() {

        @Override
        public void onProcessTerminated(@NonNull TerminationReason terminationReason) {

            Util_Log.d(LOGTAG, "onProcessTerminated");

            if (bottomSheetDialog.isShowing()) {
                bottomSheetDialog.dismiss();
            }

            switch (terminationReason) {
                case EXTENDED_LENGTH_UNSUPPORTED:
                    thirdTimePinTyped = false;
                    displayOutcome(OUTCOME_ERROR_DEVICE_NOT_COMPATIBLE);
                    break;
                case CARD_BLOCKED:
                    thirdTimePinTyped = false;
                    displayBottomSheet(BOTTOM_SHEET_CARD_BLOCKED);
                    break;
                case CARD_DEACTIVATED:
                    thirdTimePinTyped = false;
                    displayOutcome(OUTCOME_ERROR_CARD_DEACTIVATED);
                    break;
                case NFC_NOT_ACTIVE:
                    dialog_nfc(context);
                    break;
                default:
                    break;
            }
        }

        @Override
        public void onSuccess() {
            Util_Log.d(LOGTAG, "onSuccess");
            if (bottomSheetDialog.isShowing()) {
                bottomSheetDialog.dismiss();
            }
            thirdTimePinTyped = false;
            displayBottomSheet(BOTTOM_SHEET_PIN_CHANGED_SUCCESS);
        }

        @Override
        public void onEidCardLost() {
            Util_Log.d(LOGTAG, "onEidCardLost");
            if (bottomSheetDialog.isShowing() && currentBottomSheet == BOTTOM_SHEET_READY_TO_SCAN) {
                bottomSheetDialog.dismiss();
            }
        }

        @Override
        public void onEidCardFound() {
            Util_Log.d(LOGTAG, "onEidCardFound");
            if (bottomSheetDialog.isShowing()) {
                bottomSheetDialog.dismiss();
            }
            displayBottomSheet(BOTTOM_SHEET_READY_TO_SCAN);
        }

        @Override
        public void onSecretWrong(@NonNull SecretWrong secretWrong) {
            Util_Log.d(LOGTAG, "onSecretWrong");
            switch (secretWrong) {
                case PIN_WRONG_TWO_PIN_TRIES_LEFT_PIN_REQUIRED:
                    if (bottomSheetDialog.isShowing()) {
                        bottomSheetDialog.dismiss();
                    }
                    thirdTimePinTyped = false;
                    displayBottomSheet(BOTTOM_SHEET_2_ATTEMPTS_LEFT);
                    break;
                case PIN_WRONG_ONE_PIN_TRY_LEFT_CAN_PIN_REQUIRED:
                    if (bottomSheetDialog.isShowing()) {
                        bottomSheetDialog.dismiss();
                    }
                    thirdTimePinTyped = false;
                    displayBottomSheet(BOTTOM_SHEET_1_ATTEMPT_LEFT);
                    break;
                case CAN_WRONG_CAN_PIN_REQUIRED:
                    if (bottomSheetDialog.isShowing()) {
                        bottomSheetDialog.dismiss();
                    }
                    thirdTimePinTyped = true;
                    displayBottomSheet(BOTTOM_SHEET_WRONG_CAN);
                    break;
                default:
                    break;
            }
        }

        @Override
        public void onEidCardCheckFailed(@NonNull CheckFailedReason checkFailedReason) {
            Util_Log.d(LOGTAG, "onEidCardCheckFailed");
            switch (checkFailedReason) {
                case ONE_PIN_TRY_LEFT_CAN_PIN_REQUIRED:
                    if (bottomSheetDialog.isShowing()) {
                        bottomSheetDialog.dismiss();
                    }
                    thirdTimePinTyped = true;
                    displayOutcome(OUTCOME_WARNING_PIN_LAST_ATTEMPT);
                    break;
                case NO_EID_CARD:
                    displayOutcome(OUTCOME_NO_COMPATIBLE_ID);
                    break;
                default:
                    break;
            }
        }
    };

    private void bindViews(View view) {
        header = view.findViewById(R.id.header);

        pinBox0 = view.findViewById(R.id.pinBox0);
        pinBox1 = view.findViewById(R.id.pinBox1);
        pinBox2 = view.findViewById(R.id.pinBox2);
        pinBox3 = view.findViewById(R.id.pinBox3);
        pinBox4 = view.findViewById(R.id.pinBox4);
        pinBox5 = view.findViewById(R.id.pinBox5);
        pin_box_layout = view.findViewById(R.id.pin_box_layout);

        show_pin = view.findViewById(R.id.show_pin);

        main_continue_button = view.findViewById(R.id.button_continue_pin);
        main_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_CONTINUE_BUTTON, Util_Strings.LOCAL_KEY_EID_CHOOSE_CONTINUE_BUTTON));
        go_to_6_digit_pin_button = view.findViewById(R.id.go_to_6_digit_pin_button);
        go_to_6_digit_pin_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_5_DIGIT_CHOOSE_6_DIGIT, Util_Strings.LOCAL_KEY_EID_PIN_5_DIGIT_CHOOSE_6_DIGIT));
        more_info_button = view.findViewById(R.id.more_info_button);

        pin_title = view.findViewById(R.id.pin_title);
        pin_error = view.findViewById(R.id.pin_error);
        pin_description = view.findViewById(R.id.pin_description);

        sf_gif = view.findViewById(R.id.sf_gif);

        View bottomSheetContentView = getLayoutInflater().inflate(R.layout.bottom_sheet_hold_back_eid_5_digit_pin, null);
        bottomSheetDialog = new BottomSheetDialog(fragmentActivity, R.style.BottomSheetDialog);
        bottomSheetDialog.setContentView(bottomSheetContentView);
        bottomSheetDialog.setCancelable(false);

        bottom_sheet_cancel_cross = bottomSheetContentView.findViewById(R.id.bottom_sheet_cancel_cross);
        bottom_sheet_title = bottomSheetContentView.findViewById(R.id.bottomsheet_title);
        bottom_sheet_image_sign = bottomSheetContentView.findViewById(R.id.bottomsheet_image_sign);
        bottom_sheet_description = bottomSheetContentView.findViewById(R.id.bottomsheet_description);
        bottom_sheet_continue_button = bottomSheetContentView.findViewById(R.id.bottomsheet_action_button);

        outcome_imageview = view.findViewById(R.id.outcome_imageview);
        outcome_title = view.findViewById(R.id.outcome_title);
        outcome_description = view.findViewById(R.id.outcome_description);
        outcome_continue_button = view.findViewById(R.id.outcome_button);
        outcome_continue_button_secondary = view.findViewById(R.id.outcome_button_secondary);
        outcome_layout = view.findViewById(R.id.outcome_layout);
    }

    public void moreInfo(final Context context, PinScreens forcedChoice) {

        View bottomSheetContentView = getLayoutInflater().inflate(R.layout.bottom_sheet_more_information, null);
        bottomSheetMoreInfo = new BottomSheetDialog(fragmentActivity, R.style.BottomSheetDialog);
        bottomSheetMoreInfo.setContentView(bottomSheetContentView);

        ImageButton bottom_sheet_more_information_cancel_cross = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_cancel_cross);
        TextView bottom_sheet_more_information_description = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_description);
        AppCompatImageView bottom_sheet_more_information_image = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_image);
        LottieAnimationView bottom_sheet_more_information_nfc_antenna_animation = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_nfc_antenna_animation);
        TextView bottom_sheet_more_information_antenna_location_label = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_antenna_location_label);

        bottom_sheet_more_information_cancel_cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetMoreInfo.dismiss();
            }
        });

        PinScreens screen = forcedChoice != null ? forcedChoice : currentScreen;

        switch (screen) {
            case SCREEN_ENTER_5_DIGIT_PIN:

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_TRANPORT_PIN_SCREEN_LEARN_MORE);

                bottom_sheet_more_information_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DATA_CONFIRMATION_FIVE_DIGIT_DESC, Util_Strings.LOCAL_KEY_EID_DATA_CONFIRMATION_FIVE_DIGIT_DESC));
                bottom_sheet_more_information_image.setImageResource(R.drawable.transport_pin);
                bottom_sheet_more_information_nfc_antenna_animation.setVisibility(VIEW_GONE);
                bottom_sheet_more_information_antenna_location_label.setVisibility(VIEW_GONE);
                bottomSheetMoreInfo.show();
                break;
            case SCREEN_HOLD_BACK_EID:
                bottom_sheet_more_information_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PHONE_NOT_DETECTING_EID_INFO, Util_Strings.LOCAL_KEY_EID_PHONE_NOT_DETECTING_EID_INFO));
                bottom_sheet_more_information_image.setVisibility(VIEW_GONE);
                bottom_sheet_more_information_nfc_antenna_animation.setVisibility(VIEW_VISIBLE);
                bottom_sheet_more_information_antenna_location_label.setVisibility(VIEW_VISIBLE);
                bottom_sheet_more_information_antenna_location_label.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PHONE_NOT_DETECTING_EID_ANTENNA_LOCATIONS, Util_Strings.LOCAL_KEY_EID_PHONE_NOT_DETECTING_EID_ANTENNA_LOCATIONS));
                bottom_sheet_more_information_nfc_antenna_animation.setAnimation("nfc_antenna.json");
                bottom_sheet_more_information_nfc_antenna_animation.playAnimation();
                bottomSheetMoreInfo.show();
                break;
            case SCREEN_ENTER_CAN_CODE:
                eIDSdk.recordEvent(eIDSdk.EVENT_EID_CAN_SCREEN_WHERE_DO_I_FIND_CAN);
                bottom_sheet_more_information_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_WHERE_DO_I_FIND_CAN_INFO, Util_Strings.LOCAL_KEY_EID_WHERE_DO_I_FIND_CAN_INFO));
                bottom_sheet_more_information_image.setImageResource(R.drawable.can_code);
                bottom_sheet_more_information_nfc_antenna_animation.setVisibility(VIEW_GONE);
                bottom_sheet_more_information_antenna_location_label.setVisibility(VIEW_GONE);
                bottomSheetMoreInfo.show();
            default:
                break;
        }
    }

    private Spannable makeClickableSpan(Context context, CharSequence text, int color, String url, ClickableTextType clickableTextType) {

        Spannable spannable = new SpannableString(text);

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {

                switch (clickableTextType) {
                    case WHERE_IS_CAN:
                        moreInfo(context, SCREEN_ENTER_CAN_CODE);
                        break;
                    case IDNOW_HOME_PAGE:
                        if (url != null) {
                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                            try {
                                context.startActivity(browserIntent);
                            } catch (Exception e) {
                                Util_Log.e(LOGTAG, "Open link failed", e);
                                Toast.makeText(context, "Cannot open link!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
        };

        spannable.setSpan(clickableSpan, 0, spannable.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        spannable.setSpan(new ForegroundColorSpan(color), 0, spannable.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        return spannable;

    }

    private void setupPinBoxes() {
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher0 = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox0, pinBox1, main_continue_button, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher1 = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox1, pinBox2, main_continue_button, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher2 = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox2, pinBox3, main_continue_button, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher3 = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox3, pinBox4, main_continue_button, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher4_6digit = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox4, pinBox5, main_continue_button, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher4_5digit = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox4, null, main_continue_button, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);
        GenericTextWatcherWrapper.GenericTextWatcher pinBoxTextWatcher5 = new GenericTextWatcherWrapper.GenericTextWatcher(pinBox5, null, main_continue_button, pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5);

        pinBox0.addTextChangedListener(pinBoxTextWatcher0);
        pinBox1.addTextChangedListener(pinBoxTextWatcher1);
        pinBox2.addTextChangedListener(pinBoxTextWatcher2);
        pinBox3.addTextChangedListener(pinBoxTextWatcher3);
        pinBox5.addTextChangedListener(pinBoxTextWatcher5);
        if (currentScreen == SCREEN_ENTER_5_DIGIT_PIN) {
            pinBox4.removeTextChangedListener(pinBoxTextWatcher4_6digit);
            pinBox4.addTextChangedListener(pinBoxTextWatcher4_5digit);
        } else {
            pinBox4.removeTextChangedListener(pinBoxTextWatcher4_5digit);
            pinBox4.addTextChangedListener(pinBoxTextWatcher4_6digit);
        }

        pinBox0.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox0, null));
        pinBox1.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox1, pinBox0));
        pinBox2.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox2, pinBox1));
        pinBox3.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox3, pinBox2));
        pinBox4.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox4, pinBox3));
        if (currentScreen != SCREEN_ENTER_5_DIGIT_PIN) {
            pinBox5.setOnKeyListener(new GenericTextWatcherWrapper.GenericKeyEvent(pinBox5, pinBox4));
        }
    }

    private void loadUI() {
        goTo(SCREEN_ENTER_5_DIGIT_PIN);

        // set GIF
        if (Config.DARK_MODE_ENABLED_CUSTOMER) {
            sf_gif.setAnimation("animate_Card_Scan_Adnr.json");
            sf_gif.setRepeatCount(3);
            sf_gif.playAnimation();
        } else {
            sf_gif.setAnimation("animate_Card_Scan_Adnr.json");
            sf_gif.setRepeatCount(3);
            sf_gif.playAnimation();
        }

        bottom_sheet_continue_button.setBackgroundResource(R.drawable.rounded_background_grey);
        outcome_continue_button.setBackgroundResource(R.drawable.rounded_background_grey);

        main_continue_button.setEnabled(false);
        outcome_continue_button.setEnabled(true);
        bottom_sheet_continue_button.setEnabled(true);
        setProceedButtonBackgroundSelector(main_continue_button);
        setProceedButtonBackgroundSelector(outcome_continue_button);
        setProceedButtonBackgroundSelector(bottom_sheet_continue_button);
    }

    public void goToIdentIDPage() {

        Intent backPressedIntent = new Intent();
        backPressedIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        backPressedIntent.putExtra(Config.RESULT_DATA_ERROR, "User abort identification");
        backPressedIntent.putExtra(Config.RESULT_DATA_TRANSACTION_TOKEN, eIDSdk.getTransactionToken());
        fragmentActivity.setResult(Config.RESULT_CODE_CANCEL, fragmentActivity.getIntent());
        fragmentActivity.finish();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void assignClickListeners() {
        header.setCancelAction(() -> {
            Config.CANCEL_REASON = "EID_USER_CANCELLATION_TRANSPORT_PIN";
            switch (currentScreen) {
                case SCREEN_ENTER_5_DIGIT_PIN:
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_TRANPORT_PIN_SCREEN_CROSS);
                    break;
                case SCREEN_RE_ENTER_NEW_6_PIN:
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_PERSONAL_PIN_SCREEN_CROSS);
                    break;
                case SCREEN_ENTER_NEW_6_DIGIT_PIN:
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_REENTER_PERSONAL_PIN_SCREEN_CROSS);
                    break;
                case SCREEN_ENTER_CAN_CODE:
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_CAN_SCREEN_CROSS);
                    Config.CANCEL_REASON = "EID_USER_CANCELLATION_CAN_ENTRY";
                    break;
            }

            switch (currentOutcome) {
                case OUTCOME_SUCCESS_PIN_CHANGED:
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHANGE_SUCCESSFUL_CROSS);
                    Config.CANCEL_REASON = "EID_USER_CANCELLATION_SET_PIN_SUCCESS";
            }

            ((eIDActivity) context).getVisibleFragment();

            return Unit.INSTANCE;
        });

        show_pin.setOnTouchListener((v, event) -> {

            switch (currentScreen) {

                case SCREEN_ENTER_5_DIGIT_PIN:
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_TRANPORT_PIN_SCREEN_EYE);
                    break;
                case SCREEN_RE_ENTER_NEW_6_PIN:
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_PERSONAL_PIN_SCREEN_EYE);
                    break;
                case SCREEN_ENTER_NEW_6_DIGIT_PIN:
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_REENTER_PERSONAL_PIN_SCREEN_EYE);
                    break;
            }

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    showPIN();
                    show_pin.setImageResource(R.drawable.eye_invisible);
                    return true;
                case MotionEvent.ACTION_UP:
                    hidePIN();
                    show_pin.setImageResource(R.drawable.eye);
                    return false;
                default:
                    return false;
            }
        });

        main_continue_button.setOnClickListener(v -> {

            if (isPinComplete()) {

                switch (currentScreen) {

                    case SCREEN_ENTER_5_DIGIT_PIN:


                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_TRANPORT_PIN_SCREEN_CONTINUE);

                        ((eIDActivity) context).changeStepRESTCall("PIN_ENTRY");

                        storePinFrom(SCREEN_ENTER_5_DIGIT_PIN);
                        goTo(SCREEN_ENTER_NEW_6_DIGIT_PIN);
                        clearPinBoxes();
                        setupPinBoxes();
                        pin_error.setVisibility(VIEW_GONE);
                        break;
                    case SCREEN_ENTER_NEW_6_DIGIT_PIN:

                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_PERSONAL_PIN_SCREEN_CONTINUE);

                        ((eIDActivity) context).changeStepRESTCall("PIN_ENTRY");

                        storePinFrom(SCREEN_ENTER_NEW_6_DIGIT_PIN);
                        goTo(SCREEN_RE_ENTER_NEW_6_PIN);
                        clearPinBoxes();
                        setupPinBoxes();
                        break;
                    case SCREEN_RE_ENTER_NEW_6_PIN:

                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_REENTER_PERSONAL_PIN_SCREEN_CONTINUE);

                        ((eIDActivity) context).changeStepRESTCall("PIN_ENTRY");

                        storePinFrom(SCREEN_RE_ENTER_NEW_6_PIN);
                        setupPinBoxes();
                        if (newSixDigitPIN.equals(reEnterSixDigitPIN)) {
                            if (eIDSdk.isNetworkConnected(context)) {
                                if (!checkNFCenabled(context)) {
                                    dialog_nfc(context);
                                } else {
                                    pin_error.setVisibility(VIEW_GONE);
                                    goTo(SCREEN_HOLD_BACK_EID);
                                }
                            } else {
                                showNoConnectionDialog(context);
                            }
                        } else {
                            pin_error.setVisibility(View.VISIBLE);
                            pin_error.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ERROR_LABEL_PINS_DO_NOT_MATCH, Util_Strings.LOCAL_KEY_EID_ERROR_LABEL_PINS_DO_NOT_MATCH));
                            goTo(SCREEN_ENTER_NEW_6_DIGIT_PIN);
                            clearPinBoxes();
                        }
                        break;
                    case SCREEN_ENTER_CAN_CODE:

                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_CAN_SCREEN_CONTINUE);

                        storePinFrom(SCREEN_ENTER_CAN_CODE);
                        setCAN(CANcode);
                        if (thirdTimePinTyped) {
                            goTo(SCREEN_HOLD_BACK_EID);
                        } else {
                            goTo(SCREEN_ENTER_5_DIGIT_PIN);
                            clearPinBoxes();
                        }
                        break;
                }
            }

        });

        go_to_6_digit_pin_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_TRANPORT_PIN_SCREEN_SIX_DIGIT_PIN);

                Config.EID_PIN_CHOOSER = Util_Strings.SIX_DIGIT_PIN;

                Fragment_Capture_Desc fragment_capture_desc = new Fragment_Capture_Desc();
                ((eIDActivity) context).hideIntroFragment(Fragment_EnterPin_5_digit.this);
                ((eIDActivity) context).showIntroFragment(fragment_capture_desc);
            }
        });

        more_info_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moreInfo(context, null);
            }
        });

        bottom_sheet_continue_button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                bottomSheetDialog.dismiss();

                switch (currentBottomSheet) {
                    case BOTTOM_SHEET_PIN_CHANGED_SUCCESS:
                        displayOutcome(OUTCOME_SUCCESS_PIN_CHANGED);
                        break;
                    case BOTTOM_SHEET_CARD_BLOCKED:
                        displayOutcome(OUTCOME_ERROR_CARD_BLOCKED);
                        break;
                    case BOTTOM_SHEET_2_ATTEMPTS_LEFT:
                        displayOutcome(OUTCOME_WARNING_TWO_ATTEMPTS_LEFT);
                        break;
                    case BOTTOM_SHEET_1_ATTEMPT_LEFT:
                        displayOutcome(OUTCOME_WARNING_PIN_LAST_ATTEMPT);
                        break;
                    case BOTTOM_SHEET_WRONG_CAN:
                        goTo(SCREEN_ENTER_CAN_CODE);
                        clearPinBoxes();
                        break;
                    case BOTTOM_SHEET_NO_COMPATIBLE_ID:
                        Util.redirection(context, Config.CHOOSER_SCREEN);
                        break;
                    default:
                        break;
                }
            }
        });

        bottom_sheet_cancel_cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
                goTo(SCREEN_HOLD_BACK_EID);
            }
        });

        outcome_continue_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (currentOutcome) {
                    case OUTCOME_SUCCESS_PIN_CHANGED:

                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHANGE_SUCCESSFUL_CONTINUE);

                        Fragment_Capture_Desc fragment_capture_desc = new Fragment_Capture_Desc();

                        String fragmentTAG = Fragment_Capture_Desc.class.getSimpleName();
                        FragmentManager fragmentManager = fragmentActivity.getSupportFragmentManager();
                        FragmentTransaction ft = fragmentManager.beginTransaction();

                        ft.replace(R.id.activity_eid, fragment_capture_desc, fragmentTAG)
                                .commitAllowingStateLoss();

                        Config.EID_PIN_CHOOSER = Util_Strings.SIX_DIGIT_PIN;
                        break;
                    case OUTCOME_WARNING_TWO_ATTEMPTS_LEFT:
                        goTo(SCREEN_ENTER_5_DIGIT_PIN);
                        clearPinBoxes();
                        break;
                    case OUTCOME_WARNING_PIN_LAST_ATTEMPT:
                        goTo(SCREEN_ENTER_CAN_CODE);
                        break;
                    case OUTCOME_ERROR_CARD_BLOCKED:
                        Util.redirection(context, Config.CHOOSER_SCREEN);
                        break;
                    case OUTCOME_ERROR_CARD_DEACTIVATED:
                    case OUTCOME_ERROR_DEVICE_NOT_COMPATIBLE:
                    case OUTCOME_NONE:
                    default:
                        goToIdentIDPage();
                        break;
                }
            }
        });

        outcome_continue_button_secondary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentOutcome == OUTCOME_ERROR_CARD_BLOCKED) {
                    openAusweisApp();
                    displayOutcome(OUTCOME_CARD_UNBLOCK_ATTEMPT);
                    return;
                }
                Util.redirection(context, Config.CHOOSER_SCREEN);
            }
        });
    }

    private void openAusweisApp() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.governikus.ausweisapp2")));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.governikus.ausweisapp2")));
        }
    }

    private void showPIN() {

        eIDSdk.recordEvent(eIDSdk.EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_EYE);

        pinBox0.setTransformationMethod(null);
        pinBox1.setTransformationMethod(null);
        pinBox2.setTransformationMethod(null);
        pinBox3.setTransformationMethod(null);
        pinBox4.setTransformationMethod(null);
        pinBox5.setTransformationMethod(null);
    }

    private void hidePIN() {
        pinBox0.setTransformationMethod(PasswordTransformationMethod.getInstance());
        pinBox1.setTransformationMethod(PasswordTransformationMethod.getInstance());
        pinBox2.setTransformationMethod(PasswordTransformationMethod.getInstance());
        pinBox3.setTransformationMethod(PasswordTransformationMethod.getInstance());
        pinBox4.setTransformationMethod(PasswordTransformationMethod.getInstance());
        pinBox5.setTransformationMethod(PasswordTransformationMethod.getInstance());
    }

    private void enableMainContinueButton(boolean shouldEnable) {
        main_continue_button.setEnabled(shouldEnable);
        setProceedButtonBackgroundSelector(main_continue_button);
    }


    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_enter_pin_5_digit, container, false);

        pinChanger = AuthadaAuthenticationLibrary.INSTANCE.pinChanger();

        context = getContext();

        fragmentActivity = getActivity();

        bindViews(view);
        loadUI();
        assignClickListeners();
        setupPinBoxes();

        Objects.requireNonNull(getActivity()).getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        return view;
    }


    public void dialog_nfc(Context context) {

        Dialog dialog = new Dialog(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle));
        dialog.setTitle(R.string.nfc_required_title);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle));
        alertDialogBuilder.setTitle(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_NFC_REQUIRED_TITLE, Util_Strings.LOCAL_EID_NFC_REQUIRED_TITLE));
        alertDialogBuilder.setMessage(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_NFC_REQUIRED_MESSAGE, Util_Strings.LOCAL_EID_NFC_REQUIRED_MESSAGE));
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_NFC_REQUIRED_BUTTON_NEXT, Util_Strings.LOCAL_EID_NFC_REQUIRED_BUTTON_NEXT)
                , new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openNfcSettings();
                    }
                }).create().show();
    }

    public void openNfcSettings() {
        Intent intent = new Intent(Settings.ACTION_NFC_SETTINGS);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    public boolean checkNFCenabled(Context context) {

        NfcManager manager = (NfcManager) context.getSystemService(Context.NFC_SERVICE);
        NfcAdapter adapter = manager.getDefaultAdapter();
        return adapter != null && adapter.isEnabled();
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_EnterPin_5_digit.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_EnterPin_5_digit.class);
    }

    public boolean isPinComplete() {
        if (currentScreen == SCREEN_ENTER_5_DIGIT_PIN) {
            return !pinBox0.getText().toString().isEmpty() &&
                    !pinBox1.getText().toString().isEmpty() &&
                    !pinBox2.getText().toString().isEmpty() &&
                    !pinBox3.getText().toString().isEmpty() &&
                    !pinBox4.getText().toString().isEmpty();
        } else {
            return !pinBox0.getText().toString().isEmpty() &&
                    !pinBox1.getText().toString().isEmpty() &&
                    !pinBox2.getText().toString().isEmpty() &&
                    !pinBox3.getText().toString().isEmpty() &&
                    !pinBox4.getText().toString().isEmpty() &&
                    !pinBox5.getText().toString().isEmpty();
        }
    }

    public void hideScreenViews() {
        pin_description.setVisibility(VIEW_GONE);
        pin_box_layout.setVisibility(VIEW_INVISIBLE);
        pinBox5.setVisibility(VIEW_GONE);
//        pin_error.setVisibility(VIEW_GONE);
        sf_gif.setVisibility(VIEW_GONE);
        main_continue_button.setVisibility(VIEW_INVISIBLE);
        go_to_6_digit_pin_button.setVisibility(VIEW_INVISIBLE);
        more_info_button.setVisibility(VIEW_GONE);
        clearPinBoxes();
    }

    public void goTo(PinScreens screen) {

        currentScreen = screen;
        hideScreenViews();

        switch (screen) {
            case SCREEN_ENTER_5_DIGIT_PIN:

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_TRANPORT_PIN_SCREEN_SHOWN);
                eIDSdk.startEvent(eIDSdk.EVENT_EID_TRANPORT_PIN_SCREEN_TIME_SPENT);

                more_info_button.setVisibility(VIEW_VISIBLE);
                more_info_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_5_DIGIT_LEARN_MORE, Util_Strings.LOCAL_KEY_EID_PIN_5_DIGIT_LEARN_MORE));
                pin_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_5_DIGIT_TITLE, Util_Strings.LOCAL_KEY_EID_PIN_5_DIGIT_TITLE));
                pin_title.setVisibility(VIEW_VISIBLE);
                pin_description.setVisibility(VIEW_VISIBLE);
                pin_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_5_DIGIT_DESC, Util_Strings.LOCAL_KEY_EID_PIN_5_DIGIT_DESC));
                pin_error.setVisibility(VIEW_GONE);
                pin_box_layout.setVisibility(VIEW_VISIBLE);
                show_pin.setVisibility(VIEW_VISIBLE);
                outcome_layout.setVisibility(VIEW_INVISIBLE);
                main_continue_button.setVisibility(VIEW_VISIBLE);
                go_to_6_digit_pin_button.setVisibility(View.VISIBLE);
                showKeyBoard(this.getActivity(), pinBox0);
                break;
            case SCREEN_ENTER_NEW_6_DIGIT_PIN:

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_PERSONAL_PIN_SCREEN_SHOWN);
                eIDSdk.startEvent(eIDSdk.EVENT_EID_PERSONAL_PIN_SCREEN_TIME_SPENT);

                pin_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_CREATE_6_DIGIT_TITLE, Util_Strings.LOCAL_KEY_EID_PIN_CREATE_6_DIGIT_TITLE));
                pin_title.setVisibility(VIEW_VISIBLE);
                pinBox5.setVisibility(VIEW_VISIBLE);
                pin_description.setVisibility(VIEW_VISIBLE);
                pin_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_CREATE_6_DIGIT_DESCRIPTION, Util_Strings.LOCAL_KEY_EID_PIN_CREATE_6_DIGIT_DESCRIPTION));
                pin_box_layout.setVisibility(VIEW_VISIBLE);
                show_pin.setVisibility(VIEW_VISIBLE);
                main_continue_button.setVisibility(VIEW_VISIBLE);
                showKeyBoard(this.getActivity(), pinBox0);
                break;
            case SCREEN_RE_ENTER_NEW_6_PIN:

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_REENTER_PERSONAL_PIN_SCREEN_SHOWN);
                eIDSdk.startEvent(eIDSdk.EVENT_EID_REENTER_PERSONAL_PIN_SCREEN_TIME_SPENT);

                more_info_button.setVisibility(VIEW_GONE);
                pin_description.setVisibility(VIEW_GONE);
                pin_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_RE_ENTER_6_DIGIT_TITLE, Util_Strings.LOCAL_KEY_EID_PIN_RE_ENTER_6_DIGIT_TITLE));
                pin_title.setVisibility(VIEW_VISIBLE);
                pinBox5.setVisibility(VIEW_VISIBLE);
                pin_box_layout.setVisibility(VIEW_VISIBLE);
                pin_error.setVisibility(VIEW_GONE);
                show_pin.setVisibility(VIEW_VISIBLE);
                main_continue_button.setVisibility(VIEW_VISIBLE);
                showKeyBoard(this.getActivity(), pinBox0);
                break;
            case SCREEN_HOLD_BACK_EID:

                more_info_button.setVisibility(VIEW_VISIBLE);
                more_info_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_SCAN_EID_NOT_DETECTING, Util_Strings.LOCAL_KEY_EID_SCAN_EID_NOT_DETECTING));
                outcome_layout.setVisibility(View.INVISIBLE);
                hideKeyBoard(context, pinBox5);
                pin_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_SCAN_EID_TITLE, Util_Strings.LOCAL_KEY_EID_SCAN_EID_TITLE));
                pin_title.setVisibility(VIEW_VISIBLE);
                pin_error.setVisibility(VIEW_GONE);
                pin_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_SCAN_EID_DESC, Util_Strings.LOCAL_KEY_EID_SCAN_EID_DESC));
                pin_description.setVisibility(VIEW_VISIBLE);
                sf_gif.setVisibility(VIEW_VISIBLE);
                pinChange(fiveDigitTransportPIN, newSixDigitPIN);
                break;
            case SCREEN_ENTER_CAN_CODE:

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_CAN_SCREEN);
                eIDSdk.startEvent(eIDSdk.EVENT_EID_FRONT_CAPTURE_TIME_SPENT);

                more_info_button.setVisibility(VIEW_VISIBLE);
                more_info_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ENTER_CAN_CODE_WHERE_IS_IT, Util_Strings.LOCAL_KEY_EID_ENTER_CAN_CODE_WHERE_IS_IT));
                outcome_layout.setVisibility(VIEW_INVISIBLE);
                pin_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ENTER_CAN_CODE_TITLE, Util_Strings.LOCAL_KEY_EID_ENTER_CAN_CODE_TITLE));
                pin_title.setVisibility(VIEW_VISIBLE);
                pin_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ENTER_CAN_CODE_DESC, Util_Strings.LOCAL_KEY_EID_ENTER_CAN_CODE_DESC));
                pin_box_layout.setVisibility(View.VISIBLE);
                pin_description.setVisibility(VIEW_VISIBLE);
                pin_error.setVisibility(VIEW_GONE);
                pinBox5.setVisibility(View.VISIBLE);
                show_pin.setVisibility(VIEW_VISIBLE);
                main_continue_button.setVisibility(VIEW_VISIBLE);
                showKeyBoard(this.getActivity(), pinBox0);
                break;
            default:
                break;
        }
    }

    public void displayBottomSheet(BottomSheetType bottomSheet) {

        bottomSheetDialog.show();
        currentBottomSheet = bottomSheet;

        Runnable r;
        Handler h;

        switch (bottomSheet) {
            case BOTTOM_SHEET_READY_TO_SCAN:
                setBottomSheetWidgetsVisibility(VIEW_VISIBLE, VIEW_GONE, VIEW_VISIBLE, VIEW_VISIBLE, VIEW_INVISIBLE);
                bottom_sheet_image_sign.setAnimation("animate_loading_lock.json");
                bottom_sheet_image_sign.setRepeatCount(3);
                bottom_sheet_image_sign.playAnimation();
                bottom_sheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_EID_CARD_FOUND, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_EID_CARD_FOUND));
                break;
            case BOTTOM_SHEET_PIN_CHANGED_SUCCESS:
                setBottomSheetWidgetsVisibility(VIEW_INVISIBLE, VIEW_GONE, VIEW_VISIBLE, VIEW_VISIBLE, VIEW_INVISIBLE);
                bottom_sheet_image_sign.setAnimation("animate_checkmark.json");
                bottom_sheet_image_sign.playAnimation();
                bottom_sheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_PIN_CHANGE_SUCCESS, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_PIN_CHANGE_SUCCESS));
                r = () -> {
                    displayOutcome(OUTCOME_SUCCESS_PIN_CHANGED);
                    bottomSheetDialog.dismiss();
                };
                h = new Handler();
                h.postDelayed(r, DELAY_MILLIS);
                break;
            case BOTTOM_SHEET_2_ATTEMPTS_LEFT:
                setBottomSheetWidgetsVisibility(VIEW_INVISIBLE, VIEW_GONE, VIEW_VISIBLE, VIEW_VISIBLE, VIEW_INVISIBLE);
                bottom_sheet_image_sign.setAnimation("static_generic_error.json");
                bottom_sheet_image_sign.playAnimation();
                bottom_sheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_TWO_ATTEMPTS_LEFT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_TWO_ATTEMPTS_LEFT));
                r = () -> {
                    displayOutcome(OUTCOME_WARNING_TWO_ATTEMPTS_LEFT);
                    bottomSheetDialog.dismiss();
                };
                h = new Handler();
                h.postDelayed(r, DELAY_MILLIS);
                break;
            case BOTTOM_SHEET_1_ATTEMPT_LEFT:
                setBottomSheetWidgetsVisibility(VIEW_INVISIBLE, VIEW_GONE, VIEW_VISIBLE, VIEW_VISIBLE, VIEW_INVISIBLE);
                bottom_sheet_image_sign.setAnimation("static_generic_error.json");
                bottom_sheet_image_sign.playAnimation();
                bottom_sheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT));
                r = () -> {
                    displayOutcome(OUTCOME_WARNING_PIN_LAST_ATTEMPT);
                    bottomSheetDialog.dismiss();
                };
                h = new Handler();
                h.postDelayed(r, DELAY_MILLIS);
                break;
            case BOTTOM_SHEET_CARD_BLOCKED:
                setBottomSheetWidgetsVisibility(VIEW_INVISIBLE, VIEW_GONE, VIEW_VISIBLE, VIEW_VISIBLE, VIEW_INVISIBLE);
                bottom_sheet_image_sign.setAnimation("static_generic_error.json");
                bottom_sheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_CARD_BLOCKED, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_CARD_BLOCKED));
                r = () -> {
                    displayOutcome(OUTCOME_ERROR_CARD_BLOCKED);
                    bottomSheetDialog.dismiss();
                };
                h = new Handler();
                h.postDelayed(r, DELAY_MILLIS);
                break;
            case BOTTOM_SHEET_WRONG_CAN:
                setBottomSheetWidgetsVisibility(VIEW_INVISIBLE, VIEW_GONE, VIEW_VISIBLE, VIEW_VISIBLE, VIEW_INVISIBLE);
                bottom_sheet_image_sign.setAnimation("static_generic_error.json");
                bottom_sheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_CAN_PIN, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_CAN_PIN));
                r = () -> {
                    goTo(SCREEN_ENTER_CAN_CODE);
                    clearPinBoxes();
                    bottomSheetDialog.dismiss();
                };
                h = new Handler();
                h.postDelayed(r, DELAY_MILLIS);
                break;
        }
    }

    public void displayOutcome(ErrorCases outcome) {

        currentOutcome = outcome;

        switch (outcome) {
            case OUTCOME_SUCCESS_PIN_CHANGED:

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHANGE_SUCCESSFUL);
                eIDSdk.startEvent(eIDSdk.EVENT_EID_PIN_CHANGE_SUCCESSFUL_TIME_SPENT);

                toggleOutcomeStageVisibility(IS_VISIBLE);
                outcome_imageview.setAnimation("animate_checkmark.json");
                outcome_imageview.playAnimation();
                outcome_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_TITLE, Util_Strings.LOCAL_KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_TITLE));
                outcome_title.setVisibility(VIEW_VISIBLE);
                outcome_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_DESC, Util_Strings.LOCAL_KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_DESC));
                outcome_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_5_DIGIT_CONTINUE, Util_Strings.LOCAL_KEY_EID_5_DIGIT_CONTINUE));
                outcome_continue_button_secondary.setVisibility(VIEW_GONE);
                break;
            case OUTCOME_ERROR_CARD_BLOCKED:
                toggleOutcomeStageVisibility(IS_VISIBLE);
                outcome_imageview.setAnimation("static_passport_id_fail.json");
                outcome_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_CARD_BLOCKED_TITLE, Util_Strings.LOCAL_KEY_EID_OUTCOME_CARD_BLOCKED_TITLE));
                outcome_title.setVisibility(VIEW_VISIBLE);
                outcome_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_CARD_BLOCKED_DESC, Util_Strings.LOCAL_KEY_EID_OUTCOME_CARD_BLOCKED_DESC));
                outcome_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TRY_ANOTHER_METHOD, Util_Strings.LOCAL_KEY_EID_TRY_ANOTHER_METHOD));
                if (Config.STANDALONE_EID) outcome_continue_button.setVisibility(View.GONE);
                outcome_continue_button_secondary.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_5_DIGIT_OPEN_AUSWEIS_APP, Util_Strings.LOCAL_KEY_EID_5_DIGIT_OPEN_AUSWEIS_APP));
                outcome_continue_button_secondary.setVisibility(VIEW_VISIBLE);
                break;
            case OUTCOME_CARD_UNBLOCK_ATTEMPT:
                toggleOutcomeStageVisibility(IS_VISIBLE);
                outcome_imageview.setAnimation("static_passport_id_fail.json");
                outcome_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_CARD_BLOCKED_TITLE, Util_Strings.LOCAL_KEY_EID_OUTCOME_CARD_BLOCKED_TITLE));
                outcome_title.setVisibility(VIEW_VISIBLE);
                outcome_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_CARD_BLOCKED_DESC, Util_Strings.LOCAL_KEY_EID_OUTCOME_CARD_BLOCKED_DESC));
                outcome_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TRY_ANOTHER_METHOD, Util_Strings.LOCAL_KEY_EID_TRY_ANOTHER_METHOD));
                if (Config.STANDALONE_EID) outcome_continue_button.setVisibility(VIEW_GONE);
                outcome_continue_button_secondary.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TRY_AGAIN, Util_Strings.LOCAL_KEY_EID_TRY_AGAIN));
                outcome_continue_button_secondary.setVisibility(VIEW_VISIBLE);
                break;
            case OUTCOME_ERROR_DEVICE_NOT_COMPATIBLE:
                toggleOutcomeStageVisibility(IS_VISIBLE);
                outcome_imageview.setAnimation("static_generic_error.json");
                outcome_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_DEVICE_NOT_COMPATIBLE_TITLE, Util_Strings.LOCAL_KEY_EID_OUTCOME_DEVICE_NOT_COMPATIBLE_TITLE));
                outcome_title.setVisibility(VIEW_VISIBLE);
                outcome_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_DEVICE_NOT_COMPATIBLE_DESC, Util_Strings.LOCAL_KEY_EID_OUTCOME_DEVICE_NOT_COMPATIBLE_DESC));
                if (!Config.STANDALONE_EID) {
                    outcome_continue_button.setVisibility(VIEW_VISIBLE);
                    outcome_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_5_DIGIT_TRY_AGAIN, Util_Strings.LOCAL_KEY_EID_5_DIGIT_TRY_AGAIN));
                } else {
                    outcome_continue_button.setVisibility(VIEW_GONE);
                }
                outcome_continue_button_secondary.setVisibility(VIEW_GONE);
                break;
            case OUTCOME_NO_COMPATIBLE_ID:
                toggleOutcomeStageVisibility(IS_VISIBLE);
                outcome_imageview.setAnimation("static_generic_error.json");
                outcome_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_NO_COMPATIBLE_ID_TITLE, Util_Strings.LOCAL_KEY_EID_OUTCOME_NO_COMPATIBLE_ID_TITLE));
                outcome_title.setVisibility(VIEW_VISIBLE);
                outcome_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_NO_COMPATIBLE_ID_DESC, Util_Strings.LOCAL_KEY_EID_OUTCOME_NO_COMPATIBLE_ID_DESC));
                if (!Config.STANDALONE_EID) {
                    outcome_continue_button.setVisibility(VIEW_VISIBLE);
                    outcome_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_5_DIGIT_TRY_AGAIN, Util_Strings.LOCAL_KEY_EID_5_DIGIT_TRY_AGAIN));
                } else {
                    outcome_continue_button.setVisibility(VIEW_GONE);
                }
                outcome_continue_button_secondary.setVisibility(VIEW_GONE);
                break;
            case OUTCOME_ERROR_CARD_DEACTIVATED:
                toggleOutcomeStageVisibility(IS_VISIBLE);
                outcome_imageview.setAnimation("static_passport_id_fail.json");
                outcome_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_CARD_DEACTIVATED_TITLE, Util_Strings.LOCAL_KEY_EID_OUTCOME_CARD_DEACTIVATED_TITLE));
                outcome_title.setVisibility(VIEW_VISIBLE);
                outcome_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_CARD_DEACTIVATED_DESC, Util_Strings.LOCAL_KEY_EID_OUTCOME_CARD_DEACTIVATED_DESC));
                if (!Config.STANDALONE_EID) {
                    outcome_continue_button.setVisibility(VIEW_VISIBLE);
                    outcome_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_5_DIGIT_TRY_AGAIN, Util_Strings.LOCAL_KEY_EID_5_DIGIT_TRY_AGAIN));
                } else {
                    outcome_continue_button.setVisibility(VIEW_GONE);
                }
                outcome_continue_button_secondary.setVisibility(VIEW_GONE);
                break;
            case OUTCOME_WARNING_TWO_ATTEMPTS_LEFT:
                toggleOutcomeStageVisibility(IS_VISIBLE);
                outcome_imageview.setAnimation("static_generic_error.json");
                outcome_title.setVisibility(VIEW_GONE);
                outcome_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC, Util_Strings.LOCAL_KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC));
                outcome_continue_button.setVisibility(VIEW_VISIBLE);
                outcome_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_5_DIGIT_CONTINUE, Util_Strings.LOCAL_KEY_EID_5_DIGIT_CONTINUE));
                outcome_continue_button_secondary.setVisibility(VIEW_GONE);
                break;
            case OUTCOME_WARNING_PIN_LAST_ATTEMPT:
                toggleOutcomeStageVisibility(IS_VISIBLE);
                outcome_imageview.setAnimation("static_generic_error.json");
                outcome_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_INCORRECT_PIN_FINAL_ATTEMPT_TITLE, Util_Strings.LOCAL_KEY_EID_OUTCOME_INCORRECT_PIN_FINAL_ATTEMPT_TITLE));
                outcome_title.setVisibility(VIEW_VISIBLE);
                outcome_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_INCORRECT_PIN_FINAL_ATTEMPT_DESC, Util_Strings.LOCAL_KEY_EID_OUTCOME_INCORRECT_PIN_FINAL_ATTEMPT_DESC));
                outcome_description.append("\n");
                outcome_description.append(makeClickableSpan(context, Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ENTER_CAN_CODE_WHERE_IS_IT, Util_Strings.LOCAL_KEY_EID_ENTER_CAN_CODE_WHERE_IS_IT), getResources().getColor(R.color.text_color_link), "", ClickableTextType.WHERE_IS_CAN));
                outcome_description.setMovementMethod(LinkMovementMethod.getInstance());
                outcome_continue_button.setVisibility(VIEW_VISIBLE);
                outcome_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_5_DIGIT_CONTINUE, Util_Strings.LOCAL_KEY_EID_5_DIGIT_CONTINUE));
                outcome_continue_button_secondary.setVisibility(VIEW_GONE);
                break;
            default:
                break;
        }
    }

    public void setBottomSheetWidgetsVisibility(int CANCEL_CROSS_VISIBILITY, int TITLE_VISIBILITY, int DESCRIPTION_VISIBILITY, int IMAGE_VISIBILITY, int BUTTON_VISIBILITY) {
        bottom_sheet_cancel_cross.setVisibility(CANCEL_CROSS_VISIBILITY);
        bottom_sheet_title.setVisibility(TITLE_VISIBILITY);
        bottom_sheet_description.setVisibility(DESCRIPTION_VISIBILITY);
        bottom_sheet_image_sign.setVisibility(IMAGE_VISIBILITY);
        bottom_sheet_continue_button.setVisibility(BUTTON_VISIBILITY);
    }

    public void toggleOutcomeStageVisibility(boolean visible) {
        if (visible) {
            outcome_layout.setVisibility(VIEW_VISIBLE);
            pin_box_layout.setVisibility(VIEW_GONE);
            show_pin.setVisibility(VIEW_GONE);
            pin_title.setVisibility(VIEW_GONE);
            pin_error.setVisibility(VIEW_GONE);
            pin_description.setVisibility(VIEW_GONE);
            main_continue_button.setVisibility(VIEW_GONE);
            sf_gif.setVisibility(VIEW_GONE);
            more_info_button.setVisibility(View.GONE);
        } else {
            outcome_layout.setVisibility(VIEW_INVISIBLE);
            pin_box_layout.setVisibility(VIEW_VISIBLE);
            show_pin.setVisibility(VIEW_VISIBLE);
            pin_title.setVisibility(VIEW_VISIBLE);
            pin_error.setVisibility(VIEW_VISIBLE);
            pin_description.setVisibility(VIEW_VISIBLE);
            main_continue_button.setVisibility(VIEW_VISIBLE);
            sf_gif.setVisibility(VIEW_VISIBLE);
            more_info_button.setVisibility(View.VISIBLE);
        }
    }

    public void clearPinBoxes() {
        pinBox0.setText("");
        pinBox0.requestFocus();
        pinBox1.setText("");
        pinBox2.setText("");
        pinBox3.setText("");
        pinBox4.setText("");
        pinBox5.setText("");
    }

    public void clearStoredPins() {
        fiveDigitTransportPIN = "";
        reEnterSixDigitPIN = "";
        CANcode = "";
    }

    public void storePinFrom(PinScreens screen) {

        switch (screen) {
            case SCREEN_ENTER_5_DIGIT_PIN:
                fiveDigitTransportPIN = pinBox0.getText().toString()
                        + pinBox1.getText().toString()
                        + pinBox2.getText().toString()
                        + pinBox3.getText().toString()
                        + pinBox4.getText().toString();
                break;
            case SCREEN_ENTER_NEW_6_DIGIT_PIN:
                newSixDigitPIN = pinBox0.getText().toString()
                        + pinBox1.getText().toString()
                        + pinBox2.getText().toString()
                        + pinBox3.getText().toString()
                        + pinBox4.getText().toString()
                        + pinBox5.getText().toString();
                break;
            case SCREEN_RE_ENTER_NEW_6_PIN:
                reEnterSixDigitPIN = pinBox0.getText().toString()
                        + pinBox1.getText().toString()
                        + pinBox2.getText().toString()
                        + pinBox3.getText().toString()
                        + pinBox4.getText().toString()
                        + pinBox5.getText().toString();
                break;
            case SCREEN_ENTER_CAN_CODE:
                CANcode = pinBox0.getText().toString()
                        + pinBox1.getText().toString()
                        + pinBox2.getText().toString()
                        + pinBox3.getText().toString()
                        + pinBox4.getText().toString()
                        + pinBox5.getText().toString();
                break;
            default:
                break;
        }
    }

    private int[] stringToIntArray(String string) {

        int[] ints = new int[string.length()];
        int i = 0;

        char[] chars = string.toCharArray();
        for (char ch : chars) {
            ints[i++] = Character.getNumericValue(ch);
        }

        return ints;
    }

    private void setCAN(String CANCode) {
        Can can = new Can(stringToIntArray(CANCode));
        pinChanger.setCan(can);
    }

    private void pinChange(String transportPin, String newSixDigitPIN) {

        TPin tPin = new TPin(stringToIntArray(transportPin));
        Pin pin = new Pin(stringToIntArray(newSixDigitPIN));

        pinChanger.changeFiveDigitPin(tPin, pin, fragmentActivity, pinChangerCallback);
    }

}