package de.idnow.android.eid.network;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import de.idnow.android.eid.BuildConfig;
import de.idnow.android.eid.util.Util_Log;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class IDnowRestClient {

    private static IDnowRestClient m_instance;
    private static final String LOGTAG = "IDNOW_IDnowRestClient";
    private static String appPackageName = "unknown";
    private static String appVersionName = "unknown";

    private final Map<String, Network_RESTCalls> m_callsForEndpoint;

    public static IDnowRestClient getRestClient() {
        Util_Log.i(LOGTAG, " getRestClient()");
        if (m_instance == null) {
            m_instance = new IDnowRestClient();
        }

        return m_instance;
    }

    public Network_RESTCalls getCallsForEndpoint(String endpoint, Context context) {
        return getCallsForEndpoint(endpoint, context, -1, -1, -1);
    }

    public Network_RESTCalls getCallsForEndpoint(String endpoint, Context context, int readTimeout, int writeTimeout, int connectionTimeout) {
        if (m_callsForEndpoint.containsKey(endpoint)) {
            return m_callsForEndpoint.get(endpoint);
        } else {
            m_callsForEndpoint.put(endpoint, createClientCalls(endpoint, readTimeout, writeTimeout, connectionTimeout, context));
            return m_callsForEndpoint.get(endpoint);
        }
    }

    private IDnowRestClient() {
        m_callsForEndpoint = new HashMap();
    }

    private Network_RESTCalls createClientCalls(String endPoint, int readTimeout, int writeTimeout, int connectionTimeout, Context context) {
        resolvePackageInfo(context);
        Network_RESTCalls restCalls = null;

        Interceptor requestInterceptor = chain -> {
            Request.Builder request = chain.request().newBuilder();
            request.addHeader("Accept", "application/json");

            request.addHeader("X-Client-Version", String.format("%s.android-eid-%s", appPackageName, appVersionName));
            request.addHeader("X-Client-SDK-Version", String.format("%s.androidsdk-eid-%s", appPackageName, BuildConfig.CURRENT_VERSION));

            // Client secret needed to view eSign documents

            String currentSystemLanguage = "en";

            try {
                currentSystemLanguage = de.idnow.android.eid.eIDSdk.language == null || de.idnow.android.eid.eIDSdk.language.isEmpty() ? Locale.getDefault().getLanguage() : de.idnow.android.eid.eIDSdk.language;
            } catch (NullPointerException error) {
                Util_Log.e(LOGTAG, "Error getting current language", error);
            }
            Util_Log.i(LOGTAG, "SYSTEM-LANGUAGE: " + currentSystemLanguage);
            request.addHeader("Accept-Language", currentSystemLanguage);

            return chain.proceed(request.build());
        };

        try {
            int currentapiVersion = Build.VERSION.SDK_INT;
            if (readTimeout < 0) {
                readTimeout = 60;
            }

            if (writeTimeout < 0) {
                writeTimeout = 10;
            }

            if (connectionTimeout < 0) {
                connectionTimeout = 10;
            }

            if (currentapiVersion < Build.VERSION_CODES.LOLLIPOP) {
                readTimeout = 60;
                writeTimeout = 10;
                connectionTimeout = 10;
            }


            HttpLoggingInterceptor logInterceptor = new HttpLoggingInterceptor();
            logInterceptor.level(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient client = IDnowOkHttpFactory.Companion.createOkHttpClient(
                    readTimeout,
                    connectionTimeout,
                    writeTimeout,
                    requestInterceptor,
                    logInterceptor
            );

            Retrofit adapter = new Retrofit.Builder()
                    .baseUrl(endPoint)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

            restCalls = adapter.create(Network_RESTCalls.class);

        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Create api failed", e);
        }

        return restCalls;
    }

    private void resolvePackageInfo(Context context) {
        if (appPackageName.equals("unknown")) {
            String tmpAppPackageName = context.getPackageName();
            appPackageName = tmpAppPackageName.equals("de.idnow") ? "orangeapp" : tmpAppPackageName;
        }

        if (appVersionName.equals("unknown")) {
            try {
                PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                appVersionName = packageInfo.versionName;
            } catch (PackageManager.NameNotFoundException e) {
                Util_Log.e(LOGTAG, "Read app version failed", e);
            }
        }
    }
}
