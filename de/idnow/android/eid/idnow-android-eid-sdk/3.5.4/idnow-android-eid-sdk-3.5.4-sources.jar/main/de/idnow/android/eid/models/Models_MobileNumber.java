package de.idnow.android.eid.models;

public class Models_MobileNumber {

    String mobile;

    public Models_MobileNumber(String mobile) {
        this.mobile = mobile;
    }

    /**
     * @return the mobile
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * @param mobile the mobile to set
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

}