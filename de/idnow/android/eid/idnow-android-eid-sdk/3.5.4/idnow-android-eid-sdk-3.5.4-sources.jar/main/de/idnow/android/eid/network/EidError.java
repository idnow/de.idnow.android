package de.idnow.android.eid.network;

import java.io.InputStream;

import okhttp3.ResponseBody;

public class EidError {

    private final Response response;

    public Response getResponse() {
        return response;
    }

    private RetrofitErrorBody body;

    public RetrofitErrorBody getBody() {
        return body;
    }

    private String message;

    public String getMessage() {
        return message;
    }

    private String localizedMessage;

    public String getLocalizedMessage() {
        return localizedMessage;
    }

    private Throwable cause;

    public Throwable getCause() {
        return this.cause;
    }

    public EidError() {
        this.response = new Response();
    }

    public static EidError from(Throwable t) {
        EidError instance = new EidError();
        instance.message = t.getMessage();
        instance.localizedMessage = t.getLocalizedMessage();
        instance.cause = t;
        return instance;
    }

    public static <T> EidError from(retrofit2.Response<T> response) {
        EidError instance = new EidError();
        instance.response.status = response.code();

        RetrofitErrorBody body = RetrofitErrorBody.from(response.errorBody());
        instance.response.body = body;
        instance.body = body;

        return instance;
    }

    public static class Response {

        private RetrofitErrorBody body;

        public RetrofitErrorBody getBody() {
            return body;
        }

        public int status;

        public int getStatus() {
            return status;
        }
    }

    public static class RetrofitErrorBody {

        InputStream in;

        public InputStream in() {
            return in;
        }

        public static RetrofitErrorBody from(ResponseBody errorBody) {
            if (errorBody == null) {
                return null;
            }
            RetrofitErrorBody instance = new RetrofitErrorBody();
            instance.in = errorBody.byteStream();
            return instance;
        }
    }
}
