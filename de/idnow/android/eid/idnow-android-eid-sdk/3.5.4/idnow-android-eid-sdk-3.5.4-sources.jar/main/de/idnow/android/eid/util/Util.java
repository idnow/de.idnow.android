package de.idnow.android.eid.util;

import static de.idnow.android.eid.util.Util_Strings.KEY_VIDEO_IDENT_CAMERA_ERROR;
import static de.idnow.android.eid.util.Util_Strings.KEY_VIDEO_IDENT_CAMERA_ERROR_DESC;
import static de.idnow.android.eid.util.Util_Strings.KEY_VIDEO_IDENT_COMMON_CANCEL;
import static de.idnow.android.eid.util.Util_Strings.KEY_VIDEO_IDENT_COMMON_OK;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CAMERA_ERROR;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_CAMERA_ERROR_DESC;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_COMMON_CANCEL;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_KEY_VIDEO_IDENT_COMMON_OK;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.ColorFilter;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.SimpleLottieValueCallback;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Objects;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.idnow.android.eid.BuildConfig;
import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.models.Models_ClientInfo;
import de.idnow.android.eid.util.camera.CameraType;
import de.idnow.android.eid.util.helper.CameraHelper;


public class Util {

    private final static String LOGTAG = "IDNOW_Util";

    public final static String CLIENT_VERSION = "ANDROIDSDK," + BuildConfig.CURRENT_VERSION;
    public static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());


    public static void showRESTCallErrorDialog(final Context context, final int responseCode, Fragment fragment) {
        String errorDialogMessage;

        if (responseCode == 400) {
            errorDialogMessage = context.getResources().getString(R.string.rest_dialog_error_content_400);
        } else if (responseCode == 404) {
            errorDialogMessage = context.getResources().getString(R.string.rest_dialog_error_content_404);
        } else if (responseCode == 410) {
            errorDialogMessage = context.getResources().getString(R.string.rest_dialog_error_content_410);
        } else if (responseCode == 412) {
            errorDialogMessage = context.getResources().getString(R.string.rest_dialog_error_content_412);
        } else if (responseCode == 500) {
            errorDialogMessage = context.getResources().getString(R.string.rest_dialog_error_content_500);
        } else if (responseCode == 503) {
            errorDialogMessage = context.getResources().getString(R.string.rest_dialog_error_content_503);
        } else {
            errorDialogMessage = context.getResources().getString(R.string.rest_dialog_error_content_429);
        }

        int style;

        if (!Config.DARK_MODE_ENABLED_CUSTOMER) {
            style = R.style.IDnowAlertDialogStyleForcedDark;
        } else {
            style = R.style.IDnowAlertDialogStyle;
        }

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, style));

        alertDialogBuilder.setCancelable(false);

        alertDialogBuilder.setMessage(errorDialogMessage)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        ((eIDActivity) context).errorEIDscreen(fragment, Config.CALLBACK_IDENT_FAILED);

                    }
                });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        if (!((Activity) context).isFinishing()) {
            // show it
            alertDialog.show();
        }
    }

    public static void showNoConnectionDialog(final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle));
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setMessage(context.getResources().getString(de.idnow.android.eid.R.string.network_connection_failure))
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        Intent noConnectionIntent = new Intent();
                        noConnectionIntent.putExtra(Config.RESULT_DATA_ERROR, "No internet connection");
                        noConnectionIntent.putExtra(Config.RESULT_DATA_TRANSACTION_TOKEN, eIDSdk.getTransactionToken());
                        ((Activity) context).setResult(Config.RESULT_CODE_FAILED, noConnectionIntent);
                        ((Activity) context).finish();

                    }
                });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        if (!((Activity) context).isFinishing()) {
            // show it
            alertDialog.show();
        }
    }

    public static void showNotGermanIDDialog(final Context context, FragmentActivity activity) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle));

        alertDialogBuilder.setCancelable(false);

        eIDSdk.recordEvent(eIDSdk.EVENT_EID_POPUP_SCREEN);
        eIDSdk.startEvent(eIDSdk.EVENT_EID_POPUP_TIIME_SPENT);


        alertDialogBuilder.setTitle(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DIALOG_NOT_EID_TITLE, Util_Strings.LOCAL_KEY_EID_DIALOG_NOT_EID_TITLE))
                .setMessage(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DIALOG_NOT_EID_DESC, Util_Strings.LOCAL_KEY_EID_DIALOG_NOT_EID_DESC))
                .setPositiveButton(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DIALOG_NOT_EID_CONTINUE, Util_Strings.LOCAL_KEY_EID_DIALOG_NOT_EID_CONTINUE), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();

                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_POPUP_CONTINUE);


                    }
                })
                .setNegativeButton(Config.STANDALONE_EID ?
                        Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_QUIT, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_QUIT) :
                        Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DIALOG_NOT_EID_TRY_ANOTHER, Util_Strings.LOCAL_KEY_EID_DIALOG_NOT_EID_TRY_ANOTHER), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        if (Config.STANDALONE_EID) {

                            Intent backPressedIntent = new Intent();
                            backPressedIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            backPressedIntent.putExtra(Config.RESULT_DATA_ERROR, "User abort identification");
                            backPressedIntent.putExtra(Config.RESULT_DATA_TRANSACTION_TOKEN, eIDSdk.getTransactionToken());
                            Objects.requireNonNull(activity).setResult(Config.RESULT_CODE_CANCEL, activity.getIntent());
                            activity.finish();


                        } else {

                            Intent intent = new Intent();
                            eIDSdk.recordEvent(eIDSdk.EVENT_EID_POPUP_TRY_OTHER);

                            activity.setResult(Config.CHOOSER_SCREEN, intent);

                            activity.finish();
                        }
                    }
                });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        if (!((Activity) context).isFinishing()) {
            // show it
            alertDialog.show();
        }
    }


    public static void setColorLottieAnimation(int colorLottieAnimation, LottieAnimationView viewLottieAnimation, String keyPath) {
        viewLottieAnimation.addValueCallback(
                new KeyPath("**", keyPath),
                LottieProperty.COLOR_FILTER,
                new SimpleLottieValueCallback<ColorFilter>() {
                    @SuppressLint("ResourceAsColor")
                    @Override
                    public ColorFilter getValue(LottieFrameInfo<ColorFilter> frameInfo) {
                        return new PorterDuffColorFilter(colorLottieAnimation, PorterDuff.Mode.SRC_ATOP);
                    }
                }
        );

        viewLottieAnimation.playAnimation();
    }

    public static void handleServerselection(String token) {
        if (de.idnow.android.eid.eIDSdk.getEnvironment() != null) {
            Config.CURRENT_SERVER = de.idnow.android.eid.eIDSdk.getEnvironment();
        } else {
            // The Environment wasn't set by the host app. Use token to determine.
            if (token.toUpperCase().startsWith("DEV")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DEV;
                Util_Log.i(LOGTAG, "select dev server");
            } else if (token.toUpperCase().startsWith("DV2")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DEV2;
                Util_Log.i(LOGTAG, "select dev2 server");
            } else if (token.toUpperCase().startsWith("DV3")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV3;
                Util_Log.i(LOGTAG, "select dev3 server");
            } else if (token.toUpperCase().startsWith("DV4")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV4;
                Util_Log.i(LOGTAG, "select dev4 server");
            } else if (token.toUpperCase().startsWith("DV5")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV5;
                Util_Log.i(LOGTAG, "select dev5 server");
            } else if (token.toUpperCase().startsWith("DV6")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV6;
                Util_Log.i(LOGTAG, "select dev6 server");
            } else if (token.toUpperCase().startsWith("DV7")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV7;
                Util_Log.i(LOGTAG, "select dev7 server");
            } else if (token.toUpperCase().startsWith("DV8")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV8;
                Util_Log.i(LOGTAG, "select dev8 server");
            } else if (token.toUpperCase().startsWith("DV9")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV9;
                Util_Log.i(LOGTAG, "select dev9 server");
            } else if (token.toUpperCase().startsWith("DV10")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV10;
                Util_Log.i(LOGTAG, "select dev10 server");
            } else if (token.toUpperCase().startsWith("DV11")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV11;
                Util_Log.i(LOGTAG, "select dev11 server");
            } else if (token.toUpperCase().startsWith("DV12")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV12;
                Util_Log.i(LOGTAG, "select dev12 server");
            } else if (token.toUpperCase().startsWith("DV13")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV13;
                Util_Log.i(LOGTAG, "select dev13 server");
            } else if (token.toUpperCase().startsWith("DV14")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV14;
                Util_Log.i(LOGTAG, "select dev14 server");
            } else if (token.toUpperCase().startsWith("DV15")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV15;
                Util_Log.i(LOGTAG, "select dev15 server");
            } else if (token.toUpperCase().startsWith("DV16")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV16;
                Util_Log.i(LOGTAG, "select dev16 server");
            } else if (token.toUpperCase().startsWith("DV17")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV17;
                Util_Log.i(LOGTAG, "select dev17 server");
            } else if (token.toUpperCase().startsWith("DV18")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV18;
                Util_Log.i(LOGTAG, "select dev18 server");
            } else if (token.toUpperCase().startsWith("DV19")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV19;
                Util_Log.i(LOGTAG, "select dev19 server");
            } else if (token.toUpperCase().startsWith("DV20")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV20;
                Util_Log.i(LOGTAG, "select dev20 server");
            } else if (token.toUpperCase().startsWith("DV0")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV0;
                Util_Log.i(LOGTAG, "select dev0 server");
            } else if (token.toUpperCase().startsWith("DV1")) {
                Config.CURRENT_SERVER = eIDSdk.Server.DV1;
                Util_Log.i(LOGTAG, "select dev1 server");
            } else if (token.toUpperCase().startsWith("TST")) {
                Config.CURRENT_SERVER = eIDSdk.Server.TEST;
                Util_Log.i(LOGTAG, "select test server");
            } else if (token.toUpperCase().startsWith("TS1")) {
                Config.CURRENT_SERVER = eIDSdk.Server.TEST1;
                Util_Log.i(LOGTAG, "select test1 server");
            } else if (token.toUpperCase().startsWith("TS2")) {
                Config.CURRENT_SERVER = eIDSdk.Server.TEST2;
                Util_Log.i(LOGTAG, "select test2 server");
            } else if (token.toUpperCase().startsWith("TS3")) {
                Config.CURRENT_SERVER = eIDSdk.Server.TEST3;
                Util_Log.i(LOGTAG, "select test3 server");
            } else if (token.toUpperCase().startsWith("SG1")) {
                Config.CURRENT_SERVER = eIDSdk.Server.SG1;
                Util_Log.i(LOGTAG, "select staging1 server");
            } else if (token.toUpperCase().startsWith("INT")) {
                Config.CURRENT_SERVER = eIDSdk.Server.INT;
                Util_Log.i(LOGTAG, "select intrum server");
            } else {
                Config.CURRENT_SERVER = eIDSdk.Server.LIVE;
                Util_Log.i(LOGTAG, "select live server");
            }
        }
    }

    public static void showMessageOK(Context context, String message, DialogInterface.OnClickListener okListener) {

        int style;

        if (!Config.DARK_MODE_ENABLED_CUSTOMER) {
            style = R.style.IDnowAlertDialogStyleForcedDark;
        } else {
            style = R.style.IDnowAlertDialogStyle;
        }

        AlertDialog alertDialog = new AlertDialog.Builder(new ContextThemeWrapper(context, style))
                .setMessage(message)
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_CANCEL, LOCAL_KEY_VIDEO_IDENT_COMMON_CANCEL), okListener).create();

        Util.showBrandedDialog(alertDialog, null);
    }

    public static void showMessageOKCancel(final Context context, String message, DialogInterface.OnClickListener okListener) {
        AlertDialog alertDialog = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle))
                .setMessage(message)
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), okListener)
                .setCancelable(false)
                .setNegativeButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_CANCEL, LOCAL_KEY_VIDEO_IDENT_COMMON_CANCEL), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Intent backPressedIntent = new Intent();
                        backPressedIntent.putExtra(eIDSdk.RESULT_DATA_ERROR, context.getString(eIDSdk.MESSAGE_USER_CANCELED));
                        backPressedIntent.putExtra(eIDSdk.RESULT_DATA_TRANSACTION_TOKEN, eIDSdk.getTransactionToken());
                        if (context instanceof Activity) {
                            Activity activity = (Activity) context;
                            activity.setResult(eIDSdk.RESULT_CODE_CANCEL, backPressedIntent);
                            activity.finish();
                        }
                    }
                }).create();

        Util.showBrandedDialog(alertDialog, null);
    }

    public static AlertDialog showBrandedDialog(AlertDialog dialog) {
        Context context = dialog.getContext();
        Drawable dialogIconDrawable = null;
        if (eIDSdk.showDialogsWithIcon()) {
            dialogIconDrawable = context.getResources().getDrawable(R.drawable.ic_idnow);
        }
        return showBrandedDialog(dialog, dialogIconDrawable);
    }


    public static AlertDialog showBrandedDialog(AlertDialog dialog, Drawable dialogIconDrawable) {
        if (dialog == null) {
            return null;
        }

        Context context = dialog.getContext();
        Resources resources = context.getResources();

        if (dialogIconDrawable != null) {
            dialog.setIcon(dialogIconDrawable);
        }

        // there are things that must be applied before show() method: e.g. setting icon;
        // and there are things that must be applied afterwards: e.g. color styling

        if (context instanceof Activity) {
            if (!((Activity) context).isFinishing()) {
                dialog.show();
            }
        } else {
            try {
                dialog.show();
            } catch (Exception e) {
                Util_Log.e(LOGTAG, "Show branded dialog failed", e);
                if (e instanceof WindowManager.BadTokenException) {
                    // logExternally(context, "BadTokenException @ showBrandedDialog : " + e, LogEventTypeEnum.ERROR.get());
                } else {
                    //  logExternally(context, "showBrandedDialog : " + e, LogEventTypeEnum.ERROR.get());
                }
            }
        }

        if (resources.getBoolean(R.bool.customize_dialog_title_color)) {
            try {
                // change title text color
                int titleTextColor = resources.getColor(R.color.dialog_title);
                int alertTitleId = resources.getIdentifier("alertTitle", "id", "android");
                TextView alertTitle = dialog.getWindow().getDecorView().findViewById(alertTitleId);
                alertTitle.setTextColor(titleTextColor);
            } catch (Exception ex) {
                Util_Log.e(LOGTAG, "Change title text color for branded dialog failed", ex);
            }
        }

        if (resources.getBoolean(R.bool.customize_dialog_divider_color)) {
            try {
                int dividerColor = resources.getColor(R.color.dialog_divider);
                int titleDividerId = resources.getIdentifier("titleDivider", "id", "android");
                View titleDivider = dialog.getWindow().getDecorView().findViewById(titleDividerId);
                titleDivider.setBackgroundColor(dividerColor);
            } catch (Exception ex) {
                Util_Log.e(LOGTAG, "Change divider color for branded dialog failed", ex);
            }
        }
        return dialog;
    }

    public static Models_ClientInfo getClientInfo(Context context) {
        String language = "en";

        try {
            String sdkLanguage = eIDSdk.language;
            if (sdkLanguage != null && !sdkLanguage.isEmpty()) {
                language = sdkLanguage;
            } else {
                language = context.getResources()
                        .getConfiguration()
                        .locale.getLanguage();
            }
        } catch (NullPointerException e) {
            Util_Log.e(LOGTAG, "Resolve language failed", e);
        }
        String locale = context.getResources().getConfiguration().locale.toString();

        Display display = ((Activity) context).getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        String screenWidth = String.valueOf(size.x);
        String screenHeight = String.valueOf(size.y);

        boolean frontCameraAvailable = CameraHelper.INSTANCE.hasCamera(CameraType.FRONT);
        boolean backCameraAvailable = CameraHelper.INSTANCE.hasCamera(CameraType.BACK);
        String frontCameraWidth = frontCameraAvailable ? "640" : null;
        String frontCameraHeight = frontCameraAvailable ? "480" : null;
        String backCameraWidth = backCameraAvailable ? "640" : null;
        String backCameraHeight = backCameraAvailable ? "480" : null;
        boolean flashLight = CameraHelper.INSTANCE.hasTorch();

        String osVersion = String.valueOf(android.os.Build.VERSION.SDK_INT);
        String deviceInfo = android.os.Build.DEVICE;
        String timezone = TimeZone.getDefault().getID();
        String os = "Android";
        String sdkVersion = BuildConfig.CURRENT_VERSION;
        String mobileAppVersion = resolveMobileAppVersion(context);
        String clientVersion = resolveClientVersion(context);
        String customerApp = Config.APP_ID.equals("de.idnow") ? "IDnow" : eIDSdk.getCompanyId();

        return new Models_ClientInfo(language, locale, screenWidth, screenHeight, clientVersion, frontCameraWidth, frontCameraHeight, backCameraWidth, backCameraHeight, flashLight, eIDSdk.getConnectionType(), osVersion, deviceInfo, timezone, os, sdkVersion, customerApp, mobileAppVersion);
    }

    private static String resolveMobileAppVersion(Context context) {
        String tmpAppPackageName = context.getPackageName();
        String appPackageName = tmpAppPackageName.equals("de.idnow") ? "orangeapp" : tmpAppPackageName;

        String appVersionName = "";
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            appVersionName = packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            Util_Log.e(LOGTAG, "Failed to read app version", e);
        }

        return String.format("%s.android-eid-%s", appPackageName, appVersionName);
    }

    private static String resolveClientVersion(Context context) {
        String tmpAppPackageName = context.getPackageName();
        String appPackageName = tmpAppPackageName.equals("de.idnow") ? "orangeapp" : tmpAppPackageName;

        return String.format("%s.androidsdk-eid-%s", appPackageName, BuildConfig.CURRENT_VERSION);
    }

    public static void showCameraFailedErrorDialogVI(final Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle))
                .setTitle(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CAMERA_ERROR, LOCAL_KEY_VIDEO_IDENT_CAMERA_ERROR))
                .setMessage(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_CAMERA_ERROR_DESC, LOCAL_KEY_VIDEO_IDENT_CAMERA_ERROR_DESC))
                .setPositiveButton(Util_Strings.getStringWithDefault(context, KEY_VIDEO_IDENT_COMMON_OK, LOCAL_KEY_VIDEO_IDENT_COMMON_OK), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        Intent noConnectionIntent = new Intent();
                        noConnectionIntent.putExtra(eIDSdk.RESULT_DATA_ERROR, context.getResources().getString(R.string.dialog_error_camera_content));
                        noConnectionIntent.putExtra(eIDSdk.RESULT_DATA_TRANSACTION_TOKEN, eIDSdk.getTransactionToken());
                        ((Activity) context).setResult(eIDSdk.RESULT_CODE_FAILED, noConnectionIntent);
                        ((eIDActivity) context).finish();
                    }

                });

        // create alert dialog
        showAlertDialogIfActivityIsInTheProcessOfFinishing(context, alertDialogBuilder.create());
    }

    private static void showAlertDialogIfActivityIsInTheProcessOfFinishing(final Context context, AlertDialog alertDialog) {
        if (context instanceof Activity && !((Activity) context).isFinishing()) {
            Util.showBrandedDialog(alertDialog);
        }
    }

    public static void setProceedButtonBackgroundSelector(View view) {
        Drawable buttonDrawable_activate = view.getResources().getDrawable(R.drawable.rounded_background_orange);
        Drawable buDrawable_deactivated = view.getResources().getDrawable(R.drawable.rounded_background_grey);
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(new int[]{android.R.attr.state_pressed}, buttonDrawable_activate);
        stateListDrawable.addState(new int[]{android.R.attr.state_enabled}, buttonDrawable_activate);
        stateListDrawable.addState(new int[]{-android.R.attr.state_enabled}, buDrawable_deactivated);
        view.setBackgroundDrawable(stateListDrawable);
    }

    public static void showKeyBoard(Context context, View view) {
        if (context != null) {
            InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(view, InputMethodManager.SHOW_FORCED);
        }
    }

    public static void hideKeyBoard(Context context, View view) {
        if (context != null) {
            InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public static void quitDialog(Context context, Fragment fragment) {

        Dialog quitDialog = new Dialog(context);

        quitDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        quitDialog.setContentView(R.layout.quit_pin_change_dialog);

        loadQuitDialog(quitDialog, context, fragment);

        int width = ViewGroup.LayoutParams.WRAP_CONTENT;
        int height = ViewGroup.LayoutParams.WRAP_CONTENT;
        quitDialog.getWindow().setLayout(width, height);
        quitDialog.setCancelable(false);
        quitDialog.show();

    }

    public static void loadQuitDialog(Dialog quitDialog, Context context, Fragment fragment) {

        TextView quit_pin_change_title = quitDialog.findViewById(R.id.quit_pin_change_title);
        TextView quit_pin_change_description = quitDialog.findViewById(R.id.quit_pin_change_description);
        TextView quit_pin_change_quit_button = quitDialog.findViewById(R.id.quit_pin_change_quit_button);
        TextView quit_pin_change_continue_button = quitDialog.findViewById(R.id.quit_pin_change_continue_button);
        TextView quit_pin_change_try_another_method_button = quitDialog.findViewById(R.id.quit_pin_change_try_another_method_button);

        quit_pin_change_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_TITLE, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_TITLE));
        quit_pin_change_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_DESCRIPTION, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_DESCRIPTION));
        quit_pin_change_quit_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_QUIT, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_QUIT));
        quit_pin_change_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_CONTINUE, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_CONTINUE));
        quit_pin_change_try_another_method_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_TRY_ANOTHER_METHOD, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_TRY_ANOTHER_METHOD));

        if (Config.STANDALONE_EID) {
            quit_pin_change_try_another_method_button.setVisibility(View.GONE);
            quit_pin_change_description.setVisibility(View.GONE);
        }

        quit_pin_change_quit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quitDialog.dismiss();
                ((eIDActivity) context).identificationCanceledRESTCall(fragment, Config.CANCEL_REASON);
            }
        });

        quit_pin_change_try_another_method_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quitDialog.dismiss();

                redirection(context, Config.CHOOSER_SCREEN);
            }
        });
        quit_pin_change_continue_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quitDialog.dismiss();
            }
        });

    }

    public static void redirection(Context context, int resultCode) {
        Intent backPressedIntent = new Intent();
        backPressedIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        backPressedIntent.putExtra(Config.RESULT_DATA_ERROR, "User abort identification");
        backPressedIntent.putExtra(Config.RESULT_DATA_TRANSACTION_TOKEN, eIDSdk.getTransactionToken());
        ((Activity) context).setResult(resultCode, backPressedIntent);
        ((eIDActivity) context).finish();
    }

    public static boolean isPhoneValid(String phoneNo) {
        String country = Locale.getDefault().getCountry();
        if (Config.VERIFY_PHONE_NO) {
            PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
            try {
                Phonenumber.PhoneNumber phonenumber = phoneNumberUtil.parse(phoneNo, country);

                phonenumber.getCountryCode();
                return phoneNumberUtil.isValidNumber(phonenumber);
            } catch (NumberParseException e) {
                Util_Log.e(LOGTAG, "Validate phone number failed", e);
                return false;
            }
        } else {
            // remove whitespaces and special characters
            phoneNo = phoneNo.replace(" ", "");

            String expression = "^[0-9-+]{9,15}$";
            CharSequence inputStr = phoneNo;
            Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(inputStr);
            return (matcher.matches());
        }
    }

    public static void setCheckMark(ImageView imageView, boolean isChecked) {
    }

    public static void setTintedIcon(ImageView imageView, int iconResource, int colorResource) {
        Context context = imageView.getContext();
        Drawable checkedIcon = context.getResources().getDrawable(iconResource);
        checkedIcon.setColorFilter(context.getResources().getColor(colorResource), PorterDuff.Mode.SRC_IN);
        imageView.setImageDrawable(checkedIcon);
    }

    public static String formatValidE164(String number, Locale locale) {
        PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
        String e164 = null;

        try {
            e164 = phoneNumberUtil.format(phoneNumberUtil.parse(number, Locale.getDefault().getCountry()), PhoneNumberUtil.PhoneNumberFormat.E164);
        } catch (NumberParseException e) {
            Util_Log.e(LOGTAG, "Format phone number failed", e);
        }

        return e164;
    }

    public enum BottomSheetType {
        BOTTOM_SHEET_READY_TO_SCAN,
        BOTTOM_SHEET_CARD_DETECTION,
        BOTTOM_SHEET_CARD_PAUSE,

        ON_SUCCESS_ESTABLISH_CONNECTION,

        ON_SUCCESS_TRANSFER_ENCRYPTED_DATA,

        ON_SUCCESS_CHECK_CERTIFICATION,

        ON_SUCCESS_DEFAULT,

        BOTTOM_SHEET_LOST_CONNECTION,
        BOTTOM_SHEET_INCORRECT_CAN_PIN,
        BOTTOM_SHEET_INCORRECT_PIN_1,
        BOTTOM_SHEET_INCORRECT_PIN_2,
        BOTTOM_SHEET_CARD_BLOCKED,
        BOTTOM_SHEET_VERIFICATION_COMPLETED,
        BOTTOM_SHEET_CLOSED,
        ON_EID_NOT_ATTACHED,
        ON_SUCCESS_PIN,
        ON_EID_SUCCESS_SENDING_PIN,
        ON_CONNECTION_TIMEOUT_START,
        ON_PROCESS_TERMINATED_START,
        ON_EID_CARD_LOST,
        ON_CAN_WRONG,
        ON_SUCCESS_CHANGE_PIN,
        ON_WRONG_PIN_TRIES_LAST,
        ON_WRONG_PIN_TRIES_2,
        ON_WRONG_PIN_TRIES_1,
        ON_AUTHENTIFCATION_PROGRESS,
        ON_ADDITIONAL_DATA_REQUIRED,
        ON_CONNECTION_TIMEOUT_PIN,
        ON_EID_CARD_CHECK_FAILED,
        ON_PROCESS_TERMINATED_PIN,
        ON_EID_FAILURE_SEDNDING_PIN,
        ON_CARD_BLOCKED,
        BOTTOM_SHEET_REDIRECT,
        ON_PROCESS_TERMINATED
    }

    // PIN screen case
    public enum PinScreens {
        SCREEN_ENTER_5_DIGIT_PIN,
        SCREEN_ENTER_NEW_6_DIGIT_PIN,
        SCREEN_RE_ENTER_NEW_6_PIN,
        SCREEN_HOLD_BACK_EID,
        SCREEN_ENTER_CAN_CODE,
        SCREEN_ENTER_PERSONAL_6_DIGIT_PIN
    }

    public static void openUrlInNewBrowserTask(@NonNull Context context, @NonNull String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        context.startActivity(intent);
    }


    public static int getPxFromDp(Context context, int dp) {
        Resources r = context.getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }
}
