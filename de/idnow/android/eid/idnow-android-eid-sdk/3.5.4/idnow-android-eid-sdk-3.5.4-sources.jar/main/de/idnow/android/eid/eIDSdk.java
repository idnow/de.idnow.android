package de.idnow.android.eid;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import de.idnow.android.eid.Authada.AuthadaAuthenticationWrapper;
import de.idnow.android.eid.models.ModelCustomLog;
import de.idnow.android.eid.util.Util_Log;
import de.idnow.insights.DeviceId;
import de.idnow.insights.Insights;
import de.idnow.insights.InsightsConfig;

public class eIDSdk {

    private static eIDSdk instance = null;

    private Intent startEIDIntent;

    private static boolean LOGGING_ENABLED = true;

    private WeakReference<Activity> callingActivity;

    public WeakReference<Activity> getCallingActivity() {
        return callingActivity;
    }

    private Context appContext;

    private static Server environment = null;

    public static String language;

    private static final String LOGTAG = "SDK class of EID";

    private static boolean allowHttpConnections = false;
    private static boolean allowInvalidCertificates = false;
    private static String websocketHost = "";
    private static String apiHost = "";
    private static String webHost = "";
    private static String videoHost = "";
    private static String stunHost = "";
    private static Integer stunPort = 3478;

    public static final String RESULT_DATA_ERROR = "resultDataError";
    public static final int MESSAGE_USER_CANCELED = R.string.message_user_canceled;
    public static final String RESULT_DATA_TRANSACTION_TOKEN = "resultDataTransactionToken";
    public static final int RESULT_CODE_CANCEL = 3;
    public static final int RESULT_CODE_FAILED = 1;

    private static final String SHOW_DIALOGS_WITH_ICON_KEY = "showDialogsWithIcon";

    private static Boolean showDialogsWithIcon = true;
    public static final String SHARED_PREFS_NAME = "de.idnow";
    private static final String SHOW_TNC_EID_KEY = "showTNCeID";

    private static Boolean showTermsConditionsEID = null;

    public void resetStaticValues() {

        Config.IDNOW_ENDPOINT = "";

        Config.TRANSACTION_TOKEN = "";

        Config.COMPANY_ID = "";

        Config.ATTACH_EID = false;

        Config.EID_VID_TOKEN_FINISEHD = false;

        Config.EID_MOBILE_TOKEN = "";
        Config.EID_SESSION_TOKEN = "";
        Config.EID_SIGNATURE = "";

        Config.EID_EXPIRATION_DATE = "";
        Config.EID_EFFECTIVE_DATE = "";


        Config.EID_WRONG_PIN_TRIES = "";
        Config.EID_CAN_REQUIRED_1 = false;
        Config.EID_CAN_REQUIRED_2 = false;

        Config.EID_CANCEL_IDENT = false;
        Config.EID_ERROR_CODE = "";
        Config.EID_CAN = "";

        Config.CARD_ATTACHED = false;

        Config.SHOWING_DIALOG = false;
        Config.APP_KEY = "";
        Config.APP_URL = "";
        Config.CURRENT_CALLBACK = "";

        Config.DARK_MODE_ENABLED_CUSTOMER = true;
        Config.CURRENT_AUTHADA_SERVER = eIDSdk.Server.DEV;
        Config.PIN_IS_SET = false;
        Config.NAME_MISMATCH = false;
    }

    public void initialize(Activity callingActivity) {
        this.callingActivity = new WeakReference<>(callingActivity);
        this.appContext = callingActivity.getApplicationContext();

        resetStaticValues();

        Config.APP_ID = callingActivity.getPackageName();

        startEIDIntent = new Intent(this.callingActivity.get().getBaseContext(), eIDActivity.class);

        startEIDIntent.putExtra(Config.MESSAGE_USER_START_EID, Config.MESSAGE_USER_START_EID);
        this.callingActivity.get().startActivityForResult(startEIDIntent, Config.USER_START_EID_CODE);
    }

    public static void setAppkey(String appkey) {
        Config.APP_KEY = appkey;
    }

    public static void setAppURL(String appURL) {
        Config.APP_URL = appURL;

        Config.CURRENT_SERVER = eIDSdk.handleServerselection(eIDSdk.getTransactionToken());
    }

    public static String getAppkey() {
        return Config.APP_KEY;
    }

    public static String getAppURL() {
        return Config.APP_URL;
    }

    public static String getModels_clientInfoLanguage() {
        return Config.MODELS_CLIENT_INFO_LANGUAGE;
    }

    public static void setModels_clientInfoLanguage(String models_clientInfoLanguage) {
        Config.MODELS_CLIENT_INFO_LANGUAGE = models_clientInfoLanguage;
    }

    public static Boolean getShowPoweredBy() {
        return Config.SHOW_POWERED_BY_KEY;
    }

    public static void setShowPoweredBy(boolean showPoweredBy) {
        Config.SHOW_POWERED_BY_KEY = showPoweredBy;
    }

    public static Boolean getShowIDnowLogo() {
        return Config.SHOW_IDNOW_LOGO;
    }

    public static void setShowIDnowLogo(boolean showIDnowLogo) {
        Config.SHOW_IDNOW_LOGO = showIDnowLogo;
    }

    public static String getIDnowSDKEndpoint() {
        return Config.IDNOW_ENDPOINT;
    }

    public Context getAppContext() {
        return appContext;
    }


    public static void setIDnowSDKEndpoint(String endpoint) {
        Config.IDNOW_ENDPOINT = endpoint;
    }

    public static void setTransactionToken(String transactionToken) {
        Config.TRANSACTION_TOKEN = transactionToken;
    }

    public static void setMessagesfromBackend(Map<String, String> messagesfromBackend) {
        Config.MESSAGES_FROM_BACKEND = messagesfromBackend;
    }

    public static Map<String, String> getMessagesfromBackend() {
        return Config.MESSAGES_FROM_BACKEND;
    }

    public static String getTransactionToken() {
        return Config.TRANSACTION_TOKEN;
    }

    public static String getCompanyId() {
        return Config.COMPANY_ID;
    }

    public static void setCompanyId(String companyId) {
        Config.COMPANY_ID = companyId;
    }

    public static Boolean getDarkModeEnabled() {
        return Config.DARK_MODE_ENABLED_CUSTOMER;
    }

    public static void setDarkModeEnabled(Boolean darkModeEnabled) {
        Config.DARK_MODE_ENABLED_CUSTOMER = darkModeEnabled;
    }

    public static Boolean getEnableIDCaptureEID() {
        return Config.ENABLE_ID_CAPTURE_EID;
    }

    public static void setEnableIDCaptureEID(Boolean enableIDCaptureEID) {
        Config.ENABLE_ID_CAPTURE_EID = enableIDCaptureEID;
    }

    public static void setEnableChooseEIDType(boolean enableChooseEidType) {
        Config.ENABLE_CHOOSE_EID_TYPE = enableChooseEidType;
    }

    public static Boolean getEnableChooseEIDType() {
        return Config.ENABLE_CHOOSE_EID_TYPE;
    }

    public static Boolean getChangePinEID() {
        return Config.ENABLE_PIN_CHANGE_EID;
    }

    public static void setChangePinEID(Boolean changePinEID) {
        Config.ENABLE_PIN_CHANGE_EID = changePinEID;
    }

    public static void setStandaloneEID(Boolean standaloneEID) {
        Config.STANDALONE_EID = standaloneEID;
    }

    public static void setPhoneNumber(String userPhoneNo) {
        Config.USER_PHONE_NO = userPhoneNo;
    }

    public static String getPhoneNumber() {
        return Config.USER_PHONE_NO;
    }

    public static void setEnableEIDQES(boolean enableQesEid) {
        Config.ENABLE_ESIGN = enableQesEid;
    }

    public static boolean getEnableEIDQES() {
        return Config.ENABLE_ESIGN;
    }


    public static eIDSdk getInstance() {
        if (instance == null) {
            instance = new eIDSdk();
        }
        return instance;
    }

    public static boolean getAllowHttpConnections() {
        return allowHttpConnections;
    }

    public static void setAllowHttpConnections(boolean allow) {
        allowHttpConnections = allow;
    }

    public static boolean getAllowInvalidCertificates() {
        return allowInvalidCertificates;
    }


    public static boolean isNetworkConnected(Context context) {

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null;
    }

    public static Boolean isLoggingEnabled() {
        return LOGGING_ENABLED;
    }

    public static void setLogging(boolean loggingEnabled) {
        LOGGING_ENABLED = loggingEnabled;
    }

    public static Server getEnvironment() {
        return environment;
    }

    public static Boolean isShowTermsConditionsEID(Context context) {
        if (null == showTermsConditionsEID) {
            SharedPreferences prefs = context.getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            showTermsConditionsEID = prefs.getBoolean(SHOW_TNC_EID_KEY, true);
        }
        return showTermsConditionsEID;
    }

    /**
     * Method provided for SDK initialization that controls displaying the Terms&Conditions for eID
     *
     * @param context
     * @return
     */
    public static void setShowTermsConditionsEID(Boolean showTermsConditionsEID, Context context) {
        SharedPreferences prefs = context.getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        eIDSdk.showTermsConditionsEID = showTermsConditionsEID;
        prefs.edit().putBoolean(SHOW_TNC_EID_KEY, eIDSdk.showTermsConditionsEID).apply();
    }

    public static void setAuthadaStagingUrl(String url) {
        AuthadaAuthenticationWrapper.setStagingUrl(url);
    }

    public static void setAuthadaProductionUrl(String url) {
        AuthadaAuthenticationWrapper.setProductionUrl(url);
    }

    public static eIDSdk.Server handleServerselection(String token) {
        // The Environment wasn't set by the host app. Use token to determine.
        if (token.toUpperCase().startsWith("DEV")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DEV;
            Util_Log.i(LOGTAG, "select dev server");
        } else if (token.toUpperCase().startsWith("DV0")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV0;
            Util_Log.i(LOGTAG, "select dev0 server");
        } else if (token.toUpperCase().startsWith("DV1")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV1;
            Util_Log.i(LOGTAG, "select dev1 server");
        } else if (token.toUpperCase().startsWith("DV2")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DEV2;
            Util_Log.i(LOGTAG, "select dev2 server");
        } else if (token.toUpperCase().startsWith("DV3")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV3;
            Util_Log.i(LOGTAG, "select dev3 server");
        } else if (token.toUpperCase().startsWith("DV4")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV4;
            Util_Log.i(LOGTAG, "select dev4 server");
        } else if (token.toUpperCase().startsWith("DV5")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV5;
            Util_Log.i(LOGTAG, "select dev5 server");
        } else if (token.toUpperCase().startsWith("DV6")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV6;
            Util_Log.i(LOGTAG, "select dev6 server");
        } else if (token.toUpperCase().startsWith("DV7")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV7;
            Util_Log.i(LOGTAG, "select dev7 server");
        } else if (token.toUpperCase().startsWith("DV8")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV8;
            Util_Log.i(LOGTAG, "select dev8 server");
        } else if (token.toUpperCase().startsWith("DV9")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV9;
            Util_Log.i(LOGTAG, "select dev9 server");
        } else if (token.toUpperCase().startsWith("DV10")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV10;
            Util_Log.i(LOGTAG, "select dev10 server");
        } else if (token.toUpperCase().startsWith("DV11")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV11;
            Util_Log.i(LOGTAG, "select dev11 server");
        } else if (token.toUpperCase().startsWith("DV12")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV12;
            Util_Log.i(LOGTAG, "select dev12 server");
        } else if (token.toUpperCase().startsWith("DV13")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV13;
            Util_Log.i(LOGTAG, "select dev13 server");
        } else if (token.toUpperCase().startsWith("DV14")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV14;
            Util_Log.i(LOGTAG, "select dev14 server");
        } else if (token.toUpperCase().startsWith("DV15")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV15;
            Util_Log.i(LOGTAG, "select dev15 server");
        } else if (token.toUpperCase().startsWith("DV16")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV16;
            Util_Log.i(LOGTAG, "select dev16 server");
        } else if (token.toUpperCase().startsWith("DV17")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV17;
            Util_Log.i(LOGTAG, "select dev17 server");
        } else if (token.toUpperCase().startsWith("DV18")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV18;
            Util_Log.i(LOGTAG, "select dev18 server");
        } else if (token.toUpperCase().startsWith("DV19")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV19;
            Util_Log.i(LOGTAG, "select dev19 server");
        } else if (token.toUpperCase().startsWith("DV20")) {
            Config.CURRENT_AUTHADA_SERVER = Server.DV20;
            Util_Log.i(LOGTAG, "select dev20 server");
        } else if (token.toUpperCase().startsWith("TST")) {
            Config.CURRENT_AUTHADA_SERVER = Server.TEST;
            Util_Log.i(LOGTAG, "select test server");
        } else if (token.toUpperCase().startsWith("TS1")) {
            Config.CURRENT_AUTHADA_SERVER = Server.TEST1;
            Util_Log.i(LOGTAG, "select test1 server");
        } else if (token.toUpperCase().startsWith("TS2")) {
            Config.CURRENT_AUTHADA_SERVER = Server.TEST2;
            Util_Log.i(LOGTAG, "select test2 server");
        } else if (token.toUpperCase().startsWith("TS3")) {
            Config.CURRENT_AUTHADA_SERVER = Server.TEST3;
            Util_Log.i(LOGTAG, "select test3 server");
        } else if (token.toUpperCase().startsWith("SG1")) {
            Config.CURRENT_AUTHADA_SERVER = Server.SG1;
            Util_Log.i(LOGTAG, "select stage 1 server");
        } else if (token.toUpperCase().startsWith("INT")) {
            Config.CURRENT_AUTHADA_SERVER = Server.INT;
            Util_Log.i(LOGTAG, "select intrum server");
        } else {
            Config.CURRENT_AUTHADA_SERVER = Server.LIVE;
            Util_Log.i(LOGTAG, "select live server");
        }
        return Config.CURRENT_AUTHADA_SERVER;
    }


    public enum Server {
        DEV, DEV2, TEST, TEST1, TEST2, TEST3, LIVE, CUSTOM, INT, DV3, DV4, DV5, DV6, DV7, DV8, DV9, DV1, DV0, SG1,
        DV10, DV11, DV12, DV13, DV14, DV15, DV16, DV17, DV18, DV19, DV20;

        public String getApiHost(String token) {
            if (token.startsWith("DV")) {
                return "https://api.dev" + token.replaceAll("[^0-9]", "") + ".idnow.de";
            }

            switch (this) {
                case DEV:
                    return "https://api.dev.idnow.de";
                case DEV2:
                    return "https://api.dev2.idnow.de";
                case DV3:
                    return "https://api.dev3.idnow.de";
                case DV4:
                    return "https://api.dev4.idnow.de";
                case DV5:
                    return "https://api.dev5.idnow.de";
                case DV0:
                    return "https://api.dev0.idnow.de";
                case DV1:
                    return "https://api.dev1.idnow.de";
                case TEST:
                    if (token.length() == 13) {
                        return "https://api.test.online-ident.ch";
                    } else {
                        return "https://api.test.idnow.de";
                    }
                case TEST1:
                    return "https://api.test.idnow.de";
                case TEST2:
                    return "https://api.test.idnow.de";
                case TEST3:
                    return "https://api.test.idnow.de";
                case SG1:
                    return "https://api.staging1.idnow.de";
                case LIVE:
                    return "https://api.idnow.de";
                case INT:
                    return "https://api.online-ident.ch";
                case CUSTOM:
                    return apiHost;
                default:
                    return "";
            }
        }

        public String getSocketHost(String token) {
            if (token.startsWith("DV")) {
                return "https://api.dev" + token.replaceAll("[^0-9]", "") + ".idnow.de";
            }
            switch (this) {
                case DEV:
                    return "https://api.dev.idnow.de";
                case DEV2:
                    return "https://api.dev2.idnow.de";
                case TEST:
                    if (token.length() == 13) {
                        return "https://api.test.online-ident.ch";
                    } else {
                        return "https://api.test.idnow.de";
                    }
                case TEST1:
                    return "https://api.test.idnow.de";
                case TEST2:
                    return "https://api.test.idnow.de";
                case TEST3:
                    return "https://api.test.idnow.de";
                case SG1:
                    return "https://api.staging1.idnow.de";
                case LIVE:
                    return "https://api.idnow.de";
                case INT:
                    return "https://api.online-ident.ch";
                case CUSTOM:
                    return websocketHost;
                default:
                    return "";
            }
        }

        public String getWebHost(String token) {
            if (token.startsWith("DV")) {
                return "https://go.dev" + token.replaceAll("[^0-9]", "") + ".idnow.de";
            }
            switch (this) {
                case DEV:
                    return "https://go.dev.idnow.de";
                case DEV2:
                    return "https://go.dev2.idnow.de";
                case TEST:
                    if (token.length() == 13) {
                        return "https://go.test.online-ident.ch";
                    } else {
                        return "https://go.test.idnow.de";
                    }
                case TEST1:
                    return "https://go.test.idnow.de";
                case TEST2:
                    return "https://go.test.idnow.de";
                case TEST3:
                    return "https://go.test.idnow.de";
                case SG1:
                    return "https://go.staging1.idnow.de";
                case LIVE:
                    return "https://go.idnow.de";
                case INT:
                    return "https://go.online-ident.ch";
                case CUSTOM:
                    return webHost;
                default:
                    return "";
            }
        }

        public String getVideoHost(String token) {
            if (token.startsWith("DV")) {
                return "https://video.dev" + token.replaceAll("[^0-9]", "") + ".idnow.de";
            }
            switch (this) {
                case DEV:
                    return "https://video.dev.idnow.de";
                case DEV2:
                    return "https://video.dev2.idnow.de";
                case TEST:
                    if (token.length() == 13) {
                        return "https://video.test.online-ident.ch";
                    } else {
                        return "https://video.test.idnow.de";
                    }
                case TEST1:
                    return "https://video.test.idnow.de";
                case TEST2:
                    return "https://video.test.idnow.de";
                case TEST3:
                    return "https://video.test.idnow.de";
                case SG1:
                    return "https://video.staging1.idnow.de";
                case LIVE:
                    return "https://video.idnow.de";
                case INT:
                    return "https://video.online-ident.ch";
                case CUSTOM:
                    return videoHost;
                default:
                    return "";
            }
        }

        public String getStunHost(String token) {
            if (token.startsWith("DV")) {
                return "https://video.dev" + token.replaceAll("[^0-9]", "") + ".idnow.de";
            }
            switch (this) {
                case DEV:
                    return "video.dev.idnow.de";
                case DEV2:
                    return "video.dev2.idnow.de";
                case TEST:
                    if (token.length() == 13) {
                        return "video.test.online-ident.ch";
                    } else {
                        return "video.test.idnow.de";
                    }
                case TEST1:
                    return "video.test.idnow.de";
                case TEST2:
                    return "video.test.idnow.de";
                case TEST3:
                    return "video.test.idnow.de";
                case SG1:
                    return "video.staging1.idnow.de";
                case LIVE:
                    return "video.idnow.de";
                case INT:
                    return "video.online-ident.ch";
                case CUSTOM:
                    return stunHost;
                default:
                    return "";
            }
        }

        public Integer getStunPort() {
            switch (this) {
                case CUSTOM:
                    return stunPort;
                default:
                    return 3478;
            }
        }

    }

    public static AtomicBoolean enabled = new AtomicBoolean(false);

    public static void init(Activity activity, ModelCustomLog modelCustomLog) {
        InsightsConfig insightsConfig = new InsightsConfig(activity, modelCustomLog.getAppKey(), modelCustomLog.getUrl());
        insightsConfig.setLoggingEnabled(isLoggingEnabled());
        insightsConfig.setDeviceId(de.idnow.android.eid.eIDSdk.getTransactionToken());
        insightsConfig.enableCrashReporting();
        try {
            Insights.sharedInstance().init(insightsConfig);
        } catch (Exception e) {
        }
        Insights.sharedInstance().changeDeviceIdWithoutMerge(DeviceId.Type.DEVELOPER_SUPPLIED, de.idnow.android.eid.eIDSdk.getTransactionToken());

        enabled.set(true);
    }

    public static void disable() {
        enabled.set(false);
    }

    public static void onCreate(Activity activity) {
        if (enabled.get()) {
            Insights.onCreate(activity);
        }
    }

    public static void onStart(Activity activity) {
        if (enabled.get()) {
            Insights.sharedInstance().onStart(activity);
        }
    }

    public static void onStop() {
        if (enabled.get()) {
            Insights.sharedInstance().onStop();
        }
    }

    public static void startEvent(String eventName) {
        if (enabled.get()) {
            if (!TextUtils.isEmpty(eventName)) {
                Insights.sharedInstance().events().startEvent(eventName);
            }
        }
    }

    public static void endEvent(String eventName) {
        if (enabled.get()) {
            if (!TextUtils.isEmpty(eventName)) {
                Insights.sharedInstance().events().endEvent(eventName);
            }
        }
    }

    public static void recordEvent(String event) {
        if (enabled.get()) {
            Insights.sharedInstance().events().recordEvent(event);
        }
    }

    public static void recordEvent(String event, int count) {
        if (enabled.get()) {
            Insights.sharedInstance().events().recordEvent(event, count);
        }
    }

    private static void setUser(String identID) {
        HashMap<String, String> data = new HashMap<>();
        data.put("username", identID);
        Insights.userData.save();
    }

    public static String getSDKCurrentVerion() {
        return Config.CURRENT_SDK_VERSION;
    }

    public static void setSDKCurrentVerion(String currentVerion) {
        Config.CURRENT_SDK_VERSION = currentVerion;
    }

    public static String getConnectionType() {
        return Config.CONNECTION_TYPE;
    }

    public static void setConnectionType(String connectionType) {
        Config.CONNECTION_TYPE = connectionType;
    }

    public static boolean showDialogsWithIcon() {
        return Config.SHOW_DIALOG_WITH_ICON;
    }

    public static void setShowDialogsWithIcon(Boolean showDialogsWithIcon) {
        Config.SHOW_DIALOG_WITH_ICON = showDialogsWithIcon;
    }

    public static String getEIDTSP() {
        return Config.EIDTSP;
    }

    public static void setEIDTSP(String eidtsp) {
        Config.EIDTSP = eidtsp;
    }

    // ID Front

    public static final String EVENT_EID_FRONT_CAPTURE_SCREEN = "eID ID Front Capture screen shown";
    public static final String EVENT_EID_FRONT_CAPTURE_CROSS = "eID ID Front Capture screen - cross";
    public static final String EVENT_EID_FRONT_CAPTURE_TAKEN = "eID ID Front Capture screen - picture taken";
    public static final String EVENT_EID_FRONT_CAPTURE_RETAKEN = "eID ID Front Capture screen - picture retake";
    public static final String EVENT_EID_FRONT_CAPTURE_PROCESSING = "eID ID Front Capture screen - picture processing";
    public static final String EVENT_EID_FRONT_CAPTURE_CONTINUE = "eID ID Front Capture screen - picture continue";
    public static final String EVENT_EID_QES_OTP_SCREEN_CROSS = "eID QES OST screen - Cross";
    public static final String EVENT_EID_FRONT_CAPTURE_TIME_SPENT = "Time spent - eID ID Front Capture Screen";

    // ID Back

    public static final String EVENT_EID_BACK_CAPTURE_SCREEN = "eID ID Back Capture screen shown";
    public static final String EVENT_EID_BACK_CAPTURE_CROSS = "eID ID Back Capture screen - cross";
    public static final String EVENT_EID_BACK_CAPTURE_TAKEN = "eID ID Back Capture screen - picture taken";
    public static final String EVENT_EID_BACK_CAPTURE_RETAKEN = "eID ID Back Capture screen - picture retake";
    public static final String EVENT_EID_BACK_CAPTURE_PROCESSING = "eID ID Back Capture screen - picture processing";
    public static final String EVENT_EID_BACK_CAPTURE_CONTINUE = "eID ID Back Capture screen - picture continue";
    public static final String EVENT_EID_BACK_CAPTURE_TIME_SPENT = "Time spent - eID ID Back Capture Screen";

    //Not German ID

    public static final String EVENT_EID_POPUP_SCREEN = "eID Not German ID screen shown";

    public static final String EVENT_EID_POPUP_CONTINUE = "eID Not German ID screen - German eID";

    public static final String EVENT_EID_POPUP_TRY_OTHER = "eID Not German ID screen - Try another method";

    public static final String EVENT_EID_NOT_GERMAN_ID_SCREEN_CROSS = "eID Not German ID screen - Cross";

    public static final String EVENT_EID_POPUP_TIIME_SPENT = "Time spent - eID Not German ID screen";

    // PIN Chooser Screen

    public static final String EVENT_EID_PIN_CHOOSER_SCREEN_SHWON = "eID PIN chooser screen shown";

    public static final String EVENT_EID_PIN_CHOOSER_SCREEN_TRANSPORT_PIN_OPTION = "eID PIN chooser screen - Transport PIN Option";

    public static final String EVENT_EID_PIN_CHOOSER_SCREEN_PERSONAL_PIN_OPTION = "eID PIN chooser screen - Personal PIN Option";

    public static final String EVENT_EID_PIN_CHOOSER_SCREEN_TNC_CHECKED = "eID PIN chooser screen - TnC checked";

    public static final String EVENT_EID_PIN_CHOOSER_SCREEN_CONTINUE = "eID PIN chooser screen - Continue";

    public static final String EVENT_EID_PIN_CHOOSER_SCREEN_TERMS_OF_SERVICE = "eID PIN chooser screen - Terms of service";

    public static final String EVENT_EID_PIN_CHOOSER_SCREEN_PRIVACY_POLICY = "eID PIN chooser screen - Privacy policy";

    public static final String EVENT_EID_PIN_CHOOSER_SCREEN_WHERE_IS_MY_PIN = "eID PIN chooser screen - Where is my PIN?";

    public static final String EVENT_EID_PIN_CHOOSER_SCREEN_CROSS = "eID PIN chooser screen - Cross";

    public static final String EVENT_EID_PIN_CHOOSER_SCREEN_TIME_SPENT = "Time spent eID PIN chooser screen";

    // Verification Steps Screen

    public static final String EVENT_EID_VERIFICATION_STEP_SCREEN_SHOWN = "eID Verification steps screen shown";

    public static final String EVENT_EID_VERIFICATION_STEP_CONTINUE = "eID Verification steps screen - Continue";

    public static final String EVENT_EID_VERIFICATION_STEP_LEARN_MORE = "eID Verification steps screen - Learn More";

    public static final String EVENT_EID_VERIFICATION_STEP_CROSS = "eID Verification steps screen - Cross";

    public static final String EVENT_EID_VERIFICATION_STEP_SCREEN_TIME_SPENT = "Time spent - eID Verification steps screen";

    // eID Activation Steps

    public static final String EVENT_EID_ACTIVATION_STEPS_SCREEN_SHOWN = "eID Activation steps screen shown";

    public static final String EVENT_EID_ACTIVATION_STEPS_SCREEN_CONTINUE = "eID Activation steps screen - Continue";

    public static final String EVENT_EID_ACTIVATION_STEPS_SCREEN_CROSS = "eID Activation steps screen - Cross";

    public static final String EVENT_EID_ACTIVATION_STEPS_SCREEN_TIME_SPENT = "Time spent - eID Activation steps screen ";


    // Personal PIN Screen

    public static final String EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_SHOWN = "eID Personal PIN screen shown";

    public static final String EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_CONTINUE = "eID Personal PIN screen - Continue";

    public static final String EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_FIVE_DIGIT_PIN = "eID Personal PIN screen - I have a 5-digit PIN";

    public static final String EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_CROSS = "eID Personal PIN screen - Cross";

    public static final String EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_EYE = "eID Personal PIN screen - Eye";

    public static final String EVENT_EID_BACK_ID_PERSONAL_PIN_SCREEN_TIME_SPENT = "Time spent - eID Personal PIN screen";

    // Transport PIN Screen

    public static final String EVENT_EID_TRANPORT_PIN_SCREEN_SHOWN = "eID Transport PIN screen shown";

    public static final String EVENT_EID_TRANPORT_PIN_SCREEN_CONTINUE = "eID Transport PIN screen - Continue";

    public static final String EVENT_EID_TRANPORT_PIN_SCREEN_CROSS = "eID Transport PIN screen - Cross";

    public static final String EVENT_EID_TRANPORT_PIN_SCREEN_LEARN_MORE = "eID Transport PIN screen - Learn more";

    public static final String EVENT_EID_TRANPORT_PIN_SCREEN_EYE = "eID Transport PIN screen - Eye";

    public static final String EVENT_EID_TRANPORT_PIN_SCREEN_SIX_DIGIT_PIN = "I have my personal 6-digit PIN";

    public static final String EVENT_EID_TRANPORT_PIN_SCREEN_TIME_SPENT = "Time spent - eID Transport PIN screen";

    // PERSONAL PIN SCREEN /////////////

    public static final String EVENT_EID_PERSONAL_PIN_SCREEN_SHOWN = "eID personal PIN screen shown";

    public static final String EVENT_EID_PERSONAL_PIN_SCREEN_CONTINUE = "eID personal PIN screen - Continue";

    public static final String EVENT_EID_PERSONAL_PIN_SCREEN_CROSS = "eID personal PIN screen - Cross";

    public static final String EVENT_EID_PERSONAL_PIN_SCREEN_EYE = "eID personal PIN screen - Eye";

    public static final String EVENT_EID_PERSONAL_PIN_SCREEN_TIME_SPENT = "Time spent - eID personal PIN screen";

    // Reenter Personal PIN Screen ///////

    public static final String EVENT_EID_REENTER_PERSONAL_PIN_SCREEN_SHOWN = "eID Reenter personal pin screen shown";

    public static final String EVENT_EID_REENTER_PERSONAL_PIN_SCREEN_CONTINUE = "eID personal PIN screen - Continue";

    public static final String EVENT_EID_REENTER_PERSONAL_PIN_SCREEN_CROSS = "eID personal PIN screen - Cross";

    public static final String EVENT_EID_REENTER_PERSONAL_PIN_SCREEN_EYE = "eID personal PIN screen - Eye";

    public static final String EVENT_EID_REENTER_PERSONAL_PIN_SCREEN_TIME_SPENT = "Time spent - eID personal PIN screen";

    // Card Scan Screen

    public static final String EVENT_EID_CARD_SCAN_SCREEN_SHOWN = "eID Card scan screen shown";

    public static final String EVENT_EID_CARD_SCAN_SCREEN_PHONE_NOT_DETECTING_EID = "eID Card scan screen - Phone not detecting eID";

    public static final String EVENT_EID_CARD_SCAN_SCREEN_CROSS = "eID Card scan screen - Cross";

    public static final String EVENT_EID_CARD_SCAN_SCREEN_TIME_SPENT = "Time spent - eID Card scan screen";

    // Final Attempt screen

    public static final String EVENT_EID_FINAL_ATTEMPT_SCREEN_SHOWN = "eID Final attempt screen shown";

    public static final String EVENT_EID_FINAL_ATTEMPT_SCREEN_CONTINUE = "eID Final attempt screen - Continue";

    public static final String EVENT_EID_FINAL_ATTEMPT_SCREEN_CROSS = "eID Final attempt screen - Cross";

    public static final String EVENT_EID_FINAL_ATTEMPT_SCREEN_WHERE_DO_I_FIND_CAN = "eID Final attempt screen - Where do I find the CAN?";

    public static final String EVENT_EID_FINAL_ATTEMPT_SCREEN_TIME_SPENT = "Time spent - eID Final attempt screen";

    // Card blocked screen

    public static final String EVENT_EID_CARD_BLOCKED_SHOWN = "eID Card blocked screen shown";

    public static final String EVENT_EID_CARD_BLOCKED_AUSWEIS_APP = "eID Card blocked screen - AusweisApp";

    public static final String EVENT_EID_CARD_BLOCKED_TRY_ANOTHER_METHOD = "eID Card blocked screen - Try another method";

    public static final String EVENT_EID_CARD_BLOCKED_CROSS = "eID Card blocked screen - Cross";

    public static final String EVENT_EID_CARD_BLOCKED_TIME_SPENT = "Time spent - eID Card blocked screen";

    // CAN Screen

    public static final String EVENT_EID_CAN_SCREEN = " eID CAN Screen shown";

    public static final String EVENT_EID_CAN_SCREEN_CONTINUE = "eID CAN Screen - Continue";

    public static final String EVENT_EID_CAN_SCREEN_WHERE_DO_I_FIND_CAN = "eID CAN Screen - Where do I find the CAN?";

    public static final String EVENT_EID_CAN_SCREEN_CROSS = "eID CAN Screen - Cross";

    public static final String EVENT_EID_CAN_SCREEN_TIME_SPENT = "Time spent - eID CAN Screen screen";

    // Verification completed screen

    public static final String EVENT_EID_VERIFICATION_COMPLETED_SCREEN_SHOWN = "eID Verification Completed Screen Shown";

    public static final String EVENT_EID_VERIFICATION_COMPLETED_SCREEN_DONE = "eID Verification Completed Screen Done";

    // PIN Change Successful

    public static final String EVENT_EID_PIN_CHANGE_SUCCESSFUL = "eID PIN change successful screen shown";

    public static final String EVENT_EID_PIN_CHANGE_SUCCESSFUL_CONTINUE = "eID PIN change successful screen - Continue";

    public static final String EVENT_EID_PIN_CHANGE_SUCCESSFUL_CROSS = "eID PIN change successful screen  - Cross";

    public static final String EVENT_EID_PIN_CHANGE_SUCCESSFUL_TIME_SPENT = "Time spent - eID PIN change successful screen";

    // Success screen

    public static final String EVENT_EID_SUCCESS_SCREEN_SHOWN = " eID QES success screen shown";

    public static final String EVENT_EID_SUCCESS_SCREEN_DONE = "eID QES success screen - Done";

    public static final String EVENT_EID_SUCCESS_SCREEN_TIME_SPENT = "Time spent - eID QES success screen";

    // Unsuccessful screen

    public static final String EVENT_EID_UNSUCCESSFUL_SCREEN_SHOWN = " eID QES unsuccessful screen shown";

    public static final String EVENT_EID_UNSUCCESSFUL_SCREEN_DONE = "eID QES unsuccessful screen - Done";

    public static final String EVENT_EID_UNSUCCESSFUL_SCREEN_TIME_SPENT = "Time spent - eID QES usuccessful screen";

    // Technical screen

    public static final String EVENT_EID_TECHNICAL_ERROR_SCREEN_SHOWN = " eID QES technical error screen shown";

    public static final String EVENT_EID_TECHNICAL_ERROR_SCREEN_TRY_AGAIN = "eID QES technical error screen - Try again";

    public static final String EVENT_EID_TECHNICAL_ERROR_SCREEN_TIME_SPENT = "Time spent - eID QES technical error screen";

    // OTP SCREEN

    public static final String EVENT_EID_QES_OTP_SCREEN_SHOWN = "eID QES OTP screen shown";

    public static final String EVENT_EID_QES_OTP_SCREEN_TEXTFIELD_TAPPED = "eID QES OTP screen - text field tapped";

    public static final String EVENT_EID_QES_OTP_SCREEN_TEXTFIELD_FILLED = "eID QES OTP screen - text field filled";

    public static final String EVENT_EID_QES_OTP_SCREEN_RESEND_BUTTON = "eID QES OTP screen - Resend button";

    public static final String EVENT_EID_QES_OTP_SCREEN_CONTINUE = "eID QES OST screen - Continue";

    public static final String EVENT_EID_QES_OTP_SCREEN_TIME_SPENT = "Time spent - eID QES OTP screen";

    // QES Consent protocol

    public static final String EVENT_EID_QES_CP_SCREEN_SHOWN = "eID QES consent protocol screen shown";

    public static final String EVENT_EID_QES_CP_SCREEN_APPROVAL_PHREASES_CHECKED = "eID QES consent protocol screen - Approval phrases checked";

    public static final String EVENT_EID_QES_CP_SCREEN_CONTINUE = "eID QES consent protocol screen - Continue";

    public static final String EVENT_EID_QES_CP_SCREEN_TERMS_CONDITIONS = "eID QES consent protocol screen - Terms and Conditions";

    public static final String EVENT_EID_QES_CP_SCREEN_PRIVACY_POLICY = "eID QES consent protocol screen - Privacy policy";

    public static final String EVENT_EID_QES_CP_SCREEN_CONTRACT = "eID QES consent protocol screen - Signature contract";

    public static final String EVENT_EID_QES_CP_SCREEN_DOCUMENTS = "eID QES consent protocol screen - Documents";

    public static final String EVENT_EID_QES_CP_SCREEN_TIME_SPENT = "Time spent - eID QES consent protocol screen";

    // QES MOBILE NUMBER

    public static final String EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_SHOWN = "eID QES mobile number confirmation screen shown";

    public static final String EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_TEXTFIELD_TAPPED = "eID QES mobile number confirmation screen - text field tapped";

    public static final String EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_TEXTFIELD_FILLED = "eID QES mobile number confirmation screen - text field filled";

    public static final String EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_FLAG_TAPPED = "eID QES mobile number confirmation screen - flag tapped";

    public static final String EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_CONTINUE = "eID QES mobile number confirmation screen - Continue";

    public static final String EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_CROSS = "eID QES mobile number confirmation screen - Cross";

    public static final String EVENT_EID_QES_MOBILE_NUMBER_CONFIRMATION_SCREEN_TIME_SPENT = "Time spent - eID QES mobile number confirmation screen";

    // QES PREPARING SIGNING

    public static final String EVENT_EID_QES_PREPARING_SIGNING_SHOWN = "eID QES Preparing Signing screen shown";

    public static final String EVENT_EID_QES_PREPARING_SIGNING_TIME_SPENT = "Time spent - eID QES Preparing Signing screen ";

}
