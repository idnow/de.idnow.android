package de.idnow.android.eid.models;

import java.util.Map;

public class Models_ApprovalPhrase {

    String translationKey;
    String name;
    String value;
    Map<String, Models_ApprovalPhraseURL> urls;

    public Models_ApprovalPhrase(String name, String translationKey, Map<String, Models_ApprovalPhraseURL> urls, String value) {
        this.name = name;
        this.translationKey = translationKey;
        this.urls = urls;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTranslationKey() {
        return translationKey;
    }

    public void setTranslationKey(String translationKey) {
        this.translationKey = translationKey;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Map<String, Models_ApprovalPhraseURL> getUrls() {
        return urls;
    }

    public void setUrls(Map<String, Models_ApprovalPhraseURL> urls) {
        this.urls = urls;
    }

    @Override
    public String toString() {
        return "Models_ApprovalPhrase{" +
                "translationKey='" + translationKey + '\'' +
                ", name='" + name + '\'' +
                ", value='" + value + '\'' +
                ", urls=" + urls +
                '}';
    }
}