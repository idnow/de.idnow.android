package de.idnow.android.eid.AusweisApp2SDK.util

import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import de.idnow.android.eid.AusweisApp2SDK.core.IdentificationCallback
import de.idnow.android.eid.AusweisApp2SDK.core.IdentificationManager
import de.idnow.android.eid.Config

abstract class NfcInterceptorActivity : AppCompatActivity() {
    var nfcDispatcher: ForegroundDispatcher? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Config.EIDTSP.equals("governikus", true)) {
            nfcDispatcher = ForegroundDispatcher(this)
            IdentificationManager.bind(this, applicationContext, provideIdentificationCallback())
        }
    }

    override fun onDestroy() {
        releaseNfcScanning()
        super.onDestroy()
    }

    fun requestNfcScanning() {
        nfcDispatcher?.enable(::handleNfcTag)
    }

    fun releaseNfcScanning() {
        nfcDispatcher?.disable()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Android 14 and below: Foreground Dispatch flow
        val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
        tag?.let(IdentificationManager::dispatchNfcTag)
    }

    /**
     * Android 15+: Reader Mode flow
     * Called when an NFC tag is detected via Reader Mode (Android 15+).
     */
    protected fun handleNfcTag(tag: Tag) =
        IdentificationManager.dispatchNfcTag(tag)

    protected abstract fun provideIdentificationCallback(): IdentificationCallback
}
