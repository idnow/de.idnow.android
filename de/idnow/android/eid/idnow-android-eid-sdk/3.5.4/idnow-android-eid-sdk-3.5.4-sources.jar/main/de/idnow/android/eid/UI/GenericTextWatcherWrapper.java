package de.idnow.android.eid.UI;

import static de.idnow.android.eid.util.Util.setProceedButtonBackgroundSelector;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import de.idnow.android.eid.R;

public class GenericTextWatcherWrapper {

    public static class GenericTextWatcher implements TextWatcher {

        private final EditText currentView;
        private final EditText nextView;
        private final Button continueButton;

        private final EditText pinBox0, pinBox1, pinBox2, pinBox3, pinBox4, pinBox5;

        public GenericTextWatcher(EditText currentView, EditText nextView, Button button, EditText pinBox0, EditText pinBox1, EditText pinBox2, EditText pinBox3, EditText pinBox4, EditText pinBox5) {
            this.continueButton = button;
            this.currentView = currentView;
            this.nextView = nextView;
            this.pinBox0 = pinBox0;
            this.pinBox1 = pinBox1;
            this.pinBox2 = pinBox2;
            this.pinBox3 = pinBox3;
            this.pinBox4 = pinBox4;
            this.pinBox5 = pinBox5;
        }


        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            String text = s.toString();

            continueButton.setEnabled(isPinComplete());
            setProceedButtonBackgroundSelector(continueButton);

            if (currentView.getId() == R.id.pinBox0
                    || currentView.getId() == R.id.pinBox1
                    || currentView.getId() == R.id.pinBox2
                    || currentView.getId() == R.id.pinBox3
                    || currentView.getId() == R.id.pinBox4) {
                if (text.length() == 1) {
                    if (nextView != null) {
                        nextView.requestFocus();
                    }
                }
            }
        }

        private boolean isPinComplete() {

            if (!pinBox0.getText().toString().isEmpty() &&
                    !pinBox1.getText().toString().isEmpty() &&
                    !pinBox2.getText().toString().isEmpty() &&
                    !pinBox3.getText().toString().isEmpty() &&
                    !pinBox4.getText().toString().isEmpty() &&
                    pinBox5.getVisibility() != View.VISIBLE) {
                return true;
            } else return pinBox5.getVisibility() == View.VISIBLE &&
                    !pinBox0.getText().toString().isEmpty() &&
                    !pinBox1.getText().toString().isEmpty() &&
                    !pinBox2.getText().toString().isEmpty() &&
                    !pinBox3.getText().toString().isEmpty() &&
                    !pinBox5.getText().toString().isEmpty() &&
                    !pinBox4.getText().toString().isEmpty();
        }
    }


    public static class GenericKeyEvent implements View.OnKeyListener {

        private final EditText currentView;
        private final EditText previousView;

        public GenericKeyEvent(EditText currentView, EditText previousView) {
            this.currentView = currentView;
            this.previousView = previousView;
        }

        @Override
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if (event.getAction() == KeyEvent.ACTION_DOWN &&
                    keyCode == KeyEvent.KEYCODE_DEL &&
                    currentView.getId() != R.id.pinBox0 &&
                    currentView.getText().toString().isEmpty()) {

                previousView.setText("");
                previousView.requestFocus();
                return true;
            }

            if (event.getAction() == KeyEvent.ACTION_DOWN &&
                    keyCode == KeyEvent.KEYCODE_DEL) {

                currentView.setText("");
                return true;
            }
            return false;
        }
    }
}
