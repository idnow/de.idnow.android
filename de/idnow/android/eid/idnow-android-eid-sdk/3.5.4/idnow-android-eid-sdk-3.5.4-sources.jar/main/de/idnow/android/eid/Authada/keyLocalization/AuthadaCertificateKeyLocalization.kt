package de.idnow.android.eid.Authada.keyLocalization

import android.content.Context
import android.os.Build
import java.util.Locale

@Suppress("SpellCheckingInspection")
internal class AuthadaCertificateKeyLocalization(
    private val context: Context
) {
    private object DEUTSCH {
        const val TERMS_OF_USE = "Nutzungsbedingungen"
        const val SERVICE_PROVIDER = "Diensteanbieter"
        const val URL_OF_SERVICE_PROVIDER = "URL des Diensteanbieters"
        const val CERTIFICATE_ISSUER = "Zertifikatsaussteller"
        const val URL_OF_CERTIFICATE_ISSUER = "URL des Zertifikatsausstellers"
        const val TRANSACTION_INFO = "Transaktionszweck"
        const val EFFECTIVE_DATE_OF_CERTIFICATE = "Beginn der Gültigkeit des Zertifikats"
        const val EXPIRATION_DATE_OF_CERTIFICATE = "Ende der Gültigkeit des Zertifikats"
    }

    private object ENGLISH {
        const val TERMS_OF_USE = "Terms of use"
        const val SERVICE_PROVIDER = "Service Provider"
        const val URL_OF_SERVICE_PROVIDER = "URL of service provider"
        const val CERTIFICATE_ISSUER = "Certificate issuer"
        const val URL_OF_CERTIFICATE_ISSUER = "URL of certificate issuer"
        const val TRANSACTION_INFO = "Transaction info"
        const val EFFECTIVE_DATE_OF_CERTIFICATE = "Effective date of certificate"
        const val EXPIRATION_DATE_OF_CERTIFICATE = "Expiration date of certificate"
    }

    fun getValue(key: AuthadaCertificateKey): String {
        return if (context.getLanguageCode().equals(Locale.GERMAN.language, true))
            getGermanTranslation(key)
        else
            getEnglishTranslation(key)
    }

    private fun Context.getLanguageCode(): String {
        @Suppress("DEPRECATION")
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
            resources.configuration.locales.get(0).language
        else
            context.resources.configuration.locale.language
    }

    private fun getGermanTranslation(key: AuthadaCertificateKey): String {
        return when (key) {
            AuthadaCertificateKey.TERMS_OF_USE -> DEUTSCH.TERMS_OF_USE
            AuthadaCertificateKey.SERVICE_PROVIDER -> DEUTSCH.SERVICE_PROVIDER
            AuthadaCertificateKey.URL_OF_SERVICE_PROVIDER -> DEUTSCH.URL_OF_SERVICE_PROVIDER
            AuthadaCertificateKey.CERTIFICATE_ISSUER -> DEUTSCH.CERTIFICATE_ISSUER
            AuthadaCertificateKey.URL_OF_CERTIFICATE_ISSUER -> DEUTSCH.URL_OF_CERTIFICATE_ISSUER
            AuthadaCertificateKey.TRANSACTION_INFO -> DEUTSCH.TRANSACTION_INFO
            AuthadaCertificateKey.EFFECTIVE_DATE_OF_CERTIFICATE -> DEUTSCH.EFFECTIVE_DATE_OF_CERTIFICATE
            AuthadaCertificateKey.EXPIRATION_DATE_OF_CERTIFICATE -> DEUTSCH.EXPIRATION_DATE_OF_CERTIFICATE
        }
    }

    private fun getEnglishTranslation(key: AuthadaCertificateKey): String {
        return when (key) {
            AuthadaCertificateKey.TERMS_OF_USE -> ENGLISH.TERMS_OF_USE
            AuthadaCertificateKey.SERVICE_PROVIDER -> ENGLISH.SERVICE_PROVIDER
            AuthadaCertificateKey.URL_OF_SERVICE_PROVIDER -> ENGLISH.URL_OF_SERVICE_PROVIDER
            AuthadaCertificateKey.CERTIFICATE_ISSUER -> ENGLISH.CERTIFICATE_ISSUER
            AuthadaCertificateKey.URL_OF_CERTIFICATE_ISSUER -> ENGLISH.URL_OF_CERTIFICATE_ISSUER
            AuthadaCertificateKey.TRANSACTION_INFO -> ENGLISH.TRANSACTION_INFO
            AuthadaCertificateKey.EFFECTIVE_DATE_OF_CERTIFICATE -> ENGLISH.EFFECTIVE_DATE_OF_CERTIFICATE
            AuthadaCertificateKey.EXPIRATION_DATE_OF_CERTIFICATE -> ENGLISH.EXPIRATION_DATE_OF_CERTIFICATE
        }
    }
}