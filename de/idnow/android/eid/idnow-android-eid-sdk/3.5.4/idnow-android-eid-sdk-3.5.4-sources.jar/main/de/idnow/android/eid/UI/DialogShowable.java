package de.idnow.android.eid.UI;

import android.content.Context;

public interface DialogShowable {

    void showDialog(Context context);
}
