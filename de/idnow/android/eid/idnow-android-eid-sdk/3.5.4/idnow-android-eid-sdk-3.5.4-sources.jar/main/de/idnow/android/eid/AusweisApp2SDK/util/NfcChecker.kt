package de.idnow.android.eid.AusweisApp2SDK.util

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.NfcManager
import android.os.Build
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import de.idnow.android.eid.R


/**
 * Checks the availability and state of NFC for this device and asks user to turn on NFC.
 */
class NfcChecker(context: Context) {
    private var mNfcAdapter: NfcAdapter? = null

    /**
     * Check if this device has NFC capabilities
     * @return True if this device has NFC capabilities. False otherwise.
     */
    val isNfcAvailable: Boolean
        get() = mNfcAdapter != null

    /**
     * Check if this device's NFC is currently enabled.
     * @return True if NFC is available and enabled. False if NFC is either not supported entirely
     * or turned of.
     */
    val isNfcOn: Boolean
        get() = mNfcAdapter != null && mNfcAdapter!!.isEnabled()

    /**
     * Creates and shows a dialog which asks the user to enable NFC if this device has NFC capabilities.
     * Upon confirmation, opens the android NFC settings. On android 10 and above, instead it shows a
     * settings panel with the NFC settings.
     *
     * Doesn't do anything if this device has no NFC capabilities.
     * @param context The context in which the settings dialog must be shown.
     */
    fun setNfcOn(context: Context) {
        if (mNfcAdapter == null) {
            return
        }
        if (!mNfcAdapter!!.isEnabled()) {
            val alert = AlertDialog.Builder(context)
            alert.setTitle(context.getString(R.string.itm_eid_nfc_active))
            alert.setMessage(context.getString(R.string.itm_eid_please_active_nfc))
            alert.setPositiveButton(context.getString(R.string.itm_eid_nfc_active)) { dialog: DialogInterface?, which: Int ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // On android 10 and above, we can show the NFC setting as a prompt in the context
                    // of the app
                    val panelIntent = Intent(Settings.Panel.ACTION_NFC)
                    context.startActivity(panelIntent)
                } else {
                    // Open the NFC settings on older android versions
                    val intent = Intent(Settings.ACTION_NFC_SETTINGS)
                    context.startActivity(intent)
                }
            }
            alert.show()
        }
    }

    init {
        val systemService = context.getSystemService(Context.NFC_SERVICE)
        if (systemService is NfcManager) {
            mNfcAdapter = systemService.defaultAdapter
        }
    }
}