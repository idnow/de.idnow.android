package de.idnow.android.eid.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.fragments.Fragment_Signing;

public class IDnowListDocumentAdapter extends RecyclerView.Adapter<IDnowListDocumentAdapter.DocumentViewHolder> {

    public static IDnowListDocumentAdapter.DocumentItemClickListener DocumentItemClickListener;
    private static int selectedPosition = -1;
    private final LayoutInflater layoutInflater;
    private ArrayList<String> listDocument = new ArrayList<>();
    private DocumentItemClickListener documentItemClickListener;
    Context context;
    public FragmentActivity fragmentActivity;

    public IDnowListDocumentAdapter(ArrayList<String> listDocument, @NonNull Context context, FragmentActivity fragmentActivity) {

        layoutInflater = LayoutInflater.from(context);
        this.listDocument = listDocument;
        this.context = context;
        this.fragmentActivity = fragmentActivity;
    }

    public static int getSelectedPosition() {
        return selectedPosition;
    }

    public void setDocumentItemClickListener(DocumentItemClickListener documentItemClickListener) {
        this.documentItemClickListener = documentItemClickListener;
    }

    public void setData(ArrayList<String> listDocument) {
        this.listDocument = listDocument;
        notifyDataSetChanged();
    }

    public void clearSelection() {
        selectedPosition = -1;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DocumentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.document_item, parent, false);
        return new DocumentViewHolder(view, context, fragmentActivity);
    }

    @Override
    public void onBindViewHolder(DocumentViewHolder holder, int position) {

        String document = listDocument.get(position);
        holder.documnentText.setText(document);

    }

    @Override
    public int getItemCount() {
        return listDocument.size();
    }

    public interface DocumentItemClickListener {
        void onDocumentItemClick(int position);
    }

    public static class DocumentViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView documnentText;
        ImageButton document_redirect;

        DocumentViewHolder(View itemView, Context context, FragmentActivity fragmentActivity) {
            super(itemView);
            documnentText = itemView.findViewById(R.id.document_text);
            document_redirect = itemView.findViewById(R.id.document_redirect);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (Config.MODEL_PDF_DOCUMENTS[getAdapterPosition()].getDocumentDefinition() != null) {
                        Fragment_Signing fragment_signing = new Fragment_Signing();
                        fragment_signing.redirectDocument(context, getAdapterPosition(), fragmentActivity);
                    }
                }
            });

            documnentText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            document_redirect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }

        @Override
        public void onClick(View v) {

        }
    }


}
