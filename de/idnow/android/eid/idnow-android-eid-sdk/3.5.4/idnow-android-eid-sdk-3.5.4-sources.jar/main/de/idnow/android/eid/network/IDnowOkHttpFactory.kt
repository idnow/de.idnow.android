package de.idnow.android.eid.network

import android.os.Build
import de.idnow.android.eid.BuildConfig
import de.idnow.android.eid.eIDSdk
import de.idnow.android.eid.util.Util_Log
import okhttp3.ConnectionSpec
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.TlsVersion
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

class IDnowOkHttpFactory {
    companion object {
        private const val LOGTAG = "IDNOW_IDnowOkHttpFactory"
        private const val DEFAULT_READ_TIMEOUT_SECONDS = 60L
        private const val DEFAULT_CONNECT_TIMEOUT_SECONDS = 10L
        private const val DEFAULT_WRITE_TIMEOUT_SECONDS = 10L

        fun createOkHttpClient(
            readTimeoutSeconds: Long = DEFAULT_READ_TIMEOUT_SECONDS,
            connectTimeoutSeconds: Long = DEFAULT_CONNECT_TIMEOUT_SECONDS,
            writeTimeoutSeconds: Long = DEFAULT_WRITE_TIMEOUT_SECONDS,
            networkInterceptor: Interceptor? = null,
            logInterceptor: Interceptor? = null
        ): OkHttpClient? {
            val client: OkHttpClient.Builder?

            Util_Log.i(LOGTAG, "API LEVEL" + Build.VERSION.SDK_INT)

            try {
                val connectionSpec: ConnectionSpec =
                    ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS)
                        .tlsVersions(TlsVersion.TLS_1_2)
                        .cipherSuites(*provideCiphers())
                        .build()

                if (eIDSdk.getAllowInvalidCertificates()) {
                    if (eIDSdk.getAllowHttpConnections()) {
                        val httpSpec: ConnectionSpec =
                            ConnectionSpec.Builder(ConnectionSpec.CLEARTEXT).build()
                        client = OkHttpClient.Builder()
                            .hostnameVerifier(provideHostNameVerifier())
                            .connectionSpecs(listOf(httpSpec))
                    } else {
                        val sslContext = SSLContext.getInstance("SSL")
                        sslContext.init(
                            null,
                            IdnowTrustManagerFactory.createTrustAllManager(),
                            SecureRandom()
                        )

                        client = OkHttpClient.Builder()
                            .sslSocketFactory(
                                sslContext.socketFactory,
                                IdnowTrustManagerFactory.createTrustAllManager()[0] as X509TrustManager
                            )
                            .hostnameVerifier(provideHostNameVerifier())
                            .connectionSpecs(listOf(connectionSpec))
                    }
                } else {
                    client = OkHttpClient.Builder()
                        .sslSocketFactory(
                            HttpsURLConnection.getDefaultSSLSocketFactory(),
                            IdnowTrustManagerFactory.createSystemTrustManager()
                        )
                        .connectionSpecs(listOf(connectionSpec))
                }

                client.readTimeout(readTimeoutSeconds, TimeUnit.SECONDS)
                    .connectTimeout(connectTimeoutSeconds, TimeUnit.SECONDS)
                    .writeTimeout(writeTimeoutSeconds, TimeUnit.SECONDS)
            } catch (e: Exception) {
                Util_Log.e(LOGTAG, "Create OkHttpClient failed", e)
                return null
            }

            networkInterceptor?.let(client::addInterceptor)
            logInterceptor?.takeIf { eIDSdk.isLoggingEnabled() && BuildConfig.DEBUG }
                ?.let(client::addInterceptor)

            return client.build()
        }

        private fun provideHostNameVerifier(): HostnameVerifier =
            HostnameVerifier { _, _ -> true }

        private fun provideCiphers(): Array<String> {
            return arrayOf(
                "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256",
                "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
                "TLS_RSA_WITH_AES_128_GCM_SHA256"
            )
        }
    }
}