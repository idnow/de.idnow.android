package de.idnow.android.eid.fragments;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.UI.HeaderView;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.util.Util_Status;
import de.idnow.android.eid.util.Util_Strings;
import kotlin.Unit;

public class Fragment_Verify extends BaseFragment {

    public LottieAnimationView verify_animation;
    public TextView verify_title, verify_desc;

    Context context;

    private HeaderView header;

    public Fragment_Verify() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_verify, container, false);

        eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_PREPARING_SIGNING_SHOWN);
        eIDSdk.startEvent(eIDSdk.EVENT_EID_QES_PREPARING_SIGNING_TIME_SPENT);

        context = getContext();

        header = view.findViewById(R.id.header);
        verify_animation = view.findViewById(R.id.verify_animation);

        verify_title = view.findViewById(R.id.verify_title);
        verify_desc = view.findViewById(R.id.verify_desc);

        header.setCancelAction(() -> {
            Config.CANCEL_REASON = "EID_USER_CANCELLATION_PREPARE_SIGNING";
            ((eIDActivity) context).getVisibleFragment();
            return Unit.INSTANCE;
        });

        if (Config.SIGNING_SCREEN.equals(Util_Status.SCREEN_PREPARE_SIGNING)) {
            verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_VERIFY_TITLE, Util_Strings.LOCAL_KEY_EID_ESIGN_VERIFY_TITLE));
            verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_VERIFY_DESC, Util_Strings.LOCAL_KEY_EID_ESIGN_VERIFY_DESC));

        } else if (Config.SIGNING_SCREEN.equals(Util_Status.SCREEN_DOCUMENTS_SIGNING)) {
            verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_DOCUMENTS_TITLE, Util_Strings.LOCAL_KEY_EID_ESIGN_DOCUMENTS_TITLE));
            verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_DOCUMENTS_DESC, Util_Strings.LOCAL_KEY_EID_ESIGN_DOCUMENTS_DESC));
        }

        verify_animation.setAnimation("loading.json");
        verify_animation.setRepeatCount(ValueAnimator.INFINITE);
        verify_animation.playAnimation();

        Handler handler = new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (Config.SIGNING_SCREEN.equals(Util_Status.SCREEN_PREPARE_SIGNING)) {
                    Fragment_OTP fragment_otp = new Fragment_OTP();
                    if (!Config.DISPLAY_OTP_SIGNING) {
                        fragment_otp.prepareSigningSessionRestCall(context, Fragment_Verify.this, getActivity());
                    } else {
                        Config.OTP_SCREEN = Util_Status.SCREEN_PHONE_NUMBER_CONFIRM_UPDATE;
                        ((eIDActivity) getActivity()).hideIntroFragment(Fragment_Verify.this);
                        ((eIDActivity) getActivity()).showIntroFragment(fragment_otp);
                    }
                } else if (Config.SIGNING_SCREEN.equals(Util_Status.SCREEN_DOCUMENTS_SIGNING)) {
                    Config.OTP_SCREEN = Util_Status.SCREEN_PHONE_NUMBER_CONFIRM_UPDATE;
                    Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();
                    ((eIDActivity) getActivity()).hideIntroFragment(Fragment_Verify.this);
                    ((eIDActivity) getActivity()).showIntroFragment(fragment_verificationStatus);
                }
            }
        }, 2000);


        return view;
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_Verify.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_Verify.class);
    }

}