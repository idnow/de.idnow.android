package de.idnow.android.eid.models;

public class Models_Data {
    String type;
    String idType;
    String idCountry;
    String url;
    String originator;
    String timestamp;
    String content;

    String consentProtocolVersion;


    public Models_Data(String idType, String idCountry, String url, String consentProtocolVersion) {
        this.consentProtocolVersion = consentProtocolVersion;
        this.idCountry = idCountry;
        this.idType = idType;
        this.url = url;
    }

    public Models_Data(String idType, String idCountry) {
        this.idCountry = idCountry;
        this.idType = idType;
    }

    public Models_Data(String type) {
        this.type = type;
    }

    public Models_Data() {
    }

    public String getConsentProtocolVersion() {
        return consentProtocolVersion;
    }

    public String getOriginator() {
        return originator;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getContent() {
        return content;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
}

