package de.idnow.android.eid.fragments;

import static de.idnow.android.eid.util.Util.redirection;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;

import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.UI.HeaderView;
import de.idnow.android.eid.UI.SubtitleView;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.util.Util_Strings;
import kotlin.Unit;

public class Fragment_choose_eID_type extends BaseFragment {

    TextView german_card_text, german_residence_textview, eu_card_text, try_video_ident, not_listed;
    Context context;
    ImageButton eu_arrow, german_arrow, residence_arrow;
    CardView german_card, german_residence, eu_card;
    HeaderView header;
    SubtitleView subtitle;

    public Fragment_choose_eID_type() {
        super(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_choose_eid_type, container, false);

        context = getContext();
        header = view.findViewById(R.id.header);
        subtitle = view.findViewById(R.id.subtitle);
        german_card = view.findViewById(R.id.german_card);
        german_residence = view.findViewById(R.id.german_residence);
        eu_card = view.findViewById(R.id.eu_card);

        german_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Config.CARD_TYPE = "GERMAN";
                Fragment_PIN_digit_chooser fragment_pin_digit_chooser = new Fragment_PIN_digit_chooser();
                ((eIDActivity) context).hideIntroFragment(Fragment_choose_eID_type.this);
                ((eIDActivity) context).showIntroFragment(fragment_pin_digit_chooser);
            }
        });

        german_residence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Config.CARD_TYPE = "GERMAN";
                Fragment_PIN_digit_chooser fragment_pin_digit_chooser = new Fragment_PIN_digit_chooser();
                ((eIDActivity) context).hideIntroFragment(Fragment_choose_eID_type.this);
                ((eIDActivity) context).showIntroFragment(fragment_pin_digit_chooser);
            }
        });

        eu_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Config.CARD_TYPE = "EU";
                Fragment_PIN_digit_chooser fragment_pin_digit_chooser = new Fragment_PIN_digit_chooser();
                ((eIDActivity) context).hideIntroFragment(Fragment_choose_eID_type.this);
                ((eIDActivity) context).showIntroFragment(fragment_pin_digit_chooser);
            }
        });


        not_listed = view.findViewById(R.id.not_listed);
        german_card_text = view.findViewById(R.id.german_card_text);
        german_residence_textview = view.findViewById(R.id.german_residence_text);
        eu_card_text = view.findViewById(R.id.german_eu_text);
        eu_arrow = view.findViewById(R.id.eu_arrow);
        german_arrow = view.findViewById(R.id.card_de_arrow);
        residence_arrow = view.findViewById(R.id.residence_german_arrow);

        try_video_ident = view.findViewById(R.id.try_video_ident);

        not_listed.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_DONT_HAVE_LISTED, Util_Strings.LOCAL_KEY_EID_DONT_HAVE_LISTED));
        header.setTitle(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_CHOOSE_EID_TYPE, Util_Strings.LOCAL_KEY_EID_CHOOSE_EID_TYPE));
        subtitle.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_I_HAVE, Util_Strings.LOCAL_KEY_EID_I_HAVE));
        german_card_text.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_GERMAN_ID_CARD, Util_Strings.LOCAL_KEY_EID_GERMAN_ID_CARD));
        german_residence_textview.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_GERMAN_RESIDENCE_CARD, Util_Strings.LOCAL_KEY_EID_GERMAN_RESIDENCE_CARD));
        eu_card_text.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_EU_CITIZEN, Util_Strings.LOCAL_KEY_EID_EU_CITIZEN));
        try_video_ident.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_VERIFY_YOURSELF, Util_Strings.LOCAL_KEY_EID_VERIFY_YOURSELF));

        header.setCancelAction(() -> {
            Config.CANCEL_REASON = "EID_USER_CANCELLATION_DOCUMENT_TYPE";
            ((eIDActivity) context).getVisibleFragment();
            return Unit.INSTANCE;
        });

        try_video_ident.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Config.STANDALONE_EID) {
                    redirection(context, Config.RESULT_CODE_FALLBACK_VID);
                }
            }
        });

        return view;
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_choose_eID_type.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_choose_eID_type.class);
    }
}