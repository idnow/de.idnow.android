package de.idnow.android.eid.Authada

import android.app.Activity
import de.authada.library.api.AuthadaAuthenticationLibrary
import de.authada.library.api.AuthadaAuthenticationLibraryConfig
import de.authada.library.api.authentication.Authentication
import de.idnow.android.eid.BuildConfig
import de.idnow.android.eid.eIDSdk.Server
import de.idnow.android.eid.util.Util_Log
import java.net.URL

internal object AuthadaAuthenticationWrapper {
    private const val LOG_TAG = "IDnow_AuthadaAuthenticationWrapper"

    private lateinit var authentication: Authentication

    private var stagingUrl = BuildConfig.AUTHADA_STAGING_URL
    private const val STAGING_CERT_HASH_1 = BuildConfig.AUTHADA_STAGING_CERT_HASH_1
    private const val STAGING_CERT_HASH_2 = BuildConfig.AUTHADA_STAGING_CERT_HASH_2
    private var productionUrl = BuildConfig.AUTHADA_PRODUCTION_URL
    private const val PRODUCTION_CERT_HASH_1 = BuildConfig.AUTHADA_PRODUCTION_CERT_HASH_1
    private const val PRODUCTION_CERT_HASH_2 = BuildConfig.AUTHADA_PRODUCTION_CERT_HASH_2

    fun isAuthenticationInitialized(): Boolean =
        ::authentication.isInitialized

    fun getAuthentication(): Authentication =
        authentication

    @JvmStatic
    fun createNewAuthentication(
        activity: Activity,
        server: Server
    ) {
        val config = AuthadaAuthenticationLibraryConfig
            .newInstance(
                endpoint = URL(server.getEndpoint()),
                certHash = server.getCertHashes(),
                activity = activity
            )
        authentication = AuthadaAuthenticationLibrary.authenticate(config)
        Util_Log.i(LOG_TAG, "Authentication created")
    }

    @JvmStatic
    fun setStagingUrl(url: String) {
        stagingUrl = url
    }

    @JvmStatic
    fun setProductionUrl(url: String) {
        productionUrl = url
    }

    private fun Server.getEndpoint(): String =
        if (this in listOf(Server.LIVE, Server.INT)) productionUrl else stagingUrl

    private fun Server.getCertHashes(): List<String> {
        return if (this in listOf(Server.LIVE, Server.INT))
            listOf(PRODUCTION_CERT_HASH_1, PRODUCTION_CERT_HASH_2)
        else
            listOf(STAGING_CERT_HASH_1, STAGING_CERT_HASH_2)
    }
}