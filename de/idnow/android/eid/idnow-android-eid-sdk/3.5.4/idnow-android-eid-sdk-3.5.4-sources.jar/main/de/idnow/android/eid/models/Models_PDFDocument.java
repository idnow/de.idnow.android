package de.idnow.android.eid.models;

public class Models_PDFDocument {

    String name;
    String version;
    String hash;
    String displayHash;
    Models_DocumentDefinition documentDefinition;

    public Models_PDFDocument(String name, String version, String hash, String displayHash, Models_DocumentDefinition documentDefinition) {
        this.name = name;
        this.version = version;
        this.hash = hash;
        this.displayHash = displayHash;
        this.documentDefinition = documentDefinition;
    }

    public Models_DocumentDefinition getDocumentDefinition() {
        return documentDefinition;
    }

    public void setDocumentDefinition(Models_DocumentDefinition documentDefinition) {
        this.documentDefinition = documentDefinition;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getDisplayHash() {
        return displayHash;
    }

    public void setDisplayHash(String displayHash) {
        this.displayHash = displayHash;
    }

    @Override
    public String toString() {
        return "Models_PDFDocument{" +
                "name='" + name + '\'' +
                ", version='" + version + '\'' +
                ", hash='" + hash + '\'' +
                ", displayHash='" + displayHash + '\'' +
                ", documentDefinition=" + documentDefinition +
                '}';
    }
}