package de.idnow.android.eid.util;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

import de.idnow.android.eid.models.Models_HashMapWrapperStringBoolean;

public class Util_Photo {

    public static String LOGTAG = "IDNOW_Util_Photo";

    // shared prefs
    public static final String SHARED_PREFS_NAME = "de.idnow";
    public static final String SHARED_PREFS_KEY = "hashmap";

    public static final String SERVER_STRING_IDFRONTSIDE = "IDFRONTSIDE";
    public static final String SERVER_STRING_IDBACKSIDE = "IDBACKSIDE";

    public enum DocumentImages {
        idfrontside,
        idbackside
    }

    public static void updateHashMap(@Nullable Util_Photo.DocumentImages imageType, boolean value, Context context) {
        if (imageType != null) {
            Map<String, Boolean> imageDocumentTakenHashMap = new HashMap<>();
            imageDocumentTakenHashMap.put(imageType.toString(), value);

            Gson gson = new Gson();
            Models_HashMapWrapperStringBoolean wrapper = new Models_HashMapWrapperStringBoolean(imageDocumentTakenHashMap);
            String serializedMap = gson.toJson(wrapper);

            SharedPreferences prefs = context.getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().putString(SHARED_PREFS_KEY, serializedMap).apply();
        }
    }

    public static @NonNull
    String getServerStringFromDocumentImageType(@Nullable DocumentImages imageType) {
        if (imageType != null) {
            switch (imageType) {
                case idbackside:
                    return SERVER_STRING_IDBACKSIDE;
                case idfrontside:
                    return SERVER_STRING_IDFRONTSIDE;
                default:
                    return "UNDEFINDED";
            }
        }

        return "UNDEFINDED";
    }
}
