package de.idnow.android.eid.util;

public class Util_Status {

    public static String ON_ADDITIONAL_DATA_REQUIRED = "onAdditionalDataRequired";

    public static String ON_AUTHENTIFCATION_PROGRESS = "onAuthenticationProgress";

    public static String ON_CONNECTION_TIMEOUT_START = "onConnectionTimeout";

    public static String ON_SUCCESS_START = "onSuccess Start";


    public static String ON_EID_CARD_CHECK_FAILED = "onEidCardCheckFailed";

    public static String ON_EID_CARD_FOUND = "onEidCardFound";

    public static String ON_EID_CARD_LOST = "onEidCardLost";

    public static String ON_PROCESS_TERMINATED_START = "onProcessTerminated";

    public static String ON_SECRET_WRONG = "onSecretWrong";

    public static String ON_SUCCESS_PIN = "onSuccess PIN";

    public static String ON_PROCESS_TERMINATED_PIN = "onProcessTerminated";

    public static String ON_CONNECTION_TIMEOUT_PIN = "onConnectionTimeout";

    public static String ON_EID_OTHER = "Other";

    public static String ON_EID_NOT_ATTACHED = "EID Not Attached";

    public static String ON_EID_ATTACHED = "EID Attached";

    public static String ON_EID_FAILURE_SEDNDING_PIN = "RESUTLTOKENFAILURE";

    public static String ON_EID_SUCCESS_SENDING_PIN = "RESUTLTOKENSUCCESS";

    /// CAN

    public static String FIRST_CAN_CHECK_PIN_CHECK_DONE = "CAN 1st time";
    public static String CAN_WRONG_PIN_CHECK_NOT_DONE = "CAN wrong";
    public static String FIRST_CAN_CHECK_PIN_CHECK_NOT_DONE = "PIN not done";

    //

    public static String SCREEN_PHONE_NUMBER_CONFIRM_UPDATE = "confirm mobile number";
    public static String SCREEN_PHONE_NUMBER_OTP = "verification code";

    public static String SCREEN_PREPARE_SIGNING = "prepare signing";
    public static String SCREEN_DOCUMENTS_SIGNING = "documents signing";


}
