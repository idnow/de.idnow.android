package de.idnow.android.eid.network;

import de.idnow.android.eid.models.Model_Classification;
import de.idnow.android.eid.models.Model_StartCall;
import de.idnow.android.eid.models.Model_StartObject;
import de.idnow.android.eid.models.Model_failedReason;
import de.idnow.android.eid.models.Models_ApprovalPhrase;
import de.idnow.android.eid.models.Models_ConfirmationToken;
import de.idnow.android.eid.models.Models_DocumentInfo;
import de.idnow.android.eid.models.Models_EmptyJson;
import de.idnow.android.eid.models.Models_MobileNumber;
import de.idnow.android.eid.models.Models_PDFDocument;
import de.idnow.android.eid.models.Models_ResultToken;
import de.idnow.android.eid.models.Models_requestStep;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;


public interface Network_RESTCalls {

    @POST("/api/v1/{companyShort}/eid/{transactionToken}/start")
    Call<Model_StartCall> start(@Body Model_StartObject modelStartObject, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

    @POST("/api/v1/{companyShort}/eid/{transactionToken}/startEid")
    Call<Model_StartCall> startEid(@Body Model_StartObject modelStartObject, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

    @POST("/api/v1/{companyShort}/identifications/{transactionToken}/uploadImage/{type}")
    Call<Model_Classification> uploadImage(@Body RequestBody screenshot, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort, @Path("type") String type);

    @GET("/api/v1/{companyShort}/identifications/{transactionToken}/classification")
    Call<Object> getClassification(@Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

    @POST("/api/v1/{companyShort}/identifications/{transactionToken}/uploadDocumentInfo")
    Call<Object> uploadDocumentInfo(@Body Models_DocumentInfo models_documentInfo, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

    @POST("/api/v1/{companyShort}/identifications/{transactionToken}/updateMobileNumber")
    Call<Models_EmptyJson> updateMobileNumber(@Body Models_MobileNumber number, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

    @GET("/api/v1/{companyShort}/identifications/{transactionToken}/approvalPhrases")
    Call<Models_ApprovalPhrase[]> getApprovalPhrases(@Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

    @GET("/api/v1/{companyShort}/identifications/{transactionToken}/documents")
    Call<Models_PDFDocument[]> getDocuments(@Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

    @POST("/api/v1/{companyShort}/identifications/{transactionToken}/prepareSigningSession")
    Call<Models_EmptyJson> prepareSigningSession(@Body Models_EmptyJson models_emptyJson, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken, @Header("Identification-Signature") String header);

    @POST("/api/v1/{companyShort}/eid/resultWithToken")
    Call<Void> sendResultToken(@Body Models_ResultToken models_resultToken, @Path("companyShort") String companyShort);

    @POST("/api/v1/{companyShort}/identifications/{transactionToken}/resendConfirmationToken")
    Call<Object> resendConfirmationToken(@Body Models_MobileNumber mobile, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken, @Header("Identification-Signature") String header);

    @POST("/api/v1/{companyShort}/identifications/{transactionToken}/sendConfirmationToken")
    Call<Object> sendConfirmationToken(@Body Models_ConfirmationToken models_confirmationToken, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

    @POST("/api/v1/{companyShort}/eid/{transactionToken}/changeStep")
    Call<Models_EmptyJson> changeStep(@Body Models_requestStep models_requestStep, @Path("companyShort") String companyShort, @Path("transactionToken") String transactionToken);

    @POST("/api/v1/{companyShort}/identifications/{transactionToken}/canceled")
    Call<Object> identificationCanceled(@Body Model_failedReason model_failedReason, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);

    @POST("/api/v1/{companyShort}/identifications/{transactionToken}/failed")
    Call<Object> identificationFailed(@Body Models_EmptyJson emptyJson, @Path("transactionToken") String transactionToken, @Path("companyShort") String companyShort);
}
