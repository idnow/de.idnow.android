package de.idnow.android.eid.models;

public class Models_ApprovalPhraseURL {

    String link;
    public String label;

    String translationKey;

    String action;

    public Models_ApprovalPhraseURL(String link, String translationKey, String label, String action) {
        this.link = link;
        this.label = label;
        this.translationKey = translationKey;
        this.action = action;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getTranslationKey() {
        return translationKey;
    }

    public void setTranslationKey(String translationKey) {
        this.translationKey = translationKey;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    @Override
    public String toString() {
        return "Models_ApprovalPhraseURL{" +
                "action='" + action + '\'' +
                ", link='" + link + '\'' +
                ", label='" + label + '\'' +
                ", translationKey='" + translationKey + '\'' +
                '}';
    }
}