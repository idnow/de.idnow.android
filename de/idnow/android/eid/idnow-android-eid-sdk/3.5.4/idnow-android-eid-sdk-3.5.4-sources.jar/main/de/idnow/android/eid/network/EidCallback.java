package de.idnow.android.eid.network;

import retrofit2.Call;
import retrofit2.Response;

public abstract class EidCallback<T> implements retrofit2.Callback<T> {

    public abstract void success(T resultObject, Response response);

    public abstract void failure(EidError error);

    @Override
    public void onResponse(Call<T> call, Response<T> response) {
        if (response.isSuccessful()) {
            this.success(response.body(), response);
        } else {
            this.failure(EidError.from(response));
        }
    }

    @Override
    public void onFailure(Call<T> call, Throwable t) {
        this.failure(EidError.from(t));
    }
}
