package de.idnow.android.eid.UI

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.util.AttributeSet
import android.util.TypedValue
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import com.airbnb.lottie.LottieAnimationView
import de.idnow.android.eid.eIDSdk

class PoweredByView : LottieAnimationView {
    constructor(context: Context) : super(context) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context, attrs, defStyleAttr
    ) {
        init()
    }

    private fun init() {
        isVisible = eIDSdk.getShowPoweredBy()
        if (isVisible) {
            alpha = 0.2F
            setAnimation(if (isDarkMode()) "static_powered_by_idnow.json" else "static_powered_by_idnow_dark.json")
            playAnimation()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        updateLayoutParams {
            height = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                34F,
                context.resources.displayMetrics
            ).toInt()
        }
        updatePadding(
            top = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                20F,
                context.resources.displayMetrics
            ).toInt()
        )
    }

    private fun isDarkMode(): Boolean {
        val nightModeFlags =
            context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return nightModeFlags == Configuration.UI_MODE_NIGHT_YES
    }
}