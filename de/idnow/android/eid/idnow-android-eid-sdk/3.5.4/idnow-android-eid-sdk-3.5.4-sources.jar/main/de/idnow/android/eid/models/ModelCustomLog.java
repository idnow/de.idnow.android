package de.idnow.android.eid.models;

public class ModelCustomLog {

    public String appKey;
    public String url;

    public String getAppKey() {
        return appKey;
    }

    public String getUrl() {
        return url;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public void setUrl(String url) {
        this.url = url;
    }


}
