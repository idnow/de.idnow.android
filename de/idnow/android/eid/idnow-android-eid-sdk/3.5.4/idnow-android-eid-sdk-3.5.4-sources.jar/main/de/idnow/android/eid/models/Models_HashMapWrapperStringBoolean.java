package de.idnow.android.eid.models;

import java.util.Map;

public class Models_HashMapWrapperStringBoolean {

    private Map<String, Boolean> map;

    /**
     * @param map
     */
    public Models_HashMapWrapperStringBoolean(Map<String, Boolean> map) {
        super();
        this.map = map;
    }

    /**
     * @return the map
     */
    public Map<String, Boolean> getMap() {
        return map;
    }

    /**
     * @param map the map to set
     */
    public void setMap(Map<String, Boolean> map) {
        this.map = map;
    }

}