package de.idnow.android.eid.models;

public class Model_StartObject {
    Models_ClientInfo clientInfo;

    public Model_StartObject(Models_ClientInfo clientInfo) {
        this.clientInfo = clientInfo;
    }

    public Models_ClientInfo getClientInfo() {
        return clientInfo;
    }

    public void setClientInfo(Models_ClientInfo clientInfo) {
        this.clientInfo = clientInfo;
    }
}
