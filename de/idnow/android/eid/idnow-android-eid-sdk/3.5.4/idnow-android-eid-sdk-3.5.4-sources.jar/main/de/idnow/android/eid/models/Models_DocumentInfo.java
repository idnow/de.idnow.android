package de.idnow.android.eid.models;

public class Models_DocumentInfo {

    String idCountry, idType, idSubtype;

    public Models_DocumentInfo() {
    }

    public Models_DocumentInfo(String idCountry, String idType) {
        this.idCountry = idCountry;
        this.idType = idType;
    }


    public String getIdCountry() {
        return idCountry;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdCountry(String idCountry) {
        this.idCountry = idCountry;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getidSubtype() {
        return idSubtype;
    }

    public void setidSubtype(String idSubtype) {
        this.idSubtype = idSubtype;
    }

}
