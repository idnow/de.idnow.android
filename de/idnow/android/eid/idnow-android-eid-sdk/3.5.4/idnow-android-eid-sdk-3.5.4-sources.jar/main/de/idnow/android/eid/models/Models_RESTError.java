package de.idnow.android.eid.models;


import com.google.gson.annotations.SerializedName;

public class Models_RESTError {
    @SerializedName("id")
    public int id;

    @SerializedName("cause")
    public String cause;

    @SerializedName("errorType")
    public String errorType;

    @SerializedName("key")
    public String key;

    @SerializedName("message")
    public String message;
}
