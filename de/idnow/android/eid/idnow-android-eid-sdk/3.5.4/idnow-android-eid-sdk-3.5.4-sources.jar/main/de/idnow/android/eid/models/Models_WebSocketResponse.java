package de.idnow.android.eid.models;


/**
 * @author Mathias Grasy
 * @version 1.0
 * @date 10.10.2014
 * @brief received when the server sends a socket response. contains a command, some extra data and information about the agent
 */


public class Models_WebSocketResponse {
    String command;
    Models_Employee employee;
    Models_Data data;
    Models_NextStep nextStep;


    public Models_WebSocketResponse(String command, Models_Employee employee, Models_Data data, Models_NextStep nextStep) {
        this.command = command;
        this.employee = employee;
        this.data = data;
        this.nextStep = nextStep;
    }

    public Models_WebSocketResponse() {

    }

    public Models_NextStep getNextStep() {
        return nextStep;
    }

    public void setNextStep(Models_NextStep nextStep) {
        this.nextStep = nextStep;
    }

    public Models_Data getData() {
        return data;
    }

    public void setData(Models_Data data) {
        this.data = data;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public String getCommand() {
        return this.command;
    }

    public void setEmployee(Models_Employee employee) {
        this.employee = employee;
    }

    public Models_Employee getEmployee() {
        return this.employee;
    }
}
