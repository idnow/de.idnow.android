package de.idnow.android.eid.network;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.ContextThemeWrapper;

import de.idnow.android.eid.R;
import de.idnow.android.eid.UI.DialogShowable;
import de.idnow.android.eid.util.Util_Strings;

public class SocketTimeoutExceptionThrowable extends Throwable implements DialogShowable {

    SocketTimeoutExceptionThrowable(String msg, Context context) {

        Activity activity = (Activity) context;
        activity.runOnUiThread(new Runnable() {
            public void run() {
                showDialog(context);

            }
        });
    }

    @Override
    public void showDialog(Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.IDnowAlertDialogStyle));

        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setMessage(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SOCKET_CONNECTION_TIMED_OUT, Util_Strings.LOCAL_KEY_EID_SOCKET_CONNECTION_TIMED_OUT))
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        if (!((Activity) context).isFinishing()) {
            // show it
            alertDialog.show();
        }
    }
}
