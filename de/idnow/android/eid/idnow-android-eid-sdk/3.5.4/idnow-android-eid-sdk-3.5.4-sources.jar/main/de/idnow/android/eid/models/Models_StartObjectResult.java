package de.idnow.android.eid.models;

import com.google.gson.annotations.SerializedName;

public class Models_StartObjectResult {
    @SerializedName("sessionToken")
    public String sessionToken;
    @SerializedName("mobileToken")
    public String mobileToken;
    public Models_Request request;

    @SerializedName("enableOTP")
    public Model_EnableOTP modelEnableOTP;


    public Models_StartObjectResult(String sessionToken, String mobileToken, Models_Request request) {
        this.sessionToken = sessionToken;
        this.mobileToken = mobileToken;
        this.request = request;
    }

    public Models_StartObjectResult(Model_EnableOTP modelEnableOTP, Models_Request request, String mobileToken, String sessionToken) {
        this.modelEnableOTP = modelEnableOTP;
        this.request = request;
        this.mobileToken = mobileToken;
        this.sessionToken = sessionToken;
    }

    public String getSessionToken() {
        return sessionToken;
    }

    public void setSessionToken(String sessionToken) {
        this.sessionToken = sessionToken;
    }

    public String getMobileToken() {
        return mobileToken;
    }

    public void setMobileToken(String mobileToken) {
        this.mobileToken = mobileToken;
    }

    public Models_Request getRequest() {
        return request;
    }

    public void setRequest(Models_Request request) {
        this.request = request;
    }

    public Model_EnableOTP getModelEnableOTP() {
        return modelEnableOTP;
    }

    public void setModelEnableOTP(Model_EnableOTP modelEnableOTP) {
        this.modelEnableOTP = modelEnableOTP;
    }
}

