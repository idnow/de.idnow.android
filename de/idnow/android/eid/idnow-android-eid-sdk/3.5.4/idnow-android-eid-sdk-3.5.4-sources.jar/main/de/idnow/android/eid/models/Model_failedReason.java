package de.idnow.android.eid.models;

public class Model_failedReason {
    String failedReason;


    public Model_failedReason(String failedReason) {
        this.failedReason = failedReason;
    }

    public String getFailedReason() {
        return failedReason;
    }

    public void setFailedReason(String failedReason) {
        this.failedReason = failedReason;
    }
}
