package de.idnow.android.eid.util;

import android.util.Log;

import de.idnow.android.eid.BuildConfig;
import de.idnow.android.eid.eIDSdk;

public class Util_Log {
    public static void i(String tag, String string) {
        if (checkDebugLogsEnabled())
            Log.i(tag, string);
    }

    public static void e(String tag, String string) {
        if (checkErrorLogsEnabled())
            Log.e(tag, string);
    }

    public static void e(String tag, String string, Throwable e) {
        if (checkErrorLogsEnabled())
            Log.e(tag, string, e);
    }

    public static void d(String tag, String string) {
        if (checkDebugLogsEnabled())
            Log.d(tag, string);
    }

    public static void v(String tag, String string) {
        if (checkDebugLogsEnabled())
            Log.v(tag, string);
    }

    public static void w(String tag, String string) {
        if (checkDebugLogsEnabled())
            Log.w(tag, string);
    }

    private static boolean checkErrorLogsEnabled() {
        return eIDSdk.isLoggingEnabled();
    }

    private static boolean checkDebugLogsEnabled() {
        return eIDSdk.isLoggingEnabled() && BuildConfig.DEBUG;
    }
}
