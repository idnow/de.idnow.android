package de.idnow.android.eid.models;


/**
 * @author Mathias Grasy
 * @version 1.0
 * @date 10.10.2014
 * @brief is send in the start call, including information about the device
 */


public class Models_StartObject {
    String token;
    String mobile;
    Models_Data data;
    String email;

    Models_ClientInfo clientInfo;
    Boolean authenticatedRequest;

    public Models_StartObject(String token, String mobileNumber, String email, Models_ClientInfo clientInfo, Models_Data data) {
        this.token = token;
        this.mobile = mobileNumber;
        this.clientInfo = clientInfo;
        this.data = data;
    }

    public Models_StartObject(String token, Models_ClientInfo clientInfo) {
        this.token = token;
        this.clientInfo = clientInfo;
    }

    public Models_StartObject(String token, String mobile, Models_Data data, String email, Models_ClientInfo clientInfo, Boolean authenticatedRequest) {
        this.token = token;
        this.mobile = mobile;
        this.data = data;
        this.email = email;
        this.clientInfo = clientInfo;
        this.authenticatedRequest = authenticatedRequest;
    }

    @Override
    public String toString() {
        return "Models_StartObject{" +
                "token='" + token + '\'' +
                ", mobile='" + mobile + '\'' +
                ", data=" + data +
                ", email='" + email + '\'' +
                ", clientInfo=" + clientInfo +
                ", authenticatedRequest=" + authenticatedRequest +
                '}';
    }
}

