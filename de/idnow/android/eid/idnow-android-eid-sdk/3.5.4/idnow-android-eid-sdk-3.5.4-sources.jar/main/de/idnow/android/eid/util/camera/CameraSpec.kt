package de.idnow.android.eid.util.camera

data class CameraSpec(
    val ids: List<String>,
    val lensFacing: Int,
    val type: CameraType,
    val hasAutofocus: Boolean = false
)

enum class CameraType {
    BACK,
    FRONT
}