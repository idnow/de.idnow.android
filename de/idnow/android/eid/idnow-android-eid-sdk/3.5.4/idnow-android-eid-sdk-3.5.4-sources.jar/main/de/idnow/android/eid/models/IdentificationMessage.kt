package de.idnow.android.eid.models

import com.google.gson.annotations.SerializedName

data class IdentificationMessage(
    val msg: String = "",
    val success: String = "",
    val name: String = "",
    val card: Card? = null,
    val reader: Reader? = null,
    val result: Result? = null,
    val chat: AccessRightPayload? = null,
    val validity: CertificateValidity? = null,
    val description: CertificateInfo? = null,
    val url: String? = null,
    val progress: String? = null,
    val state: String? = null,
    val workflow: WorkflowProgressType? = null
) {
    // TODO add description param for certificates
    override fun toString(): String {
        return "Message(msg='$msg', name='$name', card=$card, result=$result, chat=$chat, reader=$reader, url=$url)"
    }

    enum class WorkflowProgressType {
        @SerializedName("AUTH")
        AUTHENTICATION,

        @SerializedName("CHANGE_PIN")
        CHANGE_PIN
    }
}

/**
 * List of all types of WorkflowProgress
 */


class CertificateInfo {
    val issuerName: String = ""
    val issuerUrl: String = ""
    val purpose: String = ""
    val subjectName: String = ""
    val subjectUrl: String = ""
    val termsOfUsage: String = ""
    override fun toString(): String {
        return "CertificateInfo(issuerName=$issuerName, purpose=$purpose, subjectName=$subjectName)"
    }
}

class CertificateValidity {
    val effectiveDate: String = ""
    val expirationDate: String = ""
    override fun toString(): String {
        return "CertificateValidity(effectiveDate=$effectiveDate, expirationDate=$expirationDate)"
    }
}

class AccessRightPayload {
    val effective: List<String>? = null;
    val optional: List<String>? = null;
    val required: List<String>? = null;
    override fun toString(): String {
        return "AccessRightPayload(effective=$effective, optional=$optional, required=$required)"
    }
}

class Reader {
    val card: Card? = null
    override fun toString(): String {
        return "Reader(card=$card)"
    }
}

class Card {
    val deactivated: Boolean = true;
    val inoperative: Boolean = false;
    val retryCounter: Int = -1;
    override fun toString(): String {
        return "Card(deactivated=$deactivated, inoperative=$inoperative, retryCounter=$retryCounter)"
    }
}

class Result {
    val major: String = ""
    val url: String = ""
    val description: String = ""
    val minor: String = ""
    val message: String = ""
    val reason: String = ""
    override fun toString(): String {
        return "Result(major='$major',minor='$minor',reason='$reason' url='$url', description='$description', message='$message')"
    }
}