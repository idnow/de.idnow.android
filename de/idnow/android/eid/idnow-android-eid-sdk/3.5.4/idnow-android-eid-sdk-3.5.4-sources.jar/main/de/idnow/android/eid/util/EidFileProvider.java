package de.idnow.android.eid.util;

import androidx.core.content.FileProvider;

public class EidFileProvider extends FileProvider {
}
