package de.idnow.android.eid.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import de.idnow.android.eid.R;
import de.idnow.android.eid.util.Util_Log;

public class CustomAdapter extends BaseAdapter {
    private final String LOGTAG = "IDNOW_CustomAdapter";
    Context context;
    int[] flags;
    String[] countryNames;
    ArrayList<JSONObject> stringArrayList;
    LayoutInflater inflter;

    public CustomAdapter(Context applicationContext, int[] flags, String[] countryNames) {
        this.context = applicationContext;
        this.flags = flags;
        this.countryNames = countryNames;
        inflter = (LayoutInflater.from(applicationContext));
    }

    public CustomAdapter(Context applicationContext, ArrayList<JSONObject> stringArrayList) {
        this.context = applicationContext;
        this.stringArrayList = stringArrayList;
        inflter = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        //return flags.length;
        return stringArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.item_country, null);
        ImageView icon = view.findViewById(R.id.imageView);
        TextView names = view.findViewById(R.id.textView);
        LinearLayout spinnerBackground = view.findViewById(R.id.spinnerBackground);

        spinnerBackground.setBackgroundResource(R.drawable.background_textfield);

        int drawableID = 0;
        try {
            drawableID = context.getResources().getIdentifier("flag_" + stringArrayList.get(i).getString("code").toLowerCase(), "drawable", context.getPackageName());
            names.setText(stringArrayList.get(i).getString("name") + " " + stringArrayList.get(i).getString("dial_code"));
            icon.setImageResource(drawableID);

        } catch (JSONException e) {
            Util_Log.e(LOGTAG, "Parse countries json failed", e);
        }


        return view;
    }


}

