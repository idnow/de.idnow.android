package de.idnow.android.eid.UI

import android.content.Context
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import de.idnow.android.eid.R
import de.idnow.android.eid.databinding.HeaderViewBinding
import de.idnow.android.eid.eIDSdk

class HeaderView : ConstraintLayout {
    private enum class PaddingType(val dp: Int) {
        SMALL(27),
        LARGE(126)
    }

    private enum class TextAlign {
        START,
        CENTER
    }

    private lateinit var binding: HeaderViewBinding
    private var titlePadding = PaddingType.SMALL

    constructor(context: Context) : super(context) {
        init(null)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(attrs)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context, attrs, defStyleAttr
    ) {
        init(attrs)
    }

    private fun init(attrs: AttributeSet?) {
        binding = HeaderViewBinding.inflate(LayoutInflater.from(context), this)
        readTitleAttrs(attrs)
        setupTitlePadding()
        if (eIDSdk.getShowIDnowLogo()) {
            binding.logo.visibility = View.VISIBLE
            binding.logo.setAnimation("static_logo.json")
        } else {
            binding.logo.visibility = INVISIBLE
        }
    }

    private fun readTitleAttrs(attrs: AttributeSet?) {
        val styleableAttrs = context.theme.obtainStyledAttributes(
            attrs ?: return, R.styleable.HeaderView, 0, 0
        )
        try {
            //visibility
            binding.title.isVisible = styleableAttrs.getBoolean(
                R.styleable.HeaderView_titleVisible,
                true
            )
            //top padding
            titlePadding = styleableAttrs.getInt(
                R.styleable.HeaderView_titleTopPadding,
                PaddingType.entries.indexOf(PaddingType.SMALL)
            ).let { PaddingType.entries[it] }
            //text align
            val textAlign = styleableAttrs.getInt(
                R.styleable.HeaderView_titleAlign,
                TextAlign.entries.indexOf(TextAlign.CENTER)
            ).let { TextAlign.entries[it] }
            binding.title.textAlignment = when (textAlign) {
                TextAlign.START -> TEXT_ALIGNMENT_VIEW_START
                TextAlign.CENTER -> TEXT_ALIGNMENT_CENTER
            }
            binding.title.gravity = when (textAlign) {
                TextAlign.START -> Gravity.START
                TextAlign.CENTER -> Gravity.CENTER
            }
            //text
            binding.title.text = styleableAttrs.getString(R.styleable.HeaderView_title) ?: ""
        } finally {
            styleableAttrs.recycle()
        }
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        setupTitlePadding()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        setupTitlePadding()
    }

    private fun setupTitlePadding() {
        val topPadding = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            titlePadding.dp.toFloat(),
            context.resources.displayMetrics
        ).toInt()
        binding.title.setPadding(
            binding.title.paddingLeft,
            topPadding,
            binding.title.paddingRight,
            binding.title.paddingBottom
        )
    }

    fun setTitle(text: String) {
        binding.title.text = text
        binding.title.isVisible = text.isNotBlank()
    }

    fun setCancelAction(action: () -> Unit) {
        binding.cancelButton.setOnClickListener { action() }
    }

    fun setCancelButtonVisibility(isVisible: Boolean) {
        binding.cancelButton.isVisible = isVisible
    }
}