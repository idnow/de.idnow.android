package de.idnow.android.eid.models;

public class Models_ResultToken {

    String resultToken;
    String sessionToken;
    String internalToken;

    public Models_ResultToken(String resultToken, String sessionToken, String internalToken) {
        this.resultToken = resultToken;
        this.sessionToken = sessionToken;
        this.internalToken = internalToken;
    }

    public String getResultToken() {
        return resultToken;
    }

    public void setResultToken(String resultToken) {
        this.resultToken = resultToken;
    }

    public String getSessionToken() {
        return sessionToken;
    }

    public void setSessionToken(String sessionToken) {
        this.sessionToken = sessionToken;
    }

    public String getInternalToken() {
        return internalToken;
    }

    public void setInternalToken(String internalToken) {
        this.internalToken = internalToken;
    }
}
