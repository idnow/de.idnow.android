package de.idnow.android.eid.AusweisApp2SDK.core

import com.google.gson.Gson
import de.idnow.android.eid.models.IdentificationMessage

internal object IdentificationUtil {
    const val MSG_ACCESS_RIGHTS = "ACCESS_RIGHTS"
    const val MSG_ENTER_PIN = "ENTER_PIN"
    const val MSG_ENTER_PUK = "ENTER_PUK"
    const val MSG_ENTER_CAN = "ENTER_CAN"
    const val MSG_INSERT_CARD = "INSERT_CARD"
    const val MSG_INSERT_CERTIFICATE = "CERTIFICATE"
    const val MSG_BAD_STATE = "BAD_STATE"
    const val MSG_READER = "READER"
    const val MSG_CUSTOM_URL = "URL"
    const val MSG_AUTH = "AUTH"
    const val MSG_ENTER_NEW_PIN = "ENTER_NEW_PIN"
    const val MSG_CHANGE_PIN = "CHANGE_PIN"
    const val MSG_STATUS = "STATUS"
    const val MSG_INTERNAL_ERROR = "INTERNAL_ERROR"
    const val MSG_INVALID = "INVALID"
    const val MSG_UNKNOWN_COMMAND = "UNKNOWN_COMMAND"
    const val MSG_PAUSE = "PAUSE"


    const val CMD_RUN_AUTH = "RUN_AUTH"
    const val CMD_GET_CERTIFICATE = "GET_CERTIFICATE"
    const val CMD_ACCEPT = "ACCEPT"
    const val CMD_CANCEL = "CANCEL"
    const val CMD_GET_READER = "GET_READER_LIST"
    const val CMD_SET_NEW_PIN = "SET_NEW_PIN"
    const val CMD_SET_PIN = "SET_PIN"
    const val CMD_SET_PUK = "SET_PUK"
    const val CMD_SET_CAN = "SET_CAN"
    const val CMD_RUN_CHANGE_PIN = "RUN_CHANGE_PIN"
    const val PARAM_TCTOKEN = "tcTokenURL"
    const val PARAM_STATUS = "status"
    const val PARAM_VALUE = "value"
    const val PARAM_CMD = "cmd"
    const val CMD_INTERRUPT = "INTERRUPT"
    const val CMD_CONTINUE = "CONTINUE"

    val gson = Gson()
    fun parseJson(msg: String): IdentificationMessage? {
        return gson.fromJson(msg, IdentificationMessage::class.java)
    }

    fun buildCmdString(cmd: String): String {
        return "{\"$PARAM_CMD\": \"${cmd}\" }"
    }

    fun buildCmdString(cmd: String, payload: Pair<String, String>? = null): String {
        return "{\"$PARAM_CMD\": \"${cmd}\" " + (if (payload != null) ", \"${payload.first}\": \"${payload.second}\"" else "") + "}"
    }

    fun buildCmdString(
        cmd: String,
        payload1: Pair<String, String>? = null,
        payload2: Pair<String, Boolean>? = null
    ): String {
        return "{\"$PARAM_CMD\": \"${cmd}\" " + (if (payload1 != null) ", \"${payload1.first}\": \"${payload1.second}\"" else "") + (if (payload2 != null) ", \"${payload2.first}\": \"${payload2.second}\"" else "") + "}"
    }
}