package de.idnow.android.eid.util;

import android.graphics.Bitmap;

import de.idnow.android.eid.Config;

public class BitmapHelper {

    public static Bitmap calculateAndScaleBitmap(Bitmap img) {

        int scaledWidth, scaledHeight;
        if (img.getWidth() >= img.getHeight()) {
            scaledWidth = Config.SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE;
            scaledHeight = img.getHeight() * Config.SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE / img.getWidth();
        } else {
            scaledHeight = Config.SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE;
            scaledWidth = img.getWidth() * Config.SCREENSHOT_UPLOAD_LONGEST_EDGE_SIZE / img.getHeight();
        }
        return Bitmap.createScaledBitmap(img, scaledWidth, scaledHeight, true);
    }
}
