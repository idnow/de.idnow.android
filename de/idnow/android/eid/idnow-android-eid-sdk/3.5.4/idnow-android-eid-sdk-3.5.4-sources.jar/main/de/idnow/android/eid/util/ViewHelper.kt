package de.idnow.android.eid.util

import android.annotation.SuppressLint
import android.content.Context
import android.view.View
import android.view.ViewGroup
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.marginBottom
import androidx.core.view.marginLeft
import androidx.core.view.marginRight
import androidx.core.view.marginTop
import androidx.core.view.updateLayoutParams

@Suppress("Unused")
object ViewHelper {
    private const val LOG_TAG = "IDNOW_ViewHelper"

    fun applySafeMargins(view: View) = adjust(
        view = view,
        typeMask = WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout(),
        useMargins = true
    )

    fun applySafeTopMargins(view: View) = adjust(
        view = view,
        typeMask = WindowInsetsCompat.Type.statusBars()
                or WindowInsetsCompat.Type.displayCutout(),
        useMargins = true
    )

    fun applySafeBotMargins(view: View) = adjust(
        view = view,
        typeMask = WindowInsetsCompat.Type.navigationBars(),
        useMargins = true
    )

    fun applyScreenSafePadding(
        view: View,
        useStandardHorizontalPadding: Boolean
    )  {
        (view as? ViewGroup)?.apply {
            clipToPadding = false
            clipChildren = false
        }
        val orgLeft = view.paddingLeft
        val orgRight = view.paddingRight
        val orgTop = view.paddingTop
        val orgBottom = view.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                        WindowInsetsCompat.Type.displayCutout()
            )
            val horizontal =
                (v.measuredWidth * (if (useStandardHorizontalPadding) 0.05F else 0F)).toInt()
            val updLeft = orgLeft + bars.left + horizontal
            val updRight = orgRight + bars.right + horizontal
            val updTop = orgTop + bars.top
            val updBottom = orgBottom + bars.bottom
            Util_Log.d(
                LOG_TAG,
                "Insets: top=${bars.top} bottom=${bars.bottom} left=${bars.left} right=${bars.right}"
            )
            v.setPadding(updLeft, updTop, updRight, updBottom)
            insets
        }
    }

    fun applySafeTopPadding(view: View) = adjust(
        view = view,
        typeMask = WindowInsetsCompat.Type.statusBars()
                or WindowInsetsCompat.Type.displayCutout(),
        useMargins = false
    )

    fun applySafeBotPadding(view: View) = adjust(
        view = view,
        typeMask = WindowInsetsCompat.Type.navigationBars(),
        useMargins = false
    )

    private fun adjust(
        view: View,
        @WindowInsetsCompat.Type.InsetsType typeMask: Int,
        useMargins: Boolean
    ) {
        val orgLeft = if (useMargins) view.marginLeft else view.paddingLeft
        val orgRight = if (useMargins) view.marginRight else view.paddingRight
        val orgTop = if (useMargins) view.marginTop else view.paddingTop
        val orgBottom = if (useMargins) view.marginBottom else view.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            val bars = insets.getInsets(typeMask)
            val barsBottom = bars.bottom.takeIf { it != 0 } ?: view.context.getNavigationBarDefaultHeight()
            val updLeft = orgLeft + bars.left
            val updRight = orgRight + bars.right
            val updTop = orgTop + bars.top
            val updBottom = orgBottom + barsBottom
            Util_Log.d(
                LOG_TAG,
                "Insets: top=${bars.top} bottom=${barsBottom} left=${bars.left} right=${bars.right}"
            )
            if (useMargins) {
                v.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                    leftMargin = updLeft
                    topMargin = updTop
                    rightMargin = updRight
                    bottomMargin = updBottom
                }
            } else {
                v.setPadding(updLeft, updTop, updRight, updBottom)
            }
            insets
        }
    }

    @SuppressLint("InternalInsetResource", "DiscouragedApi")
    private fun Context.getNavigationBarDefaultHeight(): Int {
        val resId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId) else 0
    }
}