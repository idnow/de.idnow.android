package de.idnow.android.eid.Authada.keyLocalization

@Suppress("SpellCheckingInspection")
internal enum class AuthadaCertificateKey {
    TERMS_OF_USE,
    SERVICE_PROVIDER,
    URL_OF_SERVICE_PROVIDER,
    CERTIFICATE_ISSUER,
    URL_OF_CERTIFICATE_ISSUER,
    TRANSACTION_INFO,
    EFFECTIVE_DATE_OF_CERTIFICATE,
    EXPIRATION_DATE_OF_CERTIFICATE
}