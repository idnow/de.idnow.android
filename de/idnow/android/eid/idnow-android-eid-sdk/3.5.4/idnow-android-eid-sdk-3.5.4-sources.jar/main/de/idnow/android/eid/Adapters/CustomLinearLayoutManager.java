package de.idnow.android.eid.Adapters;

import android.content.Context;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import de.idnow.android.eid.util.Util_Log;

public class CustomLinearLayoutManager extends LinearLayoutManager {
    private final String LOGTAG = "IDNOW_CustomLinearLayoutManager";

    public CustomLinearLayoutManager(Context context) {
        super(context);
    }

    public CustomLinearLayoutManager(Context context, int orientation, boolean reverseLayout) {
        super(context, orientation, reverseLayout);
    }

    @Override
    public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
        try {
            super.onLayoutChildren(recycler, state);
        } catch (IndexOutOfBoundsException e) {
            Util_Log.e(LOGTAG, "Inconsistency detected");
        }
    }
}
