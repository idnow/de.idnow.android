package de.idnow.android.eid.UI

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.Gravity
import de.idnow.android.eid.R

class SubtitleView : androidx.appcompat.widget.AppCompatTextView {
    private enum class TextAlign {
        START,
        CENTER
    }

    private enum class TextStyle {
        NORMAL,
        BOLD
    }

    constructor(context: Context) : super(context) {
        init(null)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(attrs)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context, attrs, defStyleAttr
    ) {
        init(attrs)
    }

    private fun init(attrs: AttributeSet?) {
        readAttrs(attrs)
    }

    private fun readAttrs(attrs: AttributeSet?) {
        val styleableAttrs = context.theme.obtainStyledAttributes(
            attrs ?: return, R.styleable.SubtitleView, 0, 0
        )
        try {
            //text align
            val textAlign = styleableAttrs.getInt(
                R.styleable.SubtitleView_textAlign,
                TextAlign.entries.indexOf(TextAlign.START)
            ).let { TextAlign.entries[it] }
            textAlignment = when (textAlign) {
                TextAlign.START -> TEXT_ALIGNMENT_VIEW_START
                TextAlign.CENTER -> TEXT_ALIGNMENT_CENTER
            }
            gravity = when (textAlign) {
                TextAlign.START -> Gravity.START
                TextAlign.CENTER -> Gravity.CENTER
            }
            //text style
            val textStyle = styleableAttrs.getInt(
                R.styleable.SubtitleView_textStyle,
                TextStyle.entries.indexOf(TextStyle.NORMAL)
            ).let { TextStyle.entries[it] }
                .let {
                    when (it) {
                        TextStyle.NORMAL -> Typeface.NORMAL
                        TextStyle.BOLD -> Typeface.BOLD
                    }
                }
            setTypeface(null, textStyle)
        } finally {
            styleableAttrs.recycle()
        }
    }
}