package de.idnow.android.eid.models;


/**
 * @author Mathias Grasy
 * @version 1.0
 * @date 10.10.2014
 * @brief used for sending/receiving a empty Json
 */


public class Models_EmptyJson {

    public Models_EmptyJson() {

    }
}
