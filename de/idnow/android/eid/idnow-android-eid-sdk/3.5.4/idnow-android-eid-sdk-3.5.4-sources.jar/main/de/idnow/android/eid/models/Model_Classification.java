package de.idnow.android.eid.models;

public class Model_Classification {

    String country;

    String idType;

    String idSubtype;


    Model_Classification() {
    }


    public Model_Classification(String country, String idType, String idSubtype) {
        this.country = country;
        this.idType = idType;
        this.idSubtype = idSubtype;
    }


    public String getCountry() {
        return country;
    }

    public String getIdType() {
        return idType;
    }

    public String getidSubtype() {
        return idSubtype;
    }


    public void setCountry(String country) {
        this.country = country;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public void setidSubtype(String idSubtype) {
        this.idSubtype = idSubtype;
    }
}

