package de.idnow.android.eid.util.helper

import android.annotation.SuppressLint
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalLensFacing
import androidx.camera.lifecycle.ProcessCameraProvider
import de.idnow.android.eid.eIDSdk
import de.idnow.android.eid.util.Util_Log
import de.idnow.android.eid.util.camera.CameraType

internal object CameraHelper {
    private const val LOGTAG = "IDNOW_CameraHelper"

    @SuppressLint("RestrictedApi")
    @OptIn(ExperimentalLensFacing::class)
    fun hasCamera(type: CameraType): Boolean {
        return try {
            val context = eIDSdk.getInstance().appContext
            val lensFacingRequired =
                if (type == CameraType.FRONT) {
                    listOf(CameraSelector.LENS_FACING_FRONT, CameraSelector.LENS_FACING_EXTERNAL)
                } else {
                    listOf(CameraSelector.LENS_FACING_BACK)
                }

            ProcessCameraProvider.Companion.getInstance(context).get()
                .availableCameraInfos
                .any { it.lensFacing in lensFacingRequired && it.cameraIdentifier != null }
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Check camera availability failed", e)
            false
        }
    }

    fun hasTorch(): Boolean {
        return try {
            val context = eIDSdk.getInstance().appContext
            ProcessCameraProvider.Companion.getInstance(context).get()
                .availableCameraInfos
                .any { it.hasFlashUnit() }
        } catch (e: Exception) {
            Util_Log.e(LOGTAG, "Check torch availability failed", e)
            false
        }
    }
}