package de.idnow.android.eid.models;

public class Models_ConfirmationToken {

    String confirmationToken;

    public Models_ConfirmationToken(String token) {
        this.confirmationToken = token;
    }

    public void setToken(String token) {
        this.confirmationToken = token;
    }

    public String getToken() {
        return confirmationToken;
    }
}
