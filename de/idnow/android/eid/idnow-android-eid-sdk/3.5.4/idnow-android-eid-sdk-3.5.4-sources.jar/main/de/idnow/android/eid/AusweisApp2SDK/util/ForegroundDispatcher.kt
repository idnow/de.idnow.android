package de.idnow.android.eid.AusweisApp2SDK.util

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.os.Build
import android.util.Log

class ForegroundDispatcher(private val mActivity: Activity) {
    private val mAdapter: NfcAdapter? = NfcAdapter.getDefaultAdapter(mActivity)
    private var mTagCallback: ((Tag) -> Unit)? = null

    companion object {
        private const val TAG = "ForegroundDispatcher"
    }

    /**
     * Enable NFC handling.
     * Uses Reader Mode on Android 15+ (to avoid BAL restrictions with PendingIntent)
     * Uses Foreground Dispatch on older versions.
     *
     * @param tagCallback Callback for Reader Mode (Android 15+). Required for Android 15+.
     */
    fun enable(tagCallback: ((Tag) -> Unit)? = null) {
        try {
            mTagCallback = tagCallback

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {
                // Android 15+ (API 35+): Use Reader Mode
                enableReaderMode()
            } else {
                // Android 14 and below: Use traditional Foreground Dispatch
                enableForegroundDispatch()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to enable NFC", e)
        }
    }

    /**
     * Disable NFC handling.
     */
    fun disable() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {
                mAdapter?.disableReaderMode(mActivity)
                Log.d(TAG, "NFC Reader Mode disabled")
            } else {
                mAdapter?.disableForegroundDispatch(mActivity)
                Log.d(TAG, "NFC Foreground Dispatch disabled")
            }
            mTagCallback = null
        } catch (e: Exception) {
            Log.e(TAG, "Failed to disable NFC", e)
        }
    }

    /**
     * Enable Reader Mode (Android 15+)
     */
    private fun enableReaderMode() {
        val readerFlags = NfcAdapter.FLAG_READER_NFC_A or
                NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK

        mAdapter?.enableReaderMode(
            mActivity,
            { tag ->
                Log.d(TAG, "NFC tag detected via Reader Mode")
                mTagCallback?.invoke(tag)
            },
            readerFlags,
            null
        )
        Log.d(TAG, "NFC Reader Mode enabled")
    }

    /**
     * Enable Foreground Dispatch (Android 14 and below)
     */
    private fun enableForegroundDispatch() {
        val intent = Intent(mActivity, mActivity.javaClass)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)

        val pendingIntent = PendingIntent.getActivity(
            mActivity,
            0,
            intent,
            PendingIntent.FLAG_MUTABLE
        )

        val filters = arrayOf(IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED))
        val techLists = arrayOf(arrayOf(IsoDep::class.java.name))

        mAdapter?.enableForegroundDispatch(
            mActivity,
            pendingIntent,
            filters,
            techLists
        )
        Log.d(TAG, "NFC Foreground Dispatch enabled")
    }
}
