package de.idnow.android.eid.models;

public class Models_DocumentDefinition {
    boolean optional;
    String name;
    String identifier;
    String mimeType;
    int sortOrder;
    String viewPolicy;


    public Models_DocumentDefinition(boolean optional, String name, String identifier, String mimeType, int sortOrder, String viewPolicy) {
        this.optional = optional;
        this.name = name;
        this.identifier = identifier;
        this.mimeType = mimeType;
        this.sortOrder = sortOrder;
        this.viewPolicy = viewPolicy;
    }

    public Models_DocumentDefinition(boolean optional, String name, String identifier) {
        this.optional = optional;
        this.name = name;
        this.identifier = identifier;
    }

    public boolean isOptional() {
        return optional;
    }

    public void setOptional(boolean optional) {
        this.optional = optional;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public int getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(int sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getViewPolicy() {
        return viewPolicy;
    }

    public void setViewPolicy(String viewPolicy) {
        this.viewPolicy = viewPolicy;
    }


    @Override
    public String toString() {
        return "Models_DocumentDefinition{" +
                "optional=" + optional +
                ", name='" + name + '\'' +
                ", identifier='" + identifier + '\'' +
                ", mimeType='" + mimeType + '\'' +
                ", sortOrder=" + sortOrder +
                ", viewPolicy='" + viewPolicy + '\'' +
                '}';
    }
}