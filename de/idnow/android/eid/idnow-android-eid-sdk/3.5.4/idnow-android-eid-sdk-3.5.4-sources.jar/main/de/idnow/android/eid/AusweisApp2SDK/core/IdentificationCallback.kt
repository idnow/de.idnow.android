package de.idnow.android.eid.AusweisApp2SDK.core

interface IdentificationCallback {
    fun onProcessPaused()
    fun onIdentificationCompleted()
    fun onFlowRestartRequested()
    fun onSdkConnectionError()
    fun onIdentificationError()
    fun onUnknownError()
    fun onNameMismatchError()

    fun onCardRecognized()
    fun onCardConnectionEstablished()
    fun onCardReadingStarted()
    fun onPinChanged(result: Boolean)
    fun onNewPinEntryRequested()
    fun onPinEntryFailed(retryCount: Int)
    fun onPinEntryLastAttemptBeforeCan()
    fun onCardPinVerified()
    fun onCardCertificationVerified()
    fun onPukEntryFailed()
    fun onCardEncryptedDataTransferred()

    fun onCertificateInserted()
    fun onAccessRightsRequired(required: List<String>?)
    fun onNfcTagDispatchError()
}