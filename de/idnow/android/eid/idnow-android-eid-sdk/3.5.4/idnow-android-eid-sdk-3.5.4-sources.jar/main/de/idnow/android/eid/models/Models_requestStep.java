package de.idnow.android.eid.models;

public class Models_requestStep {

    String request_step;

    public String getRequest_step() {
        return request_step;
    }

    public void setRequest_step(String request_step) {
        this.request_step = request_step;
    }

    public Models_requestStep() {
    }

    public Models_requestStep(String request_step) {
        this.request_step = request_step;
    }
}
