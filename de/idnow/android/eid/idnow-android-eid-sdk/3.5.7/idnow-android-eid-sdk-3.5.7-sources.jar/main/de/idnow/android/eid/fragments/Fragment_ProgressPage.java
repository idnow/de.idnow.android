package de.idnow.android.eid.fragments;

import static de.idnow.android.eid.Config.CALLBACK_IDENT_FAILED;
import static de.idnow.android.eid.Config.EID_MOBILE_TOKEN;
import static de.idnow.android.eid.Config.EID_SESSION_TOKEN;
import static de.idnow.android.eid.Config.EID_SIGNATURE;
import static de.idnow.android.eid.Config.EXTRA_TC_TOKEN_URL;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.airbnb.lottie.LottieAnimationView;

import org.json.JSONException;

import java.io.IOException;

import de.idnow.android.eid.Authada.AuthadaAuthenticationWrapper;
import de.idnow.android.eid.Authada.ControlAuthadaIntegration;
import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.models.Model_StartCall;
import de.idnow.android.eid.models.Model_StartObject;
import de.idnow.android.eid.network.EidCallback;
import de.idnow.android.eid.network.EidError;
import de.idnow.android.eid.network.IDnowRestClient;
import de.idnow.android.eid.network.Network_RESTCalls;
import de.idnow.android.eid.util.Util;
import de.idnow.android.eid.util.Util_Log;

public class Fragment_ProgressPage extends BaseFragment {


    Context context;
    LottieAnimationView progressBar;

    private static final String LOGTAG = "IDNOW_Fragment_ProgressPage";

    ControlAuthadaIntegration controlAuthadaIntegration = new ControlAuthadaIntegration();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_progress_page, container, false);

        progressBar = view.findViewById(R.id.progress);
        progressBar.setAnimation("loading.json");
        progressBar.setRepeatCount(ValueAnimator.INFINITE);
        progressBar.playAnimation();

        context = getContext();

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        makeStartRESTCall();

        return view;
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_ProgressPage.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_ProgressPage.class);
    }


    private void makeStartRESTCall() {

        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, context);

        EidCallback<Model_StartCall> callback = new EidCallback<Model_StartCall>() {
            @Override
            public void success(Model_StartCall resultObject, retrofit2.Response response) {
                System.out.println("EidCallback success : " + resultObject.toString());
                EID_MOBILE_TOKEN = resultObject.getMobileToken();
                EID_SESSION_TOKEN = resultObject.getSessionToken();
                EID_SIGNATURE = resultObject.getRequest().getIdentification_Signature();
                EXTRA_TC_TOKEN_URL = resultObject.getTcTokenUrl();

                if (resultObject.getModelEnableOTP() != null) {
                    Config.DISPLAY_OTP_SIGNING = resultObject.getModelEnableOTP().isSigning();
                    Config.DISPLAY_OTP_IDENT = resultObject.getModelEnableOTP().isIdent();
                }

                try {
                    if (eIDSdk.getEIDTSP().equals("Governikus")) {
                        proceedToGovernikusSession();
                    } else {
                        proceedToAuthadaSession();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void failure(EidError error) {
                System.out.println("EidCallback success : " + error.toString());
                ((eIDActivity) context).errorEIDscreen(Fragment_ProgressPage.this, CALLBACK_IDENT_FAILED);

            }
        };
        boolean isGovernikus = eIDSdk.getEIDTSP().equals("Governikus");
        Model_StartObject startObject = new Model_StartObject(Util.getClientInfo(context));
        String companyId = eIDSdk.getCompanyId();
        String transactionToken = eIDSdk.getTransactionToken();

        Config.EID_ID_IMAGES_CAPTURED = false;
        retrofit2.Call<Model_StartCall> result = isGovernikus
                ? service.startEid(startObject, companyId, transactionToken)
                : service.start(startObject, companyId, transactionToken);
        result.enqueue(callback);
    }

    private void proceedToAuthadaSession() {
        AuthadaAuthenticationWrapper.createNewAuthentication((Activity) context, Config.CURRENT_AUTHADA_SERVER);
        Util_Log.i(LOGTAG, "Authada initialised " + controlAuthadaIntegration.isAuthenticationInitialized());

        Activity activity = (Activity) context;
        activity.runOnUiThread(() -> controlAuthadaIntegration.Authentication(
                EID_MOBILE_TOKEN,
                activity,
                Fragment_ProgressPage.this
        ));
    }

    @Override
    public void onResume() {
        super.onResume();
        this.getView().setFocusableInTouchMode(true);
        this.getView().requestFocus();
        this.getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    return true;
                }
                return false;
            }
        });

    }

    public void proceedToGovernikusSession() throws IOException, JSONException {
        if (eIDSdk.getEnableChooseEIDType()) {
            Fragment_choose_eID_type fragment_choose_eID_type = new Fragment_choose_eID_type();
            ((eIDActivity) context).hideIntroFragment(Fragment_ProgressPage.this);
            ((eIDActivity) context).showIntroFragment(fragment_choose_eID_type);
        } else {
            Fragment_PIN_digit_chooser fragment_pin_digit_chooser = new Fragment_PIN_digit_chooser();
            ((eIDActivity) context).hideIntroFragment(Fragment_ProgressPage.this);
            ((eIDActivity) context).showIntroFragment(fragment_pin_digit_chooser);
        }
    }
}
