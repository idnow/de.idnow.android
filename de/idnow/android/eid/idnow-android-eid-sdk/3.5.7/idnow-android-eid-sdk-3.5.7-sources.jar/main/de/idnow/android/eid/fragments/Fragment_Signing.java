package de.idnow.android.eid.fragments;

import static de.idnow.android.eid.Config.URL_DOCUMENT_NAMIRIAL;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_EID_BUTTON_CONTINUE;

import android.Manifest;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.idnow.android.eid.Adapters.CustomLinearLayoutManager;
import de.idnow.android.eid.Adapters.IDnowListDocumentAdapter;
import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.UI.HeaderView;
import de.idnow.android.eid.UI.SubtitleView;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.models.Models_ApprovalPhrase;
import de.idnow.android.eid.models.Models_ApprovalPhraseURL;
import de.idnow.android.eid.models.Models_MobileNumber;
import de.idnow.android.eid.models.Models_PDFDocument;
import de.idnow.android.eid.network.EidCallback;
import de.idnow.android.eid.network.EidError;
import de.idnow.android.eid.network.IDnowRestClient;
import de.idnow.android.eid.network.Network_RESTCalls;
import de.idnow.android.eid.util.Util;
import de.idnow.android.eid.util.Util_Log;
import de.idnow.android.eid.util.Util_Status;
import de.idnow.android.eid.util.Util_Strings;
import kotlin.Unit;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Response;

public class Fragment_Signing extends BaseFragment implements IDnowListDocumentAdapter.DocumentItemClickListener {
    private final String LOGTAG = "IDNOW_Fragment_Signing";
    Button continue_button;
    Context context;
    public static LinearLayout top_show_doc, verfy_loading_signing, layout_show_doc;
    public static ConstraintLayout layout_signing;

    public static LottieAnimationView verify_animation;

    TextView startSigning_desc1, startSigning_desc2;

    CheckBox checkBox1, checkBox2;

    public View bottomSheetContentView;
    public static BottomSheetDialog bottomSheetDialog;

    public ImageButton bottom_sheet_cancel_cross;
    public TextView bottomsheet_title;
    public RecyclerView list_document_type;
    private HeaderView header;
    private SubtitleView subtitle;

    private IDnowListDocumentAdapter listDocumentAdapter;

    private static ArrayList<String> documentList;

    private static final String SIGNATURE_CONTRACT_ACTION = "DOWNLOAD_SIGNATURE_CONTRACT";

    private Map<String, Models_ApprovalPhrase> approvalPhraseMap;
    private ArrayList<SpannableString> checkEntries;
    private ArrayList<CheckBox> checkEntriesCheckBox;
    private LinearLayout eSignatureCheckBoxContainer;

    public static ImageButton defaultBackButton, downloadButton;
    @SuppressLint("StaticFieldLeak")
    public static TextView document_name;
    public static WebView pdfView;
    public String linkLabel;
    String path = "";
    String fileName = "";
    public static TextView verify_Text;

    eIDActivity mActivity;

    public FragmentActivity fragmenteIDActivity;


    public void setBottomSheet() {
        bottomSheetContentView = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_documents, null);
        bottomSheetDialog = new BottomSheetDialog(context, R.style.BottomSheetDialog);
        bottomSheetDialog.setContentView(bottomSheetContentView);
        bottomSheetDialog.setCancelable(false);
        setBottomSheetComponent(bottomSheetDialog, context);
    }


    public void setBottomSheetComponent(BottomSheetDialog bottomSheetDialog, Context context) {
        bottom_sheet_cancel_cross = bottomSheetDialog.findViewById(R.id.bottom_sheet_cancel_cross);
        bottomsheet_title = bottomSheetDialog.findViewById(R.id.bottomsheet_title);
        list_document_type = bottomSheetDialog.findViewById(R.id.list_document_type);

        bottom_sheet_cancel_cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
            }
        });

        bottomsheet_title.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_DOCUMENT_TITLE, Util_Strings.LOCAL_KEY_EID_DOCUMENT_TITLE));

        documentList = new ArrayList<>();

        if (Config.MODEL_PDF_DOCUMENTS != null) {

            int number_of_docs = Config.MODEL_PDF_DOCUMENTS.length;

            for (int i = 0; i < number_of_docs; i++) {

                documentList.add(Config.MODEL_PDF_DOCUMENTS[i].getName());

            }

            listDocumentAdapter = new IDnowListDocumentAdapter(documentList, context, fragmenteIDActivity);
            listDocumentAdapter.setDocumentItemClickListener(IDnowListDocumentAdapter.DocumentItemClickListener);

            list_document_type.setLayoutManager(new CustomLinearLayoutManager(context));
            list_document_type.setAdapter(listDocumentAdapter);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_signing, container, false);

        eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_CP_SCREEN_SHOWN);
        eIDSdk.startEvent(eIDSdk.EVENT_EID_QES_CP_SCREEN_TIME_SPENT);

        Config.CANCEL_REASON = "EID_USER_CANCELLATION_CONSENT_PROTOCOL";

        context = getContext();

        fragmenteIDActivity = getActivity();

        header = view.findViewById(R.id.header);
        subtitle = view.findViewById(R.id.subtitle);

        checkBox1 = view.findViewById(R.id.checkbox_1);
        checkBox2 = view.findViewById(R.id.checkbox_2);
        eSignatureCheckBoxContainer = view.findViewById(R.id.eSignatureCheckBoxContainer);
        continue_button = view.findViewById(R.id.continue_button);

        if (!Config.DISPLAY_OTP_SIGNING) {
            continue_button.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_SIGNING_BUTTON_DUCPLICATED, LOCAL_EID_BUTTON_CONTINUE));
        } else {
            continue_button.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_BUTTON_CONTINUE, LOCAL_EID_BUTTON_CONTINUE));
        }

        startSigning_desc1 = view.findViewById(R.id.startSigning_desc1);
        startSigning_desc2 = view.findViewById(R.id.startSigning_desc2);
        top_show_doc = view.findViewById(R.id.top_show_doc);
        verfy_loading_signing = view.findViewById(R.id.verfy_loading_signing);
        layout_signing = view.findViewById(R.id.layout_signing);
        verify_animation = view.findViewById(R.id.verify_animation);
        verify_Text = view.findViewById(R.id.verify_Text);
        layout_show_doc = view.findViewById(R.id.layout_show_doc);
        defaultBackButton = view.findViewById(R.id.defaultBackButton);
        downloadButton = view.findViewById(R.id.downloadButton);
        document_name = view.findViewById(R.id.document_name);
        pdfView = view.findViewById(R.id.pdfView);

        documentsRestCall();

        getconsent(Config.MODEL_APPROVAL_PHRASES);

        header.setCancelAction(() -> {
            ((eIDActivity) context).getVisibleFragment();
            return Unit.INSTANCE;
        });

        verify_animation.setAnimation("loading.json");
        verify_animation.setRepeatCount(ValueAnimator.INFINITE);
        verify_animation.playAnimation();

        handleTermsAndConditions();

        continue_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_CP_SCREEN_CONTINUE);
                verfy_loading_signing.setVisibility(View.VISIBLE);
                verify_animation.setRepeatCount(ValueAnimator.INFINITE);
                verify_animation.playAnimation();
                layout_signing.setVisibility(View.GONE);

                path = context.getFilesDir().toString() + "/IDnow/";

                File dir = new File(path);

                if (dir.exists()) {
                    deleteRecursive(dir);
                }
                Fragment_OTP fragment_otp = new Fragment_OTP();
                if (!Config.DISPLAY_OTP_SIGNING) {
                    fragment_otp.sendConfirmationTokenRestCall("", Fragment_Signing.this, getActivity());
                } else {
                    resendConfirmationTokenRestCall();
                }
            }
        });

        if (allCheckboxesSelected()) {
            continue_button.setEnabled(true);
            Util.setProceedButtonBackgroundSelector(continue_button);
        } else {
            continue_button.setEnabled(false);
            Util.setProceedButtonBackgroundSelector(continue_button);
        }

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof eIDActivity) {
            mActivity = (eIDActivity) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        context = null;
    }

    public void redirectDocument(Context context, int positon, FragmentActivity fragmentActivity) {
        eIDSdk.recordEvent(eIDSdk.EVENT_EID_QES_CP_SCREEN_DOCUMENTS);
        Config.DOCUMENT_POSITION = positon;

        bottomSheetDialog.dismiss();

        fragmenteIDActivity = fragmentActivity;

        showDoc(context);

    }

    public void showDoc(Context context) {

        layout_show_doc.setVisibility(View.GONE);
        top_show_doc.setVisibility(View.GONE);

        verfy_loading_signing.setVisibility(View.VISIBLE);
        verify_animation.setVisibility(View.VISIBLE);
        verify_Text.setVisibility(View.GONE);

        layout_signing.setVisibility(View.GONE);

        document_name.setText("Document " + (Config.DOCUMENT_POSITION + 1));

        if (Config.MODEL_PDF_DOCUMENTS[Config.DOCUMENT_POSITION] != null) {
            if (Config.MODEL_PDF_DOCUMENTS[Config.DOCUMENT_POSITION].getDocumentDefinition() != null) {
                document_name.setText(Config.MODEL_PDF_DOCUMENTS[Config.DOCUMENT_POSITION].getDocumentDefinition().getName());
                String identifier = Config.MODEL_PDF_DOCUMENTS[Config.DOCUMENT_POSITION].getDocumentDefinition().getIdentifier();
                getDocumentRestCall(context, identifier);
            }
        }
    }

    public void ShowDocumentAction(Context context, String identifier) {
        defaultBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bottomSheetDialog != null) {
                    bottomSheetDialog.show();
                }

                layout_show_doc.setVisibility(View.GONE);
                top_show_doc.setVisibility(View.GONE);
                verfy_loading_signing.setVisibility(View.GONE);
                layout_signing.setVisibility(View.VISIBLE);

                Config.CANCEL_REASON = "EID_USER_CANCELLATION_CONSENT_PROTOCOL";

            }
        });
        downloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // downloadFile();
                String outputfilePath = "/storage/emulated/0/Download/";

                String inputOutputfilePath = context.getFilesDir().toString() + "/IDnow/";

                Toast.makeText(context, R.string.toast_allow_permission, Toast.LENGTH_SHORT).show();

                moveFile(context, inputOutputfilePath, identifier, outputfilePath);


//               File downloadFolder = requireContext().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);


            }
        });
    }

    private static byte[] inputToByte(InputStream inputStream) throws IOException {
        ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
        byte[] buff = new byte[1024];
        int rc;
        while ((rc = inputStream.read(buff, 0, 1024)) > 0) {
            swapStream.write(buff, 0, rc);
        }
        byte[] in2b = swapStream.toByteArray();
        return in2b;

    }

    public void getDocumentRestCall(Context context, String identifier) {

        final OkHttpClient client = new OkHttpClient();

        String url = Config.CURRENT_SERVER.getApiHost(eIDSdk.getTransactionToken()) + "/api/v1/" + eIDSdk.getCompanyId() + "/identifications/" + eIDSdk.getTransactionToken() + "/documents/" + identifier + "/data";

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Content-Type", "application/pdf")
                .build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

                okhttp3.Response response = null;
                try {
                    response = client.newCall(request).execute();
                    Util.showRESTCallErrorDialog(context, response.code(), Fragment_Signing.this);
                } catch (IOException ioException) {
                    Util_Log.e(LOGTAG, "Fetch document failed", ioException);
                }

            }

            @SuppressLint("SetJavaScriptEnabled")
            @Override
            public void onResponse(Call call, okhttp3.Response response) throws IOException {

                dataToPDF(context, identifier, response);

            }
        });
    }

    public void dataToPDF(Context context, String identifier, okhttp3.Response response) throws IOException {

        InputStream in = response.body().byteStream();

        byte[] bytesArray = inputToByte(in);

        path = context.getFilesDir().toString() + "/IDnow/";

        File dir = new File(path);

        if (!dir.exists()) {
            dir.mkdir();
        }

        File[] files = dir.listFiles();

        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                Util_Log.d("before Files", "FileName:" + files[i].getName());
                if (files[i].getName().contains(identifier)) {
                    File filetoDelte = new File(path + files[i].getName());
                    filetoDelte.delete();

                }
                Util_Log.d("after Files", "FileName:" + files[i].getName());
            }
        }

        fileName = "IDnow" + "-File-" + identifier + ".pdf";

        OutputStream outStream;
        outStream = new FileOutputStream(path + fileName);
        outStream.write(bytesArray);
        outStream.close();

        showPDFDocument(context, path + fileName, identifier);

    }

    public void showPDFDocument(Context context, String s, String identifier) {
        if (fragmenteIDActivity != null) {
            fragmenteIDActivity.runOnUiThread(() -> {
                layout_show_doc.setVisibility(View.VISIBLE);
                top_show_doc.setVisibility(View.VISIBLE);
                verfy_loading_signing.setVisibility(View.GONE);

                Config.CANCEL_REASON = "EID_USER_CANCELLATION_SHOW_DOCUMENT";

                pdfView.getSettings().setLoadsImagesAutomatically(true);
                pdfView.getSettings().setJavaScriptEnabled(true);
                pdfView.clearHistory();
                WebSettings settings = pdfView.getSettings();
                settings.setJavaScriptEnabled(true);
                settings.setAllowFileAccess(true);
                settings.setAllowFileAccessFromFileURLs(true);
                settings.setAllowUniversalAccessFromFileURLs(true);
                settings.setBuiltInZoomControls(true);
                settings.setDisplayZoomControls(false);
                settings.setSupportZoom(true);
                String htmlFile;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    htmlFile = "file:///android_asset/pdfviewer.html?";
                } else {
                    htmlFile = "file:///android_asset/pdfviewer_legacy.html?";
                }
                pdfView.clearHistory();
                pdfView.loadUrl(htmlFile + s);
                ShowDocumentAction(context, identifier);
            });
        }
    }

    private Boolean allCheckboxesSelected() {

        if ((checkBox1.isChecked()) && (checkBox2.isChecked())) {
            return true;
        } else
            return (checkBox1.isChecked()) && (checkBox2.isChecked());
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_Signing.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_Signing.class);
    }

    public void handleTermsAndConditions() {
        String signatureContract = "Signature Contract";
        String myData = "my data";

        String text1 = "I have read and accept the Signature Contract with Namirial S.p.A";
        String text2 = "I confirm the correctness of my data that will be used to generate this signature by Namirial S.p.A";

        SpannableString ss1 = new SpannableString(text1);
        SpannableString ss2 = new SpannableString(text2);


        ClickableSpan clickableSpan1 = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View view) {

            }

            @SuppressLint("ResourceAsColor")
            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(getResources().getColor(R.color.text_color_link));
                ds.setUnderlineText(false);
            }
        };

        ClickableSpan clickableSpan2 = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View view) {

            }

            @SuppressLint("ResourceAsColor")
            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(getResources().getColor(R.color.text_color_link));
                ds.setUnderlineText(false);
            }
        };

        ss1.setSpan(clickableSpan1, 26, 26 + signatureContract.length() + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss2.setSpan(clickableSpan2, 28, 28 + myData.length() + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    public void documentsRestCall() {
        String token = eIDSdk.getTransactionToken();
        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, eIDSdk.getInstance().getAppContext());

        EidCallback<Models_PDFDocument[]> callback = new EidCallback<Models_PDFDocument[]>() {
            @Override
            public void success(Models_PDFDocument[] models_pdfDocument, Response response) {

                Config.MODEL_PDF_DOCUMENTS = models_pdfDocument;

                String startSigning_title_text = Util_Strings.getStringWithDefault(context, Util_Strings.KEY_SIGNING_TITLE, Util_Strings.LOCAL_KEY_SIGNING_TITLE);

                startSigning_title_text = startSigning_title_text.replace("xxx", String.valueOf(models_pdfDocument.length));

                String startSigning_desc_text = Util_Strings.getStringWithDefault(context, Util_Strings.KEY_SIGNING_DESC, Util_Strings.LOCAL_KEY_SIGNING_DESC);

                String document_text = "";

                if (models_pdfDocument.length == 1) {
                    document_text = Util_Strings.getStringWithDefault(context, Util_Strings.KEY_SIGNING_DOC, Util_Strings.LOCAL_KEY_SIGNING_DOC);
                    document_text = "1 " + document_text;
                } else {
                    document_text = Util_Strings.getStringWithDefault(context, Util_Strings.KEY_SIGNING_PLURAL_DOC, Util_Strings.LOCAL_KEY_SIGNING_PLURAL_DOC);
                    document_text = models_pdfDocument.length + " " + document_text;
                }

                startSigning_desc_text = startSigning_desc_text.replace("xxx", document_text);

                subtitle.setText(startSigning_desc_text);

                header.setTitle(startSigning_title_text);


                int startIndex = subtitle.getText().toString().indexOf(document_text); // 18
                int lenghtIndex = document_text.length();
                int endIndex = startIndex + lenghtIndex;

                SpannableString ss = new SpannableString(subtitle.getText().toString());

                ClickableSpan clickLink = clickLink();
                ss.setSpan(clickLink, startIndex, endIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                subtitle.setClickable(true);
                subtitle.setText(ss);
                subtitle.setMovementMethod(LinkMovementMethod.getInstance());
                subtitle.setLinkTextColor(getResources().getColor(R.color.text_color_link));
                subtitle.setHighlightColor(Color.TRANSPARENT);


            }

            @Override
            public void failure(EidError error) {
                Util.showRESTCallErrorDialog(context, error.getResponse().getStatus(), Fragment_Signing.this);
            }
        };

        retrofit2.Call<Models_PDFDocument[]> result = service.getDocuments(eIDSdk.getCompanyId(), eIDSdk.getTransactionToken());
        result.enqueue(callback);
    }

    public void getconsent(Models_ApprovalPhrase[] approvalPhrases) {
        List<String> listLabel = new ArrayList<String>();
        HashMap<String, String> listLabelmap = new HashMap<String, String>();

        if (approvalPhrases != null) {
            approvalPhraseMap = new HashMap<>();
            checkEntries = new ArrayList<>();

            for (Models_ApprovalPhrase approvalPhrase : approvalPhrases) {
                if (approvalPhrase.getName() != null && approvalPhrase.getTranslationKey() != null && approvalPhrase.getValue() != null) {

                    String text = approvalPhrase.getValue();
                    text = text.replaceAll("\\<.*?>", "");
                    SpannableString ss = new SpannableString(text);

                    if (approvalPhrase.getUrls() != null && !approvalPhrase.getUrls().isEmpty()) {

                        Iterator<String> it = approvalPhrase.getUrls().keySet().iterator();

                        while (it.hasNext()) {
                            String key = it.next();
                            Models_ApprovalPhraseURL url = approvalPhrase.getUrls().get(key);

                            String link = "";
                            linkLabel = "";
                            String translationKey = "";

                            if (url != null) {
                                link = url.getLink();
                                linkLabel = url.getLabel();
                                translationKey = url.getTranslationKey();
                                String action = url.getAction();
                                boolean isSignatureAction = action != null
                                        && action.equals(SIGNATURE_CONTRACT_ACTION);
                                // key : gtu
                                if (linkLabel.equals("Signature Contract") && isSignatureAction) {
                                    link = URL_DOCUMENT_NAMIRIAL;
                                }
                            }

                            Pattern p = Pattern.compile("\\$\\(.*?\\)");
                            Matcher m = p.matcher(text);

                            listLabel.add(linkLabel);
                            listLabelmap.put(linkLabel, link);

                            while (m.find()) {
                                if (m.group().contains(key)) {
                                    text = text.replace(m.group(), url.getLabel());
                                }
                            }

                            it.remove();

                        }

                        ss = new SpannableString(text);

                        for (Map.Entry<String, String> entry : listLabelmap.entrySet()) {
                            int startIndex = text.indexOf(entry.getKey());
                            int lenghtIndex = entry.getKey().length();
                            int endIndex = startIndex + lenghtIndex;
                            ClickableSpan clickLink = clickLink(linkLabel, entry.getValue());
                            ss.setSpan(clickLink, startIndex,
                                    endIndex,
                                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                    }
                    approvalPhraseMap.put(approvalPhrase.getName(), approvalPhrase);
                    checkEntries.add(ss);
                }
            }
        }
        updateCheckEntries();


    }

    public boolean checkSelectedCheckbox() {
        for (int i = 0; i < checkEntriesCheckBox.size(); i++) {

            if (!checkEntriesCheckBox.get(i).isChecked()) {
                return false;
            }
        }
        return true;
    }

    public ClickableSpan clickLink(String label, String link) {

        ClickableSpan clickableSpan = new ClickableSpan() {

            public void onClick(View textView) {

                textView.invalidate();

                if (link != null) {
                    if (link.contains("https")) {
                        Intent browserIntent = new Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse(link));
                        startActivity(browserIntent);
                    } else if (!link.contains("pdf") && !link.equals("")) {
                        Util.openUrlInNewBrowserTask(context, Config.CURRENT_SERVER.getWebHost(eIDSdk.getTransactionToken()) + link);
                    } else {
                        if (link.equals("")) {
                            Toast.makeText(getActivity(), R.string.toast_load_pdf_doc, Toast.LENGTH_LONG).show();
                        } else {
                            layout_show_doc.setVisibility(View.VISIBLE);
                            top_show_doc.setVisibility(View.VISIBLE);
                            document_name.setText(label);

                            verfy_loading_signing.setVisibility(View.VISIBLE);
                            verify_animation.setVisibility(View.VISIBLE);
                            layout_signing.setVisibility(View.GONE);
                            showPDFDocument(context, URL_DOCUMENT_NAMIRIAL, "signature Document");

                            defaultBackButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    layout_show_doc.setVisibility(View.GONE);
                                    top_show_doc.setVisibility(View.GONE);
                                    verfy_loading_signing.setVisibility(View.GONE);
                                    layout_signing.setVisibility(View.VISIBLE);

                                    Config.CANCEL_REASON = "EID_USER_CANCELLATION_CONSENT_PROTOCOL";

                                }
                            });
                            downloadButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // downloadFile();

                                    Toast.makeText(context, R.string.toast_check_download_folder, Toast.LENGTH_LONG).show();

                                    String outputfilePath = "/storage/emulated/0/Download/";

                                    String inputOutputfilePath = context.getFilesDir().toString() + "/IDnow/";

                                    linkLabel = linkLabel.replaceAll("\\s", "");

                                    Toast.makeText(context, R.string.toast_allow_permission, Toast.LENGTH_SHORT).show();

                                    moveFile(context, inputOutputfilePath, linkLabel, outputfilePath);

                                }
                            });

                        }
                    }
                }
            }
        };

        return clickableSpan;
    }

    /*public void checkPermission(Context context,String permission, int requestCode)
    {
        // Checking if permission is not granted
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(getActivity(), new String[] { permission }, requestCode);
        }
        else {
            Toast.makeText(context, "Permission already granted", Toast.LENGTH_SHORT).show();
        }
    }*/

    public ClickableSpan clickLink() {

        ClickableSpan clickableSpan = new ClickableSpan() {
            public void onClick(View textView) {
                setBottomSheet();
                bottomSheetDialog.show();
            }
        };

        return clickableSpan;
    }

    private void updateCheckEntries() {

        checkEntriesCheckBox = new ArrayList<>();

        for (SpannableString s : checkEntries) {
            LayoutInflater inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.view_checkbox_element_eid, null);
            TextView textView = view.findViewById(R.id.eSigningCheckTextView);
            CheckBox checkBox = view.findViewById(R.id.eSigningChecBox);

            checkEntriesCheckBox.add(checkBox);

            textView.setClickable(true);
            textView.setText(s);
            textView.setMovementMethod(LinkMovementMethod.getInstance());
            textView.setLinkTextColor(getResources().getColor(R.color.text_color_link));
            textView.setHighlightColor(Color.TRANSPARENT);

            view.setPadding(Util.getPxFromDp(context, 8), Util.getPxFromDp(context, 8), Util.getPxFromDp(context, 8), Util.getPxFromDp(context, 8));

            eSignatureCheckBoxContainer.addView(view);
        }

        for (CheckBox checkBox : checkEntriesCheckBox) {
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if ((isChecked) && (checkSelectedCheckbox())) {
                        continue_button.setEnabled(true);
                        Util.setProceedButtonBackgroundSelector(continue_button);
                    } else {
                        continue_button.setEnabled(false);
                        Util.setProceedButtonBackgroundSelector(continue_button);
                    }
                }
            });
        }


    }

    public void resendConfirmationTokenRestCall() {
        String customer = eIDSdk.getCompanyId();
        String token = eIDSdk.getTransactionToken();
        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, eIDSdk.getInstance().getAppContext());

        EidCallback<Object> callback = new EidCallback<Object>() {

            @Override
            public void success(Object models_emptyJson, Response response) {
                Config.OTP_SCREEN = Util_Status.SCREEN_PHONE_NUMBER_OTP;
                Fragment_OTP fragment_otp = new Fragment_OTP();
                ((eIDActivity) getActivity()).hideIntroFragment(Fragment_Signing.this);
                ((eIDActivity) getActivity()).showIntroFragment(fragment_otp);
            }

            @Override
            public void failure(EidError error) {
                verfy_loading_signing.setVisibility(View.GONE);
                layout_signing.setVisibility(View.VISIBLE);
                Util.showRESTCallErrorDialog(context, 0, Fragment_Signing.this);
            }
        };

        retrofit2.Call<Object> result = service.resendConfirmationToken(
                new Models_MobileNumber(Config.USER_PHONE_NO),
                customer,
                token,
                Config.EID_SIGNATURE
        );
        result.enqueue(callback);

    }

    @Override
    public void onDocumentItemClick(int position) {
    }


    private void moveFile(Context context, File file, File dir) throws IOException {
        File newFile = new File(dir, file.getName());
        FileChannel outputChannel = null;
        FileChannel inputChannel = null;
        try {
            outputChannel = new FileOutputStream(newFile).getChannel();
            inputChannel = new FileInputStream(file).getChannel();
            inputChannel.transferTo(0, inputChannel.size(), outputChannel);
            inputChannel.close();
            Toast.makeText(context, R.string.toast_check_download_folder, Toast.LENGTH_LONG).show();

            file.delete();
        } finally {
            if (inputChannel != null) inputChannel.close();
            if (outputChannel != null) outputChannel.close();
        }

    }


    private void moveFile(Context context, String inputPath, String inputFile, String outputPath) {

        InputStream in = null;
        OutputStream out = null;
        try {
            //create output directory if it doesn't exist
           /* File dir = new File (outputPath);
            if (!dir.exists())
            {
                dir.mkdir();
            } */

            File inputDir = new File(inputPath);

            File[] files = inputDir.listFiles();

            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    Util_Log.d("before Files", "FileName:" + files[i].getName());
                    if (files[i].getName().contains(inputFile)) {

                        moveFile(context, files[i], Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));

                    }
                    Util_Log.d("after Files", "FileName:" + files[i].getName());
                }
            }

        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Move file failed", e);
        }

    }

    void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                deleteRecursive(child);

        fileOrDirectory.delete();
    }

    String[] PERMISSIONS = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.MANAGE_EXTERNAL_STORAGE};

}