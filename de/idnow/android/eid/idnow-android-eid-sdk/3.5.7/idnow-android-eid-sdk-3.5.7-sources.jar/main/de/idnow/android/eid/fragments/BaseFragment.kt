package de.idnow.android.eid.fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import de.idnow.android.eid.R
import de.idnow.android.eid.util.Util_Log
import de.idnow.android.eid.util.ViewHelper

abstract class BaseFragment(
    private val useStandardHorizontalPadding: Boolean = true
) : Fragment() {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<View>(R.id.main)
            ?.let { ViewHelper.applyScreenSafePadding(it, useStandardHorizontalPadding) }
            ?: Util_Log.d(
                "IDNOW_${this@BaseFragment::class.simpleName}",
                "Main layout not found"
            )
    }

    /**
     * Called when the user requests to leave this screen — via the header cross
     * button or the system back gesture/button. Override to record the screen's
     * cancellation analytics event. Default is a no-op.
     */
    open fun onUserCancel() {}
}