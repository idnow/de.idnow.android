package de.idnow.android.eid.fragments;

import static de.idnow.android.eid.util.Util_Photo.DocumentImages.idbackside;
import static de.idnow.android.eid.util.Util_Photo.DocumentImages.idfrontside;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.util.Base64;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ImageProxy;
import androidx.camera.view.PreviewView;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;

import com.airbnb.lottie.LottieAnimationView;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.Objects;

import de.idnow.android.eid.AusweisApp2SDK.core.IdentificationManager;
import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.models.Model_Classification;
import de.idnow.android.eid.models.Models_DocumentInfo;
import de.idnow.android.eid.network.EidCallback;
import de.idnow.android.eid.network.EidError;
import de.idnow.android.eid.network.IDnowRestClient;
import de.idnow.android.eid.network.Network_RESTCalls;
import de.idnow.android.eid.util.Util;
import de.idnow.android.eid.util.Util_Log;
import de.idnow.android.eid.util.Util_Photo;
import de.idnow.android.eid.util.Util_Strings;
import de.idnow.android.eid.util.ViewHelper;
import de.idnow.android.eid.util.camera.CameraType;
import de.idnow.android.eid.util.camera.IDnowCamera;
import de.idnow.android.eid.util.helper.CameraHelper;
import de.idnow.android.eid.util.helper.ImageHelper;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Response;


public class Fragment_Capture extends BaseFragment {
    private final String LOGTAG = "IDNOW_Fragment_Capture";

    public Fragment_Capture() {
        super(false);
    }

    public LottieAnimationView takePictureButton, retake;
    public TextView idcard_text_normal, mainTextDescription, retakeAction;
    Context context;
    Button continueButton;
    public LinearLayout retakeButton;
    public View takePictureLayout;

    public LinearLayout layoutAction_1, layoutAction_2;
    public AlertDialog takingImageDialog = null;
    public static Util_Photo.DocumentImages ID_DOCUMENT = Util_Photo.DocumentImages.idfrontside;

    public PreviewView cameraPreview;
    public IDnowCamera camera;
    private ImageCapture.OnImageCapturedCallback imageCapturedCallback;
    public ImageView imageViewPhoto;
    public String capturedImageFilePath = "";

    private static Fragment_Capture instance;

    public ImageButton defaultBackButton, defaultTorchButton;

    boolean flashLightOn = false;

    private boolean isProcessing = false;

    Dialog quitDialog;

    TextView quit_pin_change_title,
            quit_pin_change_description,
            quit_pin_change_quit_button,
            quit_pin_change_continue_button,
            quit_pin_change_try_another_method_button;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        context = getContext();

        instance = this;

        View view = inflater.inflate(R.layout.fragment_capture, container, false);

        Config.CANCEL_REASON = "EID_USER_CANCELLATION_IMAGE_CAPTURE";

        ViewHelper.INSTANCE.applySafeBotMargins(view.findViewById(R.id.poweredByLogo));

        imageViewPhoto = view.findViewById(R.id.imageViewPhoto);

        defaultBackButton = view.findViewById(R.id.defaultBackButton);
        ViewHelper.INSTANCE.applySafeTopMargins(defaultBackButton);
        defaultTorchButton = view.findViewById(R.id.defaultTorchButton);
        ViewHelper.INSTANCE.applySafeTopMargins(defaultTorchButton);
        defaultTorchButton.setImageResource(R.drawable.flashlight_on);

        defaultBackButton.setOnClickListener(v -> {
            onUserCancel();
            ((eIDActivity) context).getVisibleFragment();
        });

        defaultTorchButton.setOnClickListener(v -> toggleFlash());

        cameraPreview = view.findViewById(R.id.cameraPreview);
        cameraPreview.setFocusable(true);
        cameraPreview.setFocusableInTouchMode(true);
        camera = new IDnowCamera(this, requireActivity(), cameraPreview);


        layoutAction_1 = view.findViewById(R.id.layoutAction_1);
        layoutAction_2 = view.findViewById(R.id.layoutAction_2);

        retakeButton = view.findViewById(R.id.retakeButton);
        takePictureButton = view.findViewById(R.id.takePictureButton);

        takePictureButton.setAnimation("static_camera_button.json");
        Util.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.primaryColor)), takePictureButton, "Primary");
        //takePictureButton.setAlpha(0.5f);

        idcard_text_normal = view.findViewById(R.id.idcard_text_normal);
        mainTextDescription = view.findViewById(R.id.mainTextDescription);
        retakeAction = view.findViewById(R.id.retakeAction);
        continueButton = view.findViewById(R.id.continueButton);
        takePictureLayout = view.findViewById(R.id.takePictureLayout);
        if (view.findViewById(R.id.poweredByLogo).getVisibility() != View.VISIBLE) {
            ViewHelper.INSTANCE.applySafeBotMargins(takePictureLayout);
        }

        retake = view.findViewById(R.id.retakeImage);
        retake.setAnimation("static_camera_retake.json");
        retake.playAnimation();

        setRightScreen(idfrontside);

        return view;
    }

    public void setRightScreen(Util_Photo.DocumentImages rightScreen) {

        defaultTorchButton.setVisibility(View.VISIBLE);

        dismissProgressDialog();

        imageViewPhoto.setImageDrawable(null);

        ID_DOCUMENT = rightScreen;

        if (rightScreen.equals(idfrontside)) {
            eIDSdk.recordEvent(eIDSdk.EVENT_EID_FRONT_CAPTURE_SCREEN);
            eIDSdk.startEvent(eIDSdk.EVENT_EID_FRONT_CAPTURE_TIME_SPENT);
            idcard_text_normal.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TAKE_FRONT_TITLE, Util_Strings.LOCAL_KEY_EID_TAKE_FRONT_TITLE));
            mainTextDescription.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TAKE_FRONT_DESC, Util_Strings.LOCAL_KEY_EID_TAKE_FRONT_DESC));
            setRightLayout(idfrontside, true);
        } else if (rightScreen.equals(idbackside)) {
            eIDSdk.recordEvent(eIDSdk.EVENT_EID_BACK_CAPTURE_SCREEN);
            eIDSdk.startEvent(eIDSdk.EVENT_EID_BACK_CAPTURE_TIME_SPENT);
            idcard_text_normal.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TAKE_BACK_TITLE, Util_Strings.LOCAL_KEY_EID_TAKE_BACK_TITLE));
            mainTextDescription.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TAKE_BACK_DESC, Util_Strings.LOCAL_KEY_EID_TAKE_BACK_DESC));
            imageViewPhoto.setImageDrawable(null);
            setRightLayout(idbackside, true);
        }
    }

    public static Fragment_Capture getInstance() {
        Util_Log.d("IdentSdk", "instance :" + instance);
        return instance;
    }

    public void dismissProgressDialog() {
        if (takingImageDialog != null && takingImageDialog.isShowing()) {
            takingImageDialog.dismiss();
        }
    }

    public void setRightLayout(Util_Photo.DocumentImages rightScreen, Boolean rightLayout) {

        if (rightLayout) {
            layoutAction_1.setVisibility(View.GONE);
            layoutAction_2.setVisibility(View.VISIBLE);

            layoutAction_2.setOnClickListener(v -> {
                if (flashLightOn) {
                    toggleFlash();
                }

                if (ID_DOCUMENT.equals(idbackside)) {
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_BACK_CAPTURE_TAKEN);
                } else if (ID_DOCUMENT.equals(idfrontside)) {
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_FRONT_CAPTURE_TAKEN);

                }
                takePicture();
            });
            setupImageCaptureCallback(rightScreen);
            openCamera();
        } else {
            defaultTorchButton.setVisibility(View.GONE);
            camera.close();

            mainTextDescription.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TAKE_FRONT_IMAGE_DESC, Util_Strings.LOCAL_KEY_EID_TAKE_FRONT_IMAGE_DESC));

            layoutAction_1.setVisibility(View.VISIBLE);
            layoutAction_2.setVisibility(View.GONE);
            continueButton.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TAKE_IMAGE_CONTINUE, Util_Strings.LOCAL_KEY_EID_TAKE_IMAGE_CONTINUE));
            retakeAction.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TAKE_IMAGE_RETAKE, Util_Strings.LOCAL_EID_TAKE_IMAGE_RETAKE));

            retakeButton.setOnClickListener(v -> {
                imageViewPhoto.setImageBitmap(null);

                if (rightScreen.equals(idfrontside)) {

                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_FRONT_CAPTURE_RETAKEN);
                } else if (rightScreen.equals(idbackside)) {

                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_BACK_CAPTURE_RETAKEN);
                } else {
                    openCamera();
                }
                setRightScreen(ID_DOCUMENT);
            });

            continueButton.setOnClickListener(v -> {

                if (isProcessing) return;
                isProcessing = true;

                if (rightScreen.equals(idfrontside)) {
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_FRONT_CAPTURE_CONTINUE);
                } else if (rightScreen.equals(idbackside)) {
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_BACK_CAPTURE_CONTINUE);
                }
                ID_DOCUMENT = rightScreen;
                callUploadPhoto();
            });
        }

    }

    private void openCamera() {
        try {
            camera.open(CameraType.BACK);
        } catch (Error error) {
            Util_Log.e(LOGTAG, "Start camera preview failed", error);
        }
    }

    public void takePicture() {
        if (isProcessing) return;
        isProcessing = true;
        takingImageDialog = setProgressDialog();
        try {
            camera.takePicture(imageCapturedCallback);
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Capture image failed", e);
        }
    }

    private void setupImageCaptureCallback(final Util_Photo.DocumentImages rightScreen) {
        imageCapturedCallback = new ImageCapture.OnImageCapturedCallback() {
            @Override
            public void onCaptureSuccess(@NonNull ImageProxy image) {
                super.onCaptureSuccess(image);
                isProcessing = false;
                try {
                    int rotationDegrees = image.getImageInfo().getRotationDegrees();
                    Bitmap rotatedBitmap = ImageHelper.INSTANCE.rotateBitmap(image.toBitmap(), rotationDegrees);
                    Bitmap croppedBitmap = ImageHelper.INSTANCE.cropBitmapToPreviewAspect(rotatedBitmap, imageViewPhoto.getMeasuredWidth(), imageViewPhoto.getMeasuredHeight());
                    imageViewPhoto.setImageBitmap(croppedBitmap);
                    File folder = new File(context.getCacheDir(), "IDnow");
                    folder.mkdir();

                    File[] files = folder.listFiles();
                    if (files != null) {
                        for (File file : files) {
                            if (file.getName().contains(rightScreen.toString()))
                                file.delete();
                        }
                    }

                    String filePath = new File(folder, "IDnow" + rightScreen + System.currentTimeMillis() + ".jpeg").getAbsolutePath();

                    OutputStream outStream;
                    outStream = new FileOutputStream(filePath);
                    rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
                    outStream.close();
                    capturedImageFilePath = filePath;
                    Util_Log.d(LOGTAG, "Path: " + (filePath));

                } catch (Exception e) {
                    Util_Log.e(LOGTAG, "Handling taken picture failed", e);
                    capturedImageFilePath = "";
                }

                dismissProgressDialog();
                callPhotoCheckActivity();
            }

            @Override
            public void onError(@NonNull ImageCaptureException exception) {
                super.onError(exception);
                isProcessing = false;
                Util_Log.e(LOGTAG, "CameraX capture failed", exception);
                capturedImageFilePath = "";
                dismissProgressDialog();
                callPhotoCheckActivity();
            }
        };
    }

    private void callPhotoCheckActivity() {
        dismissProgressDialog();
        setRightLayout(ID_DOCUMENT, false);
    }

    private void callUploadPhoto() {
        takingImageDialog = setProgressDialog();

        Util_Photo.updateHashMap(ID_DOCUMENT, true, context);
        Util_Photo.DocumentImages imageType = ID_DOCUMENT;

        if (ID_DOCUMENT.equals(idfrontside)) {
            eIDSdk.recordEvent(eIDSdk.EVENT_EID_FRONT_CAPTURE_PROCESSING);
        } else {
            eIDSdk.recordEvent(eIDSdk.EVENT_EID_BACK_CAPTURE_PROCESSING);
        }

        byte[] imageStringToPush = ImageHelper.INSTANCE.readAsBase64(capturedImageFilePath, 90);
        sendUploadPhotoRESTCall(imageStringToPush, imageType);
    }

    public void sendUploadPhotoRESTCall(byte[] imageStringToPush, @NonNull final Util_Photo.DocumentImages imageType) {
        Util_Log.i(LOGTAG, "http upload photo called Bis");
        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, getActivity());

        EidCallback<Model_Classification> callback = new EidCallback<>() {
            @Override
            public void success(Model_Classification model_classification, Response response) {
                Util_Log.d("IdentSdk sendUploadPhotoRESTCall", "success");
                isProcessing = false;
                if (ID_DOCUMENT.equals(idfrontside)) {
                    getClassificationRESTCall();
                } else {
                    Config.EID_ID_IMAGES_CAPTURED = true;
                    dismissProgressDialog();
                    if (eIDSdk.getEIDTSP().equals("Governikus")) {
                        Config.CURRENT_FRAGMENT = ((eIDActivity) context).getCurrentFragment();
                        IdentificationManager.INSTANCE.requestAcceptRights();
                    } else {
                        if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                            Fragment_EnterPin_5_digit fragmentEnterPin5Digit = new Fragment_EnterPin_5_digit();
                            ((eIDActivity) getActivity()).hideIntroFragment(Fragment_Capture.this);
                            ((eIDActivity) getActivity()).showIntroFragment(fragmentEnterPin5Digit);
                        } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                            Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                            Fragment_EnterPin_6_digit fragmentEnterPin = new Fragment_EnterPin_6_digit();
                            ((eIDActivity) getActivity()).hideIntroFragment(Fragment_Capture.this);
                            ((eIDActivity) getActivity()).showIntroFragment(fragmentEnterPin);
                        }
                    }
                }
            }

            @Override
            public void failure(EidError error) {
                Util_Log.d("IdentSdk sendUploadPhotoRESTCall 1", "failure");
                isProcessing = false;
                dismissProgressDialog();
                if (error != null && error.getResponse() != null) {
                    Util_Log.d("IdentSdk sendUploadPhotoRESTCall 2", "failure");
                    Util.showRESTCallErrorDialog(context, error.getResponse().getStatus(), Fragment_Capture.this);
                }
            }
        };

        byte[] bytes = Base64.encode(imageStringToPush, Base64.DEFAULT);
        Call<Model_Classification> result = service.uploadImage(
                RequestBody.create(bytes),
                eIDSdk.getTransactionToken(),
                eIDSdk.getCompanyId(),
                Util_Photo.getServerStringFromDocumentImageType(imageType)
        );
        result.enqueue(callback);
    }

    public void quitDialog(Context context) {

        quitDialog = new Dialog(context);

        quitDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        quitDialog.setContentView(R.layout.quit_pin_change_dialog);

        loadQuitDialog(quitDialog);

        int width = ViewGroup.LayoutParams.WRAP_CONTENT;
        int height = ViewGroup.LayoutParams.WRAP_CONTENT;
        quitDialog.getWindow().setLayout(width, height);
        quitDialog.setCancelable(false);
        quitDialog.show();

    }

    public void loadQuitDialog(Dialog dialog) {

        quit_pin_change_title = dialog.findViewById(R.id.quit_pin_change_title);
        quit_pin_change_description = dialog.findViewById(R.id.quit_pin_change_description);
        quit_pin_change_quit_button = dialog.findViewById(R.id.quit_pin_change_quit_button);
        quit_pin_change_continue_button = dialog.findViewById(R.id.quit_pin_change_continue_button);
        quit_pin_change_try_another_method_button = dialog.findViewById(R.id.quit_pin_change_try_another_method_button);

        quit_pin_change_try_another_method_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_TRY_ANOTHER_METHOD, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_TRY_ANOTHER_METHOD));

        quit_pin_change_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DIALOG_NOT_EID_TITLE, Util_Strings.LOCAL_KEY_EID_DIALOG_NOT_EID_TITLE));
        quit_pin_change_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DIALOG_NOT_EID_DESC, Util_Strings.LOCAL_KEY_EID_DIALOG_NOT_EID_DESC));
        quit_pin_change_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DIALOG_NOT_EID_CONTINUE, Util_Strings.LOCAL_KEY_EID_DIALOG_NOT_EID_CONTINUE));
        quit_pin_change_quit_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_QUIT, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_QUIT));

        quit_pin_change_try_another_method_button.setVisibility(Config.STANDALONE_EID ? View.GONE : View.VISIBLE);
        quit_pin_change_try_another_method_button.setOnClickListener(v -> {
            quitDialog.dismiss();
            Util.redirection(context, Config.CHOOSER_SCREEN);
        });

        quit_pin_change_quit_button.setOnClickListener(v -> {
            quitDialog.dismiss();
            goToIdentIDPage();
        });

        quit_pin_change_continue_button.setOnClickListener(v -> dialog.dismiss());

    }

    public void goToIdentIDPage() {

        Intent backPressedIntent = new Intent();
        backPressedIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        backPressedIntent.putExtra(Config.RESULT_DATA_ERROR, "User abort identification");
        backPressedIntent.putExtra(Config.RESULT_DATA_TRANSACTION_TOKEN, eIDSdk.getTransactionToken());
        Objects.requireNonNull(getActivity()).setResult(Config.RESULT_CODE_CANCEL, getActivity().getIntent());
        getActivity().finish();
    }

    private void getClassificationRESTCall() {
        Util_Log.i(LOGTAG, "http Classification called ");
        String endPoint = Config.CURRENT_SERVER.getApiHost(eIDSdk.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, getActivity());

        EidCallback<Object> callback = new EidCallback<>() {
            @Override
            public void success(Object o, Response response) {
                try {
                    Gson gson = new Gson();
                    String json = gson.toJson(o);
                    JSONObject jsonObject = new JSONObject(json);
                    try {
                        Locale loc = new Locale("", (String) jsonObject.get("country"));
                        loc.getDisplayCountry();

                        Models_DocumentInfo models_documentInfo = new Models_DocumentInfo();

                        if (jsonObject.get("country").equals("DE")) {
                            models_documentInfo.setIdCountry((String) jsonObject.get("country"));
                            models_documentInfo.setIdType((String) jsonObject.get("idType"));
                            models_documentInfo.setidSubtype((String) jsonObject.get("idSubtype"));
                            sendDocumentInfoRESTCall(models_documentInfo);
                        } else {
                            dismissProgressDialog();
                            if (Config.CARD_TYPE.equals("GERMAN")) {
                                quitDialog(context);
                            }
                            setRightScreen(idbackside);
                        }

                    } catch (Exception e) {
                        dismissProgressDialog();
                        if (Config.CARD_TYPE.equals("GERMAN")) {
                            quitDialog(context);
                        }
                        setRightScreen(idbackside);
                    }

                } catch (JSONException e) {
                    Util_Log.e(LOGTAG, "Parse document info json failed", e);

                    if (Objects.requireNonNull(getActivity()).isDestroyed()) {
                        return;
                    }
                    dismissProgressDialog();

                }
            }

            @Override
            public void failure(EidError error) {

                if (Objects.requireNonNull(getActivity()).isDestroyed()) {
                    return;
                }
                dismissProgressDialog();

                Util.showRESTCallErrorDialog(context, error.getResponse().getStatus(), Fragment_Capture.this);


            }
        };

        Call<Object> result = service.getClassification(eIDSdk.getTransactionToken(), eIDSdk.getCompanyId());
        result.enqueue(callback);
    }

    private void sendDocumentInfoRESTCall(Models_DocumentInfo models_documentInfo) {
        //Util_Log.i(LOGTAG, "http sendScreenshot called Bis");
        String endPoint = Config.CURRENT_SERVER.getApiHost(eIDSdk.getTransactionToken());
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, getActivity());

        EidCallback<Object> callback = new EidCallback<>() {
            @Override
            public void failure(EidError error) {
                // updateErrorScreen(false);

                dismissProgressDialog();
                Util.showRESTCallErrorDialog(context, error.getResponse().getStatus(), Fragment_Capture.this);

            }

            @Override
            public void success(Object resultObject, Response response) {
                if (Objects.requireNonNull(getActivity()).isDestroyed()) {
                    return;
                }
                dismissProgressDialog();
                setRightScreen(idbackside);
            }
        };

        Call<Object> result = service.uploadDocumentInfo(
                models_documentInfo,
                eIDSdk.getTransactionToken(),
                eIDSdk.getCompanyId()
        );

        result.enqueue(callback);

    }

    public AlertDialog setProgressDialog() {

        int llPadding = 30;
        LinearLayout ll = new LinearLayout(getContext());
        ll.setOrientation(LinearLayout.HORIZONTAL);
        ll.setPadding(llPadding, llPadding, llPadding, llPadding);
        ll.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams llParam = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        llParam.gravity = Gravity.CENTER;
        ll.setLayoutParams(llParam);

        ProgressBar progressBar = new ProgressBar(getContext());
        progressBar.setIndeterminate(true);
        progressBar.setPadding(0, 0, llPadding, 0);
        progressBar.setLayoutParams(llParam);
        progressBar.getIndeterminateDrawable().setColorFilter(getResources().getColor(R.color.primaryColor), PorterDuff.Mode.MULTIPLY);

        llParam = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        llParam.gravity = Gravity.CENTER;
        TextView tvText = new TextView(getContext());
        tvText.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_VIDEO_IDENT_IMAGE_PROCESSING, Util_Strings.LOCAL_KEY_VIDEO_IDENT_IMAGE_PROCESSING));

        tvText.setTextColor(getResources().getColor(R.color.primarytextColor));
        tvText.setTextSize(14);
        tvText.setLayoutParams(llParam);

        ll.addView(progressBar);
        ll.addView(tvText);

        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(getContext(), R.style.IDnowAlertDialogStyle));

        builder.setCancelable(false);
        builder.setView(ll);


        takingImageDialog = builder.create();
        takingImageDialog.show();
        Window window = takingImageDialog.getWindow();
        if (window != null) {
            WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
            layoutParams.copyFrom(takingImageDialog.getWindow().getAttributes());
            layoutParams.width = LinearLayout.LayoutParams.WRAP_CONTENT;
            layoutParams.height = LinearLayout.LayoutParams.WRAP_CONTENT;
            takingImageDialog.getWindow().setAttributes(layoutParams);
        }

        return takingImageDialog;
    }

    @Override
    public void onUserCancel() {
        if (ID_DOCUMENT.equals(idfrontside)) {
            eIDSdk.recordEvent(eIDSdk.EVENT_EID_FRONT_CAPTURE_CROSS);
        } else if (ID_DOCUMENT.equals(idbackside)) {
            eIDSdk.recordEvent(eIDSdk.EVENT_EID_BACK_CAPTURE_CROSS);
        }
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_Capture.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_Capture.class);
    }

    public void redirection() {
        Util_Log.d("IdentSdk", "redirection FRAGMENT CAPTURE 222");

        getActivity().runOnUiThread(new Runnable() {
            @SuppressLint("UseRequireInsteadOfGet")
            public void run() {

                Util_Log.d("IdentSdk", "redirection FRAGMENT CAPTURE111");

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_VERIFICATION_STEP_CONTINUE);

                Fragment_HoldIDBack fragment_holdIDBack = new Fragment_HoldIDBack();
                ((eIDActivity) getActivity()).hideIntroFragment(Fragment_Capture.this);
                ((eIDActivity) getActivity()).showIntroFragment(fragment_holdIDBack);

            }
        });
    }

    private void toggleFlash() {
        try {
            if (CameraHelper.INSTANCE.hasTorch()) {
                try {
                    camera.setTorchEnabled(!flashLightOn);
                    flashLightOn = !flashLightOn;

                    defaultTorchButton.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                    getResources(),
                                    flashLightOn ? R.drawable.flashlight_off : R.drawable.flashlight_on,
                                    null));
                } catch (Exception e) {
                    Util_Log.e(LOGTAG, "Set camera torch to " + !flashLightOn + " failed", e);
                }
            } else {
                Toast.makeText(context, getString(R.string.photo_ident_failure_activating_flash), Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Util_Log.e(LOGTAG, "Toggle camera flash failed", e);
        }
    }

}