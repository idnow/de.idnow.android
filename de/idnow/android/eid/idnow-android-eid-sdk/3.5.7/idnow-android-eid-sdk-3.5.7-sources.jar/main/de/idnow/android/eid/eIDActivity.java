package de.idnow.android.eid;

import static android.os.Build.VERSION.SDK_INT;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;

import de.idnow.android.eid.AusweisApp2SDK.core.IdentificationCallback;
import de.idnow.android.eid.AusweisApp2SDK.core.IdentificationManager;
import de.idnow.android.eid.AusweisApp2SDK.util.NfcInterceptorActivity;
import de.idnow.android.eid.fragments.Fragment_Capture;
import de.idnow.android.eid.fragments.Fragment_Capture_Desc;
import de.idnow.android.eid.fragments.Fragment_EnterPin_5_digit;
import de.idnow.android.eid.fragments.Fragment_EnterPin_6_digit;
import de.idnow.android.eid.fragments.BaseFragment;
import de.idnow.android.eid.fragments.Fragment_HoldIDBack;
import de.idnow.android.eid.fragments.Fragment_OTP;
import de.idnow.android.eid.fragments.Fragment_PIN_digit_chooser;
import de.idnow.android.eid.fragments.Fragment_ProgressPage;
import de.idnow.android.eid.fragments.Fragment_ShowDocument;
import de.idnow.android.eid.fragments.Fragment_Signing;
import de.idnow.android.eid.fragments.Fragment_VerificationStatus;
import de.idnow.android.eid.fragments.Fragment_Verify;
import de.idnow.android.eid.fragments.Fragment_choose_eID_type;
import de.idnow.android.eid.models.ModelCustomLog;
import de.idnow.android.eid.models.Model_failedReason;
import de.idnow.android.eid.models.Models_EmptyJson;
import de.idnow.android.eid.models.Models_requestStep;
import de.idnow.android.eid.network.EidCallback;
import de.idnow.android.eid.network.EidError;
import de.idnow.android.eid.network.IDnowRestClient;
import de.idnow.android.eid.network.Network_RESTCalls;
import de.idnow.android.eid.util.Util;
import de.idnow.android.eid.util.Util_Log;
import de.idnow.android.eid.util.Util_Strings;
import retrofit2.Call;
import retrofit2.Response;

public class eIDActivity extends NfcInterceptorActivity {
    private static final String LOGTAG = "IDNOW_eIDActivity";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eid);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        eIDSdk.onCreate(this);

        if (!(Objects.equals(Config.APP_URL, "") && Objects.equals(Config.APP_KEY, ""))) {
            ModelCustomLog modelCustomLog = new ModelCustomLog();
            modelCustomLog.setAppKey(Config.APP_KEY);
            modelCustomLog.setUrl(Config.APP_URL);
            eIDSdk.init(eIDActivity.this, modelCustomLog);
        }

        Util_Log.i(LOGTAG, "Messages from Backend : " + eIDSdk.getMessagesfromBackend());
        showProgressPage();
    }

    public void showIntroFragment(Fragment fragment) {

        if (fragment instanceof Fragment_PIN_digit_chooser) {
            Fragment_PIN_digit_chooser.showMe(this);
        } else if (fragment instanceof Fragment_EnterPin_6_digit) {
            Fragment_EnterPin_6_digit.showMe(this);
        } else if (fragment instanceof Fragment_EnterPin_5_digit) {
            Fragment_EnterPin_5_digit.showMe(this);
        } else if (fragment instanceof Fragment_HoldIDBack) {
            Fragment_HoldIDBack.showMe(this);
        } else if (fragment instanceof Fragment_ProgressPage) {
            Fragment_ProgressPage.showMe(this);
        } else if (fragment instanceof Fragment_Capture) {
            Fragment_Capture.showMe(this);
        } else if (fragment instanceof Fragment_Capture_Desc) {
            Fragment_Capture_Desc.showMe(this);
        } else if (fragment instanceof Fragment_Verify) {
            Fragment_Verify.showMe(this);
        } else if (fragment instanceof Fragment_OTP) {
            Fragment_OTP.showMe(this);
        } else if (fragment instanceof Fragment_ShowDocument) {
            Fragment_ShowDocument.showMe(this);
        } else if (fragment instanceof Fragment_Signing) {
            Fragment_Signing.showMe(this);
        } else if (fragment instanceof Fragment_VerificationStatus) {
            Fragment_VerificationStatus.showMe(this);
        } else if (fragment instanceof Fragment_choose_eID_type) {
            Fragment_choose_eID_type.showMe(this);
        }
    }

    public void hideIntroFragment(Fragment fragment) {
        if (fragment instanceof Fragment_PIN_digit_chooser) {
            Fragment_PIN_digit_chooser.hideMe(this);
        } else if (fragment instanceof Fragment_EnterPin_5_digit) {
            Fragment_EnterPin_5_digit.hideMe(this);
        } else if (fragment instanceof Fragment_EnterPin_6_digit) {
            Fragment_EnterPin_6_digit.hideMe(this);
        } else if (fragment instanceof Fragment_HoldIDBack) {
            Fragment_HoldIDBack.hideMe(this);
        } else if (fragment instanceof Fragment_ProgressPage) {
            Fragment_ProgressPage.hideMe(this);
        } else if (fragment instanceof Fragment_Capture) {
            Fragment_Capture.hideMe(this);
        } else if (fragment instanceof Fragment_Capture_Desc) {
            Fragment_Capture_Desc.hideMe(this);
        } else if (fragment instanceof Fragment_Verify) {
            Fragment_Verify.hideMe(this);
        } else if (fragment instanceof Fragment_OTP) {
            Fragment_OTP.hideMe(this);
        } else if (fragment instanceof Fragment_Signing) {
            Fragment_Signing.hideMe(this);
        } else if (fragment instanceof Fragment_VerificationStatus) {
            Fragment_VerificationStatus.hideMe(this);
        } else if (fragment instanceof Fragment_ShowDocument) {
            Fragment_ShowDocument.hideMe(this);
        } else if (fragment instanceof Fragment_choose_eID_type) {
            Fragment_choose_eID_type.hideMe(this);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        Fragment visibleFragment = getVisibleFragment();
        // Mirror the header cross button: record the screen's cancellation event
        // so back gesture/button cancellations are tracked too.
        if (visibleFragment instanceof BaseFragment) {
            ((BaseFragment) visibleFragment).onUserCancel();
        }
    }

    public Fragment getVisibleFragment() {

        FragmentManager fragmentManager = eIDActivity.this.getSupportFragmentManager();

        List<Fragment> fragments = fragmentManager.getFragments();

        for (Fragment fragment : fragments) {

            if (!(fragment instanceof Fragment_VerificationStatus)) {
                Util.quitDialog(this, fragment);
            }
            if (fragment != null && fragment.isVisible()) {
                return fragment;
            }

        }
        return null;
    }


    public void identificationCanceledRESTCall(Fragment fragment, String failureReason, boolean updateUI) {
        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, eIDSdk.getInstance().getAppContext());

        EidCallback<Object> callback = new EidCallback<>() {

            @Override
            public void failure(EidError error) {

            }

            @Override
            public void success(Object resultObject, Response response) {

                if (updateUI) {
                    Config.EID_STATUS = false;

                    Config.RESULT_CODE = failureReason.equals(Config.CANCEL_REASON)
                            ? Config.RESULT_CODE_CANCEL
                            : Config.RESULT_CODE_FAILED;

                    Config.GENERAL_CALLBACK = Config.CALLBACK_IDENT_FAILED;

                    Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();

                    hideIntroFragment(fragment);
                    showIntroFragment(fragment_verificationStatus);
                }
            }
        };

        Call<Object> result = service.identificationCanceled(
                new Model_failedReason(failureReason),
                eIDSdk.getTransactionToken(),
                eIDSdk.getCompanyId()
        );
        result.enqueue(callback);
    }

    public void identificationCanceledRESTCall(Fragment fragment, String failureReason) {
        identificationCanceledRESTCall(fragment, failureReason, true);
    }

    public void errorEIDscreen(Fragment fragment, String callback) {
        Config.GENERAL_CALLBACK = callback;
        identificationCanceledRESTCall(fragment, "EID_CARD_SCAN_UNSUCCESSFUL");
        Config.EID_ERROR_CODE = "System Error";
    }

    public void changeStepRESTCall(String nameOfTheStepToSet) {
        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        Network_RESTCalls service = IDnowRestClient.getRestClient().getCallsForEndpoint(endPoint, eIDSdk.getInstance().getAppContext());

        EidCallback<Models_EmptyJson> callback = new EidCallback<>() {
            @Override
            public void success(Models_EmptyJson models_requestStep, Response response) {
            }

            @Override
            public void failure(EidError error) {
            }
        };

        String nameOfStepAPI = "";
        if (nameOfTheStepToSet.equals("CARD_SCAN")) {
            nameOfStepAPI = "CARD_SCAN";
        }
        if (nameOfTheStepToSet.equals("PIN_ENTRY")) {
            nameOfStepAPI = "PIN_ENTRY";
        }

        Call<Models_EmptyJson> result = service.changeStep(
                new Models_requestStep(nameOfStepAPI),
                eIDSdk.getCompanyId(),
                eIDSdk.getTransactionToken()
        );
        result.enqueue(callback);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 2296) {
            if (SDK_INT >= Build.VERSION_CODES.R) {
                if (!Environment.isExternalStorageManager()) {
                    Toast.makeText(this, "Allow permission for storage access!", Toast.LENGTH_SHORT).show();
                }
            }
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void showProgressPage() {
        Fragment_ProgressPage fragmentProgressPage = new Fragment_ProgressPage();

        showIntroFragment(fragmentProgressPage);

    }

    public Fragment getCurrentFragment() {
        FragmentManager fragmentManager = eIDActivity.this.getSupportFragmentManager();

        List<Fragment> fragments = fragmentManager.getFragments();
        for (Fragment fragment : fragments) {
            if (fragment != null && fragment.isVisible()) {
                return fragment;
            }
        }
        return null;
    }

    @Override
    protected @NotNull IdentificationCallback provideIdentificationCallback() {
        return new IdentificationCallback() {
            @Override
            public void onNfcTagDispatchError() {

            }

            @Override
            public void onPinEntryLastAttemptBeforeCan() {
                Fragment_HoldIDBack.getInstance()
                        .displayBottomSheetGovernikus(Util.BottomSheetType.ON_WRONG_PIN_TRIES_LAST);
            }

            @Override
            public void onFlowRestartRequested() {
                try {
                    Fragment_PIN_digit_chooser.getInstance().flowChooser();
                } catch (Exception e) {
                    Util_Log.e(LOGTAG, "");
                }
            }

            @Override
            public void onAccessRightsRequired(@org.jetbrains.annotations.Nullable List<@NotNull String> required) {
                Config.DOCUMENT_INFO = required;
                IdentificationManager.INSTANCE.requestGetCertificate();
            }

            @Override
            public void onNameMismatchError() {
                Config.NAME_MISMATCH = true;
                onUnknownError();
            }

            @Override
            public void onUnknownError() {
                Config.GENERAL_CALLBACK = Config.CALLBACK_IDENT_FAILED;

                if (Fragment_HoldIDBack.getInstance() != null) {
                    Fragment_HoldIDBack.getInstance()
                            .displayBottomSheetGovernikus(Util.BottomSheetType.ON_EID_CARD_CHECK_FAILED);
                }
            }

            @Override
            public void onIdentificationError() {
                errorEIDscreen(getCurrentFragment(), Config.CALLBACK_IDENT_FAILED);
            }

            @Override
            public void onCardReadingStarted() {
                if (Config.PIN_IS_SET) {
                    if (!Fragment_HoldIDBack.getInstance().bottomSheetDialog.isShowing()) {
                        Fragment_HoldIDBack.getInstance()
                                .displayBottomSheetGovernikus(Util.BottomSheetType.BOTTOM_SHEET_CARD_DETECTION);
                    }
                }
            }

            @Override
            public void onPinEntryFailed(int retryCount) {
                switch (retryCount) {
                    case 1:
                        Fragment_HoldIDBack.getInstance()
                                .displayBottomSheetGovernikus(Util.BottomSheetType.ON_WRONG_PIN_TRIES_1);
                        break;
                    case 2:
                        Fragment_HoldIDBack.getInstance()
                                .displayBottomSheetGovernikus(Util.BottomSheetType.ON_WRONG_PIN_TRIES_2);
                        break;
                    case 3:
                        Fragment_HoldIDBack.getInstance().redirectUser();
                        break;
                }
            }

            @Override
            public void onPukEntryFailed() {
                Fragment_HoldIDBack.getInstance().displayBottomSheetGovernikus(Util.BottomSheetType.ON_CARD_BLOCKED);
            }

            @Override
            public void onCardEncryptedDataTransferred() {
                if (Fragment_HoldIDBack.getInstance() != null) {
                    Fragment_HoldIDBack.getInstance()
                            .displayBottomSheetGovernikus(Util.BottomSheetType.ON_SUCCESS_TRANSFER_ENCRYPTED_DATA);
                }
            }

            @Override
            public void onCardCertificationVerified() {
                Fragment_HoldIDBack.getInstance()
                        .displayBottomSheetGovernikus(Util.BottomSheetType.ON_SUCCESS_CHECK_CERTIFICATION);
            }

            @Override
            public void onCardPinVerified() {
                Fragment_HoldIDBack.getInstance()
                        .displayBottomSheetGovernikus(Util.BottomSheetType.ON_SUCCESS_PIN);
            }

            @Override
            public void onCardConnectionEstablished() {
                Fragment_HoldIDBack.getInstance()
                        .displayBottomSheetGovernikus(Util.BottomSheetType.ON_SUCCESS_ESTABLISH_CONNECTION);
            }

            @Override
            public void onSdkConnectionError() {
                onIdentificationError();
            }

            @Override
            public void onNewPinEntryRequested() {
                Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_NEW_6_DIGIT_PIN;
                Fragment_HoldIDBack.getInstance().redirectUser();
            }

            @Override
            public void onPinChanged(boolean result) {
                if (result) {
                    Fragment_HoldIDBack.getInstance()
                            .displayBottomSheetGovernikus(Util.BottomSheetType.ON_SUCCESS_CHANGE_PIN);
                } else {
                    if (!Config.USER_RESTART_FLOW)
                        return;

                    try {
                        Fragment_PIN_digit_chooser.getInstance().flowChooser();
                    } catch (Exception e) {
                        Util_Log.e(LOGTAG, "");
                    }
                }
            }

            @Override
            public void onCertificateInserted() {
                if (Config.USER_RESTART_FLOW && !Config.FROM_SCRATCH) {
                    Fragment_EnterPin_6_digit.getInstance().redirectionUser();
                    Config.USER_RESTART_FLOW = false;
                } else if (Config.FROM_SCRATCH) {
                    if (Fragment_VerificationStatus.getInstance() != null) {
                        Config.EID_PIN_CHOOSER = Util_Strings.SIX_DIGIT_PIN;
                        Config.DIGIT_SCREEN_TO_SHOW =
                                Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                        Fragment_VerificationStatus.getInstance().redirectUser();
                        Config.FROM_SCRATCH = false;
                    }
                } else if (Objects.equals(Config.EID_PIN_CHOOSER, Util_Strings.SIX_DIGIT_PIN)) {
                    if (Fragment_PIN_digit_chooser.getInstance() != null) {
                        Fragment_PIN_digit_chooser.getInstance().redirectUser();
                    }
                } else if (Objects.equals(Config.EID_PIN_CHOOSER, Util_Strings.FIVE_DIGIT_PIN)) {
                    if (Fragment_VerificationStatus.getInstance() != null) {
                        Config.EID_PIN_CHOOSER = Util_Strings.SIX_DIGIT_PIN;
                        Config.DIGIT_SCREEN_TO_SHOW =
                                Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                        Fragment_VerificationStatus.getInstance().redirectUser();
                    }
                }
            }

            @Override
            public void onProcessPaused() {

            }

            @Override
            public void onCardRecognized() {
                if (Fragment_HoldIDBack.getInstance() != null && Fragment_HoldIDBack.getInstance().bottomSheetDialog != null) {
                    Fragment_HoldIDBack.getInstance().bottomSheetDialog.dismiss();
                }

                Fragment currentFragment = Config.CURRENT_FRAGMENT;
                if (currentFragment == Fragment_Capture.getInstance()) {
                    Fragment_Capture.getInstance().redirection();
                } else if (currentFragment == Fragment_PIN_digit_chooser.getInstance()) {
                    Fragment_PIN_digit_chooser.getInstance().redirectScanning();
                } else if (currentFragment == Fragment_Capture_Desc.getInstance()) {
                    Fragment_Capture_Desc.getInstance().redirection();
                } else if (currentFragment == Fragment_EnterPin_6_digit.getInstance()) {
                    Fragment_EnterPin_6_digit.getInstance().redirectScanning();
                }
            }

            @Override
            public void onIdentificationCompleted() {
                if (Fragment_HoldIDBack.getInstance() != null) {
                    Fragment_HoldIDBack.getInstance()
                            .displayBottomSheetGovernikus(Util.BottomSheetType.ON_EID_SUCCESS_SENDING_PIN);
                }
            }
        };
    }
}
