package de.idnow.android.eid.fragments;

import static de.idnow.android.eid.Config.CALLBACK_CARD_BLOCKED;
import static de.idnow.android.eid.Config.CALLBACK_CHANGE_PIN_SUCCESSFUL;
import static de.idnow.android.eid.Config.CALLBACK_FINAL_ATTEMPT;
import static de.idnow.android.eid.Config.CALLBACK_IDENT_SUCCEEDED;
import static de.idnow.android.eid.Config.CALLBACK_ONE_ATTEMPT;
import static de.idnow.android.eid.Config.CALLBACK_SECOND_ATTEMPT;
import static de.idnow.android.eid.Config.GENERAL_CALLBACK;
import static de.idnow.android.eid.util.Util.BottomSheetType.BOTTOM_SHEET_READY_TO_SCAN;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.List;

import de.idnow.android.eid.Authada.ControlAuthadaIntegration;
import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.UI.HeaderView;
import de.idnow.android.eid.UI.SubtitleView;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.util.Util;
import de.idnow.android.eid.util.Util_Log;
import de.idnow.android.eid.util.Util_Status;
import de.idnow.android.eid.util.Util_Strings;
import kotlin.Unit;

public class Fragment_HoldIDBack extends BaseFragment {

    private static Object context1;
    static Context context;

    private LottieAnimationView sfGifView;

    private static final String LOGTAG = "FRAGMENT HOLD ID DACK";

    public static LottieAnimationView establish_connection, check_pin, transferring_data, check_certif;

    public static Dialog myDialog;

    public static TextView touch_id_back_detecting, dialog_establish_connection, dialog_sendpin_text, dialog_transfer_data, dialog_error_text, dialog_check_certif_text;

    Bundle nfcConfig;

    FragmentActivity fragmentActivity;

    public View bottomSheetContentView, view_list_check;

    public BottomSheetDialog bottomSheetDialog;
    public BottomSheetDialog bottomSheetMoreInfo;
    public Util.BottomSheetType currentBottomSheet = BOTTOM_SHEET_READY_TO_SCAN;

    public TextView bottomsheet_description;

    public LottieAnimationView bottomsheet_image_sign;

    public ImageButton bottom_sheet_cancel_cross;

    public View view1;

    private HeaderView header;
    private SubtitleView subtitle;

    private static Fragment_HoldIDBack instance;

    ControlAuthadaIntegration controlAuthadaIntegration = new ControlAuthadaIntegration();

    public Fragment_HoldIDBack(){
        super(false);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_hold_id_back, container, false);

        eIDSdk.recordEvent(eIDSdk.EVENT_EID_CARD_SCAN_SCREEN_SHOWN);
        eIDSdk.startEvent(eIDSdk.EVENT_EID_CARD_SCAN_SCREEN_TIME_SPENT);

        Config.CANCEL_REASON = "EID_USER_CANCELLATION_CARD_SCAN";

        instance = this;
        header = view.findViewById(R.id.header);
        subtitle = view.findViewById(R.id.subtitle);

        view1 = view;
        context = getContext();

        context1 = getContext();

        header.setCancelAction(() -> {
            onUserCancel();
            ((eIDActivity) context).getVisibleFragment();
            return Unit.INSTANCE;
        });

        sfGifView = view.findViewById(R.id.sf_gif);
        sfGifView.setAnimation("animate_card_scan.json");
        sfGifView.setRepeatCount(ValueAnimator.INFINITE);
        sfGifView.playAnimation();

        touch_id_back_detecting = view.findViewById(R.id.touch_id_back_detecting);

        header.setTitle(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_HOLDID_PAGE_TITLE, Util_Strings.LOCAL_EID_HOLDID_PAGE_TITLE));
        subtitle.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_HOLDID_PAGE_DESC, Util_Strings.LOCAL_EID_HOLDID_PAGE_DESC));

        touch_id_back_detecting.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_HOLDID_PAGE_DETECTING, Util_Strings.LOCAL_EID_HOLDID_PAGE_DETECTING));

        touch_id_back_detecting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moreInfo();
            }
        });

        setBottomSheet(context);

        fragmentActivity = getActivity();

        Config.EID_CANCEL_IDENT = false;

        myDialog = new Dialog(context);

        this.nfcConfig = new Bundle();
        this.nfcConfig.putInt("presence", 2000);

        if (!eIDSdk.getEIDTSP().equals("Governikus")) {
            startAuthentication(bottomSheetDialog);
        }

        return view;
    }


    public void startAuthentication(BottomSheetDialog bottomSheetDialog) {
        if (controlAuthadaIntegration.isAuthenticationInitialized()) {
            controlAuthadaIntegration.startAuthenticationWithPin(context, Config.PIN_EID, Fragment_HoldIDBack.this, bottomSheetDialog);
        } else {
            Util_Log.e(LOGTAG, "ERROR AUTHENTICATION");
        }
    }

    public BottomSheetDialog getBottomSheetDialog() {
        return bottomSheetDialog;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() instanceof eIDActivity) {
            ((eIDActivity) getActivity()).requestNfcScanning();
        } else {
            Util_Log.e(LOGTAG, "Error starting the NFC scanning service");
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (getActivity() instanceof eIDActivity) {
            ((eIDActivity) getActivity()).releaseNfcScanning();
        } else {
            Util_Log.e(LOGTAG, "Error stopping the NFC scanning service");
        }
    }

    @Override
    public void onUserCancel() {
        eIDSdk.recordEvent(eIDSdk.EVENT_EID_CARD_SCAN_SCREEN_CROSS);
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_HoldIDBack.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_HoldIDBack.class);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        setBottomSheet(context);
    }

    public void setBottomSheet(final Context context) {

        bottomSheetContentView = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_scan, null);
        bottomSheetDialog = new BottomSheetDialog(context, R.style.BottomSheetDialog);
        bottomSheetDialog.setContentView(bottomSheetContentView);
        bottomSheetDialog.setCancelable(false);
        setBottomSheetComponent(bottomSheetDialog);

        establish_connection.setAnimation("static_loading_round.json");
        check_pin.setAnimation("static_loading_round.json");
        transferring_data.setAnimation("static_loading_round.json");
        check_certif.setAnimation("static_loading_round.json");

        bottom_sheet_cancel_cross.setVisibility(View.GONE);

        bottom_sheet_cancel_cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismissDialog(bottomSheetDialog);
            }
        });

        dialog_establish_connection.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_HOLDID_PAGE_DESC1, Util_Strings.LOCAL_EID_HOLDID_PAGE_DESC1));
        dialog_sendpin_text.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_HOLDID_PAGE_DESC2, Util_Strings.LOCAL_EID_HOLDID_PAGE_DESC2));
        dialog_check_certif_text.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_HOLDID_PAGE_DESC3, Util_Strings.LOCAL_EID_HOLDID_PAGE_DESC3));
        dialog_transfer_data.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_HOLDID_PAGE_DESC4, Util_Strings.LOCAL_EID_HOLDID_PAGE_DESC4));

    }

    public void redirectUser() {
        getActivity().runOnUiThread(new Runnable() {
            public void run() {
                dismissDialog(bottomSheetDialog);
                Fragment_EnterPin_6_digit fragment_enterPin_6_digit = new Fragment_EnterPin_6_digit();
                ((eIDActivity) getActivity()).hideIntroFragment(Fragment_HoldIDBack.this);
                ((eIDActivity) getActivity()).showIntroFragment(fragment_enterPin_6_digit);
            }
        });
    }

    public void setBottomSheetComponent(BottomSheetDialog bottomSheetComponent) {
        bottomsheet_description = bottomSheetComponent.findViewById(R.id.bottomsheet_description);
        bottomsheet_image_sign = bottomSheetComponent.findViewById(R.id.bottomsheet_image_sign);
        bottom_sheet_cancel_cross = bottomSheetComponent.findViewById(R.id.bottom_sheet_cancel_cross);
        view_list_check = bottomSheetComponent.findViewById(R.id.view_list_check);

        establish_connection = bottomSheetComponent.findViewById(R.id.establish_connection);
        check_pin = bottomSheetComponent.findViewById(R.id.check_pin);
        transferring_data = bottomSheetComponent.findViewById(R.id.transferring_data);
        check_certif = bottomSheetComponent.findViewById(R.id.check_certif);

        dialog_establish_connection = bottomSheetComponent.findViewById(R.id.dialog_establish_connection);
        dialog_sendpin_text = bottomSheetComponent.findViewById(R.id.dialog_sendpin_text);
        dialog_transfer_data = bottomSheetComponent.findViewById(R.id.dialog_transfer_data);
        dialog_check_certif_text = bottomSheetComponent.findViewById(R.id.dialog_check_certif_text);
    }

    public void fallBacktoPIN(BottomSheetDialog bottomSheetDialog) {
        Config.ATTACH_EID = false;

        bottomSheetDialog.dismiss();

        IDnowFragmentManager.hideFragment(((eIDActivity) context1), Fragment_HoldIDBack.class);

        IDnowFragmentManager.showFragment(((eIDActivity) context1), Fragment_EnterPin_6_digit.class);
    }

    public void dismissDialog(BottomSheetDialog bottomSheetDialog) {
        Config.SHOWING_DIALOG = false;
        if (bottomSheetDialog != null && bottomSheetDialog.isShowing()) {
            bottomSheetDialog.dismiss();
        }
    }

    public void showDialog(BottomSheetDialog bottomSheetDialog) {
        Config.SHOWING_DIALOG = true;
        bottomSheetDialog.show();
    }

    public boolean onBackPressed() {
        return false;
    }

    public void displayBottomSheetAuthada(Util.BottomSheetType bottomSheetType, Context context, BottomSheetDialog bottomSheetDialog) {

        if (bottomSheetDialog != null) {
            if (!bottomSheetDialog.isShowing()) {
                showDialog(bottomSheetDialog);
            }
            setBottomSheetComponent(bottomSheetDialog);

            currentBottomSheet = bottomSheetType;
            switch (bottomSheetType) {
                case BOTTOM_SHEET_READY_TO_SCAN:
                    bottomsheet_image_sign.setAnimation("animate_loading_lock.json");
                    bottomsheet_image_sign.setRepeatCount(ValueAnimator.INFINITE);
                    bottomsheet_image_sign.playAnimation();

                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_HOLD, Util_Strings.LOCAL_KEY_EID_SCAN_HOLD));
                    break;

                case BOTTOM_SHEET_CARD_DETECTION:
                    setBottomSheetComponent(bottomSheetDialog);
                    bottomsheet_image_sign.setVisibility(View.VISIBLE);
                    bottomsheet_image_sign.setAnimation("animate_loading_lock.json");
                    bottomsheet_image_sign.setRepeatCount(ValueAnimator.INFINITE);
                    bottomsheet_image_sign.playAnimation();
                    bottomsheet_description.setVisibility(View.VISIBLE);
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_HOLD, Util_Strings.LOCAL_KEY_EID_SCAN_HOLD));

                    Handler handler9 = new Handler();
                    handler9.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            bottomsheet_image_sign.setVisibility(View.VISIBLE);
                            bottomsheet_description.setVisibility(View.GONE);
                            view_list_check.setVisibility(View.VISIBLE);
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    establish_connection.setAnimation("static_checkbox_round.json");
                                    establish_connection.playAnimation();
                                }
                            }, 1000);
                            check_pin.setAnimation("static_loading_round.json");
                            check_pin.playAnimation();

                            check_certif.setAnimation("static_loading_round.json");
                            check_certif.playAnimation();

                            transferring_data.setAnimation("static_loading_round.json");
                            transferring_data.playAnimation();

                        }
                    }, 1500);

                    break;
                case ON_SUCCESS_PIN:

                    setBottomSheetComponent(bottomSheetDialog);
                    bottomsheet_image_sign.setVisibility(View.VISIBLE);
                    bottomsheet_image_sign.setAnimation("animate_loading_lock.json");
                    bottomsheet_image_sign.setRepeatCount(ValueAnimator.INFINITE);
                    bottomsheet_image_sign.playAnimation();

                    bottomsheet_description.setVisibility(View.GONE);
                    view_list_check.setVisibility(View.VISIBLE);
                    establish_connection.setAnimation("static_checkbox_round.json");
                    establish_connection.playAnimation();
                    check_pin.setAnimation("static_checkbox_round.json");
                    check_pin.playAnimation();

                    Handler handler1 = new Handler();

                    handler1.postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            check_certif.setAnimation("static_checkbox_round.json");
                            check_certif.playAnimation();

                            Handler handler2 = new Handler();

                            handler2.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    transferring_data.setAnimation("static_checkbox_round.json");
                                    transferring_data.playAnimation();

                                    Handler handler21 = new Handler();
                                    handler21.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            controlAuthadaIntegration.sendResultToken(context, Fragment_HoldIDBack.this, bottomSheetDialog);

                                        }
                                    }, 1000);

                                }
                            }, 2000);
                        }
                    }, 2000);

                    break;

                case BOTTOM_SHEET_LOST_CONNECTION:

                    view_list_check.setVisibility(View.GONE);
                    bottomsheet_description.setVisibility(View.VISIBLE);
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_COMPATIBLE, Util_Strings.LOCAL_KEY_EID_SCAN_COMPATIBLE));
                    bottomsheet_image_sign.setAnimation("static_generic_error.json");

                    Handler handler222 = new Handler();

                    handler222.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            dismissDialog(bottomSheetDialog);
                            Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                            controlAuthadaIntegration.stopAuthada();
                            fallBacktoPIN(bottomSheetDialog);
                        }
                    }, 1500);

                    break;

                case ON_PROCESS_TERMINATED:

                    Handler handler2 = new Handler();

                    handler2.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                            fallBacktoPIN(bottomSheetDialog);
                        }
                    }, 1500);
                    break;

                case BOTTOM_SHEET_INCORRECT_CAN_PIN:
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_WRONG_CAN, Util_Strings.LOCAL_KEY_EID_SCAN_WRONG_CAN));
                    bottomsheet_image_sign.setAnimation("static_generic_error.json");

                    break;

                case BOTTOM_SHEET_VERIFICATION_COMPLETED:
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_VERIFICATION_COMPLETED, Util_Strings.LOCAL_KEY_EID_VERIFICATION_COMPLETED));
                    bottomsheet_image_sign.setAnimation("animate_checkmark.json");

                    break;

                case BOTTOM_SHEET_CLOSED:
                    break;

                case ON_EID_NOT_ATTACHED:
                    bottomsheet_image_sign.setVisibility(View.VISIBLE);
                    bottomsheet_description.setVisibility(View.VISIBLE);
                    view_list_check.setVisibility(View.GONE);
                    bottomsheet_image_sign.setAnimation("animate_loading_lock.json");
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_HOLD, Util_Strings.LOCAL_KEY_EID_SCAN_HOLD));
                    break;
                case ON_EID_SUCCESS_SENDING_PIN:
                    setBottomSheetComponent(bottomSheetDialog);
                    bottomsheet_image_sign.setVisibility(View.VISIBLE);
                    bottomsheet_image_sign.setAnimation("animate_checkmark.json");
                    bottomsheet_image_sign.playAnimation();
                    bottomsheet_description.setVisibility(View.VISIBLE);
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_VERIFICATION_COMPLETED, Util_Strings.LOCAL_KEY_EID_VERIFICATION_COMPLETED));
                    view_list_check.setVisibility(View.GONE);

                    Handler handler_success = new Handler();
                    handler_success.postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            if (eIDSdk.getEnableEIDQES()) {
                                GENERAL_CALLBACK = CALLBACK_IDENT_SUCCEEDED;
                                dismissDialog(bottomSheetDialog);
                                Config.SIGNING_SCREEN = Util_Status.SCREEN_PREPARE_SIGNING;
                                Fragment_Verify fragment_verify = new Fragment_Verify();
                                ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                                ((eIDActivity) context).showIntroFragment(fragment_verify);
                            } else {
                                GENERAL_CALLBACK = CALLBACK_IDENT_SUCCEEDED;
                                dismissDialog(bottomSheetDialog);
                                Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();
                                ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                                ((eIDActivity) context).showIntroFragment(fragment_verificationStatus);
                            }
                        }
                    }, 2000);
                    break;

                case ON_CAN_WRONG:
                    bottomsheet_image_sign.setVisibility(View.VISIBLE);
                    bottomsheet_image_sign.setAnimation("static_generic_error.json");
                    bottomsheet_description.setVisibility(View.VISIBLE);
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_CAN_PIN, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_CAN_PIN));

                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_WRONG_CAN, Util_Strings.LOCAL_KEY_EID_SCAN_WRONG_CAN));
                    view_list_check.setVisibility(View.GONE);

                    Handler handler22 = new Handler();

                    handler22.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_CAN_CODE;
                            fallBacktoPIN(bottomSheetDialog);
                        }
                    }, 1500);

                    break;

                case ON_WRONG_PIN_TRIES_2:

                    bottomsheet_image_sign.setVisibility(View.VISIBLE);
                    bottomsheet_image_sign.setAnimation("static_generic_error.json");
                    bottomsheet_image_sign.playAnimation();
                    bottomsheet_description.setVisibility(View.VISIBLE);
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_TWO_ATTEMPTS_LEFT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_TWO_ATTEMPTS_LEFT));
                    view_list_check.setVisibility(View.GONE);

                    Handler handler4 = new Handler();

                    handler4.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            GENERAL_CALLBACK = CALLBACK_SECOND_ATTEMPT;
                            dismissDialog(bottomSheetDialog);
                            controlAuthadaIntegration.stopAuthada();
                            Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();

                            ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                            ((eIDActivity) context).showIntroFragment(fragment_verificationStatus);

                        }
                    }, 1500);
                    break;

                case ON_WRONG_PIN_TRIES_1:

                    bottomsheet_image_sign.setVisibility(View.VISIBLE);
                    bottomsheet_image_sign.setAnimation("static_generic_error.json");
                    bottomsheet_image_sign.playAnimation();
                    bottomsheet_description.setVisibility(View.VISIBLE);
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT));
                    view_list_check.setVisibility(View.GONE);

                    Handler handler3 = new Handler();

                    handler3.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            GENERAL_CALLBACK = CALLBACK_FINAL_ATTEMPT;
                            dismissDialog(bottomSheetDialog);
                            controlAuthadaIntegration.stopAuthada();
                            Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();

                            ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                            ((eIDActivity) context).showIntroFragment(fragment_verificationStatus);
                        }
                    }, 1500);
                    break;

                case ON_EID_CARD_LOST:

                    showDialog(bottomSheetDialog);
                    // to define
                    view_list_check.setVisibility(View.GONE);
                    bottomsheet_description.setVisibility(View.VISIBLE);
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_HOLDID_PAGE_ERROR_PLACE, Util_Strings.LOCAL_EID_HOLDID_PAGE_ERROR_PLACE));


                    break;

                case ON_EID_CARD_CHECK_FAILED:

                    bottomsheet_image_sign.setVisibility(View.VISIBLE);
                    bottomsheet_image_sign.setAnimation("static_generic_error.json");
                    bottomsheet_image_sign.playAnimation();
                    bottomsheet_description.setVisibility(View.VISIBLE);
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_ESIGN_WRONG_TITLE, Util_Strings.LOCAL_KEY_EID_ESIGN_WRONG_TITLE));
                    view_list_check.setVisibility(View.GONE);

                    Handler handler6 = new Handler();

                    handler6.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            dismissDialog(bottomSheetDialog);
                            ((eIDActivity) context).errorEIDscreen(Fragment_HoldIDBack.this, GENERAL_CALLBACK);
                        }
                    }, 2000);

                    break;

                case ON_CARD_BLOCKED:

                    bottomsheet_image_sign.setVisibility(View.VISIBLE);
                    bottomsheet_image_sign.setAnimation("static_generic_error.json");
                    bottomsheet_image_sign.playAnimation();
                    bottomsheet_description.setVisibility(View.VISIBLE);
                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_BOTTOM_SHEET_CARD_BLOCKED, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_CARD_BLOCKED));
                    view_list_check.setVisibility(View.GONE);


                    Handler handler8 = new Handler();

                    handler8.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            dismissDialog(bottomSheetDialog);
                            Config.GENERAL_CALLBACK = CALLBACK_CARD_BLOCKED;
                            Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();

                            ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                            ((eIDActivity) context).showIntroFragment(fragment_verificationStatus);

                        }
                    }, 2000);

                    break;
            }
        }
    }

    public void displayBottomSheetGovernikus(Util.BottomSheetType bottomSheetType) {
        if (isAdded() && getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    if (getBottomSheetDialog() != null && extracted()) {
                        if (!bottomSheetDialog.isShowing()) {
                            getActivity().runOnUiThread(new Runnable() {
                                public void run() {
                                    showDialog(bottomSheetDialog);
                                }
                            });


                        }

                        setBottomSheetComponent(bottomSheetDialog);

                        currentBottomSheet = bottomSheetType;

                        switch (bottomSheetType) {
                            case BOTTOM_SHEET_READY_TO_SCAN:
                                bottomsheet_image_sign.setAnimation("animate_loading_lock.json");
                                bottomsheet_image_sign.playAnimation();
                                bottomsheet_image_sign.setRepeatCount(ValueAnimator.INFINITE);
                                Config.PLAY_ANIMATION_LOOP = true;
                                bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_HOLD, Util_Strings.LOCAL_KEY_EID_SCAN_HOLD));
                                break;

                            case BOTTOM_SHEET_CARD_DETECTION:

                                if (extracted()) {
                                    bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                    bottomsheet_image_sign.setAnimation("animate_loading_lock.json");
                                    bottomsheet_image_sign.setRepeatCount(ValueAnimator.INFINITE);
                                    bottomsheet_image_sign.playAnimation();
                                    bottomsheet_description.setVisibility(View.VISIBLE);
                                    bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_HOLD, Util_Strings.LOCAL_KEY_EID_SCAN_HOLD));
                                }
                                break;

                            case BOTTOM_SHEET_CARD_PAUSE:
                                bottomSheetDialog.dismiss();
                                break;

                            case ON_SUCCESS_DEFAULT:

                                setBottomSheetComponent(bottomSheetDialog);
                                bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                bottomsheet_description.setVisibility(View.GONE);
                                view_list_check.setVisibility(View.VISIBLE);

                                establish_connection.setAnimation("static_loading_round.json");
                                establish_connection.playAnimation();

                                check_pin.setAnimation("static_loading_round.json");
                                check_pin.playAnimation();

                                check_certif.setAnimation("static_loading_round.json");
                                check_certif.playAnimation();

                                transferring_data.setAnimation("static_loading_round.json");
                                transferring_data.playAnimation();

                                break;

                            case ON_SUCCESS_ESTABLISH_CONNECTION:

                                setBottomSheetComponent(bottomSheetDialog);
                                bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                bottomsheet_description.setVisibility(View.GONE);
                                view_list_check.setVisibility(View.VISIBLE);

                                establish_connection.setAnimation("static_loading_round.json");
                                establish_connection.playAnimation();

                                check_pin.setAnimation("static_loading_round.json");
                                check_pin.playAnimation();

                                check_certif.setAnimation("static_loading_round.json");
                                check_certif.playAnimation();

                                transferring_data.setAnimation("static_loading_round.json");
                                transferring_data.playAnimation();

                            case ON_SUCCESS_PIN:

                                setBottomSheetComponent(bottomSheetDialog);

                                bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                bottomsheet_description.setVisibility(View.GONE);
                                view_list_check.setVisibility(View.VISIBLE);

                                establish_connection.setAnimation("static_checkbox_round.json");
                                establish_connection.playAnimation();

                                Handler handlerS = new Handler();

                                handlerS.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        check_pin.setAnimation("static_checkbox_round.json");
                                        check_pin.playAnimation();

                                        check_certif.setAnimation("static_loading_round.json");
                                        check_certif.playAnimation();

                                        transferring_data.setAnimation("static_loading_round.json");
                                        transferring_data.playAnimation();
                                    }
                                }, 1000);


                                break;

                            case ON_SUCCESS_CHECK_CERTIFICATION:

                                setBottomSheetComponent(bottomSheetDialog);

                                bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                bottomsheet_description.setVisibility(View.GONE);
                                view_list_check.setVisibility(View.VISIBLE);

                                check_certif.setAnimation("static_checkbox_round.json");
                                check_certif.playAnimation();

                                transferring_data.setAnimation("static_loading_round.json");
                                transferring_data.playAnimation();

                                break;

                            case ON_SUCCESS_TRANSFER_ENCRYPTED_DATA:

                                setBottomSheetComponent(bottomSheetDialog);

                                bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                bottomsheet_description.setVisibility(View.GONE);
                                view_list_check.setVisibility(View.VISIBLE);

                                transferring_data.setAnimation("static_checkbox_round.json");
                                transferring_data.playAnimation();

                                break;

                            case BOTTOM_SHEET_LOST_CONNECTION:

                                view_list_check.setVisibility(View.GONE);
                                bottomsheet_description.setVisibility(View.VISIBLE);
                                bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_COMPATIBLE, Util_Strings.LOCAL_KEY_EID_SCAN_COMPATIBLE));
                                bottomsheet_image_sign.setAnimation("static_generic_error.json");

                                Handler handler222 = new Handler();

                                handler222.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        // dismissDialog(bottomSheetDialog);

                                        if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                                            Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_5_DIGIT_PIN;
                                        } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                                            Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                                        }
                                        fallBacktoPIN(bottomSheetDialog);
                                    }
                                }, 1500);

                                break;

                            case ON_PROCESS_TERMINATED:

                                Handler handler2 = new Handler();

                                handler2.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                                        fallBacktoPIN(bottomSheetDialog);
                                    }
                                }, 1500);
                                break;

                            case BOTTOM_SHEET_INCORRECT_CAN_PIN:
                                Config.PLAY_ANIMATION_LOOP = false;
                                bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_WRONG_CAN, Util_Strings.LOCAL_KEY_EID_SCAN_WRONG_CAN));
                                bottomsheet_image_sign.setAnimation("static_generic_error.json");

                                break;

                            case BOTTOM_SHEET_VERIFICATION_COMPLETED:
                                Config.PLAY_ANIMATION_LOOP = false;
                                bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_VERIFICATION_COMPLETED, Util_Strings.LOCAL_KEY_EID_VERIFICATION_COMPLETED));
                                bottomsheet_image_sign.setAnimation("animate_checkmark.json");

                                break;

                            case BOTTOM_SHEET_CLOSED:
                                break;

                            case ON_EID_NOT_ATTACHED:
                                bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                bottomsheet_description.setVisibility(View.VISIBLE);
                                view_list_check.setVisibility(View.GONE);
                                Config.PLAY_ANIMATION_LOOP = false;
                                bottomsheet_image_sign.setAnimation("animate_loading_lock.json");
                                bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_HOLD, Util_Strings.LOCAL_KEY_EID_SCAN_HOLD));
                                break;
                            case ON_EID_SUCCESS_SENDING_PIN:

                                getActivity().runOnUiThread(new Runnable() {
                                    public void run() {
                                        setBottomSheetComponent(bottomSheetDialog);
                                        view_list_check.setVisibility(View.GONE);
                                        dismissDialog(bottomSheetDialog);
                                        showDialog(bottomSheetDialog);
                                        view_list_check.getParent().requestLayout();

                                        bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                        Config.PLAY_ANIMATION_LOOP = false;
                                        bottomsheet_image_sign.setAnimation("animate_checkmark.json");
                                        bottomsheet_image_sign.playAnimation();
                                        bottomsheet_description.setVisibility(View.VISIBLE);
                                        bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_VERIFICATION_COMPLETED, Util_Strings.LOCAL_KEY_EID_VERIFICATION_COMPLETED));

                                        Handler handler_success = new Handler();
                                        handler_success.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {

                                                if (eIDSdk.getEnableEIDQES()) {
                                                    Config.GENERAL_CALLBACK = CALLBACK_IDENT_SUCCEEDED;
                                                    dismissDialog(bottomSheetDialog);
                                                    Config.SIGNING_SCREEN = Util_Status.SCREEN_PREPARE_SIGNING;
                                                    Fragment_Verify fragment_verify = new Fragment_Verify();
                                                    ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                                                    ((eIDActivity) context).showIntroFragment(fragment_verify);
                                                } else {
                                                    Config.GENERAL_CALLBACK = CALLBACK_IDENT_SUCCEEDED;
                                                    dismissDialog(bottomSheetDialog);
                                                    Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();
                                                    ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                                                    ((eIDActivity) context).showIntroFragment(fragment_verificationStatus);
                                                }
                                            }
                                        }, 2000);

                                    }
                                });

                                break;

                            case ON_CAN_WRONG:
                                bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                bottomsheet_image_sign.setAnimation("static_generic_error.json");
                                bottomsheet_description.setVisibility(View.VISIBLE);
                                bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_CAN_PIN, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_CAN_PIN));

                                bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_SCAN_WRONG_CAN, Util_Strings.LOCAL_KEY_EID_SCAN_WRONG_CAN));
                                view_list_check.setVisibility(View.GONE);

                                Handler handler22 = new Handler();

                                handler22.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_CAN_CODE;
                                        fallBacktoPIN(bottomSheetDialog);
                                    }
                                }, 1500);

                                break;


                            case ON_WRONG_PIN_TRIES_1:

                                getActivity().runOnUiThread(new Runnable() {

                                    public void run() {

                                        bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                        bottomsheet_image_sign.setAnimation("static_generic_error.json");
                                        bottomsheet_image_sign.playAnimation();
                                        bottomsheet_description.setVisibility(View.VISIBLE);
                                        if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                                            bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT_6_DIGIT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT_6_DIGIT));

                                        } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                                            bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT));
                                        }
                                        view_list_check.setVisibility(View.GONE);

                                        Handler handler4 = new Handler();

                                        handler4.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {

                                                if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                                                    Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_5_DIGIT_PIN;
                                                } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                                                    Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                                                }

                                                Config.GENERAL_CALLBACK = CALLBACK_ONE_ATTEMPT;
                                                dismissDialog(bottomSheetDialog);
                                                Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();

                                                ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                                                ((eIDActivity) context).showIntroFragment(fragment_verificationStatus);

                                            }
                                        }, 1500);
                                    }
                                });


                                break;

                    /*
                case ON_WRONG_PIN_TRIES_1:

                    getActivity().runOnUiThread(new Runnable() {

                        public void run() {

                            bottomsheet_image_sign.setVisibility(View.VISIBLE);
                            bottomsheet_image_sign.setAnimation("static_generic_error.json");
                            bottomsheet_image_sign.playAnimation();
                            bottomsheet_description.setVisibility(View.VISIBLE);
                            if(Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)){
                                bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT_6_DIGIT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT_6_DIGIT));

                            }
                            else if(Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)){
                                bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT));
                            }
                            view_list_check.setVisibility(View.GONE);

                            Handler handler4 = new Handler();

                            handler4.postDelayed(new Runnable() {
                                @Override
                                public void run() {

                                    if(Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)){
                                        Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_5_DIGIT_PIN;
                                    }
                                    else if(Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)){
                                        Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                                    }

                                    Config.GENERAL_CALLBACK = CALLBACK_ONE_ATTEMPT;
                                    dismissDialog(bottomSheetDialog);
                                    Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();

                                    ((eIDActivity)context).hideIntroFragment(Fragment_HoldIDBack.this);
                                    ((eIDActivity)context).showIntroFragment(fragment_verificationStatus);

                                }
                            },1500);                        }
                    });



                    break;*/

                            case ON_WRONG_PIN_TRIES_2:

                                getActivity().runOnUiThread(new Runnable() {
                                    public void run() {

                                        bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                        bottomsheet_image_sign.setAnimation("static_generic_error.json");
                                        bottomsheet_image_sign.playAnimation();
                                        bottomsheet_description.setVisibility(View.VISIBLE);

                                        if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                                            bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC_6_DIGIT_PIN, Util_Strings.LOCAL_KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC_6_DIGIT_PIN));

                                        } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                                            bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_TWO_ATTEMPTS_LEFT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_TWO_ATTEMPTS_LEFT));
                                        }

                                        view_list_check.setVisibility(View.GONE);

                                        Handler handler4 = new Handler();

                                        handler4.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                                                    Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_5_DIGIT_PIN;
                                                } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                                                    Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                                                }

                                                Config.GENERAL_CALLBACK = CALLBACK_SECOND_ATTEMPT;
                                                dismissDialog(bottomSheetDialog);
                                                Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();

                                                ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                                                ((eIDActivity) context).showIntroFragment(fragment_verificationStatus);

                                            }
                                        }, 1500);
                                    }
                                });


                                break;

                            case ON_SUCCESS_CHANGE_PIN:

                                getActivity().runOnUiThread(new Runnable() {
                                    public void run() {

                                        bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                        bottomsheet_image_sign.setAnimation("animate_checkmark.json");
                                        bottomsheet_image_sign.playAnimation();
                                        bottomsheet_description.setVisibility(View.VISIBLE);

                                        bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_TITLE, Util_Strings.LOCAL_KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_TITLE));

                                        view_list_check.setVisibility(View.GONE);

                                        Handler handler3 = new Handler();

                                        handler3.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {

                                                Config.GENERAL_CALLBACK = CALLBACK_CHANGE_PIN_SUCCESSFUL;
                                                dismissDialog(bottomSheetDialog);
                                                Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();

                                                ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                                                ((eIDActivity) context).showIntroFragment(fragment_verificationStatus);
                                            }
                                        }, 1500);

                                    }
                                });

                                break;

                            case ON_WRONG_PIN_TRIES_LAST:

                                getActivity().runOnUiThread(new Runnable() {
                                    public void run() {

                                        bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                        bottomsheet_image_sign.setAnimation("static_generic_error.json");
                                        bottomsheet_image_sign.playAnimation();
                                        bottomsheet_description.setVisibility(View.VISIBLE);

                                        if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                                            bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT_6_DIGIT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT_6_DIGIT));

                                        } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                                            bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT));
                                        }

                                        view_list_check.setVisibility(View.GONE);

                                        Handler handler3 = new Handler();

                                        handler3.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {

                                                Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_CAN_CODE;

                                                Config.GENERAL_CALLBACK = CALLBACK_FINAL_ATTEMPT;
                                                dismissDialog(bottomSheetDialog);
                                                Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();

                                                ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                                                ((eIDActivity) context).showIntroFragment(fragment_verificationStatus);
                                            }
                                        }, 1500);

                                    }
                                });

                                break;

                            case ON_EID_CARD_LOST:

                                //  showDialog(bottomSheetDialog);
                                // to define
                                view_list_check.setVisibility(View.GONE);
                                bottomsheet_description.setVisibility(View.VISIBLE);
                                bottomsheet_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_HOLDID_PAGE_ERROR_PLACE, Util_Strings.LOCAL_EID_HOLDID_PAGE_ERROR_PLACE));
                                break;

                            case ON_EID_CARD_CHECK_FAILED:
                                if (extracted()) {
                                    getActivity().runOnUiThread(new Runnable() {
                                        public void run() {

                                            if (view_list_check.getVisibility() == View.VISIBLE) {
                                                view_list_check.setVisibility(View.GONE);
                                                dismissDialog(bottomSheetDialog);
                                                showDialog(bottomSheetDialog);

                                                Handler handlerc = new Handler();

                                                handlerc.postDelayed(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        if (view_list_check.getVisibility() == View.GONE) {
                                                            bottomsheet_image_sign.setAnimation("static_generic_error.json");
                                                            bottomsheet_image_sign.playAnimation();
                                                            bottomsheet_description.setVisibility(View.VISIBLE);
                                                            bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_ESIGN_WRONG_TITLE, Util_Strings.LOCAL_KEY_EID_ESIGN_WRONG_TITLE));
                                                        }
                                                    }
                                                }, 200);

                                            }
                                            Handler handler6 = new Handler();

                                            handler6.postDelayed(new Runnable() {
                                                @Override
                                                public void run() {
                                                    dismissDialog(bottomSheetDialog);

                                                    if (bottomSheetDialog.isShowing()) {
                                                        bottomSheetDialog.dismiss();
                                                    }

                                                    ((eIDActivity) context).errorEIDscreen(Fragment_HoldIDBack.this, GENERAL_CALLBACK);
                                                }
                                            }, 2100);
                                        }
                                    });

                                }

                                break;

                            case ON_CARD_BLOCKED:

                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {

                                        bottomsheet_image_sign.setVisibility(View.VISIBLE);
                                        bottomsheet_image_sign.setAnimation("static_generic_error.json");
                                        bottomsheet_image_sign.playAnimation();
                                        bottomsheet_description.setVisibility(View.VISIBLE);
                                        bottomsheet_description.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_BOTTOM_SHEET_CARD_BLOCKED, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_CARD_BLOCKED));
                                        view_list_check.setVisibility(View.GONE);
                                        dismissDialog(bottomSheetDialog);
                                        showDialog(bottomSheetDialog);

                                        Handler handler8 = new Handler();

                                        handler8.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                dismissDialog(bottomSheetDialog);
                                                Config.GENERAL_CALLBACK = CALLBACK_CARD_BLOCKED;
                                                Fragment_VerificationStatus fragment_verificationStatus = new Fragment_VerificationStatus();

                                                ((eIDActivity) context).hideIntroFragment(Fragment_HoldIDBack.this);
                                                ((eIDActivity) context).showIntroFragment(fragment_verificationStatus);
                                            }
                                        }, 2000);
                                    }
                                });
                                break;
                        }
                    }
                }
            });
        }
    }

    private boolean extracted() {
        if (getActivity() != null) {
            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            List<Fragment> fragments = fragmentManager.getFragments();
            for (Fragment fragment : fragments) {

                if (fragment != null && fragment.isVisible() && fragment instanceof Fragment_HoldIDBack) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public static Fragment_HoldIDBack getInstance() {

        return instance;
    }

    public void moreInfo() {

        View bottomSheetContentView = getLayoutInflater().inflate(R.layout.bottom_sheet_more_information, null);
        bottomSheetMoreInfo = new BottomSheetDialog(fragmentActivity, R.style.BottomSheetDialog);
        bottomSheetMoreInfo.setContentView(bottomSheetContentView);

        ImageButton bottom_sheet_more_information_cancel_cross = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_cancel_cross);
        TextView bottom_sheet_more_information_description = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_description);
        AppCompatImageView bottom_sheet_more_information_image = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_image);
        LottieAnimationView bottom_sheet_more_information_nfc_antenna_animation = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_nfc_antenna_animation);
        TextView bottom_sheet_more_information_antenna_location_label = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_antenna_location_label);

        bottom_sheet_more_information_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PHONE_NOT_DETECTING_EID_INFO, Util_Strings.LOCAL_KEY_EID_PHONE_NOT_DETECTING_EID_INFO));
        bottom_sheet_more_information_image.setVisibility(View.GONE);
        bottom_sheet_more_information_nfc_antenna_animation.setVisibility(View.VISIBLE);
        bottom_sheet_more_information_antenna_location_label.setVisibility(View.VISIBLE);
        bottom_sheet_more_information_antenna_location_label.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PHONE_NOT_DETECTING_EID_ANTENNA_LOCATIONS, Util_Strings.LOCAL_KEY_EID_PHONE_NOT_DETECTING_EID_ANTENNA_LOCATIONS));
        bottom_sheet_more_information_nfc_antenna_animation.setAnimation("nfc_antenna.json");
        bottom_sheet_more_information_nfc_antenna_animation.playAnimation();
        bottomSheetMoreInfo.show();

        bottom_sheet_more_information_cancel_cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetMoreInfo.dismiss();
            }
        });
    }
}
