package de.idnow.android.eid.fragments;

import static de.idnow.android.eid.Config.CALLBACK_CARD_BLOCKED;
import static de.idnow.android.eid.Config.CALLBACK_CARD_UNBLOCK_ATTEMPT;
import static de.idnow.android.eid.Config.CALLBACK_CHANGE_PIN_SUCCESSFUL;
import static de.idnow.android.eid.Config.CALLBACK_FINAL_ATTEMPT;
import static de.idnow.android.eid.Config.CALLBACK_IDENT_FAILED;
import static de.idnow.android.eid.Config.CALLBACK_IDENT_SUCCEEDED;
import static de.idnow.android.eid.Config.CALLBACK_ONE_ATTEMPT;
import static de.idnow.android.eid.Config.CALLBACK_SECOND_ATTEMPT;
import static de.idnow.android.eid.Config.CALLBACK_SESSION_TIMEOUT_URL;
import static de.idnow.android.eid.Config.CALLBACK_SOMETHING_WENT_WRONG;
import static de.idnow.android.eid.Config.EXTRA_TC_TOKEN_URL;
import static de.idnow.android.eid.Config.NAME_MISMATCH;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.fragment.app.FragmentActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import de.idnow.android.eid.AusweisApp2SDK.core.IdentificationManager;
import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.UI.HeaderView;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.util.Util;
import de.idnow.android.eid.util.Util_Log;
import de.idnow.android.eid.util.Util_Strings;
import kotlin.Unit;
import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class Fragment_VerificationStatus extends BaseFragment {

    private final String LOGTAG = "IDNOW_Fragment_VerificationStatus";
    public LottieAnimationView verify_animation;

    public TextView verify_title, verify_desc, token, verify_link, button_redirect;

    public Button buttonDone;

    public LinearLayout tokenLayout;

    Context context;

    FragmentActivity verificationStatusFragment;

    public BottomSheetDialog bottomSheetMoreInfo;

    private HeaderView header;

    public Fragment_VerificationStatus() {
        // Required empty public constructor
    }

    public static Fragment_VerificationStatus instance;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_verification_status, container, false);

        context = getActivity();

        instance = this;

        header = view.findViewById(R.id.header);
        header.setCancelButtonVisibility(false);
        header.setCancelAction(() -> {
            if (Config.GENERAL_CALLBACK.equals(CALLBACK_CARD_BLOCKED)) {
                eIDSdk.recordEvent(eIDSdk.EVENT_EID_CARD_BLOCKED_CROSS);
                Config.CANCEL_REASON = "EID_USER_CANCELLATION_CARD_BLOCKED";
            } else if (Config.GENERAL_CALLBACK.equals(CALLBACK_FINAL_ATTEMPT)) {
                eIDSdk.recordEvent(eIDSdk.EVENT_EID_FINAL_ATTEMPT_SCREEN_CROSS);
                Config.CANCEL_REASON = "EID_USER_CANCELLATION_LAST_PIN_ATTEMPT";
            } else if (Config.GENERAL_CALLBACK.equals(CALLBACK_IDENT_FAILED)) {
                Config.CANCEL_REASON = "EID_USER_CANCELLATION_IDENTIFICATION_FAIL";
            } else if (Config.GENERAL_CALLBACK.equals(CALLBACK_CHANGE_PIN_SUCCESSFUL)) {
                Config.CANCEL_REASON = "EID_USER_CANCELLATION_SET_PIN_SUCCESS";
            }
            ((eIDActivity) context).getVisibleFragment();
            ((eIDActivity) context).identificationCanceledRESTCall(Fragment_VerificationStatus.this, Config.CANCEL_REASON);
            return Unit.INSTANCE;
        });

        verify_title = view.findViewById(R.id.verify_title);
        verify_desc = view.findViewById(R.id.verify_desc);
        verify_link = view.findViewById(R.id.verify_link);
        buttonDone = view.findViewById(R.id.buttonDone);
        tokenLayout = view.findViewById(R.id.tokenLayout);
        verify_animation = view.findViewById(R.id.verify_animation);
        token = view.findViewById(R.id.token);
        button_redirect = view.findViewById(R.id.button_redirect);
        if (Config.STANDALONE_EID) {
            button_redirect.setVisibility(View.GONE);
        }

        if (Config.GENERAL_CALLBACK.equals(CALLBACK_IDENT_SUCCEEDED)) {

            if (eIDSdk.getEnableEIDQES()) {

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_SUCCESS_SCREEN_SHOWN);
                eIDSdk.startEvent(eIDSdk.EVENT_EID_SUCCESS_SCREEN_TIME_SPENT);

                tokenLayout.setVisibility(View.VISIBLE);
                verify_animation.setAnimation("static_signing_success.json");
                verify_animation.playAnimation();
                verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_SUCCESSFUL_TITLE, Util_Strings.LOCAL_KEY_EID_ESIGN_SUCCESSFUL_TITLE));
                verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_SUCCESSFUL_DESC, Util_Strings.LOCAL_KEY_EID_ESIGN_SUCCESSFUL_DESC));
                String transactionToken = eIDSdk.getTransactionToken();
                token.setText(transactionToken);
                buttonDone.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DONE, Util_Strings.LOCAL_KEY_EID_DONE));

            } else {
                eIDSdk.recordEvent(eIDSdk.EVENT_EID_VERIFICATION_COMPLETED_SCREEN_SHOWN);

                tokenLayout.setVisibility(View.VISIBLE);
                verify_animation.setAnimation("static_passport_id_success.json");
                verify_animation.playAnimation();
                verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFY_COMPLETE_TITLE, Util_Strings.LOCAL_EID_VERIFY_COMPLETE_TITLE));
                verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_SUCCESSFUL_DESC, Util_Strings.LOCAL_KEY_EID_ESIGN_SUCCESSFUL_DESC));
                buttonDone.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DONE, Util_Strings.LOCAL_KEY_EID_DONE));
                String transactionToken = eIDSdk.getTransactionToken();

                token.setText(transactionToken);
                verify_animation.setAnimation("static_passport_id_success.json");
                verify_animation.playAnimation();

            }

        } else {
            tokenLayout.setVisibility(View.GONE);
            resultScreen(Config.GENERAL_CALLBACK);
        }

        if (Config.GENERAL_CALLBACK.equals(CALLBACK_CARD_BLOCKED)) {
            ((eIDActivity) context).identificationCanceledRESTCall(Fragment_VerificationStatus.this, "EID_CARD_BLOCKED", false);
        }

        buttonDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Config.GENERAL_CALLBACK.equals(Config.CALLBACK_IDENT_SUCCEEDED)) {
                    if (eIDSdk.getEnableEIDQES()) {
                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_SUCCESS_SCREEN_DONE);

                        Intent intent = new Intent();
                        if (context instanceof Activity) {
                            verificationStatusFragment = (FragmentActivity) context;
                        }
                        verificationStatusFragment.setResult(Config.RESULT_CODE_SUCCESS, intent);
                        verificationStatusFragment.finish();
                    } else {
                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_VERIFICATION_COMPLETED_SCREEN_DONE);

                        Intent intent = new Intent();
                        if (context instanceof Activity) {
                            verificationStatusFragment = (FragmentActivity) context;
                        }
                        verificationStatusFragment.setResult(Config.RESULT_CODE_SUCCESS, intent);
                        verificationStatusFragment.finish();
                    }
                } else if (Config.GENERAL_CALLBACK.equals(CALLBACK_FINAL_ATTEMPT)) {

                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_FINAL_ATTEMPT_SCREEN_CONTINUE);

                    Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_CAN_CODE;
                    Config.CURRENT_CALLBACK = CALLBACK_FINAL_ATTEMPT;

                    Fragment_EnterPin_6_digit fragment_enterPin = new Fragment_EnterPin_6_digit();
                    fragment_enterPin.clearPinBoxes();
                    ((eIDActivity) getActivity()).hideIntroFragment(Fragment_VerificationStatus.this);
                    ((eIDActivity) getActivity()).showIntroFragment(fragment_enterPin);
                } else if (Config.GENERAL_CALLBACK.equals(CALLBACK_SECOND_ATTEMPT)) {
                    buttonDone.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_CHOOSE_CONTINUE_BUTTON, Util_Strings.LOCAL_KEY_EID_CHOOSE_CONTINUE_BUTTON));
                    Config.CURRENT_CALLBACK = CALLBACK_SECOND_ATTEMPT;
                    Fragment_EnterPin_6_digit fragment_enterPin = new Fragment_EnterPin_6_digit();
                    fragment_enterPin.clearPinBoxes();
                    ((eIDActivity) getActivity()).hideIntroFragment(Fragment_VerificationStatus.this);
                    ((eIDActivity) getActivity()).showIntroFragment(fragment_enterPin);

                } else if (Config.GENERAL_CALLBACK.equals(CALLBACK_ONE_ATTEMPT)) {
                    buttonDone.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_CHOOSE_CONTINUE_BUTTON, Util_Strings.LOCAL_KEY_EID_CHOOSE_CONTINUE_BUTTON));

                    Config.CURRENT_CALLBACK = CALLBACK_ONE_ATTEMPT;
                    Fragment_EnterPin_6_digit fragment_enterPin = new Fragment_EnterPin_6_digit();
                    fragment_enterPin.clearPinBoxes();
                    ((eIDActivity) getActivity()).hideIntroFragment(Fragment_VerificationStatus.this);
                    ((eIDActivity) getActivity()).showIntroFragment(fragment_enterPin);
                } else if (Config.GENERAL_CALLBACK.equals(CALLBACK_CHANGE_PIN_SUCCESSFUL)) {
                    Config.CURRENT_CALLBACK = CALLBACK_CHANGE_PIN_SUCCESSFUL;
                    try {
                        buttonDone.setEnabled(false);
                        buttonDone.setAlpha(0.5f);
                        getMobileSessionToken();
                    } catch (IOException | JSONException e) {
                        Util_Log.e(LOGTAG, "Fetch mobile session token failed", e);
                        throw new RuntimeException(e);
                    }
                    //identificationManager.startIdent(new IdentificationManager.RunAuth(EXTRA_TC_TOKEN_URL,false,true));
                } else if (Config.GENERAL_CALLBACK.equals(CALLBACK_CARD_BLOCKED) || Config.GENERAL_CALLBACK.equals(CALLBACK_CARD_UNBLOCK_ATTEMPT)) {

                    goBackToChooserScreen();

                } else if (Config.GENERAL_CALLBACK.equals(CALLBACK_IDENT_FAILED)) {

                    if (eIDSdk.getEnableEIDQES()) {
                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_UNSUCCESSFUL_SCREEN_DONE);
                    }

                    Intent intent = new Intent();
                    if (context instanceof Activity) {
                        verificationStatusFragment = (FragmentActivity) context;
                    }
                    Config.RESULT_CODE = Config.RESULT_CODE == 0
                            ? Config.RESULT_CODE_FAILED
                            : Config.RESULT_CODE;
                    verificationStatusFragment.setResult(Config.RESULT_CODE, intent);
                    verificationStatusFragment.finish();

                } else if (Config.GENERAL_CALLBACK.equals(CALLBACK_SOMETHING_WENT_WRONG) || Config.GENERAL_CALLBACK.equals(CALLBACK_SESSION_TIMEOUT_URL)) {

                    ((eIDActivity) context).identificationCanceledRESTCall(Fragment_VerificationStatus.this, "EID_CARD_SCAN_UNSUCCESSFUL");

                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_TECHNICAL_ERROR_SCREEN_TRY_AGAIN);

                }
            }
        });

        button_redirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if ((Config.GENERAL_CALLBACK.equals(CALLBACK_IDENT_FAILED))) {
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_CARD_BLOCKED_TRY_ANOTHER_METHOD);
                }

                if (Config.GENERAL_CALLBACK.equals(CALLBACK_CARD_BLOCKED)) {
                    openAusweisApp();
                    return;
                }
                goBackToChooserScreen();
            }
        });

        // Inflate the layout for this fragment
        return view;
    }

    private void goBackToChooserScreen() {
        if (eIDSdk.getEIDTSP().equals("Governikus")) {
            IdentificationManager.INSTANCE.requestCancel();
        }
        Intent intent = new Intent();
        if (context instanceof Activity) {
            verificationStatusFragment = (FragmentActivity) context;
        }
        verificationStatusFragment.setResult(Config.CHOOSER_SCREEN, intent);
        verificationStatusFragment.finish();
    }

    private void openAusweisApp() {
        eIDSdk.recordEvent(eIDSdk.EVENT_EID_CARD_BLOCKED_AUSWEIS_APP);

        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.governikus.ausweisapp2")));

        Config.GENERAL_CALLBACK = CALLBACK_CARD_UNBLOCK_ATTEMPT;
        resultScreen(Config.GENERAL_CALLBACK);
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_VerificationStatus.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_VerificationStatus.class);
    }

    public void resultScreen(String resultFailure) {

        tokenLayout.setVisibility(View.GONE);

        if (resultFailure.equals(CALLBACK_SESSION_TIMEOUT_URL)) {

            verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_TIMEOUT_TITLE, Util_Strings.LOCAL_KEY_EID_ESIGN_TIMEOUT_TITLE));
            verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_TIMEOUT_DESC, Util_Strings.LOCAL_KEY_EID_ESIGN_TIMEOUT_DESC));
            verify_animation.setAnimation("static_time_out.json");
            verify_animation.playAnimation();
            buttonDone.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TRY_AGAIN, Util_Strings.LOCAL_KEY_EID_TRY_AGAIN));
        }
        if (Config.GENERAL_CALLBACK.equals(CALLBACK_CHANGE_PIN_SUCCESSFUL)) {
            verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_TITLE, Util_Strings.LOCAL_KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_TITLE));
            verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_DESC, Util_Strings.LOCAL_KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_DESC));
            verify_animation.setAnimation("static_time_out.json");
            verify_animation.playAnimation();
            buttonDone.setVisibility(View.VISIBLE);
            buttonDone.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_BUTTON, Util_Strings.LOCAL_KEY_EID_OUTCOME_PIN_CHANGED_SUCCESS_BUTTON));
            button_redirect.setVisibility(View.GONE);
        } else if (resultFailure.equals(CALLBACK_FINAL_ATTEMPT)) {

            eIDSdk.recordEvent(eIDSdk.EVENT_EID_FINAL_ATTEMPT_SCREEN_SHOWN);
            eIDSdk.startEvent(eIDSdk.EVENT_EID_FINAL_ATTEMPT_SCREEN_TIME_SPENT);
            verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_FINAL_ATTEMPT_TITLE, Util_Strings.LOCAL_KEY_EID_FINAL_ATTEMPT_TITLE));
            verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_FINAL_ATTEMPT_DESC, Util_Strings.LOCAL_KEY_EID_FINAL_ATTEMPT_DESC));
            verify_link.setVisibility(View.VISIBLE);
            verify_link.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_FINAL_ATTEMPT_LINK, Util_Strings.LOCAL_KEY_EID_FINAL_ATTEMPT_LINK));
            verify_link.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_FINAL_ATTEMPT_SCREEN_WHERE_DO_I_FIND_CAN);
                    moreInfo();
                }
            });
            verify_animation.setVisibility(View.VISIBLE);
            verify_animation.setAnimation("static_generic_error.json");
            verify_animation.playAnimation();
            buttonDone.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_BUTTON_CONTINUE, Util_Strings.LOCAL_EID_BUTTON_CONTINUE));
        } else if (resultFailure.equals(CALLBACK_SECOND_ATTEMPT)) {
            header.setCancelButtonVisibility(true);
            verify_title.setVisibility(View.GONE);
            verify_desc.setVisibility(View.VISIBLE);
            String description = switch (Config.DIGIT_SCREEN_TO_SHOW) {
                case SCREEN_ENTER_5_DIGIT_PIN ->
                        Util_Strings.getStringWithDefault(context.getApplicationContext(),
                                Util_Strings.KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC,
                                Util_Strings.LOCAL_KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC);

                case SCREEN_ENTER_PERSONAL_6_DIGIT_PIN ->
                        Util_Strings.getStringWithDefault(context.getApplicationContext(),
                                Util_Strings.KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC_6_DIGIT_PIN,
                                Util_Strings.LOCAL_KEY_EID_OUTCOME_INCORRECT_PIN_TWO_ATTEMPTS_LEFT_DESC_6_DIGIT_PIN);

                default -> Util_Strings.getStringWithDefault(
                                context.getApplicationContext(),
                                Util_Strings.KEY_EID_SCAN_WRONG_PIN,
                                Util_Strings.LOCAL_KEY_EID_SCAN_WRONG_PIN)
                        .replace("x", "2");
            };

            verify_desc.setText(description);
            verify_link.setVisibility(View.GONE);
            verify_animation.setVisibility(View.VISIBLE);
            verify_animation.setAnimation("static_generic_error.json");
            verify_animation.playAnimation();
            buttonDone.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_BUTTON_CONTINUE, Util_Strings.LOCAL_EID_BUTTON_CONTINUE));

        } else if (resultFailure.equals(CALLBACK_ONE_ATTEMPT)) {
            header.setCancelButtonVisibility(true);
            verify_title.setVisibility(View.GONE);
            verify_desc.setVisibility(View.VISIBLE);

            if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT_6_DIGIT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT_6_DIGIT));

            } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT, Util_Strings.LOCAL_KEY_EID_BOTTOM_SHEET_INCORRECT_PIN_FINAL_ATTEMPT));
            }
            verify_link.setVisibility(View.GONE);
            verify_animation.setVisibility(View.VISIBLE);
            verify_animation.setAnimation("static_generic_error.json");
            verify_animation.playAnimation();
            buttonDone.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_BUTTON_CONTINUE, Util_Strings.LOCAL_EID_BUTTON_CONTINUE));
        } else if (resultFailure.equals(CALLBACK_SOMETHING_WENT_WRONG)) {

            eIDSdk.recordEvent(eIDSdk.EVENT_EID_TECHNICAL_ERROR_SCREEN_SHOWN);
            eIDSdk.recordEvent(eIDSdk.EVENT_EID_TECHNICAL_ERROR_SCREEN_TIME_SPENT);

            verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_WRONG_TITLE, Util_Strings.LOCAL_KEY_EID_ESIGN_WRONG_TITLE));
            verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ESIGN_WRONG_DESC, Util_Strings.LOCAL_KEY_EID_ESIGN_WRONG_DESC));
            verify_animation.setAnimation("static_generic_error.json");
            verify_animation.playAnimation();
            buttonDone.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_TRY_AGAIN, Util_Strings.LOCAL_KEY_EID_TRY_AGAIN));
        } else if (resultFailure.equals(CALLBACK_IDENT_FAILED)) {
            if (eIDSdk.getEnableEIDQES()) {
                eIDSdk.recordEvent(eIDSdk.EVENT_EID_UNSUCCESSFUL_SCREEN_SHOWN);
                eIDSdk.startEvent(eIDSdk.EVENT_EID_UNSUCCESSFUL_SCREEN_TIME_SPENT);
            }
            verify_animation.setAnimation("static_passport_id_fail.json");
            verify_animation.playAnimation();
            if (eIDSdk.getEnableEIDQES() && NAME_MISMATCH) {
                verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_VIDEO_IDENT_COMMON_ERROR, Util_Strings.LOCAL_KEY_VIDEO_IDENT_COMMON_ERROR));
                verify_desc.setVisibility(View.VISIBLE);
                verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_NAME_MISMATCH, Util_Strings.LOCAL_KEY_EID_NAME_MISMATCH));
            } else {
                verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_IDENTIFICATION_NOT_COMPLETED, Util_Strings.LOCAL_KEY_EID_IDENTIFICATION_NOT_COMPLETED));

                if (NAME_MISMATCH) {
                    verify_desc.setVisibility(View.VISIBLE);
                    verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VALUE_MISMATCH, Util_Strings.LOCAL_KEY_EID_VALUE_MISMATCH));
                } else {
                    verify_desc.setVisibility(View.GONE);
                }
            }

            buttonDone.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_DONE, Util_Strings.LOCAL_KEY_EID_DONE));
            if (!Config.STANDALONE_EID) button_redirect.setVisibility(View.VISIBLE);
            if (!Config.STANDALONE_EID) button_redirect.setVisibility(View.VISIBLE);
            if (NAME_MISMATCH) {
                button_redirect.setVisibility(View.GONE);
            }
            button_redirect.setText(Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_TRY_AGAIN, Util_Strings.LOCAL_KEY_EID_TRY_AGAIN));
        } else if (resultFailure.equals(CALLBACK_CARD_BLOCKED)) {
            header.setCancelButtonVisibility(true);
            eIDSdk.recordEvent(eIDSdk.EVENT_EID_CARD_BLOCKED_SHOWN);
            eIDSdk.startEvent(eIDSdk.EVENT_EID_CARD_BLOCKED_TIME_SPENT);

            verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CARD_BLOCKED_TITLE, Util_Strings.LOCAL_KEY_EID_CARD_BLOCKED_TITLE));
            verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CARD_BLOCKED_DESC, Util_Strings.LOCAL_KEY_EID_CARD_BLOCKED_DESC));
            verify_animation.setAnimation("static_passport_id_fail.json");
            verify_animation.playAnimation();
            buttonDone.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TRY_ANOTHER_METHOD, Util_Strings.LOCAL_KEY_EID_TRY_ANOTHER_METHOD));
            if (Config.STANDALONE_EID) buttonDone.setVisibility(View.GONE);
            button_redirect.setVisibility(View.VISIBLE);
            button_redirect.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CARD_BLOCKED_BUTTON, Util_Strings.LOCAL_KEY_EID_CARD_BLOCKED_BUTTON));


        } else if (resultFailure.equals(CALLBACK_CARD_UNBLOCK_ATTEMPT)) {
            header.setCancelButtonVisibility(true);

            verify_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CARD_BLOCKED_TITLE, Util_Strings.LOCAL_KEY_EID_CARD_BLOCKED_TITLE));
            verify_desc.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CARD_BLOCKED_DESC, Util_Strings.LOCAL_KEY_EID_CARD_BLOCKED_DESC));
            verify_animation.setAnimation("static_passport_id_fail.json");
            verify_animation.playAnimation();
            buttonDone.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TRY_ANOTHER_METHOD, Util_Strings.LOCAL_KEY_EID_TRY_ANOTHER_METHOD));
            if (Config.STANDALONE_EID) buttonDone.setVisibility(View.GONE);
            button_redirect.setVisibility(View.VISIBLE);
            button_redirect.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_TRY_AGAIN, Util_Strings.LOCAL_KEY_EID_TRY_AGAIN));


        }

    }

    public void moreInfo() {

        View bottomSheetContentView = getLayoutInflater().inflate(R.layout.bottom_sheet_more_information, null);
        bottomSheetMoreInfo = new BottomSheetDialog(context, R.style.BottomSheetDialog);
        bottomSheetMoreInfo.setContentView(bottomSheetContentView);

        ImageButton bottom_sheet_more_information_cancel_cross = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_cancel_cross);
        TextView bottom_sheet_more_information_description = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_description);
        AppCompatImageView bottom_sheet_more_information_image = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_image);
        LottieAnimationView bottom_sheet_more_information_nfc_antenna_animation = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_nfc_antenna_animation);
        TextView bottom_sheet_more_information_antenna_location_label = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_antenna_location_label);

        bottom_sheet_more_information_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_WHERE_DO_I_FIND_CAN_INFO, Util_Strings.LOCAL_KEY_EID_WHERE_DO_I_FIND_CAN_INFO));
        bottom_sheet_more_information_image.setImageResource(R.drawable.can_code);
        bottom_sheet_more_information_nfc_antenna_animation.setVisibility(View.GONE);
        bottom_sheet_more_information_antenna_location_label.setVisibility(View.GONE);
        bottomSheetMoreInfo.show();

        bottom_sheet_more_information_cancel_cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetMoreInfo.dismiss();
            }
        });
    }


    public static Fragment_VerificationStatus getInstance() {

        return instance;
    }

    public void redirectUser() {
        getActivity().runOnUiThread(new Runnable() {
            public void run() {
                Fragment_Capture_Desc fragment_capture_desc = new Fragment_Capture_Desc();
                ((eIDActivity) context).hideIntroFragment(Fragment_VerificationStatus.this);
                ((eIDActivity) context).showIntroFragment(fragment_capture_desc);
            }
        });
    }

    public void getMobileSessionToken() throws IOException, JSONException {

        OkHttpClient client = new OkHttpClient();

        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        String companyShortName = eIDSdk.getCompanyId();
        String transactionToken = eIDSdk.getTransactionToken();
        endPoint = endPoint + "/api/v1/" + companyShortName + "/eid/" + transactionToken + "/startEid";

        String language = eIDSdk.getModels_clientInfoLanguage();

        JSONObject object = new JSONObject();
        JSONObject obj = new JSONObject();

        obj.put("language", language);
        object.put("clientInfo", obj);

        MediaType JSON = MediaType.parse(Util_Strings.LOGIN_CONTENT_TYPE);
        RequestBody body = RequestBody.create(JSON, String.valueOf(object));

        Util_Log.i(LOGTAG, "Get mobile token and session token API : " + endPoint);

        Request request = new Request.Builder()
                .url(endPoint)
                .post(body)
                .build();
        Call response = null;

        response = client.newCall(request);

        response.enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

                Util_Log.i(LOGTAG, "Failure request");
                ((eIDActivity) context).errorEIDscreen(Fragment_VerificationStatus.this, CALLBACK_IDENT_FAILED);

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Util_Log.i(LOGTAG, "Success request: " + response.code() + " " + response.isSuccessful());
                if ((response.isSuccessful()) && (!Config.EID_VID_TOKEN_FINISEHD)) {
                    if (response.body() != null) {
                        try {
                            Gson gson = new Gson();
                            String jSonString = response.body().string();
                            gson.fromJson(jSonString, Object.class);
                            JsonObject jsonObject = new JsonParser().parse(jSonString).getAsJsonObject();
                            // EID_MOBILE_TOKEN = jsonObject.get("mobileToken").getAsString();
                            // Config.EID_SESSION_TOKEN = jsonObject.get("sessionToken").getAsString();
                            Config.EID_SIGNATURE = jsonObject.get("request").getAsJsonObject().get("Identification-Signature").getAsString();
                            EXTRA_TC_TOKEN_URL = jsonObject.get("tcTokenUrl").getAsString();
                            Config.EID_ID_IMAGES_CAPTURED = false;
                            IdentificationManager.INSTANCE.startIdent(EXTRA_TC_TOKEN_URL);
                            Config.FROM_SCRATCH = true;

                        } catch (Exception e) {
                            Util_Log.e(LOGTAG, "Extract mobile session failed", e);
                            ((eIDActivity) context).errorEIDscreen(Fragment_VerificationStatus.this, CALLBACK_IDENT_FAILED);
                        }
                    } else {
                        ((eIDActivity) context).errorEIDscreen(Fragment_VerificationStatus.this, CALLBACK_IDENT_FAILED);
                    }
                } else {
                    ((eIDActivity) context).errorEIDscreen(Fragment_VerificationStatus.this, CALLBACK_IDENT_FAILED);
                }
            }
        });

    }
}

