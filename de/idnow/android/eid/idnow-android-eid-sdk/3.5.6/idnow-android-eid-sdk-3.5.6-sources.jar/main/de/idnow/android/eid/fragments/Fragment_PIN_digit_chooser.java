package de.idnow.android.eid.fragments;

import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.os.Build.VERSION.SDK_INT;
import static de.idnow.android.eid.Config.EXTRA_TC_TOKEN_URL;
import static de.idnow.android.eid.util.Util_Strings.KEY_EID_LINK_PRIVACY_POLICY;
import static de.idnow.android.eid.util.Util_Strings.KEY_EID_LINK_TERMS_OF_USE;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_EID_LINK_PRIVACY_POLICY;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_EID_LINK_TERMS_OF_USE;
import static de.idnow.android.eid.util.Util_Strings.LOCAL_EID_VERIFY_PAGE_PRIVACY;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.idnow.android.eid.AusweisApp2SDK.core.IdentificationManager;
import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.UI.HeaderView;
import de.idnow.android.eid.UI.SubtitleView;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.util.Util;
import de.idnow.android.eid.util.Util_Log;
import de.idnow.android.eid.util.Util_Strings;
import kotlin.Unit;
import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class Fragment_PIN_digit_chooser extends BaseFragment {
    private final String LOGTAG = "IDNOW_Fragment_PIN_digit_chooser";

    public TextView eid_consent_6_digit_title,
            eid_consent_5_digit_title,
            eid_consent_5_digit_description,
            i_agree_textview,
            i_have_a_5_digit_pin_button,
            try_another_id_method_button,
            bottom_sheet_where_is_5_digit_pin_description;

    public enum ClickableTextType {
        LEARN_MORE,
        WHERE_IS_IT,
        IDNOW_HOME_PAGE,
        TERMS_OF_SERVICE,
        PRIVACY_POLICY
    }

    public BottomSheetDialog bottomSheetDialog;

    public Button button_continue_digit_pin;

    public ImageView bottom_sheet_where_is_5_digit_pin_image;

    public ImageButton bottom_sheet_where_is_5_digit_pin_cancel_cross;

    public RadioButton checkbox_eid_6_digit_pin, checkbox_eid_5_digit_pin;
    public CheckBox i_agree_checkbox;

    public CardView cardview_5_digit,
            cardview_6_digit;

    public RelativeLayout i_have_a_5_digit_pin_layout;

    public LinearLayout i_have_a_6_digit_pin_layout, tc_layout;

    Context context;

    private HeaderView header;
    private SubtitleView subtitle;

    FragmentActivity fragmentActivity;

    Dialog quitDialog;

    String termsUrl = "";
    String privacyUrl = "";

    private boolean isAnyPINboxChecked = false,
            isTCagreed = false;

    private static final String TAG = Fragment_PIN_digit_chooser.class.getName();

    ProgressBar progress;

    final private int REQUEST_CODE_ASK_PERMISSIONS = 46825;

    private static Fragment_PIN_digit_chooser instance;

    public Fragment_PIN_digit_chooser() {
        super(true);
    }

    private void setTexts() {

        header.setTitle(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_IDENTIFICATION_TITLE, Util_Strings.LOCAL_KEY_EID_IDENTIFICATION_TITLE));
        subtitle.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_DESCRIPTION, Util_Strings.LOCAL_KEY_EID_CHOOSE_DESCRIPTION));
        eid_consent_5_digit_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_FIVE_DIGIT_PIN, Util_Strings.LOCAL_KEY_EID_CHOOSE_FIVE_DIGIT_PIN));
        eid_consent_6_digit_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_SIX_DIGIT_PIN, Util_Strings.LOCAL_KEY_EID_CHOOSE_SIX_DIGIT_PIN));
        i_have_a_5_digit_pin_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_WHERE_TRANSPORT_PIN, Util_Strings.LOCAL_KEY_EID_CHOOSE_WHERE_TRANSPORT_PIN));
        try_another_id_method_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_TRY_ANOTHER_IDENT_METHOD, Util_Strings.LOCAL_KEY_EID_CHOOSE_TRY_ANOTHER_IDENT_METHOD));
        button_continue_digit_pin.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_CONTINUE_BUTTON, Util_Strings.LOCAL_KEY_EID_CHOOSE_CONTINUE_BUTTON));

        String privacyPolicyText = Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFY_PAGE_PRIVACY, LOCAL_EID_VERIFY_PAGE_PRIVACY);
        String termsText = Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFY_PAGE_TERMS, Util_Strings.LOCAL_EID_VERIFY_PAGE_TERMS);
        termsUrl = Util_Strings.getStringWithDefault(context.getApplicationContext(), KEY_EID_LINK_TERMS_OF_USE, LOCAL_EID_LINK_TERMS_OF_USE);
        privacyUrl = Util_Strings.getStringWithDefault(context.getApplicationContext(), KEY_EID_LINK_PRIVACY_POLICY, LOCAL_EID_LINK_PRIVACY_POLICY);

        i_agree_textview.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_TERMS_PART1, Util_Strings.LOCAL_KEY_EID_CHOOSE_TERMS_PART1) + " ");
        i_agree_textview.append(makeClickableSpan(context, termsText, getResources().getColor(R.color.text_color_link), termsUrl, ClickableTextType.TERMS_OF_SERVICE));
        i_agree_textview.setMovementMethod(LinkMovementMethod.getInstance());
        i_agree_textview.append(" " + Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_TERMS_PART2, Util_Strings.LOCAL_KEY_EID_CHOOSE_TERMS_PART2) + " ");
        i_agree_textview.append(makeClickableSpan(context, privacyPolicyText, getResources().getColor(R.color.text_color_link), privacyUrl, ClickableTextType.PRIVACY_POLICY));
        i_agree_textview.setMovementMethod(LinkMovementMethod.getInstance());
        i_agree_textview.append(" " + Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_TERMS_PART3, Util_Strings.LOCAL_KEY_EID_CHOOSE_TERMS_PART3));


        eid_consent_5_digit_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_TRANSPORT_PIN_DESC, Util_Strings.LOCAL_KEY_EID_CHOOSE_TRANSPORT_PIN_DESC) + " ");
        eid_consent_5_digit_description.append(makeClickableSpan(context, Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CHOOSE_WHERE_PIN_LINK, Util_Strings.LOCAL_KEY_EID_CHOOSE_WHERE_PIN_LINK), getResources().getColor(R.color.text_color_link), null, ClickableTextType.WHERE_IS_IT));
        eid_consent_5_digit_description.setMovementMethod(LinkMovementMethod.getInstance());

        bottom_sheet_where_is_5_digit_pin_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_DATA_CONFIRMATION_FIVE_DIGIT_DESC, Util_Strings.LOCAL_KEY_EID_DATA_CONFIRMATION_FIVE_DIGIT_DESC));

    }

    private void bindViews(View view) {
        header = view.findViewById(R.id.header);
        subtitle = view.findViewById(R.id.subtitle);

        progress = view.findViewById(R.id.progressVerify);
        progress.getIndeterminateDrawable().setColorFilter(getResources().getColor(R.color.primaryColor), PorterDuff.Mode.MULTIPLY);

        eid_consent_6_digit_title = view.findViewById(R.id.eid_consent_6_digit_title);
        eid_consent_5_digit_title = view.findViewById(R.id.eid_consent_5_digit_title);
        eid_consent_5_digit_description = view.findViewById(R.id.eid_consent_5_digit_description);
        i_have_a_5_digit_pin_button = view.findViewById(R.id.i_have_a_5_digit_pin_button);
        i_agree_textview = view.findViewById(R.id.i_agree_textview);
        try_another_id_method_button = view.findViewById(R.id.try_another_id_method_button);


        button_continue_digit_pin = view.findViewById(R.id.button_continue_digit_pin);
        enableContinueButton(false);

        cardview_5_digit = view.findViewById(R.id.cardview_5_digit);
        cardview_6_digit = view.findViewById(R.id.cardview_6_digit);

        tc_layout = view.findViewById(R.id.tc_layout);
        i_have_a_5_digit_pin_layout = view.findViewById(R.id.i_have_a_5_digit_pin_layout);
        i_have_a_6_digit_pin_layout = view.findViewById(R.id.i_have_a_6_digit_pin_layout);

        checkbox_eid_6_digit_pin = view.findViewById(R.id.checkbox_eid_6_digit_pin);
        checkbox_eid_5_digit_pin = view.findViewById(R.id.checkbox_eid_5_digit_pin);
        i_agree_checkbox = view.findViewById(R.id.i_agree_checkbox);

        button_continue_digit_pin.setBackgroundResource(R.drawable.rounded_background_grey);

        View bottomSheetContentView = getLayoutInflater().inflate(R.layout.bottom_sheet_more_information, null);
        bottomSheetDialog = new BottomSheetDialog(fragmentActivity, R.style.BottomSheetDialog);
        bottomSheetDialog.setContentView(bottomSheetContentView);
        bottomSheetDialog.setCancelable(true);

        bottom_sheet_where_is_5_digit_pin_cancel_cross = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_cancel_cross);
        bottom_sheet_where_is_5_digit_pin_description = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_description);
        bottom_sheet_where_is_5_digit_pin_image = bottomSheetContentView.findViewById(R.id.bottom_sheet_more_information_image);

        setTexts();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_pin_digit_chooser, container, false);

        eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHOOSER_SCREEN_SHWON);
        eIDSdk.startEvent(eIDSdk.EVENT_EID_PIN_CHOOSER_SCREEN_TIME_SPENT);

        context = getContext();

        instance = this;

        fragmentActivity = getActivity();

        bindViews(view);

        assignClickListeners();

        // for test only - override TRUE/FALSE 5 digit
        // delete below line if intended for production

        if (eIDSdk.getChangePinEID()) {
            // 5 digit PIN change possibility
            i_have_a_5_digit_pin_button.setVisibility(View.GONE);
            try_another_id_method_button.setVisibility(View.GONE);
        } else {
            // 6 digit PIN change ONLY possibility
            cardview_5_digit.setVisibility(View.GONE);
        }

        if (Config.STANDALONE_EID) {
            try_another_id_method_button.setVisibility(View.GONE);
        }

        tc_layout.setVisibility(eIDSdk.isShowTermsConditionsEID(context) ? View.VISIBLE : View.INVISIBLE);

        return view;

    }

    private void assignClickListeners() {

        button_continue_digit_pin.setOnClickListener(v -> {

            eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHOOSER_SCREEN_CONTINUE);

            // eIDSdk.endEvent(eIDSdk.EVENT_EID_PIN_CHOOSER_SCREEN_TIME_SPENT);


            if ((checkbox_eid_5_digit_pin.isChecked() ||
                    checkbox_eid_6_digit_pin.isChecked()) &&
                    (i_agree_checkbox.isChecked() || !eIDSdk.isShowTermsConditionsEID(context))) {
                if (eIDSdk.isNetworkConnected(context)) {
                    progress.setVisibility(View.VISIBLE);
                    checkForRuntimePermissions();
                } else {
                    Util.showNoConnectionDialog(context);
                }
            }
        });

        header.setCancelAction(() -> {
            eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHOOSER_SCREEN_CROSS);
            Config.CANCEL_REASON = "EID_USER_CANCELLATION_TNC";
            ((eIDActivity) context).getVisibleFragment();
            return Unit.INSTANCE;
        });

        bottom_sheet_where_is_5_digit_pin_cancel_cross.setOnClickListener(v -> {
            bottomSheetDialog.dismiss();
        });

        bottom_sheet_where_is_5_digit_pin_cancel_cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
            }
        });

        checkbox_eid_5_digit_pin.setOnCheckedChangeListener((buttonView, isChecked) -> {

                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHOOSER_SCREEN_TRANSPORT_PIN_OPTION);


                    if (isTCagreed || !eIDSdk.isShowTermsConditionsEID(context)) {
                        enableContinueButton(true);
                    }
                    checkbox_eid_6_digit_pin.setChecked(!isChecked);
                    isAnyPINboxChecked = true;
                }
        );

        checkbox_eid_6_digit_pin.setOnCheckedChangeListener((buttonView, isChecked) -> {

                    eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHOOSER_SCREEN_PERSONAL_PIN_OPTION);


                    checkbox_eid_5_digit_pin.setChecked(!isChecked);

                    isAnyPINboxChecked = eIDSdk.getChangePinEID() || isChecked;

                    enableContinueButton((isTCagreed || !eIDSdk.isShowTermsConditionsEID(context)) && isAnyPINboxChecked);
                }
        );

        i_agree_checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {

            eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHOOSER_SCREEN_TNC_CHECKED);

            isTCagreed = isChecked;
            enableContinueButton((isChecked || !eIDSdk.isShowTermsConditionsEID(context)) && isAnyPINboxChecked);
        });

        try_another_id_method_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Util.redirection(context, Config.CHOOSER_SCREEN);
            }
        });

        i_have_a_5_digit_pin_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String link = Util_Strings.getStringWithDefault(context, Util_Strings.KEY_EID_TRANSPORT_PIN_LINK, Util_Strings.LOCAL_KEY_EID_TRANSPORT_PIN_LINK);
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link)));
            }
        });

    }


    private Spannable makeClickableSpan(Context context, CharSequence text, int color, String url, ClickableTextType clickableTextType) {
        Spannable spannable = new SpannableString(text);

        ClickableSpan clickableSpan = new ClickableSpan() {

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(false);
            }

            @Override
            public void onClick(@NonNull View widget) {
                switch (clickableTextType) {

                    case WHERE_IS_IT:
                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHOOSER_SCREEN_WHERE_IS_MY_PIN);
                        bottomSheetDialog.show();
                        break;
                    case IDNOW_HOME_PAGE:
                    case TERMS_OF_SERVICE:
                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHOOSER_SCREEN_TERMS_OF_SERVICE);
                    case PRIVACY_POLICY:
                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_PIN_CHOOSER_SCREEN_PRIVACY_POLICY);
                        if (url != null) {
                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                            try {
                                context.startActivity(browserIntent);
                            } catch (Exception e) {
                                Util_Log.e(LOGTAG, "Open link failed", e);
                                Toast.makeText(context, "Cannot open link!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
        };

        spannable.setSpan(clickableSpan, 0, spannable.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        spannable.setSpan(new ForegroundColorSpan(color), 0, spannable.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        return spannable;
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_PIN_digit_chooser.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_PIN_digit_chooser.class);
    }

    private void enableContinueButton(boolean shouldEnable) {
        button_continue_digit_pin.setEnabled(shouldEnable);
        Util.setProceedButtonBackgroundSelector(button_continue_digit_pin);
    }

    /**
     * check the runtime permissions
     */
    @TargetApi(23)
    private void checkForRuntimePermissions() {
        List<String> permissionsNeeded = new ArrayList<String>();

        final List<String> permissionsList = new ArrayList<String>();
        if (!addPermission(permissionsList, Manifest.permission.CAMERA)) {
            permissionsNeeded.add(getResources().getString(R.string.permission_camera));
        }

        if (permissionsList.size() > 0) {
            requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), REQUEST_CODE_ASK_PERMISSIONS);
            return;
        }
        redirection();
    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_PERMISSIONS: {

                Map<String, Integer> perms = new HashMap<String, Integer>();
                // Initial
                perms.put(Manifest.permission.CAMERA, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.RECORD_AUDIO, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.RECEIVE_SMS, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.MANAGE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);

                // Fill with results
                for (int i = 0; i < permissions.length; i++) {
                    perms.put(permissions[i], grantResults[i]);
                }
                // Check for ACCESS_FINE_LOCATION
                if (perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    redirection();
                } else {
                    // Permission Denied
                    Util.showMessageOK(context, getResources().getString(R.string.permission_failed_continue), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions((eIDActivity) context, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_CODE_ASK_PERMISSIONS);

                        }
                    });
                    return;
                }
            }
            break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    public void redirection() {
        if (progress != null) {
            progress.setVisibility(View.GONE);
        }

        if (checkbox_eid_5_digit_pin.isChecked()) {
            Config.EID_PIN_CHOOSER = Util_Strings.FIVE_DIGIT_PIN;
        } else if (checkbox_eid_6_digit_pin.isChecked()) {
            Config.EID_PIN_CHOOSER = Util_Strings.SIX_DIGIT_PIN;
        }
        if (eIDSdk.getEIDTSP().equals("Governikus")) {
            if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                button_continue_digit_pin.setEnabled(false);
                progress.setVisibility(View.VISIBLE);
                IdentificationManager.INSTANCE.startIdent(EXTRA_TC_TOKEN_URL);

                Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;

            } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                redirectUser();
                Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_5_DIGIT_PIN;
            }
        } else {
            Fragment_Capture_Desc fragment_capture_desc = new Fragment_Capture_Desc();
            ((eIDActivity) context).hideIntroFragment(Fragment_PIN_digit_chooser.this);
            ((eIDActivity) context).showIntroFragment(fragment_capture_desc);
        }

    }

    public void updateTCTokenURL() throws IOException, JSONException {

        OkHttpClient client = new OkHttpClient();

        String endPoint = eIDSdk.getIDnowSDKEndpoint();
        String companyShortName = eIDSdk.getCompanyId();
        String transactionToken = eIDSdk.getTransactionToken();
        endPoint = endPoint + "/api/v1/" + companyShortName + "/eid/" + transactionToken + "/startEid";

        String language = eIDSdk.getModels_clientInfoLanguage();

        JSONObject object = new JSONObject();
        JSONObject obj = new JSONObject();

        obj.put("language", language);
        object.put("clientInfo", obj);

        MediaType JSON = MediaType.parse(Util_Strings.LOGIN_CONTENT_TYPE);
        RequestBody body = RequestBody.create(JSON, String.valueOf(object));

        Util_Log.i(LOGTAG, "Get mobile token and session token API : " + endPoint);

        Request request = new Request.Builder()
                .url(endPoint)
                .post(body)
                .build();
        Call response = null;

        response = client.newCall(request);

        response.enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

                Util_Log.i(LOGTAG, "Failure request");
                // ((eIDActivity) context).errorEIDscreen( Fragment_VerificationStatus.this, CALLBACK_IDENT_FAILED);

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Util_Log.i(LOGTAG, "Success request: " + response.code() + " " + response.isSuccessful());
                if ((response.isSuccessful()) && (!Config.EID_VID_TOKEN_FINISEHD)) {
                    if (response.body() != null) {
                        try {
                            Gson gson = new Gson();
                            String jSonString = response.body().string();
                            gson.fromJson(jSonString, Object.class);
                            JsonObject jsonObject = new JsonParser().parse(jSonString).getAsJsonObject();
                            // EID_MOBILE_TOKEN = jsonObject.get("mobileToken").getAsString();
                            // Config.EID_SESSION_TOKEN = jsonObject.get("sessionToken").getAsString();
                            Config.EID_SIGNATURE = jsonObject.get("request").getAsJsonObject().get("Identification-Signature").getAsString();
                            EXTRA_TC_TOKEN_URL = jsonObject.get("tcTokenUrl").getAsString();
                            Config.EID_ID_IMAGES_CAPTURED = false;
                            IdentificationManager.INSTANCE.startIdent(EXTRA_TC_TOKEN_URL);
                            Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;


                        } catch (Exception e) {
                            Util_Log.e(LOGTAG, "Parse start response failed", e);
                            // ((eIDActivity)context).errorEIDscreen(Fragment_VerificationStatus.this, CALLBACK_IDENT_FAILED);
                        }
                    } else {
                        // ((eIDActivity) context).errorEIDscreen( Fragment_VerificationStatus.this, CALLBACK_IDENT_FAILED);
                    }
                } else {
                    //  ((eIDActivity) context).errorEIDscreen( Fragment_VerificationStatus.this, CALLBACK_IDENT_FAILED);
                }
            }
        });

    }


    public void flowChooser() throws JSONException, IOException {
        if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
            updateTCTokenURL();
        } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
            Fragment_EnterPin_6_digit.getInstance().redirectionUser();
            Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_5_DIGIT_PIN;
        }
    }

    @TargetApi(23)
    private boolean addPermission(List<String> permissionsList, String permission) {
        if (context.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(permission);
            // Check for Rationale Option
            return shouldShowRequestPermissionRationale(permission);
        }
        return true;
    }

    private void requestPermission() {
        if (SDK_INT >= Build.VERSION_CODES.R) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.addCategory("android.intent.category.DEFAULT");
                intent.setData(Uri.parse(String.format("package:%s", context.getApplicationContext().getPackageName())));
                startActivityForResult(intent, 2296);
            } catch (Exception e) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivityForResult(intent, 2296);
            }
        } else {
            //below android 11
            ActivityCompat.requestPermissions((eIDActivity) context, new String[]{WRITE_EXTERNAL_STORAGE}, REQUEST_CODE_ASK_PERMISSIONS);
        }
    }

    public void redirectUser() {
        getActivity().runOnUiThread(new Runnable() {
            public void run() {
                Fragment_Capture_Desc fragment_capture_desc = new Fragment_Capture_Desc();
                ((eIDActivity) context).hideIntroFragment(Fragment_PIN_digit_chooser.this);
                ((eIDActivity) context).showIntroFragment(fragment_capture_desc);

            }
        });
    }

    public void redirectScanning() {
        getActivity().runOnUiThread(new Runnable() {
            public void run() {
                Fragment_HoldIDBack fragmentHoldIDBack = new Fragment_HoldIDBack();
                ((eIDActivity) context).hideIntroFragment(Fragment_PIN_digit_chooser.this);
                ((eIDActivity) context).showIntroFragment(fragmentHoldIDBack);

            }
        });
    }

    public static Fragment_PIN_digit_chooser getInstance() {

        return instance;
    }
}