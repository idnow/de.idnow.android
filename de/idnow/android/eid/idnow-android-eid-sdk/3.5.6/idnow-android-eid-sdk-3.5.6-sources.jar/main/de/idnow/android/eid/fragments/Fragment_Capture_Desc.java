package de.idnow.android.eid.fragments;

import static de.idnow.android.eid.Config.DOCUMENT_INFO;
import static de.idnow.android.eid.Config.ISSUER_URL;
import static de.idnow.android.eid.Config.VALIDITY_DATE;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.Objects;

import de.idnow.android.eid.AusweisApp2SDK.core.IdentificationManager;
import de.idnow.android.eid.Config;
import de.idnow.android.eid.R;
import de.idnow.android.eid.UI.HeaderView;
import de.idnow.android.eid.UI.SubtitleView;
import de.idnow.android.eid.eIDActivity;
import de.idnow.android.eid.eIDSdk;
import de.idnow.android.eid.util.Util;
import de.idnow.android.eid.util.Util_Log;
import de.idnow.android.eid.util.Util_Strings;
import kotlin.Unit;

public class Fragment_Capture_Desc extends BaseFragment {
    private final String LOGTAG = "IDNOW_Fragment_Capture_Desc";

    HeaderView header;

    LottieAnimationView capture1_animation, capture2_animation, capture3_animation, capture4_animation;

    TextView step1_title, step2_title, step3_title, step1_desc1, step1_desc2, step2_desc1, step2_desc2, step3_desc1, step3_desc2, step4_title, step4_desc1, step4_desc2,
            quit_pin_change_title,
            quit_pin_change_description,
            quit_pin_change_quit_button,
            quit_pin_change_continue_button,
            quit_pin_change_try_another_method_button;

    Button bancaccount_start;

    LinearLayout eid_step1_layout, eid_step2_layout, eid_step3_layout, eid_step4_layout;

    Dialog quitDialog;

    Context context;

    SubtitleView subtitle;

    public TextView bottom_sheet_learn_more_desc1,
            bottom_sheet_learn_more_desc2,
            bottom_sheet_learn_more_desc3,
            bottom_sheet_learn_more_desc4,
            bottom_sheet_learn_more_dt,
            bottom_sheet_learn_more_st,
            bottom_sheet_learn_more_fn,
            bottom_sheet_learn_more_fan,
            bottom_sheet_learn_more_dob,
            bottom_sheet_learn_more_pob,
            bottom_sheet_learn_more_na,
            bottom_sheet_learn_more_ad,
            bottom_sheet_learn_more_bn,
            bottom_sheet_learn_more_dd,
            bottom_sheet_learn_more_ic,
            bottom_sheet_learn_more_gn,
            bottom_sheet_learn_more_ps,
            bottom_sheet_learn_more_vu,
            bottom_sheet_learn_more_provider_title,
            bottom_sheet_learn_more_provider,
            bottom_sheet_learn_more_url_title,
            bottom_sheet_learn_more_url,
            bottom_sheet_learn_more_val_title,
            bottom_sheet_learn_more_val,
            bottom_sheet_learn_more_usage_title,
            bottom_sheet_learn_more_usage;

    private BottomSheetDialog bottomSheetLearnMore;

    private ImageButton bottom_sheet_learn_more_cancel_cross;

    public enum ClickableTextType {
        LEARN_MORE,
        IDNOW_HOME_PAGE,
    }

    public static Fragment_Capture_Desc instance;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_capture_descriptions, container, false);

        context = getContext();

        instance = this;

        header = view.findViewById(R.id.header);
        subtitle = view.findViewById(R.id.subtitle);

        eid_step1_layout = view.findViewById(R.id.eid_step1_layout);
        capture1_animation = view.findViewById(R.id.capture1_animation);
        step1_title = view.findViewById(R.id.step1_title);
        step1_desc1 = view.findViewById(R.id.step1_desc1);
        step1_desc2 = view.findViewById(R.id.step1_desc2);

        eid_step2_layout = view.findViewById(R.id.eid_step2_layout);
        capture2_animation = view.findViewById(R.id.capture2_animation);
        step2_title = view.findViewById(R.id.step2_title);
        step2_desc1 = view.findViewById(R.id.step2_desc1);
        step2_desc2 = view.findViewById(R.id.step2_desc2);

        eid_step3_layout = view.findViewById(R.id.eid_step3_layout);
        capture3_animation = view.findViewById(R.id.capture3_animation);
        step3_title = view.findViewById(R.id.step3_title);
        step3_desc1 = view.findViewById(R.id.step3_desc1);
        step3_desc2 = view.findViewById(R.id.step3_desc2);

        eid_step4_layout = view.findViewById(R.id.eid_step4_layout);
        capture4_animation = view.findViewById(R.id.capture4_animation);
        step4_title = view.findViewById(R.id.step4_title);
        step4_desc1 = view.findViewById(R.id.step4_desc1);
        step4_desc2 = view.findViewById(R.id.step4_desc2);

        eid_step1_layout.setVisibility(View.VISIBLE);
        eid_step2_layout.setVisibility(View.VISIBLE);
        eid_step3_layout.setVisibility(View.VISIBLE);


        bancaccount_start = view.findViewById(R.id.bancaccount_start);
        bancaccount_start.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BUTTON_CONTINUE, Util_Strings.LOCAL_EID_BUTTON_CONTINUE));

        if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {

            eIDSdk.recordEvent(eIDSdk.EVENT_EID_VERIFICATION_STEP_SCREEN_SHOWN);
            eIDSdk.startEvent(eIDSdk.EVENT_EID_VERIFICATION_STEP_SCREEN_TIME_SPENT);

            header.setTitle(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BEFORE_START_STEP_VERIFICATION_TITLE, Util_Strings.LOCAL_KEY_EID_BEFORE_START_STEP_VERIFICATION_TITLE));

            subtitle.setVisibility(View.VISIBLE);
            subtitle.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_STEPS_VERIFICATION_DESCRIPTION, Util_Strings.LOCAL_KEY_EID_STEPS_VERIFICATION_DESCRIPTION));
            subtitle.append("\n");
            subtitle.append(makeClickableSpan(context, Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_PIN_5_DIGIT_LEARN_MORE, Util_Strings.LOCAL_KEY_EID_PIN_5_DIGIT_LEARN_MORE), getResources().getColor(R.color.text_color_link), null, ClickableTextType.LEARN_MORE));
            subtitle.setMovementMethod(LinkMovementMethod.getInstance());

            if (eIDSdk.shouldCaptureIdImages()) {

                step1_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP1, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP1));
                step1_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFICATION_STEPS_PHOTO_TITLE, Util_Strings.LOCAL_KEY_EID_VERIFICATION_STEPS_PHOTO_TITLE));
                step1_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFICATION_STEPS_PHOTO_DESC, Util_Strings.LOCAL_KEY_EID_VERIFICATION_STEPS_PHOTO_DESC));

                step2_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP2, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP2));
                step2_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFICATION_STEPS_6_DIGIT_TITLE, Util_Strings.LOCAL_KEY_EID_VERIFICATION_STEPS_6_DIGIT_TITLE));
                step2_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFICATION_STEPS_6_DIGIT_DESC, Util_Strings.LOCAL_KEY_EID_VERIFICATION_STEPS_6_DIGIT_DESC));

                step3_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP3, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP3));
                step3_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFICATION_STEPS_SCAN_TITLE, Util_Strings.LOCAL_KEY_EID_VERIFICATION_STEPS_SCAN_TITLE));
                step3_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFICATION_STEPS_SCAN_DESC, Util_Strings.LOCAL_KEY_EID_VERIFICATION_STEPS_SCAN_DESC));


                capture1_animation.setAnimation("static_step_id_photo.json");
                capture2_animation.setAnimation("static_step_enter_5_pin.json");
                capture3_animation.setAnimation("static_step_nfc_card.json");

                Util.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.capture_animation)), capture1_animation, "Primary");
                Util.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.capture_animation)), capture2_animation, "Primary");
                Util.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.capture_animation)), capture3_animation, "Primary");

                if (eIDSdk.getEnableEIDQES()) {
                    eid_step4_layout.setVisibility(View.VISIBLE);
                    capture4_animation.setAnimation("static_phone_verify.json");
                    Util.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.capture_animation)), capture4_animation, "Primary");
                    step4_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4));
                    if (Config.DISPLAY_OTP_SIGNING) {
                        step4_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_TITTLE, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_TITLE));
                        step4_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_DESC, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_DESC));
                    } else {
                        step4_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_NOOTP_TITTLE, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_TITLE));
                        step4_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_NOOTP_DESC, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_DESC));
                    }
                }

            } else {

                eid_step1_layout.setVisibility(View.GONE);
                eid_step2_layout.setVisibility(View.VISIBLE);
                eid_step3_layout.setVisibility(View.VISIBLE);


                step2_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP1, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP1));
                step2_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFICATION_STEPS_6_DIGIT_TITLE, Util_Strings.LOCAL_KEY_EID_VERIFICATION_STEPS_6_DIGIT_TITLE));
                step2_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFICATION_STEPS_6_DIGIT_DESC, Util_Strings.LOCAL_KEY_EID_VERIFICATION_STEPS_6_DIGIT_DESC));

                step3_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP2, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP2));
                step3_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFICATION_STEPS_SCAN_TITLE, Util_Strings.LOCAL_KEY_EID_VERIFICATION_STEPS_SCAN_TITLE));
                step3_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_VERIFICATION_STEPS_SCAN_DESC, Util_Strings.LOCAL_KEY_EID_VERIFICATION_STEPS_SCAN_DESC));

                capture2_animation.setAnimation("static_step_enter_5_pin.json");
                capture3_animation.setAnimation("static_step_nfc_card.json");

                if (eIDSdk.getEnableEIDQES()) {
                    eid_step4_layout.setVisibility(View.VISIBLE);
                    capture4_animation.setAnimation("static_phone_verify.json");
                    Util.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.capture_animation)), capture4_animation, "Primary");
                    step4_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP3, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP3));
                    if (Config.DISPLAY_OTP_SIGNING) {
                        step4_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_TITTLE, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_TITLE));
                        step4_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_DESC, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_DESC));
                    } else {
                        step4_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_NOOTP_TITTLE, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_TITLE));
                        step4_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_NOOTP_DESC, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_DESC));
                    }
                } else {
                    eid_step4_layout.setVisibility(View.GONE);
                }
            }

        } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {

            eIDSdk.recordEvent(eIDSdk.EVENT_EID_ACTIVATION_STEPS_SCREEN_SHOWN);
            eIDSdk.startEvent(eIDSdk.EVENT_EID_ACTIVATION_STEPS_SCREEN_TIME_SPENT);

            subtitle.setVisibility(View.GONE);

            header.setTitle(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_BEFORE_START_STEP_ACTIVATION_TITLE, Util_Strings.LOCAL_KEY_EID_BEFORE_START_STEP_ACTIVATION_TITLE));

            eid_step1_layout.setVisibility(View.VISIBLE);
            eid_step2_layout.setVisibility(View.VISIBLE);
            eid_step3_layout.setVisibility(View.VISIBLE);

            step1_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP1, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP1));
            step1_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_STEPS_ENTER_5_DIGIT_TITLE, Util_Strings.LOCAL_KEY_EID_STEPS_ENTER_5_DIGIT_TITLE));
            step1_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_STEPS_ENTER_5_DIGIT_DESC, Util_Strings.LOCAL_KEY_EID_STEPS_ENTER_5_DIGIT_DESC));

            step2_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP2, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP2));
            step2_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_STEPS_CREATE_6_DIGIT_TITLE, Util_Strings.LOCAL_KEY_EID_STEPS_CREATE_6_DIGIT_TITLE));
            step2_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_STEPS_CREATE_6_DIGIT_DESC, Util_Strings.LOCAL_KEY_EID_STEPS_CREATE_6_DIGIT_DESC));

            step3_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP3, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP3));
            step3_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_STEPS_SCAN_TITLE, Util_Strings.LOCAL_KEY_EID_STEPS_SCAN_TITLE));
            step3_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_STEPS_SCAN_DESC, Util_Strings.LOCAL_KEY_EID_STEPS_SCAN_DESC));

            capture1_animation.setAnimation("static_step_enter_5_pin.json");
            capture2_animation.setAnimation("static_step_enter_6_pin.json");
            capture3_animation.setAnimation("static_step_nfc_card.json");

            Util.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.capture_animation)), capture1_animation, "Primary");
            Util.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.capture_animation)), capture2_animation, "Primary");
            Util.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.capture_animation)), capture3_animation, "Primary");

            if (eIDSdk.getEnableEIDQES()) {
                eid_step4_layout.setVisibility(View.VISIBLE);
                capture4_animation.setAnimation("static_phone_verify.json");
                Util.setColorLottieAnimation(Color.parseColor(getResources().getString(R.color.capture_animation)), capture4_animation, "Primary");
                step4_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4));
                if (Config.DISPLAY_OTP_SIGNING) {
                    step4_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_TITTLE, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_TITLE));
                    step4_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_DESC, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_DESC));
                } else {
                    step4_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_NOOTP_TITTLE, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_TITLE));
                    step4_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_CAPTURE_STEP4_NOOTP_DESC, Util_Strings.LOCAL_KEY_EID_CAPTURE_STEP4_DESC));
                }
            }
        }

        bancaccount_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eIDSdk.getEIDTSP().equals("Governikus")) {
                    if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                        Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_5_DIGIT_PIN;
                        Config.CURRENT_FRAGMENT = ((eIDActivity) context).getCurrentFragment();
                        IdentificationManager.INSTANCE.changePin();
                    } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                        if (eIDSdk.shouldCaptureIdImages()) {
                            Fragment_Capture fragment_capture = new Fragment_Capture();
                            ((eIDActivity) getActivity()).hideIntroFragment(Fragment_Capture_Desc.this);
                            ((eIDActivity) getActivity()).showIntroFragment(fragment_capture);
                        } else {
                            Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                            Config.CURRENT_FRAGMENT = ((eIDActivity) context).getCurrentFragment();
                            IdentificationManager.INSTANCE.requestAcceptRights();
                        }
                    }
                } else {
                    if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {

                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_VERIFICATION_STEP_CONTINUE);

                        if (eIDSdk.shouldCaptureIdImages()) {
                            Fragment_Capture fragment_capture = new Fragment_Capture();
                            ((eIDActivity) context).hideIntroFragment(Fragment_Capture_Desc.this);
                            ((eIDActivity) context).showIntroFragment(fragment_capture);
                        } else {
                            Config.DIGIT_SCREEN_TO_SHOW = Util.PinScreens.SCREEN_ENTER_PERSONAL_6_DIGIT_PIN;
                            Fragment_EnterPin_6_digit fragmentEnterPin = new Fragment_EnterPin_6_digit();
                            ((eIDActivity) context).hideIntroFragment(Fragment_Capture_Desc.this);
                            ((eIDActivity) context).showIntroFragment(fragmentEnterPin);
                        }
                    } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_ACTIVATION_STEPS_SCREEN_CONTINUE);

                        Fragment_EnterPin_5_digit fragmentEnterPin5Digit = new Fragment_EnterPin_5_digit();
                        ((eIDActivity) context).hideIntroFragment(Fragment_Capture_Desc.this);
                        ((eIDActivity) context).showIntroFragment(fragmentEnterPin5Digit);
                    }
                }
            }
        });

        header.setCancelAction(() -> {
            Config.CANCEL_REASON = "EID_USER_CANCELLATION_VERIFICATION_STEPS";
            if (Config.EID_PIN_CHOOSER.equals(Util_Strings.SIX_DIGIT_PIN)) {
                eIDSdk.recordEvent(eIDSdk.EVENT_EID_VERIFICATION_STEP_CROSS);
            } else if (Config.EID_PIN_CHOOSER.equals(Util_Strings.FIVE_DIGIT_PIN)) {
                eIDSdk.recordEvent(eIDSdk.EVENT_EID_ACTIVATION_STEPS_SCREEN_CROSS);
            }
            ((eIDActivity) context).getVisibleFragment();
            return Unit.INSTANCE;
        });

        return view;
    }

    public void quitDialog(Context context) {

        quitDialog = new Dialog(context);

        quitDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        quitDialog.setContentView(R.layout.quit_pin_change_dialog);

        loadQuitDialog(quitDialog);

        int width = ViewGroup.LayoutParams.WRAP_CONTENT;
        int height = ViewGroup.LayoutParams.WRAP_CONTENT;
        quitDialog.getWindow().setLayout(width, height);
        quitDialog.setCancelable(false);
        quitDialog.show();

    }

    public void loadQuitDialog(Dialog dialog) {

        quit_pin_change_title = dialog.findViewById(R.id.quit_pin_change_title);
        quit_pin_change_description = dialog.findViewById(R.id.quit_pin_change_description);
        quit_pin_change_quit_button = dialog.findViewById(R.id.quit_pin_change_quit_button);
        quit_pin_change_continue_button = dialog.findViewById(R.id.quit_pin_change_continue_button);
        quit_pin_change_try_another_method_button = dialog.findViewById(R.id.quit_pin_change_try_another_method_button);

        quit_pin_change_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_TITLE, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_TITLE));
        quit_pin_change_description.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_DESCRIPTION, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_DESCRIPTION));
        quit_pin_change_quit_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_QUIT, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_QUIT));
        quit_pin_change_continue_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_CONTINUE, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_CONTINUE));
        quit_pin_change_try_another_method_button.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_QUIT_DIALOG_TRY_ANOTHER_METHOD, Util_Strings.LOCAL_KEY_EID_QUIT_DIALOG_TRY_ANOTHER_METHOD));

        if (Config.STANDALONE_EID) {
            quit_pin_change_try_another_method_button.setVisibility(View.GONE);
            quit_pin_change_description.setVisibility(View.GONE);
        }

        quit_pin_change_quit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quitDialog.dismiss();
                goToIdentIDPage();
            }
        });

        quit_pin_change_try_another_method_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quitDialog.dismiss();
                Util.redirection(context, Config.CHOOSER_SCREEN);
            }
        });
        quit_pin_change_continue_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

    }

    public void loadMeInformationLayout(final Context context) {

        View bottomSheetContentView = getLayoutInflater().inflate(R.layout.bottom_sheet_learn_more_card_read_info, null);
        bottomSheetLearnMore = new BottomSheetDialog(context, R.style.BottomSheetDialog);
        bottomSheetLearnMore.setContentView(bottomSheetContentView);
        bottomSheetLearnMore.setCancelable(true);

        bottom_sheet_learn_more_cancel_cross = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_cancel_cross);
        bottom_sheet_learn_more_desc1 = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_desc1);
        bottom_sheet_learn_more_desc2 = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_desc2);
        bottom_sheet_learn_more_desc3 = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_desc3);
        bottom_sheet_learn_more_desc4 = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_desc4);
        bottom_sheet_learn_more_ad = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_ad);
        bottom_sheet_learn_more_bn = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_bn);
        bottom_sheet_learn_more_na = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_na);
        bottom_sheet_learn_more_pob = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_pob);
        bottom_sheet_learn_more_dob = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_dob);
        bottom_sheet_learn_more_dd = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_dd);
        bottom_sheet_learn_more_fan = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_fn);
        bottom_sheet_learn_more_gn = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_gn);
        bottom_sheet_learn_more_vu = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_vu);
        bottom_sheet_learn_more_ic = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_ic);
        bottom_sheet_learn_more_dt = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_dt);
        bottom_sheet_learn_more_ps = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_ps);

        bottom_sheet_learn_more_provider_title = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_provider_title);
        bottom_sheet_learn_more_provider = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_provider);
        bottom_sheet_learn_more_url_title = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_url_title);
        bottom_sheet_learn_more_url = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_url);
        bottom_sheet_learn_more_val_title = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_val_title);
        bottom_sheet_learn_more_val = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_val);
        bottom_sheet_learn_more_usage_title = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_usage_title);
        bottom_sheet_learn_more_usage = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_usage);

        bottom_sheet_learn_more_cancel_cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetLearnMore.dismiss();
            }
        });


        bottom_sheet_learn_more_desc1 = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_desc1);
        bottom_sheet_learn_more_desc2 = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_desc2);
        bottom_sheet_learn_more_desc3 = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_desc3);
        bottom_sheet_learn_more_desc4 = bottomSheetContentView.findViewById(R.id.bottom_sheet_learn_more_desc4);

        if (eIDSdk.getEIDTSP().equals("Governikus")) {
            for (String item : DOCUMENT_INFO) {

                switch (item.replaceAll("\\s", "").
                        replace("(", "").
                        replace(")", "").
                        replace("\"", "")) {
                    case "Address":
                        bottom_sheet_learn_more_ad.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_ADDRESS, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_ADDRESS));
                        break;

                    case "BirthName":
                        bottom_sheet_learn_more_bn.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_BIRTHNAME, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_BIRTHNAME));
                        break;

                    case "Nationality":
                        bottom_sheet_learn_more_na.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_NATIONALITY, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_NATIONALITY));
                        break;

                    case "PlaceOfBirth":
                        bottom_sheet_learn_more_pob.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_PLACEOFBIRTH, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_PLACEOFBIRTH));
                        break;

                    case "DateOfBirth":
                        bottom_sheet_learn_more_dob.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_DATEOFBIRTH, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_DATEOFBIRTH));
                        break;

                    case "DoctoralDegree":
                        bottom_sheet_learn_more_dd.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_DOCTORALDEGREE, Util_Strings.LOCAL_KEY_EID_ID_MORE_INFO_PAGE_DOCTORALDEGREE));
                        break;

                    case "FamilyName":
                        bottom_sheet_learn_more_fan.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_FAMILYNAME, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_FAMILYNAME));
                        break;

                    case "GivenNames":
                        bottom_sheet_learn_more_gn.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_GIVENNAMES, Util_Strings.LOCAL_KEY_EID_ID_MORE_INFO_PAGE_GIVENNAMES));
                        break;

                    case "ValidUntil":
                        bottom_sheet_learn_more_vu.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_VALIDUNTIL, Util_Strings.LOCAL_KEY_EID_ID_MORE_INFO_PAGE_VALIDUNTIL));
                        break;

                    case "IssuingCountry":
                        bottom_sheet_learn_more_ic.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_ISSUINGCOUNTRY, Util_Strings.LOCAL_KEY_EID_ID_MORE_INFO_PAGE_ISSUINGCOUNTRY));
                        break;

                    case "DocumentType":
                        bottom_sheet_learn_more_dt.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_DOCUMENTTYPE, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_DOCUMENTTYPE));
                        break;

                    case "Pseudonym":
                        bottom_sheet_learn_more_ps.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_PSEUDONYM, Util_Strings.LOCAL_KEY_EID_ID_MORE_INFO_PAGE_PSEUDONYM));
                        break;
                    default:
                        if (!item.equals("Birthname")) {
                            bottom_sheet_learn_more_gn.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_GIVENNAMES, Util_Strings.LOCAL_KEY_EID_ID_MORE_INFO_PAGE_GIVENNAMES));
                        }
                }
            }
        } else if (DOCUMENT_INFO.size() >= 11) {
            bottom_sheet_learn_more_ps.setText(DOCUMENT_INFO.get(0).replace("\"", ""));  // 0 = "Pseudonym"
            bottom_sheet_learn_more_dt.setText(DOCUMENT_INFO.get(1).replace("\"", ""));  // 1 = "Dokumentenart"
            bottom_sheet_learn_more_vu.setText(DOCUMENT_INFO.get(2).replace("\"", ""));  // 2 = ""Gültig bis""
            bottom_sheet_learn_more_gn.setText(DOCUMENT_INFO.get(3).replace("\"", ""));  // 3 = "Vorname(n)"
            bottom_sheet_learn_more_fan.setText(DOCUMENT_INFO.get(4).replace("\"", "")); // 4 = "Familienname"
            bottom_sheet_learn_more_dd.setText(DOCUMENT_INFO.get(5).replace("\"", ""));  // 5 = "Doktorgrad"
            bottom_sheet_learn_more_dob.setText(DOCUMENT_INFO.get(6).replace("\"", "")); // 6 = "Geburtsdatum"
            bottom_sheet_learn_more_pob.setText(DOCUMENT_INFO.get(7).replace("\"", "")); // 7 = "Geburtsort"
            bottom_sheet_learn_more_na.setText(DOCUMENT_INFO.get(8).replace("\"", ""));  // 8 = "Staatsangehörigkeit"
            bottom_sheet_learn_more_bn.setText(DOCUMENT_INFO.get(9).replace("\"", ""));  // 9 = "Geburtsname"
            bottom_sheet_learn_more_ad.setText(DOCUMENT_INFO.get(10).replace("\"", "")); // 10 = "Anschrift"
        }

        bottom_sheet_learn_more_desc1.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_SECURITY_PAGE_DESC2, Util_Strings.LOCAL_EID_SECURITY_PAGE_DESC2));
        bottom_sheet_learn_more_desc2.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_SECURITY_PAGE_DESC3, Util_Strings.LOCAL_EID_SECURITY_PAGE_DESC3));
        bottom_sheet_learn_more_desc3.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_SECURITY_PAGE_DESC4, Util_Strings.LOCAL_EID_SECURITY_PAGE_DESC4));
        bottom_sheet_learn_more_desc4.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_DISCRIPTION, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_DISCRIPTION));

        bottom_sheet_learn_more_provider_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_PROVIDER, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_PROVIDER));
        bottom_sheet_learn_more_provider.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_IDNOW, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_IDNOW));
        bottom_sheet_learn_more_url_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_PROVIDERURL, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_PROVIDERURL));
        bottom_sheet_learn_more_val_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_IDNOWVALIDITY, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_IDNOWVALIDITY));
        bottom_sheet_learn_more_usage_title.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_USAGE, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_USAGE));
        bottom_sheet_learn_more_usage.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_BUSINESS_REASON, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_BUSINESS_REASON));

        if (VALIDITY_DATE.equals(null)) {
            bottom_sheet_learn_more_val.setText("Could not retrieve DATE");
        } else {
            bottom_sheet_learn_more_val.setText(VALIDITY_DATE);
        }

        if (ISSUER_URL.equals(null)) {
            bottom_sheet_learn_more_url.setText(Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_IDNOWURL, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_IDNOWURL));
            bottom_sheet_learn_more_url.append(makeClickableSpan(context, Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_IDNOWURL, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_IDNOWURL), getResources().getColor(R.color.text_color_link), Util_Strings.getStringWithDefault(context.getApplicationContext(), Util_Strings.KEY_EID_ID_MORE_INFO_PAGE_IDNOWURL, Util_Strings.LOCAL_EID_ID_MORE_INFO_PAGE_IDNOWURL), ClickableTextType.IDNOW_HOME_PAGE));
            bottom_sheet_learn_more_url.setMovementMethod(LinkMovementMethod.getInstance());
        } else {
            if (!ISSUER_URL.equals(null)) {
                SpannableString spannableString = new SpannableString(ISSUER_URL);
                ClickableSpan clickableSpan = new ClickableSpan() {
                    @Override
                    public void onClick(View widget) {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(ISSUER_URL));
                        startActivity(browserIntent);
                    }
                };
                spannableString.setSpan(clickableSpan, 0, ISSUER_URL.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

                bottom_sheet_learn_more_url.setText(spannableString);
                bottom_sheet_learn_more_url.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
            }
        }

        bottomSheetLearnMore.show();
    }

    private Spannable makeClickableSpan(Context context, CharSequence text, int color, String url, ClickableTextType clickableTextType) {

        Spannable spannable = new SpannableString(text);

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {

                switch (clickableTextType) {
                    case LEARN_MORE:
                        eIDSdk.recordEvent(eIDSdk.EVENT_EID_VERIFICATION_STEP_LEARN_MORE);
                        loadMeInformationLayout(context);
                        break;
                    case IDNOW_HOME_PAGE:
                        if (url != null) {
                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                            try {
                                context.startActivity(browserIntent);
                            } catch (Exception e) {
                                Util_Log.e(LOGTAG, "Open link failed", e);
                                Toast.makeText(context, "Cannot open link!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
        };

        spannable.setSpan(clickableSpan, 0, spannable.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        spannable.setSpan(new ForegroundColorSpan(color), 0, spannable.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        return spannable;

    }

    public void goToIdentIDPage() {

        Intent backPressedIntent = new Intent();
        backPressedIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        backPressedIntent.putExtra(Config.RESULT_DATA_ERROR, "User abort identification");
        backPressedIntent.putExtra(Config.RESULT_DATA_TRANSACTION_TOKEN, eIDSdk.getTransactionToken());
        Objects.requireNonNull(getActivity()).setResult(Config.RESULT_CODE_CANCEL, getActivity().getIntent());
        getActivity().finish();
    }

    public static void showMe(eIDActivity activity) {
        IDnowFragmentManager.showFragment(activity, Fragment_Capture_Desc.class);
    }

    public static void hideMe(eIDActivity activity) {
        IDnowFragmentManager.hideFragment(activity, Fragment_Capture_Desc.class);
    }

    public static Fragment_Capture_Desc getInstance() {

        return instance;
    }

    public void redirection() {
        Util_Log.d("IdentSdk", "redirection FRAGMENT CAPTURE 222");

        getActivity().runOnUiThread(new Runnable() {
            @SuppressLint("UseRequireInsteadOfGet")
            public void run() {

                Util_Log.d("IdentSdk", "redirection FRAGMENT CAPTURE");

                eIDSdk.recordEvent(eIDSdk.EVENT_EID_VERIFICATION_STEP_CONTINUE);

                Fragment_HoldIDBack fragment_holdIDBack = new Fragment_HoldIDBack();
                ((eIDActivity) getActivity()).hideIntroFragment(Fragment_Capture_Desc.this);
                ((eIDActivity) getActivity()).showIntroFragment(fragment_holdIDBack);

            }
        });
    }
}
